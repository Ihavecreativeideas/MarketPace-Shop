# MarketPace Setup Guide

## Step 1: Download/Clone the Code

### Option A: From Famous.AI Dashboard
1. Go to your Famous.AI dashboard
2. Find your MarketPace project
3. Look for download/export option
4. Download the complete codebase

### Option B: From Git Repository
```bash
git clone [your-repository-url]
cd marketpace
```

## Step 2: Install Dependencies

```bash
# Install Node.js dependencies
npm install

# Or if you prefer yarn
yarn install
```

## Step 3: Set Up Supabase Backend

### Create Supabase Project
1. Go to [supabase.com](https://supabase.com)
2. Create a new account or sign in
3. Click "New Project"
4. Choose organization and fill project details
5. Wait for project to be ready (2-3 minutes)

### Get Your Credentials
1. In your Supabase dashboard, go to Settings > API
2. Copy your:
   - Project URL
   - `anon` `public` key

### Configure Environment Variables
1. Copy `.env.example` to `.env.local`:
   ```bash
   cp .env.example .env.local
   ```
2. Edit `.env.local` with your credentials:
   ```env
   REACT_APP_SUPABASE_URL=https://your-project-id.supabase.co
   REACT_APP_SUPABASE_ANON_KEY=your-actual-anon-key
   ```

## Step 4: Set Up Database Schema

### Option A: SQL Editor (Recommended)
1. In Supabase dashboard, go to SQL Editor
2. Create the following tables:

```sql
-- Users table
CREATE TABLE users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Products table
CREATE TABLE products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10,2),
  image_url TEXT,
  seller_id UUID REFERENCES users(id),
  category TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Orders table
CREATE TABLE orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  buyer_id UUID REFERENCES users(id),
  seller_id UUID REFERENCES users(id),
  product_id UUID REFERENCES products(id),
  status TEXT DEFAULT 'pending',
  total DECIMAL(10,2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add more tables as needed...
```

### Option B: Import from Existing
If you have access to the original database:
1. Export schema from original Supabase project
2. Import into your new project

## Step 5: Start Development

```bash
# Start the development server
npm run dev

# Or with yarn
yarn dev
```

The app will be available at [http://localhost:5173](http://localhost:5173)

## Step 6: Build for Production

```bash
# Build the app
npm run build

# Preview the build
npm run preview
```

## Troubleshooting

### Common Issues

1. **Build Errors**: Check that all dependencies are installed
2. **Supabase Connection**: Verify your credentials in `.env.local`
3. **Database Errors**: Ensure all required tables exist
4. **Import Errors**: Check that all component files exist

### Getting Help

- Check the browser console for errors
- Verify Supabase dashboard for database issues
- Ensure all environment variables are set correctly

## Next Steps

1. Customize the app for your needs
2. Add your own branding and styling
3. Configure additional Supabase features (Auth, Storage, etc.)
4. Deploy to your preferred hosting platform

## Security Notes

- Never commit `.env.local` to version control
- Use Row Level Security (RLS) in Supabase for data protection
- Replace demo credentials before going to production
