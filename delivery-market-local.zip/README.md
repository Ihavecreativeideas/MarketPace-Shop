# MarketPace - Multi-Platform Marketplace & Delivery App

A comprehensive React application built with TypeScript, Vite, and Tailwind CSS featuring marketplace functionality, delivery services, musician platforms, and business management tools.

## 🚀 Quick Start

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn
- Supabase account (for backend)

### Installation Steps

1. **Clone the repository**
   ```bash
   git clone [your-repo-url]
   cd marketpace
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up Supabase Backend**
   - Create a new project at [supabase.com](https://supabase.com)
   - Copy your project URL and anon key
   - Update `src/lib/supabase.ts` with your credentials:
   ```typescript
   const supabaseUrl = 'YOUR_SUPABASE_URL';
   const supabaseKey = 'YOUR_SUPABASE_ANON_KEY';
   ```

4. **Start development server**
   ```bash
   npm run dev
   ```
   Open [http://localhost:5173](http://localhost:5173) in your browser

## 🏗️ Build for Production

```bash
npm run build
npm run preview
```

## 📱 Features

- **Marketplace**: Buy/sell items with offers system
- **Delivery Services**: MedPace (pharmacy), PostPace (mail)
- **Musicians Platform**: Profiles, gigs, equipment sharing
- **Business Tools**: Analytics, partnerships, AI assistance
- **PWA Support**: Offline functionality, push notifications
- **Real-time**: Live tracking, messaging, notifications

## 🛠️ Tech Stack

- **Frontend**: React 18, TypeScript, Vite
- **Styling**: Tailwind CSS, shadcn/ui components
- **Backend**: Supabase (PostgreSQL, Auth, Storage)
- **Routing**: React Router v6
- **State**: React Context API
- **Forms**: React Hook Form + Zod validation
- **Charts**: Recharts
- **Icons**: Lucide React

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
├── pages/              # Route components
├── contexts/           # React Context providers
├── hooks/              # Custom React hooks
├── lib/                # Utilities and configurations
├── types/              # TypeScript type definitions
└── App.tsx             # Main application component
```

## 🔧 Development

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run lint` - Run ESLint
- `npm run preview` - Preview production build

## 🚨 Important Notes

1. **Replace Supabase Credentials**: The current credentials are for demo purposes only
2. **Database Setup**: You'll need to recreate the database schema in your Supabase project
3. **Environment Variables**: Consider using `.env` files for sensitive data
4. **PWA**: The app includes service worker for offline functionality

## 📄 License

This project is private and proprietary.
