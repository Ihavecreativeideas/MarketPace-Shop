import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, ShoppingCart, Trash2, Share2 } from 'lucide-react';
import { BackButton } from '@/components/BackButton';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/components/CartContext';
import { useToast } from '@/hooks/use-toast';

interface WishlistItem {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  inStock: boolean;
}

const WishlistPage: React.FC = () => {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>([
    {
      id: '1',
      name: 'Local Honey',
      price: 12.99,
      image: '/placeholder.svg',
      category: 'Food',
      inStock: true
    },
    {
      id: '2',
      name: 'Handmade Soap',
      price: 8.50,
      image: '/placeholder.svg',
      category: 'Beauty',
      inStock: false
    }
  ]);

  const handleAddToCart = (item: WishlistItem) => {
    if (item.inStock) {
      addToCart({
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: 1,
        image: item.image
      });
      toast({ title: 'Added to cart!', description: `${item.name} added to your cart` });
    }
  };

  const handleRemoveFromWishlist = (itemId: string) => {
    setWishlistItems(items => items.filter(item => item.id !== itemId));
    toast({ title: 'Removed from wishlist', description: 'Item removed from your wishlist' });
  };

  const handleShareWishlist = () => {
    const wishlistText = `Check out my MarketPace wishlist: ${wishlistItems.map(item => item.name).join(', ')}`;
    if (navigator.share) {
      navigator.share({
        title: 'My MarketPace Wishlist',
        text: wishlistText,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(wishlistText);
      toast({ title: 'Wishlist copied!', description: 'Wishlist copied to clipboard' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <BackButton />
      <div className="max-w-4xl mx-auto pt-16">
        <Card className="mb-6">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Heart className="w-6 h-6 text-red-500" />
                My Wishlist
              </CardTitle>
              <p className="text-gray-600 mt-1">
                {wishlistItems.length} items saved
              </p>
            </div>
            <Button onClick={handleShareWishlist} variant="outline" className="flex items-center gap-2">
              <Share2 className="w-4 h-4" />
              Share
            </Button>
          </CardHeader>
        </Card>

        {wishlistItems.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Your wishlist is empty</h3>
              <p className="text-gray-500 mb-4">Start adding items you love to keep track of them!</p>
              <Button onClick={() => window.history.back()}>Continue Shopping</Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {wishlistItems.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <img 
                      src={item.image} 
                      alt={item.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold">{item.name}</h3>
                      <p className="text-gray-600">${item.price.toFixed(2)}</p>
                      <Badge variant={item.inStock ? 'default' : 'secondary'}>
                        {item.inStock ? 'In Stock' : 'Out of Stock'}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        onClick={() => handleAddToCart(item)}
                        disabled={!item.inStock}
                        className="flex items-center gap-2"
                      >
                        <ShoppingCart className="w-4 h-4" />
                        Add to Cart
                      </Button>
                      <Button
                        onClick={() => handleRemoveFromWishlist(item.id)}
                        variant="outline"
                        size="icon"
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default WishlistPage;