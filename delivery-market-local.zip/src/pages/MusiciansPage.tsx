import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Music, Calendar, Bell, Crown, Star, MapPin, MessageCircle, Plus, DollarSign, Users } from 'lucide-react';
import LocationSearch from '@/components/LocationSearch';
import PostingModal from '@/components/PostingModal';
import { BackButton } from '@/components/BackButton';

const MusiciansPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [selectedMusician, setSelectedMusician] = useState<any>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showPostingModal, setShowPostingModal] = useState(false);
  const [postType, setPostType] = useState('');
  const [bookingForm, setBookingForm] = useState({ eventType: '', venue: '', message: '' });
  
  const mockMusicians = [
    { 
      id: 1, 
      name: 'The Midnight Blues', 
      genre: 'Blues Rock', 
      location: 'Nashville, TN',
      followers: 1250, 
      image: '/placeholder.svg',
      hasNewRelease: true,
      nextShow: 'Dec 15 - Blue Note Cafe',
      isPro: true,
      bio: 'Professional blues rock band with 10+ years of experience performing at weddings, corporate events, and concerts.',
      rating: 4.8,
      totalGigs: 156
    },
    { 
      id: 2, 
      name: 'Sarah Chen', 
      genre: 'Indie Folk', 
      location: 'Austin, TX',
      followers: 890, 
      image: '/placeholder.svg',
      hasNewRelease: false,
      nextShow: 'Dec 22 - The Venue',
      isPro: true,
      bio: 'Singer-songwriter specializing in acoustic performances for intimate gatherings and special occasions.',
      rating: 4.9,
      totalGigs: 89
    },
    { 
      id: 3, 
      name: 'Electric Dreams', 
      genre: 'Electronic', 
      location: 'Los Angeles, CA',
      followers: 2100, 
      image: '/placeholder.svg',
      hasNewRelease: true,
      nextShow: 'Jan 5 - Metro Club',
      isPro: false,
      bio: 'Electronic music duo creating energetic performances.',
      rating: 4.5,
      totalGigs: 34
    }
  ];

  const postingOptions = [
    { type: 'rent', label: 'Rent Equipment', icon: DollarSign, color: 'bg-green-500' },
    { type: 'sell', label: 'Sell Item', icon: DollarSign, color: 'bg-blue-500' },
    { type: 'music-alert', label: 'New Music Alert', icon: Music, color: 'bg-purple-500' },
    { type: 'band-recruit', label: 'Band Member Recruit', icon: Users, color: 'bg-orange-500' },
    { type: 'gig-opportunity', label: 'Gig Opportunity', icon: Calendar, color: 'bg-red-500' }
  ];

  const handleBookNow = (musician: any) => {
    setSelectedMusician(musician);
    setShowBookingModal(true);
  };

  const handlePost = (type: string) => {
    setPostType(type);
    setShowPostingModal(true);
  };

  const submitBooking = async () => {
    alert('Booking request sent successfully!');
    setShowBookingModal(false);
    setBookingForm({ eventType: '', venue: '', message: '' });
  };

  const filteredMusicians = mockMusicians.filter(musician => {
    const matchesSearch = musician.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         musician.genre.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLocation = !locationFilter || 
                           musician.location.toLowerCase().includes(locationFilter.toLowerCase());
    return matchesSearch && matchesLocation;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <BackButton to="/" />
        
        <div className="flex items-center gap-2 mb-6">
          <Music className="w-6 h-6 text-blue-600" />
          <h1 className="text-3xl font-bold">MarketPace Musicians</h1>
        </div>

        {/* Search and Location Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <Input
            placeholder="Search musicians by name or genre..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-md"
          />
          <LocationSearch 
            onLocationChange={setLocationFilter}
            placeholder="Search by location..."
          />
        </div>

        {/* Quick Post Options */}
        <Card className="mb-6 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Plus className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg font-semibold text-gray-800">Quick Post</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              {postingOptions.map((option) => {
                const IconComponent = option.icon;
                return (
                  <Button
                    key={option.type}
                    variant="outline"
                    onClick={() => handlePost(option.type)}
                    className="h-auto p-3 flex flex-col items-center gap-2 hover:bg-white"
                  >
                    <div className={`w-8 h-8 rounded-full ${option.color} flex items-center justify-center`}>
                      <IconComponent className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-xs text-center">{option.label}</span>
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Musicians Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredMusicians.map((musician) => (
            <Card key={musician.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="p-0 relative">
                <img src={musician.image} alt={musician.name} className="w-full h-48 object-cover rounded-t-lg" />
                <div className="absolute top-2 right-2 flex gap-2">
                  {musician.hasNewRelease && <Badge className="bg-red-500">New!</Badge>}
                  {musician.isPro && <Badge className="bg-purple-600"><Crown className="w-3 h-3 mr-1" />PRO</Badge>}
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div>
                    <CardTitle className="text-lg">{musician.name}</CardTitle>
                    <p className="text-sm text-gray-600">{musician.genre}</p>
                    <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
                      <MapPin className="w-3 h-3" />
                      <span>{musician.location}</span>
                    </div>
                    {musician.isPro && (
                      <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        <span>{musician.rating} • {musician.totalGigs} gigs completed</span>
                      </div>
                    )}
                  </div>
                  
                  {musician.isPro && (
                    <p className="text-sm text-gray-700">{musician.bio}</p>
                  )}

                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Calendar className="w-4 h-4" />
                    <span>Next: {musician.nextShow}</span>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <Bell className="w-4 h-4 mr-1" />Follow
                    </Button>
                    {musician.isPro && (
                      <Button size="sm" onClick={() => handleBookNow(musician)} className="bg-blue-600 hover:bg-blue-700">
                        Book Now
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Pro Upgrade Section */}
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-8">
            <div className="text-center space-y-4">
              <Crown className="w-12 h-12 mx-auto text-purple-600" />
              <h3 className="text-2xl font-bold text-gray-800">Upgrade to MarketPace Musician Pro</h3>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Join our professional musician network! Get enhanced visibility, booking management, and more.
              </p>
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 text-lg">
                <Crown className="w-5 h-5 mr-2" />Upgrade to Pro - $29/month
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Booking Modal */}
      <Dialog open={showBookingModal} onOpenChange={setShowBookingModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Book {selectedMusician?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Event Type</Label>
              <Input 
                placeholder="Wedding, Party, Corporate Event, etc."
                value={bookingForm.eventType}
                onChange={(e) => setBookingForm({...bookingForm, eventType: e.target.value})}
              />
            </div>
            <div>
              <Label>Venue/Location</Label>
              <Input 
                placeholder="Event location or venue name"
                value={bookingForm.venue}
                onChange={(e) => setBookingForm({...bookingForm, venue: e.target.value})}
              />
            </div>
            <div>
              <Label>Message</Label>
              <Textarea 
                placeholder="Tell them about your event, date, duration, and any special requirements..."
                value={bookingForm.message}
                onChange={(e) => setBookingForm({...bookingForm, message: e.target.value})}
                rows={4}
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowBookingModal(false)} className="flex-1">
                Cancel
              </Button>
              <Button onClick={submitBooking} className="flex-1 bg-blue-600 hover:bg-blue-700">
                <MessageCircle className="w-4 h-4 mr-2" />Send Request
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Posting Modal */}
      <PostingModal 
        isOpen={showPostingModal}
        onClose={() => setShowPostingModal(false)}
        postType={postType}
      />
    </div>
  );
};

export default MusiciansPage;