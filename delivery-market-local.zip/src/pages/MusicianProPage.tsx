import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Crown, Star, Calendar, DollarSign, FileText, Shield, Zap } from 'lucide-react';
import { BackButton } from '@/components/BackButton';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';

const MusicianProPage: React.FC = () => {
  const navigate = useNavigate();

  const handleSubscribe = (plan: string) => {
    // Navigate to subscription page or handle subscription
    alert(`Subscribing to ${plan} plan!`);
  };

  const proFeatures = [
    {
      icon: Star,
      title: 'Professional Profile',
      description: 'Enhanced biography, photo gallery, and performance history'
    },
    {
      icon: Calendar,
      title: 'Booking Calendar',
      description: 'Integrated calendar system for managing gigs and availability'
    },
    {
      icon: FileText,
      title: 'AI Contract Generator',
      description: 'Automatically generate professional contracts for bookings'
    },
    {
      icon: DollarSign,
      title: 'Secure Payments',
      description: 'Built-in payment processing and invoice management'
    },
    {
      icon: Shield,
      title: 'Verified Badge',
      description: 'Stand out with a verified professional musician badge'
    },
    {
      icon: Zap,
      title: 'Priority Support',
      description: '24/7 priority customer support and account management'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 p-4">
      <BackButton />
      <div className="max-w-4xl mx-auto pt-16">
        {/* Hero Section */}
        <Card className="mb-8 overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white text-center">
            <div className="flex justify-center mb-4">
              <div className="bg-white p-4 rounded-full">
                <Crown className="w-12 h-12 text-purple-600" />
              </div>
            </div>
            <CardTitle className="text-3xl font-bold mb-2">
              Musician Pro
            </CardTitle>
            <p className="text-purple-100 text-lg">
              Elevate your music career with professional tools and features
            </p>
            <Badge className="bg-white text-purple-600 mt-4 text-sm font-semibold">
              Limited Time: 50% Off First Month
            </Badge>
          </CardHeader>
        </Card>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {proFeatures.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="bg-purple-100 p-2 rounded-lg">
                      <Icon className="w-6 h-6 text-purple-600" />
                    </div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Pricing Plans */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="border-2 border-purple-200">
            <CardHeader className="text-center">
              <CardTitle className="text-xl">Pro Monthly</CardTitle>
              <div className="text-3xl font-bold text-purple-600">
                $19.99<span className="text-sm font-normal text-gray-500">/month</span>
              </div>
              <p className="text-gray-600">Perfect for active musicians</p>
            </CardHeader>
            <CardContent className="space-y-3">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-green-500" />
                  All Pro features included
                </li>
                <li className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-green-500" />
                  Unlimited bookings
                </li>
                <li className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-green-500" />
                  Priority customer support
                </li>
              </ul>
              <Button 
                onClick={() => handleSubscribe('Monthly')} 
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                Start Monthly Plan
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 border-pink-200 relative">
            <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-pink-500">
              Most Popular
            </Badge>
            <CardHeader className="text-center">
              <CardTitle className="text-xl">Pro Annual</CardTitle>
              <div className="text-3xl font-bold text-pink-600">
                $199.99<span className="text-sm font-normal text-gray-500">/year</span>
              </div>
              <p className="text-gray-600">Save $40 with annual billing</p>
            </CardHeader>
            <CardContent className="space-y-3">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-green-500" />
                  All Pro features included
                </li>
                <li className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-green-500" />
                  2 months free
                </li>
                <li className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-green-500" />
                  Exclusive annual member perks
                </li>
              </ul>
              <Button 
                onClick={() => handleSubscribe('Annual')} 
                className="w-full bg-pink-600 hover:bg-pink-700"
              >
                Start Annual Plan
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Section */}
        <Card>
          <CardHeader>
            <CardTitle>Frequently Asked Questions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Can I cancel anytime?</h4>
              <p className="text-gray-600 text-sm">Yes, you can cancel your subscription at any time. No long-term commitments.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Do you offer a free trial?</h4>
              <p className="text-gray-600 text-sm">We offer a 7-day free trial for all new Pro subscribers.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">What payment methods do you accept?</h4>
              <p className="text-gray-600 text-sm">We accept all major credit cards, PayPal, and bank transfers.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MusicianProPage;