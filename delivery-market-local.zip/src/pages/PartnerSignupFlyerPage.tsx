import React from 'react';
import PartnerSignupFlyer from '../components/PartnerSignupFlyer';
import { useNavigate } from 'react-router-dom';

const PartnerSignupFlyerPage: React.FC = () => {
  const navigate = useNavigate();

  const handleSignupClick = () => {
    navigate('/marketplace-partner');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 to-blue-100 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Page Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            MarketPlace Partner Program
          </h1>
          <p className="text-lg text-gray-600">
            Join thousands of businesses already growing with MarketPlace
          </p>
        </div>

        {/* Flyer Component */}
        <PartnerSignupFlyer 
          onSignupClick={handleSignupClick}
          isShareable={true}
        />

        {/* Additional Info */}
        <div className="mt-8 text-center">
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">
              Why Join During Beta Testing?
            </h2>
            <div className="grid md:grid-cols-3 gap-4 text-sm">
              <div className="p-4 bg-green-50 rounded-lg">
                <h3 className="font-semibold text-green-800 mb-2">🚀 First Mover Advantage</h3>
                <p className="text-green-700">Get established before your competitors</p>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <h3 className="font-semibold text-blue-800 mb-2">💰 Lifetime Savings</h3>
                <p className="text-blue-700">Lock in discounted rates forever</p>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <h3 className="font-semibold text-purple-800 mb-2">🎯 Shape the Platform</h3>
                <p className="text-purple-700">Your feedback helps us improve</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PartnerSignupFlyerPage;