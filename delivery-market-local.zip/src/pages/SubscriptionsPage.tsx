import React from 'react';
import { useParams } from 'react-router-dom';
import UniversalPageWrapper from '@/components/UniversalPageWrapper';
import SubscriptionDetector from '@/components/SubscriptionDetector';
import { Card, CardContent } from '@/components/ui/card';
import { Crown, Zap, Star } from 'lucide-react';

const SubscriptionsPage: React.FC = () => {
  const { userId } = useParams();
  const currentUserId = userId || 'user-123'; // Mock user ID

  return (
    <UniversalPageWrapper>
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
        <div className="max-w-6xl mx-auto px-4 py-8">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Crown className="w-8 h-8 text-purple-600" />
              <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                Upgrade Your Profile
              </h1>
            </div>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Unlock premium features for your musician profile, marketplace account, or PaceMaker business
            </p>
          </div>

          {/* Benefits Overview */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold mb-2">Enhanced Features</h3>
                <p className="text-sm text-gray-600">
                  Access advanced tools and integrations specific to your profile type
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold mb-2">Priority Support</h3>
                <p className="text-sm text-gray-600">
                  Get faster responses and dedicated assistance from our team
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Crown className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold mb-2">Exclusive Access</h3>
                <p className="text-sm text-gray-600">
                  Unlock features only available to premium subscribers
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Main Subscription Component */}
          <SubscriptionDetector userId={currentUserId} />
        </div>
      </div>
    </UniversalPageWrapper>
  );
};

export default SubscriptionsPage;