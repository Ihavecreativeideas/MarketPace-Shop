import React from 'react';
import Marketplace from '@/components/Marketplace';

const MarketplacePage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <Marketplace />
    </div>
  );
};

export default MarketplacePage;