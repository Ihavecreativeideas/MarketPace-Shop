import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Facebook, Twitter, Mail, Copy, Share2 } from 'lucide-react';
import { BackButton } from '@/components/BackButton';
import { useToast } from '@/hooks/use-toast';

const InvitePage: React.FC = () => {
  const { toast } = useToast();
  const inviteUrl = window.location.origin;
  const inviteMessage = "Join me on MarketPace - the local marketplace that supports our community! Shop local, support families, and discover amazing deals.";

  const handleFacebookShare = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(inviteUrl)}&quote=${encodeURIComponent(inviteMessage)}`;
    window.open(url, '_blank', 'width=600,height=400');
  };

  const handleTwitterShare = () => {
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(inviteMessage)}&url=${encodeURIComponent(inviteUrl)}`;
    window.open(url, '_blank', 'width=600,height=400');
  };

  const handleEmailShare = () => {
    const subject = 'Join MarketPace - Shop Local!';
    const body = `${inviteMessage}\n\n${inviteUrl}`;
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl);
      toast({ title: 'Link copied!', description: 'Invite link copied to clipboard' });
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to copy link', variant: 'destructive' });
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'MarketPace - Shop Local',
          text: inviteMessage,
          url: inviteUrl,
        });
      } catch (err) {
        console.log('Share cancelled');
      }
    } else {
      handleCopyLink();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <BackButton />
      <div className="max-w-2xl mx-auto pt-16">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-blue-600">
              Invite Friends to MarketPace
            </CardTitle>
            <p className="text-gray-600 mt-2">
              Share MarketPace with friends and help grow our local community!
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Button onClick={handleFacebookShare} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700">
                <Facebook className="w-4 h-4" />
                Facebook
              </Button>
              <Button onClick={handleTwitterShare} className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600">
                <Twitter className="w-4 h-4" />
                Twitter
              </Button>
              <Button onClick={handleEmailShare} variant="outline" className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Email
              </Button>
              <Button onClick={handleCopyLink} variant="outline" className="flex items-center gap-2">
                <Copy className="w-4 h-4" />
                Copy Link
              </Button>
            </div>
            <Button onClick={handleNativeShare} className="w-full flex items-center gap-2" variant="secondary">
              <Share2 className="w-4 h-4" />
              Share via Device
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InvitePage;