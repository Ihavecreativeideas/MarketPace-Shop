import React from 'react';
import { PaceMakers } from '@/components/PaceMakers';

const PaceMakersPage: React.FC = () => {
  return <PaceMakers />;
};

export default PaceMakersPage;