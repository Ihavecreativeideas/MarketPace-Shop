import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import PreLaunchSignup from '@/components/PreLaunchSignup';
import LandingPage from '@/components/LandingPage';
import TestComponent from '@/components/TestComponent';
import SetupWizard from '@/components/SetupWizard';
import { ForYouSection } from '@/components/ForYouSection';
import { InterestTracker } from '@/components/InterestTracker';
import { NotificationCenter } from '@/components/NotificationCenter';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Bell, AlertTriangle } from 'lucide-react';

const Index: React.FC = () => {
  const [showNotifications, setShowNotifications] = useState(false);
  const userId = 'demo-user-123'; // In real app, get from auth context

  return (
    <div className="min-h-screen">
      {/* Interest Tracker - invisible component that monitors behavior */}
      <InterestTracker userId={userId} />
      
      {/* Setup Wizard - shows if configuration is needed */}
      <div className="container mx-auto px-4 py-4">
        <SetupWizard />
      </div>
      
      {/* Update Status Banner */}
      <div className="bg-yellow-100 border-b border-yellow-300 py-2">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 text-yellow-800">
            <AlertTriangle className="h-4 w-4" />
            <span className="text-sm font-medium">
              Testing live updates - Changes should appear immediately
            </span>
          </div>
        </div>
      </div>
      
      {/* Test Component */}
      <div className="container mx-auto px-4 py-4">
        <TestComponent />
      </div>
      
      {/* Notification Bell */}
      <div className="fixed top-4 right-4 z-50">
        <Button
          variant="outline"
          size="icon"
          onClick={() => setShowNotifications(!showNotifications)}
          className="bg-white shadow-lg"
        >
          <Bell className="h-4 w-4" />
        </Button>
        
        {showNotifications && (
          <div className="absolute top-12 right-0">
            <NotificationCenter 
              userId={userId} 
              onClose={() => setShowNotifications(false)}
            />
          </div>
        )}
      </div>

      {/* Pre-launch signup section at the top - Mobile Optimized */}
      <div className="bg-orange-50 border-b border-orange-200 py-3 sm:py-4">
        <div className="container mx-auto px-3 sm:px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 lg:gap-8">
            <Card className="order-2 lg:order-1">
              <CardHeader className="pb-3 sm:pb-4">
                <CardTitle className="text-lg sm:text-xl lg:text-2xl">Welcome to MarketPace</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-gray-600 mb-3 sm:mb-4 text-sm sm:text-base leading-relaxed">
                  Your all-in-one platform for marketplace, delivery, and music services.
                </p>
                <p className="text-xs sm:text-sm text-orange-600 leading-relaxed">
                  We're preparing to launch! Join our campaign to help us reach launch readiness.
                </p>
              </CardContent>
            </Card>
            
            <div className="order-1 lg:order-2">
              <PreLaunchSignup />
            </div>
          </div>
        </div>
      </div>
      
      {/* AI-Powered For You Section */}
      <div className="container mx-auto px-3 sm:px-4 py-6 sm:py-8">
        <ForYouSection userId={userId} />
      </div>
      
      {/* Full landing page content below */}
      <LandingPage />
    </div>
  );
};

export default Index;
