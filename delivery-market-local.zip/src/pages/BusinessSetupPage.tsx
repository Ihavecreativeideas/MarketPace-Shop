import React from 'react';
import { BusinessSetupList } from '@/components/BusinessSetupList';
import { UniversalPageWrapper } from '@/components/UniversalPageWrapper';
import { BackButton } from '@/components/BackButton';

export const BusinessSetupPage: React.FC = () => {
  return (
    <UniversalPageWrapper>
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <BackButton />
          <div className="mt-6">
            <BusinessSetupList />
          </div>
        </div>
      </div>
    </UniversalPageWrapper>
  );
};

export default BusinessSetupPage;