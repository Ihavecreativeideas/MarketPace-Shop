import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Shield, Eye, Scale } from 'lucide-react';
import { BackButton } from '@/components/BackButton';
import { PrivacyPolicy } from '@/components/PrivacyPolicy';
import { TermsOfService } from '@/components/TermsOfService';

type LegalSection = 'overview' | 'privacy' | 'terms' | 'cookies';

const LegalPage: React.FC = () => {
  const [activeSection, setActiveSection] = useState<LegalSection>('overview');

  const legalSections = [
    { id: 'overview' as LegalSection, label: 'Legal Overview', icon: Scale },
    { id: 'privacy' as LegalSection, label: 'Privacy Policy', icon: Shield },
    { id: 'terms' as LegalSection, label: 'Terms of Service', icon: FileText },
    { id: 'cookies' as LegalSection, label: 'Cookie Policy', icon: Eye }
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'privacy':
        return <PrivacyPolicy />;
      case 'terms':
        return <TermsOfService />;
      case 'cookies':
        return (
          <div className="prose max-w-none">
            <h2>Cookie Policy</h2>
            <p>This Cookie Policy explains how MarketPace uses cookies and similar technologies.</p>
            <h3>What are cookies?</h3>
            <p>Cookies are small text files stored on your device when you visit our website.</p>
            <h3>How we use cookies</h3>
            <ul>
              <li>Essential cookies for site functionality</li>
              <li>Analytics cookies to understand usage</li>
              <li>Preference cookies to remember your settings</li>
            </ul>
            <h3>Managing cookies</h3>
            <p>You can control cookies through your browser settings.</p>
          </div>
        );
      default:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Legal Information</h2>
            <p className="text-gray-600">
              Welcome to MarketPace's legal center. Here you can find all our legal documents and policies.
            </p>
            <div className="grid gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5 text-blue-600" />
                    Privacy Policy
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-3">
                    Learn how we collect, use, and protect your personal information.
                  </p>
                  <Button onClick={() => setActiveSection('privacy')} variant="outline" size="sm">
                    Read Privacy Policy
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-green-600" />
                    Terms of Service
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-3">
                    Understand the terms and conditions for using MarketPace.
                  </p>
                  <Button onClick={() => setActiveSection('terms')} variant="outline" size="sm">
                    Read Terms of Service
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="w-5 h-5 text-purple-600" />
                    Cookie Policy
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-3">
                    Learn about our use of cookies and tracking technologies.
                  </p>
                  <Button onClick={() => setActiveSection('cookies')} variant="outline" size="sm">
                    Read Cookie Policy
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <BackButton />
      <div className="max-w-4xl mx-auto pt-16">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Scale className="w-6 h-6 text-blue-600" />
              Legal Center
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {legalSections.map((section) => {
                const Icon = section.icon;
                return (
                  <Button
                    key={section.id}
                    variant={activeSection === section.id ? 'default' : 'outline'}
                    onClick={() => setActiveSection(section.id)}
                    className="flex items-center gap-2"
                  >
                    <Icon className="w-4 h-4" />
                    {section.label}
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            {renderContent()}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LegalPage;