import React from 'react';
import QuickStart from '@/components/QuickStart';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

export default function SetupPage() {
  const navigate = useNavigate();

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Button variant="ghost" onClick={() => navigate('/')} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Home
        </Button>
        <h1 className="text-3xl font-bold">Setup MarketPace</h1>
        <p className="text-gray-600 mt-2">
          Follow these steps to get your MarketPace application up and running.
        </p>
      </div>
      
      <QuickStart />
    </div>
  );
}
