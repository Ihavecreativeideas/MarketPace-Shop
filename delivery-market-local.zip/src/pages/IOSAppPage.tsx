import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Smartphone, Download, Apple, Star } from 'lucide-react';
import { BackButton } from '@/components/BackButton';
import { Badge } from '@/components/ui/badge';

const IOSAppPage: React.FC = () => {
  const handleDownload = () => {
    // In a real app, this would redirect to App Store
    window.open('https://apps.apple.com/app/marketpace', '_blank');
  };

  const handleInstallPWA = () => {
    // Check if PWA can be installed
    if ('serviceWorker' in navigator) {
      // Show PWA install prompt
      const installPrompt = localStorage.getItem('pwa-install-prompt');
      if (installPrompt) {
        // Trigger PWA install
        window.dispatchEvent(new Event('beforeinstallprompt'));
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-4">
      <BackButton />
      <div className="max-w-2xl mx-auto pt-16">
        <Card className="overflow-hidden">
          <CardHeader className="text-center bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div className="flex justify-center mb-4">
              <div className="bg-white p-4 rounded-2xl">
                <Smartphone className="w-12 h-12 text-blue-600" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold">
              MarketPace iOS App
            </CardTitle>
            <p className="text-blue-100 mt-2">
              Get the full MarketPace experience on your iPhone
            </p>
            <Badge className="bg-white text-blue-600 mt-2">
              Coming Soon
            </Badge>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">App Features:</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-500" />
                  Native iOS performance
                </li>
                <li className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-500" />
                  Push notifications for orders
                </li>
                <li className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-500" />
                  Offline browsing capability
                </li>
                <li className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-500" />
                  Enhanced location services
                </li>
                <li className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-500" />
                  Apple Pay integration
                </li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <Button 
                onClick={handleDownload} 
                className="w-full flex items-center gap-2 bg-black hover:bg-gray-800 text-white"
                disabled
              >
                <Apple className="w-5 h-5" />
                Download from App Store
                <Badge variant="secondary" className="ml-2">Soon</Badge>
              </Button>
              
              <Button 
                onClick={handleInstallPWA} 
                variant="outline" 
                className="w-full flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Install Web App
              </Button>
            </div>
            
            <div className="text-center text-sm text-gray-500">
              <p>Currently available as a web app.</p>
              <p>Native iOS app launching soon!</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default IOSAppPage;