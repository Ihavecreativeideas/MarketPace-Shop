import { createClient } from '@supabase/supabase-js';

// Environment variables for Supabase configuration
// Replace these with your own Supabase project credentials
const supabaseUrl = process.env.REACT_APP_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseKey = process.env.REACT_APP_SUPABASE_ANON_KEY || 'your-anon-key-here';

// Fallback to demo credentials if environment variables are not set
// IMPORTANT: Replace these with your own credentials for production
const DEMO_URL = 'https://mmdhnbfdlecjznaupqko.supabase.co';
const DEMO_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1tZGhuYmZkbGVjanpuYXVwcWtvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDkyNDQwNDMsImV4cCI6MjA2NDgyMDA0M30.go63GJvsqrqahZf4vj6sl_fCRgfm91c_XEm2Nl3JlYo';

// Use environment variables if available, otherwise fall back to demo
const finalUrl = supabaseUrl !== 'https://your-project.supabase.co' ? supabaseUrl : DEMO_URL;
const finalKey = supabaseKey !== 'your-anon-key-here' ? supabaseKey : DEMO_KEY;

// Initialize Supabase client
export const supabase = createClient(finalUrl, finalKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
});

// Helper function to check if using demo credentials
export const isDemoMode = () => {
  return finalUrl === DEMO_URL && finalKey === DEMO_KEY;
};

// Database table names for reference
export const TABLES = {
  USERS: 'users',
  PRODUCTS: 'products', 
  ORDERS: 'orders',
  MUSICIANS: 'musicians',
  BUSINESSES: 'businesses',
  DELIVERIES: 'deliveries',
  NOTIFICATIONS: 'notifications'
} as const;
