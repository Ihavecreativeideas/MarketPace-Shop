import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

interface LaunchContextType {
  isLaunched: boolean;
  launchProgress: number;
  totalSignups: number;
  preLaunchSignups: number;
  postLaunchSignups: number;
  launchDate: Date | null;
  setIsLaunched: (launched: boolean) => void;
  incrementSignups: () => void;
  checkSustainabilityFeeExemption: (userId: string) => Promise<boolean>;
}

const LaunchContext = createContext<LaunchContextType | undefined>(undefined);

export const LaunchProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isLaunched, setIsLaunched] = useState(false);
  const [totalSignups, setTotalSignups] = useState(0);
  const [preLaunchSignups, setPreLaunchSignups] = useState(0);
  const [postLaunchSignups, setPostLaunchSignups] = useState(0);
  const [launchDate, setLaunchDate] = useState<Date | null>(null);
  const [launchProgress, setLaunchProgress] = useState(0);

  const LAUNCH_TARGET = 1000;

  useEffect(() => {
    fetchLaunchData();
  }, []);

  const fetchLaunchData = async () => {
    try {
      const { data } = await supabase
        .from('launch_campaign')
        .select('*')
        .single();
      
      if (data) {
        setTotalSignups(data.total_signups || 0);
        setPreLaunchSignups(data.pre_launch_signups || 0);
        setPostLaunchSignups(data.post_launch_signups || 0);
        setIsLaunched(data.is_launched || false);
        setLaunchDate(data.launch_date ? new Date(data.launch_date) : null);
        setLaunchProgress(Math.min((data.total_signups || 0) / LAUNCH_TARGET * 100, 100));
      }
    } catch (error) {
      console.error('Error fetching launch data:', error);
    }
  };

  const incrementSignups = async () => {
    try {
      const newTotal = totalSignups + 1;
      const updateData = {
        id: 1,
        total_signups: newTotal,
        is_launched: isLaunched
      };

      if (isLaunched) {
        updateData.post_launch_signups = postLaunchSignups + 1;
      } else {
        updateData.pre_launch_signups = preLaunchSignups + 1;
      }

      await supabase
        .from('launch_campaign')
        .upsert(updateData);
      
      setTotalSignups(newTotal);
      if (isLaunched) {
        setPostLaunchSignups(postLaunchSignups + 1);
      } else {
        setPreLaunchSignups(preLaunchSignups + 1);
      }
      setLaunchProgress(Math.min(newTotal / LAUNCH_TARGET * 100, 100));
    } catch (error) {
      console.error('Error updating signups:', error);
    }
  };

  const checkSustainabilityFeeExemption = async (userId: string): Promise<boolean> => {
    try {
      const { data: userData } = await supabase
        .from('users')
        .select('created_at')
        .eq('id', userId)
        .single();

      if (!userData || !launchDate) return false;

      const userSignupDate = new Date(userData.created_at);
      return userSignupDate < launchDate;
    } catch (error) {
      console.error('Error checking fee exemption:', error);
      return false;
    }
  };

  return (
    <LaunchContext.Provider value={{
      isLaunched,
      launchProgress,
      totalSignups,
      preLaunchSignups,
      postLaunchSignups,
      launchDate,
      setIsLaunched,
      incrementSignups,
      checkSustainabilityFeeExemption
    }}>
      {children}
    </LaunchContext.Provider>
  );
};

export const useLaunch = () => {
  const context = useContext(LaunchContext);
  if (!context) {
    throw new Error('useLaunch must be used within LaunchProvider');
  }
  return context;
};