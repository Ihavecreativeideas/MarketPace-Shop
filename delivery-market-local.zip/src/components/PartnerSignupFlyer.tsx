import React from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Share2, Store, Globe, TrendingUp, BarChart3, Truck, Gift, Zap, Check } from 'lucide-react';

interface PartnerSignupFlyerProps {
  onSignupClick?: () => void;
  isShareable?: boolean;
}

const PartnerSignupFlyer: React.FC<PartnerSignupFlyerProps> = ({ onSignupClick, isShareable = false }) => {
  const shareUrl = `${window.location.origin}/partner-signup`;
  
  const handleFacebookShare = () => {
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent('Join MarketPlace as a FREE Partner! Get lifetime benefits by signing up for our beta test!')}`;
    window.open(facebookUrl, '_blank', 'width=600,height=400');
  };

  const benefits = [
    { icon: Globe, text: 'Website Integration' },
    { icon: TrendingUp, text: 'Platform to Promote' },
    { icon: Truck, text: 'No Delivery Fees' },
    { icon: BarChart3, text: 'Analytics & Insights' }
  ];

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-2 border-green-200">
        <CardContent className="p-8">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="bg-gradient-to-r from-green-500 to-blue-500 text-white p-4 rounded-lg mb-4">
              <h1 className="text-2xl font-bold mb-2">🚀 MarketPlace Partner</h1>
              <p className="text-lg font-semibold">FREE Trial - No Payment Required!</p>
            </div>
            
            <Badge className="bg-yellow-100 text-yellow-800 text-sm px-3 py-1">
              ⚡ Limited Time Beta Offer
            </Badge>
          </div>

          {/* Benefits Grid */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            {benefits.map((benefit, index) => {
              const IconComponent = benefit.icon;
              return (
                <div key={index} className="flex items-center gap-2 p-3 bg-white rounded-lg shadow-sm">
                  <IconComponent className="w-5 h-5 text-green-600" />
                  <span className="text-sm font-medium">{benefit.text}</span>
                </div>
              );
            })}
          </div>

          {/* Key Features */}
          <div className="bg-white p-4 rounded-lg mb-6">
            <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
              <Gift className="w-5 h-5 text-green-600" />
              What You Get FREE:
            </h3>
            <div className="grid grid-cols-1 gap-2 text-sm">
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-600" />
                <span>Social media integration</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-600" />
                <span>Customer messaging system</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-600" />
                <span>Marketing promotion tools</span>
              </div>
            </div>
          </div>

          {/* Special Offer */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <h3 className="font-bold text-yellow-800 mb-2">🎯 Early Bird Special</h3>
            <p className="text-yellow-700 text-sm mb-2">
              This is temporary app testing pricing - take advantage now!
            </p>
            <p className="text-xs text-yellow-600">
              Early members get lifetime discounts for supporting our startup!
            </p>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <Button 
              onClick={onSignupClick || (() => window.location.href = '/partner-signup')}
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3"
            >
              <Zap className="w-4 h-4 mr-2" />
              Join FREE Trial Now!
            </Button>
            
            {isShareable && (
              <Button 
                onClick={handleFacebookShare}
                variant="outline" 
                className="w-full border-blue-500 text-blue-600 hover:bg-blue-50"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Share on Facebook
              </Button>
            )}
          </div>

          {/* Footer */}
          <div className="text-center mt-4">
            <p className="text-xs text-gray-500">
              No credit card required • Cancel anytime • Lifetime benefits
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PartnerSignupFlyer;