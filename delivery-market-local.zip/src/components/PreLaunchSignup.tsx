import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Users, Music, Store, Truck, Gift } from 'lucide-react';
import { useLaunch } from '@/contexts/LaunchContext';
import { toast } from './ui/use-toast';
import { SustainabilityFeeInfo } from './SustainabilityFeeInfo';
import { supabase } from '@/lib/supabase';
import FacebookSignup from './FacebookSignup';

const PreLaunchSignup: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [userType, setUserType] = useState('');
  const [loading, setLoading] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const { incrementSignups, isLaunched } = useLaunch();

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !userType) {
      toast({ title: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const { data: userData, error } = await supabase
        .from('users')
        .insert({
          name,
          email,
          user_type: userType,
          is_pre_launch: !isLaunched
        })
        .select()
        .single();

      if (error) throw error;

      setUserId(userData.id);
      incrementSignups();
      
      const benefitMessage = !isLaunched 
        ? 'As a pre-launch member, you get 3 months with no sustainability fee!' 
        : 'Welcome! The sustainability fee is $4/month.';
      
      toast({ 
        title: 'Welcome to the launch campaign!', 
        description: benefitMessage 
      });
      
      setName('');
      setEmail('');
      setUserType('');
    } catch (error) {
      console.error('Error signing up:', error);
      toast({ title: 'Error signing up', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleFacebookSuccess = (fbUserId: string) => {
    setUserId(fbUserId);
  };

  const userTypes = [
    { value: 'member', label: 'Member', icon: Users },
    { value: 'musician', label: 'Musician', icon: Music },
    { value: 'vendor', label: 'Vendor/Shop', icon: Store },
    { value: 'driver', label: 'Driver', icon: Truck }
  ];

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
        <CardHeader className="pb-4">
          <CardTitle className="text-center text-blue-800 flex items-center justify-center gap-2 text-lg sm:text-xl">
            <Gift className="h-5 w-5 sm:h-6 sm:w-6" />
            Join the Launch Campaign!
          </CardTitle>
          {!isLaunched && (
            <p className="text-center text-xs sm:text-sm text-green-600 font-medium px-2">
              🎉 Pre-Launch Special: 3 Months FREE Sustainability Fee!
            </p>
          )}
        </CardHeader>
        <CardContent className="space-y-4 px-4 sm:px-6">
          {/* Facebook Signup Option */}
          <div className="w-full">
            <FacebookSignup onSuccess={handleFacebookSuccess} />
          </div>
          
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">Or continue with email</span>
            </div>
          </div>

          {/* Regular Email Signup */}
          <form onSubmit={handleSignup} className="space-y-3 sm:space-y-4">
            <Input
              placeholder="Your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="border-blue-200 h-10 sm:h-11 text-sm sm:text-base"
            />
            <Input
              type="email"
              placeholder="Your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="border-blue-200 h-10 sm:h-11 text-sm sm:text-base"
            />
            <Select value={userType} onValueChange={setUserType}>
              <SelectTrigger className="border-blue-200 h-10 sm:h-11 text-sm sm:text-base">
                <SelectValue placeholder="I want to join as..." />
              </SelectTrigger>
              <SelectContent>
                {userTypes.map((type) => {
                  const Icon = type.icon;
                  return (
                    <SelectItem key={type.value} value={type.value}>
                      <div className="flex items-center space-x-2">
                        <Icon className="w-3 h-3 sm:w-4 sm:h-4" />
                        <span className="text-sm sm:text-base">{type.label}</span>
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
            <Button 
              type="submit" 
              className="w-full bg-blue-600 hover:bg-blue-700 h-10 sm:h-11 text-sm sm:text-base"
              disabled={loading}
            >
              {loading ? 'Joining...' : 'Join Campaign'}
            </Button>
          </form>
        </CardContent>
      </Card>
      
      {userId && (
        <div className="px-2 sm:px-0">
          <SustainabilityFeeInfo userId={userId} />
        </div>
      )}
    </div>
  );
};

export default PreLaunchSignup;