import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Truck, CheckCircle, XCircle, Star, Package } from 'lucide-react';
import DeliveryAcceptanceModal from './DeliveryAcceptanceModal';
import TipDriverModal from './TipDriverModal';

interface DeliveryStatusProps {
  orderId: string;
  itemName: string;
  status: 'pending' | 'in_route' | 'delivered' | 'accepted' | 'returned';
  userType: 'buyer' | 'seller';
  onStatusChange?: (newStatus: 'accepted' | 'returned') => void;
}

const DeliveryStatus: React.FC<DeliveryStatusProps> = ({
  orderId,
  itemName,
  status,
  userType,
  onStatusChange
}) => {
  const [currentStatus, setCurrentStatus] = useState(status);
  const [showAcceptanceModal, setShowAcceptanceModal] = useState(false);
  const [showTipModal, setShowTipModal] = useState(false);
  const [itemAction, setItemAction] = useState<'accepted' | 'returned' | null>(null);

  const getStatusBadge = () => {
    switch (currentStatus) {
      case 'pending':
        return <Badge variant="secondary">Pending Pickup</Badge>;
      case 'in_route':
        return <Badge variant="default">In Route</Badge>;
      case 'delivered':
        return <Badge variant="outline" className="border-orange-500 text-orange-600">Delivered - Action Required</Badge>;
      case 'accepted':
        return <Badge variant="default" className="bg-green-500">Accepted</Badge>;
      case 'returned':
        return <Badge variant="destructive">Returned</Badge>;
    }
  };

  const handleAccept = () => {
    setCurrentStatus('accepted');
    setItemAction('accepted');
    setShowAcceptanceModal(false);
    onStatusChange?.('accepted');
    // Show tip modal after accepting
    setTimeout(() => setShowTipModal(true), 500);
  };

  const handleReturn = () => {
    setCurrentStatus('returned');
    setItemAction('returned');
    setShowAcceptanceModal(false);
    onStatusChange?.('returned');
    // Show tip modal after returning
    setTimeout(() => setShowTipModal(true), 500);
  };

  const handleTipSubmit = (tip: number, rating: number, review: string) => {
    console.log('Tip submitted:', { tip, rating, review, userType, itemAction });
    // Here you would send this data to your backend
  };

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg flex items-center gap-2">
              <Package className="w-5 h-5" />
              Order #{orderId}
            </CardTitle>
            {getStatusBadge()}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {currentStatus === 'in_route' && (
            <div className="flex items-center gap-2 text-blue-600">
              <Truck className="w-4 h-4" />
              <span>Your item is on the way!</span>
            </div>
          )}
          
          {currentStatus === 'delivered' && userType === 'buyer' && (
            <div className="space-y-4">
              <p className="text-sm text-gray-600">
                Your item has been delivered. Please choose an action:
              </p>
              <Button 
                onClick={() => setShowAcceptanceModal(true)} 
                className="w-full"
              >
                <Package className="w-4 h-4 mr-2" />
                Review Delivery
              </Button>
            </div>
          )}
          
          {currentStatus === 'delivered' && userType === 'seller' && (
            <div className="space-y-2">
              <p className="text-sm text-gray-600">
                Your item has been delivered to the buyer.
              </p>
              <Button 
                onClick={() => setShowTipModal(true)} 
                variant="outline" 
                className="w-full"
              >
                <Star className="w-4 h-4 mr-2" />
                Tip Driver
              </Button>
            </div>
          )}
          
          {(currentStatus === 'accepted' || currentStatus === 'returned') && (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                {currentStatus === 'accepted' ? (
                  <CheckCircle className="w-4 h-4 text-green-600" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-600" />
                )}
                <span className="text-sm">
                  {currentStatus === 'accepted' 
                    ? 'Item accepted successfully!' 
                    : 'Item returned successfully!'}
                </span>
              </div>
              {userType === 'buyer' && (
                <Button 
                  onClick={() => setShowTipModal(true)} 
                  variant="outline" 
                  size="sm"
                >
                  <Star className="w-4 h-4 mr-2" />
                  Tip Driver
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <DeliveryAcceptanceModal
        isOpen={showAcceptanceModal}
        onClose={() => setShowAcceptanceModal(false)}
        onAccept={handleAccept}
        onReturn={handleReturn}
        itemName={itemName}
        orderId={orderId}
      />

      <TipDriverModal
        isOpen={showTipModal}
        onClose={() => setShowTipModal(false)}
        onSubmit={handleTipSubmit}
        userType={userType}
        itemAction={itemAction || undefined}
      />
    </>
  );
};

export default DeliveryStatus;