import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calculator, MapPin, Clock, CreditCard, Crown, Package } from 'lucide-react';
import { useState } from 'react';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface DeliveryCalculatorProps {
  itemSize: 'small' | 'medium' | 'large';
  itemPrice: number;
  sellerLocation: string;
  isPartnerShop?: boolean;
  customShippingFee?: number;
  partnerTier?: 'silver' | 'gold' | 'platinum';
}

const DeliveryCalculator: React.FC<DeliveryCalculatorProps> = ({ 
  itemSize, 
  itemPrice, 
  sellerLocation, 
  isPartnerShop = false,
  customShippingFee = 0,
  partnerTier = 'silver'
}) => {
  const [buyerLocation, setBuyerLocation] = useState('');
  const [distance, setDistance] = useState<number | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [viewAsPartner, setViewAsPartner] = useState(isPartnerShop);
  const [selectedItemSize, setSelectedItemSize] = useState<'small' | 'medium' | 'large'>(itemSize);
  const [selectedPartnerTier, setSelectedPartnerTier] = useState<'silver' | 'gold' | 'platinum'>(partnerTier);

  const calculateDelivery = async () => {
    if (!buyerLocation.trim()) return;
    setIsCalculating(true);
    setTimeout(() => {
      const mockDistance = Math.random() * 20 + 1;
      setDistance(mockDistance);
      setIsCalculating(false);
    }, 1000);
  };

  const getDeliveryInfo = () => {
    if (!distance) return null;
    
    if (selectedItemSize === 'large') {
      const driverEarnings = 40;
      let totalDeliveryFee = driverEarnings + 4;
      
      if (viewAsPartner) {
        const deliveryDiscount = selectedPartnerTier === 'platinum' ? 0.25 : 0.2;
        totalDeliveryFee = driverEarnings * (1 - deliveryDiscount);
      }
      
      const buyerShare = totalDeliveryFee / 2;
      const sellerShare = totalDeliveryFee / 2;
      
      return {
        baseFee: 0,
        mileageFee: 0,
        sustainabilityFee: viewAsPartner ? 0 : 4,
        buyerShare,
        sellerShare,
        totalDeliveryFee,
        driverEarnings,
        estimatedTime: Math.ceil(distance * 3),
        customShippingFee: viewAsPartner ? customShippingFee : 0,
        isLargeItem: true
      };
    }
    
    const baseFee = 10;
    const mileageRate = 1.25;
    const sustainabilityFee = 4;
    
    const totalMileageFee = distance * mileageRate;
    const sharedFees = baseFee + totalMileageFee;
    const buyerShare = sharedFees / 2;
    
    let sellerShare;
    let actualSustainabilityFee;
    
    if (viewAsPartner) {
      let deliveryDiscount = 0.2;
      if (selectedPartnerTier === 'platinum') {
        deliveryDiscount = 0.25;
      }
      
      sellerShare = (sharedFees / 2) * (1 - deliveryDiscount);
      actualSustainabilityFee = selectedPartnerTier === 'silver' ? sustainabilityFee * 0.5 : 0;
      sellerShare += actualSustainabilityFee;
    } else {
      sellerShare = sharedFees / 2 + sustainabilityFee;
      actualSustainabilityFee = sustainabilityFee;
    }
    
    const totalDeliveryFee = buyerShare + sellerShare;
    const driverEarnings = 4 + 2 + (distance * 0.75);
    
    return {
      baseFee,
      mileageFee: totalMileageFee,
      sustainabilityFee: actualSustainabilityFee,
      buyerShare,
      sellerShare,
      totalDeliveryFee,
      driverEarnings,
      estimatedTime: Math.ceil(distance * 2),
      customShippingFee: viewAsPartner ? customShippingFee : 0,
      isLargeItem: false
    };
  };

  const deliveryInfo = getDeliveryInfo();
  const isInRange = distance ? distance <= 20 : true;

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="w-5 h-5" />
          Delivery Calculator
          {viewAsPartner && (
            <Badge className="bg-purple-600">
              <Crown className="w-3 h-3 mr-1" />
              {selectedPartnerTier.charAt(0).toUpperCase() + selectedPartnerTier.slice(1)}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <span className="text-sm font-medium">View as Partner Shop</span>
          <Switch
            checked={viewAsPartner}
            onCheckedChange={setViewAsPartner}
          />
        </div>

        {viewAsPartner && (
          <div>
            <label className="text-sm font-medium mb-2 block">Partner Tier</label>
            <Select value={selectedPartnerTier} onValueChange={(value: 'silver' | 'gold' | 'platinum') => setSelectedPartnerTier(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="silver">Silver (20% off delivery)</SelectItem>
                <SelectItem value="gold">Gold (20% off delivery)</SelectItem>
                <SelectItem value="platinum">Platinum (25% off delivery)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Item Size</label>
            <Select value={selectedItemSize} onValueChange={(value: 'small' | 'medium' | 'large') => setSelectedItemSize(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Small Item</SelectItem>
                <SelectItem value="medium">Medium Item</SelectItem>
                <SelectItem value="large">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4" />
                    Large Item (Furniture, Appliances)
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">From (Seller)</label>
              <div className="flex items-center gap-2 mt-1">
                <MapPin className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600">{sellerLocation}</span>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">To (Your Location)</label>
              <Input
                placeholder="Enter your address"
                value={buyerLocation}
                onChange={(e) => setBuyerLocation(e.target.value)}
                className="mt-1"
              />
            </div>
          </div>
        </div>

        <Button 
          onClick={calculateDelivery} 
          disabled={!buyerLocation.trim() || isCalculating}
          className="w-full"
        >
          {isCalculating ? 'Calculating...' : 'Calculate Delivery'}
        </Button>

        {distance && (
          <div className={`space-y-3 p-4 rounded-lg ${viewAsPartner ? 'bg-purple-50 border border-purple-200' : 'bg-gray-50'}`}>
            <div className="flex justify-between items-center">
              <span className="font-medium">Distance:</span>
              <Badge variant={isInRange ? 'default' : 'destructive'}>
                {distance.toFixed(1)} miles
              </Badge>
            </div>
            
            {!isInRange && (
              <div className="text-red-600 text-sm">
                ⚠️ Outside 20-mile delivery radius
              </div>
            )}
            
            {isInRange && deliveryInfo && (
              <>
                <div className="space-y-2">
                  {!deliveryInfo.isLargeItem && (
                    <>
                      <div className="flex justify-between">
                        <span>Base Fee:</span>
                        <span>${deliveryInfo.baseFee.toFixed(2)}</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span>Mileage Fee:</span>
                        <span>${deliveryInfo.mileageFee.toFixed(2)}</span>
                      </div>
                    </>
                  )}
                  
                  <div className="flex justify-between">
                    <span>Sustainability Fee:</span>
                    <span className={viewAsPartner ? 'text-green-600' : ''}>
                      ${deliveryInfo.sustainabilityFee.toFixed(2)}
                      {viewAsPartner && selectedPartnerTier !== 'silver' && ' (Waived)'}
                      {viewAsPartner && selectedPartnerTier === 'silver' && ' (50% off)'}
                    </span>
                  </div>
                  
                  <div className="border-t pt-2">
                    <div className="flex justify-between text-green-600">
                      <span>Your Share (Buyer):</span>
                      <span className="font-medium">${deliveryInfo.buyerShare.toFixed(2)}</span>
                    </div>
                    
                    <div className={`flex justify-between ${viewAsPartner ? 'text-purple-600' : 'text-blue-600'}`}>
                      <span>Seller Share:</span>
                      <span className="font-medium">
                        ${deliveryInfo.sellerShare.toFixed(2)}
                        {viewAsPartner && !deliveryInfo.isLargeItem && (
                          selectedPartnerTier === 'platinum' ? ' (25% off)' : ' (20% off)'
                        )}
                      </span>
                    </div>
                  </div>
                  
                  <div className="pt-2 border-t">
                    <div className="flex justify-between font-bold">
                      <span>Total Cost to You:</span>
                      <span>${(itemPrice + deliveryInfo.buyerShare + deliveryInfo.customShippingFee).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default DeliveryCalculator;