import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CreditCard, Zap, DollarSign, Clock, MapPin, Truck, Route, Pill } from 'lucide-react';
import { useState, useEffect } from 'react';
import LargeItemDeliveryPay from './LargeItemDeliveryPay';
import GreenRouteOptimizer from './GreenRouteOptimizer';
import DriverPharmacyDashboard from './DriverPharmacyDashboard';

interface Delivery {
  id: string;
  pickup: string;
  dropoff: string;
  distance: number;
  status: 'pending' | 'in_progress' | 'completed';
  basePay: number;
  tip: number;
  type: 'standard' | 'large_item' | 'pharmacy';
}

const DriverPortalEnhanced: React.FC = () => {
  const [deliveries, setDeliveries] = useState<Delivery[]>([
    {
      id: 'DEL001',
      pickup: '123 Main St',
      dropoff: '456 Oak Ave',
      distance: 5.2,
      status: 'completed',
      basePay: 12.00,
      tip: 5.00,
      type: 'standard'
    },
    {
      id: 'DEL002',
      pickup: '789 Pine Rd',
      dropoff: '321 Elm St',
      distance: 15.8,
      status: 'completed',
      basePay: 40.00,
      tip: 15.00,
      type: 'large_item'
    },
    {
      id: 'PH001',
      pickup: 'CVS Pharmacy - 123 Main St',
      dropoff: '456 Oak Ave',
      distance: 3.2,
      status: 'completed',
      basePay: 14.00,
      tip: 8.00,
      type: 'pharmacy'
    }
  ]);

  const [paymentStatus, setPaymentStatus] = useState<{[key: string]: 'pending' | 'processing' | 'paid'}>({});
  const [activeTab, setActiveTab] = useState<'dashboard' | 'pharmacy' | 'large_items' | 'green_routes'>('dashboard');

  const calculatePay = (distance: number, type: 'standard' | 'large_item' | 'pharmacy') => {
    if (type === 'large_item') return 40;
    if (type === 'pharmacy') return 14;
    const baseFee = 10;
    const mileageRate = 1.25;
    return (baseFee + (distance * mileageRate)) / 2;
  };

  const processInstantPayment = async (deliveryId: string, amount: number) => {
    setPaymentStatus(prev => ({ ...prev, [deliveryId]: 'processing' }));
    
    try {
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/4f9b62c2-db04-4293-88fb-fce001aa326c',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            deliveryId,
            driverPay: amount,
            tipAmount: deliveries.find(d => d.id === deliveryId)?.tip || 0,
            driverId: 'driver-123',
            bankAccount: 'xxxx-1234'
          })
        }
      );
      
      const result = await response.json();
      
      if (result.success) {
        setPaymentStatus(prev => ({ ...prev, [deliveryId]: 'paid' }));
      }
    } catch (error) {
      console.error('Payment failed:', error);
    }
  };

  const totalEarnings = deliveries
    .filter(d => d.status === 'completed')
    .reduce((sum, d) => sum + d.basePay + d.tip, 0);

  const getDeliveryIcon = (type: string) => {
    switch (type) {
      case 'pharmacy': return <Pill className="w-3 h-3 mr-1" />;
      case 'large_item': return <Truck className="w-3 h-3 mr-1" />;
      default: return null;
    }
  };

  const getDeliveryColor = (type: string) => {
    switch (type) {
      case 'pharmacy': return 'bg-blue-600 text-white';
      case 'large_item': return 'bg-green-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  return (
    <div className="space-y-6 p-6">
      <Tabs value={activeTab} onValueChange={(value: any) => setActiveTab(value)}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="pharmacy" className="flex items-center gap-2">
            <Pill className="w-4 h-4" />
            Pharmacy
          </TabsTrigger>
          <TabsTrigger value="green_routes" className="flex items-center gap-2">
            <Route className="w-4 h-4" />
            Green Routes
          </TabsTrigger>
          <TabsTrigger value="large_items" className="flex items-center gap-2">
            <Truck className="w-4 h-4" />
            Large Items
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pharmacy">
          <DriverPharmacyDashboard />
        </TabsContent>

        <TabsContent value="green_routes">
          <GreenRouteOptimizer />
        </TabsContent>
        
        <TabsContent value="large_items">
          <LargeItemDeliveryPay />
        </TabsContent>
        
        <TabsContent value="dashboard">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-500" />
                Driver Dashboard - Instant Payments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-green-50 p-4 rounded-lg mb-4">
                <div className="flex items-center justify-between">
                  <span className="font-semibold">Total Earnings Today:</span>
                  <span className="text-2xl font-bold text-green-600">${totalEarnings.toFixed(2)}</span>
                </div>
              </div>
              
              <div className="space-y-4">
                {deliveries.map((delivery) => {
                  const calculatedPay = calculatePay(delivery.distance, delivery.type as any);
                  const totalPayout = calculatedPay + delivery.tip;
                  const status = paymentStatus[delivery.id] || 'pending';
                  
                  return (
                    <div key={delivery.id} className={`border rounded-lg p-4 ${
                      delivery.type === 'large_item' ? 'border-green-300 bg-green-50' : 
                      delivery.type === 'pharmacy' ? 'border-blue-300 bg-blue-50' : ''
                    }`}>
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h3 className="font-semibold flex items-center gap-2">
                            Delivery #{delivery.id}
                            <Badge className={getDeliveryColor(delivery.type)}>
                              {getDeliveryIcon(delivery.type)}
                              {delivery.type === 'pharmacy' ? 'Pharmacy' : 
                               delivery.type === 'large_item' ? 'Large Item' : 'Standard'}
                            </Badge>
                          </h3>
                          <div className="text-sm text-gray-600 space-y-1">
                            <div className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              <span>{delivery.pickup} → {delivery.dropoff}</span>
                            </div>
                            <div>{delivery.distance} miles</div>
                          </div>
                        </div>
                        <Badge variant={delivery.status === 'completed' ? 'default' : 'secondary'}>
                          {delivery.status}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 mb-3">
                        <div>
                          <div className="text-sm text-gray-600">Base Pay</div>
                          <div className="font-semibold">${calculatedPay.toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Tips (100%)</div>
                          <div className="font-semibold text-green-600">+${delivery.tip.toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Total</div>
                          <div className="font-bold">${totalPayout.toFixed(2)}</div>
                        </div>
                      </div>
                      
                      {delivery.status === 'completed' && (
                        <div>
                          {status === 'pending' && (
                            <Button 
                              onClick={() => processInstantPayment(delivery.id, calculatedPay)}
                              className="w-full bg-green-600 hover:bg-green-700"
                            >
                              <CreditCard className="w-4 h-4 mr-2" />
                              Get Paid Instantly - ${totalPayout.toFixed(2)}
                            </Button>
                          )}
                          
                          {status === 'processing' && (
                            <div className="text-center py-2">
                              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-green-600 mx-auto mb-1"></div>
                              <p className="text-sm">Processing payment...</p>
                            </div>
                          )}
                          
                          {status === 'paid' && (
                            <div className="bg-green-100 p-3 rounded-lg">
                              <div className="flex items-center gap-2 text-green-800">
                                <DollarSign className="w-4 h-4" />
                                <span className="font-medium">Paid ${totalPayout.toFixed(2)} - In your account now!</span>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DriverPortalEnhanced;