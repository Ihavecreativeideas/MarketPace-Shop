import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Copy, ExternalLink, Settings, Webhook, Key, TestTube } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PartnerIntegrationWizardProps {
  partnerTier: 'silver' | 'gold' | 'platinum';
  onComplete: () => void;
}

const PartnerIntegrationWizard: React.FC<PartnerIntegrationWizardProps> = ({ 
  partnerTier, 
  onComplete 
}) => {
  const [activeTab, setActiveTab] = useState('credentials');
  const [formData, setFormData] = useState({
    websiteUrl: '',
    webhookUrl: '',
    businessName: '',
    contactEmail: ''
  });
  const { toast } = useToast();

  const apiCredentials = {
    apiKey: 'pk_live_' + Math.random().toString(36).substr(2, 24),
    secretKey: 'sk_live_' + Math.random().toString(36).substr(2, 24),
    webhookSecret: 'whsec_' + Math.random().toString(36).substr(2, 20)
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: 'Copied!',
      description: `${label} copied to clipboard`
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const testConnection = async () => {
    toast({
      title: 'Testing Connection...',
      description: 'Validating your integration setup'
    });
    
    // Simulate API test
    setTimeout(() => {
      toast({
        title: 'Connection Successful!',
        description: 'Your integration is working correctly'
      });
    }, 2000);
  };

  const codeExamples = {
    javascript: `// Initialize the SDK
const client = new PartnerAPI({
  apiKey: '${apiCredentials.apiKey}',
  environment: 'production'
});

// Create a delivery request
const delivery = await client.deliveries.create({
  pickup: {
    address: '123 Main St',
    contact: 'John Doe'
  },
  dropoff: {
    address: '456 Oak Ave',
    contact: 'Jane Smith'
  }
});`,
    curl: `curl -X POST https://api.yourplatform.com/v1/deliveries \
  -H "Authorization: Bearer ${apiCredentials.apiKey}" \
  -H "Content-Type: application/json" \
  -d '{
    "pickup": {
      "address": "123 Main St",
      "contact": "John Doe"
    },
    "dropoff": {
      "address": "456 Oak Ave",
      "contact": "Jane Smith"
    }
  }'`
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 p-6">
      <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Settings className="h-8 w-8 text-purple-600" />
              <div>
                <h2 className="text-2xl font-bold text-purple-800">
                  Integration Wizard
                </h2>
                <p className="text-sm text-purple-600 mt-1">
                  Set up your website integration in minutes
                </p>
              </div>
            </div>
            <Badge className="bg-purple-600 text-white">
              {partnerTier.toUpperCase()}
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="credentials" className="flex items-center gap-2">
            <Key className="h-4 w-4" />
            Credentials
          </TabsTrigger>
          <TabsTrigger value="setup" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Setup
          </TabsTrigger>
          <TabsTrigger value="webhooks" className="flex items-center gap-2">
            <Webhook className="h-4 w-4" />
            Webhooks
          </TabsTrigger>
          <TabsTrigger value="testing" className="flex items-center gap-2">
            <TestTube className="h-4 w-4" />
            Testing
          </TabsTrigger>
        </TabsList>

        <TabsContent value="credentials" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>API Credentials</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Public API Key</Label>
                <div className="flex gap-2">
                  <Input value={apiCredentials.apiKey} readOnly className="font-mono" />
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyToClipboard(apiCredentials.apiKey, 'API Key')}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Secret Key</Label>
                <div className="flex gap-2">
                  <Input value={apiCredentials.secretKey} readOnly className="font-mono" />
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyToClipboard(apiCredentials.secretKey, 'Secret Key')}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800">
                  <strong>Important:</strong> Keep your secret key secure and never expose it in client-side code.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="setup" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Business Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Business Name</Label>
                  <Input 
                    value={formData.businessName}
                    onChange={(e) => handleInputChange('businessName', e.target.value)}
                    placeholder="Your Business Name"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Contact Email</Label>
                  <Input 
                    type="email"
                    value={formData.contactEmail}
                    onChange={(e) => handleInputChange('contactEmail', e.target.value)}
                    placeholder="contact@yourbusiness.com"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Website URL</Label>
                <Input 
                  value={formData.websiteUrl}
                  onChange={(e) => handleInputChange('websiteUrl', e.target.value)}
                  placeholder="https://yourbusiness.com"
                />
              </div>

              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="pt-4">
                  <h4 className="font-semibold mb-2">Code Example</h4>
                  <Tabs defaultValue="javascript" className="w-full">
                    <TabsList>
                      <TabsTrigger value="javascript">JavaScript</TabsTrigger>
                      <TabsTrigger value="curl">cURL</TabsTrigger>
                    </TabsList>
                    <TabsContent value="javascript">
                      <pre className="text-xs bg-gray-900 text-green-400 p-3 rounded overflow-x-auto">
                        {codeExamples.javascript}
                      </pre>
                    </TabsContent>
                    <TabsContent value="curl">
                      <pre className="text-xs bg-gray-900 text-green-400 p-3 rounded overflow-x-auto">
                        {codeExamples.curl}
                      </pre>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="webhooks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Webhook Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Webhook URL</Label>
                <Input 
                  value={formData.webhookUrl}
                  onChange={(e) => handleInputChange('webhookUrl', e.target.value)}
                  placeholder="https://yourbusiness.com/webhooks/delivery"
                />
              </div>
              
              <div className="space-y-2">
                <Label>Webhook Secret</Label>
                <div className="flex gap-2">
                  <Input value={apiCredentials.webhookSecret} readOnly className="font-mono" />
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => copyToClipboard(apiCredentials.webhookSecret, 'Webhook Secret')}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">Webhook Events</h4>
                <ul className="text-sm text-green-700 space-y-1">
                  <li>• delivery.created - New delivery request</li>
                  <li>• delivery.updated - Delivery status change</li>
                  <li>• delivery.completed - Delivery finished</li>
                  <li>• payment.processed - Payment completed</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="testing" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Test Your Integration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <Button 
                  onClick={testConnection}
                  className="flex items-center gap-2"
                >
                  <TestTube className="h-4 w-4" />
                  Test API Connection
                </Button>
                
                <Button 
                  variant="outline"
                  className="flex items-center gap-2"
                  onClick={() => window.open('https://docs.yourplatform.com', '_blank')}
                >
                  <ExternalLink className="h-4 w-4" />
                  View Documentation
                </Button>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold mb-2">Integration Checklist</h4>
                <div className="space-y-2 text-sm">
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded" />
                    API credentials configured
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded" />
                    Webhook endpoint set up
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded" />
                    Test delivery created successfully
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded" />
                    Webhook events received
                  </label>
                </div>
              </div>

              <Button 
                onClick={onComplete}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                Complete Integration Setup
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PartnerIntegrationWizard;