import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Music, Store, Users, Crown, ArrowRight } from 'lucide-react';
import ProfileSubscriptionManager from './ProfileSubscriptionManager';

interface SubscriptionDetectorProps {
  userId: string;
}

interface UserProfile {
  type: 'musician' | 'marketplace' | 'pacemaker';
  name: string;
  created_at: string;
  subscription?: any;
}

const SubscriptionDetector: React.FC<SubscriptionDetectorProps> = ({ userId }) => {
  const [userProfiles, setUserProfiles] = useState<UserProfile[]>([]);
  const [selectedProfile, setSelectedProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserProfiles();
  }, [userId]);

  const fetchUserProfiles = async () => {
    try {
      // Mock data - in real app, fetch from Supabase
      const mockProfiles: UserProfile[] = [
        {
          type: 'musician',
          name: 'John Doe Music',
          created_at: '2024-01-15',
          subscription: null
        },
        {
          type: 'pacemaker',
          name: 'Local Coffee Shop',
          created_at: '2024-02-01',
          subscription: null
        }
      ];
      
      setUserProfiles(mockProfiles);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching profiles:', error);
      setLoading(false);
    }
  };

  const getProfileIcon = (type: string) => {
    switch (type) {
      case 'musician': return <Music className="w-6 h-6 text-purple-600" />;
      case 'marketplace': return <Store className="w-6 h-6 text-blue-600" />;
      case 'pacemaker': return <Users className="w-6 h-6 text-green-600" />;
      default: return <Store className="w-6 h-6" />;
    }
  };

  const getProfileLabel = (type: string) => {
    switch (type) {
      case 'musician': return 'Musician Profile';
      case 'marketplace': return 'Marketplace Profile';
      case 'pacemaker': return 'PaceMaker Business';
      default: return 'Profile';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (selectedProfile) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            onClick={() => setSelectedProfile(null)}
            className="flex items-center gap-2"
          >
            ← Back to Profiles
          </Button>
          <div className="flex items-center gap-2">
            {getProfileIcon(selectedProfile.type)}
            <span className="font-medium">{selectedProfile.name}</span>
          </div>
        </div>
        
        <ProfileSubscriptionManager
          profileType={selectedProfile.type}
          userId={userId}
          onSubscriptionChange={(subscription) => {
            setUserProfiles(prev => 
              prev.map(p => 
                p.type === selectedProfile.type 
                  ? { ...p, subscription }
                  : p
              )
            );
          }}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          Choose Profile to Upgrade
        </h1>
        <p className="text-gray-600">
          Select which profile you'd like to upgrade with subscription benefits
        </p>
      </div>

      {userProfiles.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-gray-600 mb-4">No profiles found.</p>
            <p className="text-sm text-gray-500">
              Create a musician profile, marketplace account, or PaceMaker business to access subscriptions.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {userProfiles.map((profile, index) => (
            <Card 
              key={index} 
              className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-purple-300"
              onClick={() => setSelectedProfile(profile)}
            >
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {getProfileIcon(profile.type)}
                    <span className="text-lg">{profile.name}</span>
                  </div>
                  {profile.subscription && (
                    <Badge className="bg-green-100 text-green-800">
                      <Crown className="w-3 h-3 mr-1" />
                      Pro
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Profile Type:</span>
                    <span className="font-medium">{getProfileLabel(profile.type)}</span>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Created:</span>
                    <span className="font-medium">
                      {new Date(profile.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Status:</span>
                    <Badge variant={profile.subscription ? 'default' : 'secondary'}>
                      {profile.subscription ? 'Subscribed' : 'Free'}
                    </Badge>
                  </div>
                  
                  <div className="pt-2 border-t">
                    <Button className="w-full" variant="outline">
                      <span>Upgrade Profile</span>
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default SubscriptionDetector;