import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Route, Clock, Truck, Package } from 'lucide-react';
import { useState } from 'react';

interface RouteStop {
  id: string;
  type: 'pickup' | 'dropoff';
  address: string;
  orderId: string;
  customerName: string;
  items?: string[];
  priority: 'urgent' | 'grow';
  coordinates?: { lat: number; lng: number };
}

interface OptimizedRoute {
  stops: RouteStop[];
  totalDistance: number;
  estimatedTime: number;
  totalEarnings: number;
}

const GreenRouteOptimizer: React.FC = () => {
  const [routeStops] = useState<RouteStop[]>([
    { id: '1', type: 'pickup', address: '123 Seller Ave', orderId: 'ORD-001', customerName: 'John Seller', items: ['Electronics'], priority: 'grow' },
    { id: '2', type: 'dropoff', address: '456 Buyer St', orderId: 'ORD-001', customerName: 'Jane Buyer', priority: 'grow' },
    { id: '3', type: 'pickup', address: '789 Store Rd', orderId: 'ORD-002', customerName: 'Mike Store', items: ['Books'], priority: 'urgent' },
    { id: '4', type: 'dropoff', address: '321 Customer Ln', orderId: 'ORD-002', customerName: 'Sarah Customer', priority: 'urgent' },
    { id: '5', type: 'pickup', address: '654 Shop Blvd', orderId: 'ORD-003', customerName: 'Tom Shop', items: ['Groceries'], priority: 'grow' },
    { id: '6', type: 'dropoff', address: '987 Home Dr', orderId: 'ORD-003', customerName: 'Lisa Home', priority: 'grow' }
  ]);

  const [optimizedRoute, setOptimizedRoute] = useState<OptimizedRoute | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const optimizeGreenRoute = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Fallback optimization without external API call
      const urgentStops = routeStops.filter(stop => stop.priority === 'urgent');
      const growStops = routeStops.filter(stop => stop.priority === 'grow');
      
      const optimizedStops: RouteStop[] = [];
      
      // Add urgent pickups first, then their dropoffs
      urgentStops.filter(s => s.type === 'pickup').forEach(pickup => {
        optimizedStops.push(pickup);
        const dropoff = urgentStops.find(s => s.orderId === pickup.orderId && s.type === 'dropoff');
        if (dropoff) optimizedStops.push(dropoff);
      });
      
      // Add grow route pickups, then all dropoffs
      const growPickups = growStops.filter(s => s.type === 'pickup');
      optimizedStops.push(...growPickups);
      
      const growDropoffs = growStops.filter(s => s.type === 'dropoff');
      optimizedStops.push(...growDropoffs);
      
      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setOptimizedRoute({
        stops: optimizedStops,
        totalDistance: 12.5,
        estimatedTime: 85,
        totalEarnings: 24.50
      });
    } catch (error) {
      console.error('Route optimization error:', error);
      setError('Failed to optimize route. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getStopIcon = (type: string) => {
    return type === 'pickup' ? Package : MapPin;
  };

  const getPriorityColor = (priority: string) => {
    return priority === 'urgent' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Route className="w-6 h-6 text-green-600" />
            Green Route Optimizer
          </CardTitle>
        </CardHeader>
        <CardContent>
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold">Available Stops</h3>
              {routeStops.map((stop) => {
                const Icon = getStopIcon(stop.type);
                return (
                  <Card key={stop.id} className="hover:shadow-md transition-all">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Icon className={`w-5 h-5 mt-1 ${
                          stop.type === 'pickup' ? 'text-blue-600' : 'text-green-600'
                        }`} />
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant={stop.type === 'pickup' ? 'default' : 'secondary'}>
                              {stop.type === 'pickup' ? 'Pickup' : 'Dropoff'}
                            </Badge>
                            <Badge className={getPriorityColor(stop.priority)}>
                              {stop.priority}
                            </Badge>
                          </div>
                          <div className="text-sm font-medium">{stop.customerName}</div>
                          <div className="text-sm text-gray-600">{stop.address}</div>
                          {stop.items && (
                            <div className="text-xs text-gray-500 mt-1">
                              Items: {stop.items.join(', ')}
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold">Optimized Route</h3>
                <Button 
                  onClick={optimizeGreenRoute}
                  disabled={loading}
                  className="bg-gradient-to-r from-green-600 to-blue-600"
                >
                  {loading ? 'Optimizing...' : 'Optimize Route'}
                </Button>
              </div>
              
              {!optimizedRoute && !loading && (
                <Card className="bg-gray-50">
                  <CardContent className="p-4 text-center text-gray-600">
                    Click "Optimize Route" to create the most efficient delivery path
                  </CardContent>
                </Card>
              )}
              
              {optimizedRoute && (
                <div className="space-y-4">
                  <Card className="bg-gradient-to-r from-green-50 to-blue-50">
                    <CardContent className="p-4">
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <div className="text-xl font-bold text-green-600">${optimizedRoute.totalEarnings}</div>
                          <div className="text-xs text-gray-600">Earnings</div>
                        </div>
                        <div>
                          <div className="text-xl font-bold text-blue-600">{optimizedRoute.totalDistance} mi</div>
                          <div className="text-xs text-gray-600">Distance</div>
                        </div>
                        <div>
                          <div className="text-xl font-bold text-purple-600">{optimizedRoute.estimatedTime}m</div>
                          <div className="text-xs text-gray-600">Time</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Truck className="w-5 h-5" />
                        Route Sequence
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {optimizedRoute.stops.map((stop, index) => {
                        const Icon = getStopIcon(stop.type);
                        return (
                          <div key={`${stop.id}-${index}`} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                            <div className="w-8 h-8 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                              {index + 1}
                            </div>
                            <Icon className={`w-4 h-4 ${
                              stop.type === 'pickup' ? 'text-blue-600' : 'text-green-600'
                            }`} />
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <Badge variant={stop.type === 'pickup' ? 'default' : 'secondary'} className="text-xs">
                                  {stop.type}
                                </Badge>
                                <Badge className={`${getPriorityColor(stop.priority)} text-xs`}>
                                  {stop.priority}
                                </Badge>
                              </div>
                              <div className="text-sm font-medium">{stop.customerName}</div>
                              <div className="text-xs text-gray-600">{stop.address}</div>
                            </div>
                          </div>
                        );
                      })}
                    </CardContent>
                  </Card>
                  
                  <Button className="w-full bg-gradient-to-r from-green-600 to-blue-600">
                    Start Green Route
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GreenRouteOptimizer;