import React from 'react';
import { Button } from '@/components/ui/button';
import { Facebook, ExternalLink } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface FacebookShareButtonProps {
  product: {
    id: number;
    name: string;
    price: string;
    description?: string;
    image: string;
    shop: string;
  };
  variant?: 'default' | 'outline';
  size?: 'sm' | 'default' | 'lg';
  className?: string;
}

const FacebookShareButton: React.FC<FacebookShareButtonProps> = ({
  product,
  variant = 'outline',
  size = 'default',
  className = ''
}) => {
  const shareToFacebook = () => {
    const fbText = `${product.name}\n\n${product.description || 'Check out this amazing item!'}\n\nPrice: ${product.price}\n\nFrom: ${product.shop}\n\nContact me for more details!`;
    
    // Share to Facebook Page
    const fbPageUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${encodeURIComponent(fbText)}`;
    
    window.open(fbPageUrl, '_blank', 'width=600,height=400');
    
    toast({ 
      title: 'Sharing to Facebook', 
      description: 'Opening Facebook share dialog...' 
    });
  };

  const shareToFacebookMarketplace = () => {
    const fbText = `${product.name}\n\n${product.description || 'Check out this amazing item!'}\n\nPrice: ${product.price}\n\nContact me for more details!`;
    
    // Facebook Marketplace URL (opens marketplace creation page)
    const fbMarketplaceUrl = `https://www.facebook.com/marketplace/create/item?title=${encodeURIComponent(product.name)}&description=${encodeURIComponent(fbText)}&price=${encodeURIComponent(product.price.replace('$', ''))}`;
    
    window.open(fbMarketplaceUrl, '_blank');
    
    toast({ 
      title: 'Opening Facebook Marketplace', 
      description: 'Redirecting to Facebook Marketplace...' 
    });
  };

  return (
    <div className={`flex gap-2 ${className}`}>
      <Button
        variant={variant}
        size={size}
        onClick={shareToFacebook}
        className="flex-1 text-blue-600 border-blue-600 hover:bg-blue-50"
      >
        <Facebook className="w-4 h-4 mr-2" />
        Share to Facebook
      </Button>
      <Button
        variant={variant}
        size={size}
        onClick={shareToFacebookMarketplace}
        className="flex-1 text-blue-800 border-blue-800 hover:bg-blue-50"
      >
        <ExternalLink className="w-4 h-4 mr-2" />
        FB Marketplace
      </Button>
    </div>
  );
};

export default FacebookShareButton;