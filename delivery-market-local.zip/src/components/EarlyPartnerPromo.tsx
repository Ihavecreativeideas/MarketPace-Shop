import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Diamond, Clock, Users, Sparkles, Star, TrendingUp, Shield, Zap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import { useNavigate } from 'react-router-dom';
import GrowingRoutesSection from './GrowingRoutesSection';
import FreeAccessPromotion from './FreeAccessPromotion';

interface EarlyPartnerPromoProps {
  userId?: string;
  onSubscriptionChange?: () => void;
  isMarketplaceMember?: boolean;
  isPartner?: boolean;
}

const EarlyPartnerPromo: React.FC<EarlyPartnerPromoProps> = ({ 
  userId, 
  onSubscriptionChange,
  isMarketplaceMember = false,
  isPartner = false
}) => {
  const [partnersCount, setPartnersCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const remainingSlots = Math.max(0, 50 - partnersCount);
  const isPromoActive = remainingSlots > 0;

  useEffect(() => {
    fetchPartnersCount();
  }, []);

  const fetchPartnersCount = async () => {
    try {
      const { count, error } = await supabase
        .from('users')
        .select('*', { count: 'exact', head: true })
        .eq('subscription_tier', 'platinum')
        .not('early_partner_promo', 'is', null);

      if (error) throw error;
      setPartnersCount(count || 0);
    } catch (error) {
      console.error('Error fetching partners count:', error);
    }
  };

  const handleFreeAccessSignup = () => {
    // Navigate to the comprehensive signup form
    navigate('/partner-signup-form');
  };

  if (!isPromoActive) {
    return (
      <Card className="border-2 border-gray-300 bg-gray-50">
        <CardHeader className="text-center">
          <Badge variant="secondary" className="mx-auto mb-2">
            Promotion Ended
          </Badge>
          <CardTitle className="text-2xl text-gray-600">
            Free Access Period Ended
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          <p className="text-gray-500 mb-4">
            The free access promotion has ended. 
            Regular pricing now applies for all partnership tiers.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <GrowingRoutesSection />
      
      {/* Show promotion to non-partners */}
      <FreeAccessPromotion 
        isMarketplaceMember={isMarketplaceMember}
        isPartner={isPartner}
      />
      
      <Card className="border-2 border-green-500 bg-gradient-to-br from-green-50 to-blue-50 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-400 to-blue-400 rounded-full -translate-y-16 translate-x-16 opacity-20" />
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-green-300 to-blue-300 rounded-full translate-y-12 -translate-x-12 opacity-20" />
        
        <CardHeader className="text-center relative z-10">
          <Badge className="mx-auto mb-2 bg-gradient-to-r from-green-500 to-blue-500 text-white">
            <Sparkles className="w-3 h-3 mr-1" />
            FREE ACCESS FOR A LIMITED TIME
          </Badge>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
            Join MarketPace Today
          </CardTitle>
          <p className="text-lg text-gray-700 font-medium">
            Get 3 Months Completely FREE
          </p>
        </CardHeader>
        
        <CardContent className="relative z-10">
          <div className="text-center mb-6">
            <div className="flex items-center justify-center gap-4 mb-4">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-green-600" />
                <span className="font-semibold">{partnersCount}/50 Joined</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-600" />
                <span className="font-semibold">{remainingSlots} Spots Left</span>
              </div>
            </div>
            
            <div className="bg-white rounded-lg p-4 mb-6 border border-green-200">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Diamond className="w-6 h-6 text-green-600" />
                <span className="text-xl font-bold">Full Platform Access</span>
              </div>
              <div className="flex items-center justify-center gap-4">
                <span className="text-3xl font-bold text-green-600">FREE</span>
                <Badge className="bg-green-500">
                  3 MONTHS
                </Badge>
              </div>
              <p className="text-sm text-gray-600 mt-1">No credit card required</p>
            </div>
            
            <div className="text-left mb-6">
              <h3 className="text-lg font-bold text-center mb-4 text-gray-800">Everything You Get With MarketPace:</h3>
              
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-3 bg-white rounded-lg p-3 border border-green-100">
                  <TrendingUp className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <div className="font-semibold text-green-600">Reach More Customers</div>
                    <div className="text-gray-600">Get discovered by thousands of local shoppers actively looking for your products and services</div>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 bg-white rounded-lg p-3 border border-green-100">
                  <Zap className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <div className="font-semibold text-blue-600">Flexible Delivery Options</div>
                    <div className="text-gray-600">Choose MarketPace drivers, UPS, FedEx, DoorDash, or handle delivery yourself - you're in control</div>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 bg-white rounded-lg p-3 border border-green-100">
                  <Shield className="w-5 h-5 text-purple-600 mt-0.5" />
                  <div>
                    <div className="font-semibold text-purple-600">Zero Platform Fees</div>
                    <div className="text-gray-600">Keep 100% of your sales - no commission fees, no hidden charges, just pure profit</div>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 bg-white rounded-lg p-3 border border-green-100">
                  <Star className="w-5 h-5 text-yellow-600 mt-0.5" />
                  <div>
                    <div className="font-semibold text-yellow-600">Professional Business Profile</div>
                    <div className="text-gray-600">Showcase your business with photos, descriptions, hours, and customer reviews</div>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 bg-white rounded-lg p-3 border border-green-100">
                  <Diamond className="w-5 h-5 text-indigo-600 mt-0.5" />
                  <div>
                    <div className="font-semibold text-indigo-600">Advanced Analytics & AI Tools</div>
                    <div className="text-gray-600">Track sales, understand customers, and get AI-powered recommendations to grow your business</div>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 bg-white rounded-lg p-3 border border-green-100">
                  <Sparkles className="w-5 h-5 text-pink-600 mt-0.5" />
                  <div>
                    <div className="font-semibold text-pink-600">Marketing & Promotion Tools</div>
                    <div className="text-gray-600">Built-in social sharing, promotional campaigns, and customer engagement features</div>
                  </div>
                </div>
              </div>
            </div>
            
            <Button 
              size="lg" 
              className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-bold py-3 text-lg"
              onClick={handleFreeAccessSignup}
              disabled={loading}
            >
              {loading ? 'Processing...' : 'Get FREE Access Now - No Credit Card Required'}
            </Button>
            
            <p className="text-xs text-gray-500 mt-3">
              Limited time offer for the first 50 businesses. Start reaching more customers today with zero risk and zero cost.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EarlyPartnerPromo;