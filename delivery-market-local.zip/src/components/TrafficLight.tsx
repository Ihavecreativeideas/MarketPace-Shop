import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/components/CartContext';
import { supabase } from '@/lib/supabase';

type RouteStatus = 'none' | 'growing' | 'in-route';

interface GrowRoute {
  id: string;
  status: string;
  created_at: string;
  delivery_time: string;
}

export const TrafficLight = () => {
  const [routeStatus, setRouteStatus] = useState<RouteStatus>('none');
  const { openCart } = useCart();

  useEffect(() => {
    const checkRouteStatus = async () => {
      try {
        const { data: routes, error } = await supabase
          .from('grow_routes')
          .select('*')
          .in('status', ['growing', 'in_route'])
          .order('created_at', { ascending: false })
          .limit(1);

        if (error) {
          console.error('Error fetching routes:', error);
          return;
        }

        if (!routes || routes.length === 0) {
          setRouteStatus('none');
          return;
        }

        const route = routes[0] as GrowRoute;
        const now = new Date();
        const createdAt = new Date(route.created_at);
        const threeHoursLater = new Date(createdAt.getTime() + 3 * 60 * 60 * 1000);

        if (route.status === 'in_route') {
          setRouteStatus('in-route');
        } else if (route.status === 'growing' && now < threeHoursLater) {
          setRouteStatus('growing');
        } else {
          setRouteStatus('none');
        }
      } catch (error) {
        console.error('Error checking route status:', error);
        setRouteStatus('none');
      }
    };

    checkRouteStatus();
    const interval = setInterval(checkRouteStatus, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const getTrafficLightColor = () => {
    switch (routeStatus) {
      case 'none':
        return 'bg-red-500';
      case 'growing':
        return 'bg-yellow-500';
      case 'in-route':
        return 'bg-green-500';
      default:
        return 'bg-red-500';
    }
  };

  const getTooltipText = () => {
    switch (routeStatus) {
      case 'none':
        return 'No routes in progress';
      case 'growing':
        return 'Growing Route - Join for discount!';
      case 'in-route':
        return 'Route in progress - 5% off available';
      default:
        return 'Click to view cart';
    }
  };

  return (
    <Button
      onClick={openCart}
      className="fixed bottom-4 left-4 w-16 h-16 rounded-full p-0 shadow-lg hover:shadow-xl transition-all duration-300 z-50"
      title={getTooltipText()}
      variant="outline"
    >
      <div className="relative w-12 h-12 bg-gray-800 rounded-full flex items-center justify-center">
        <div className={`w-8 h-8 rounded-full ${getTrafficLightColor()} animate-pulse shadow-inner`} />
      </div>
    </Button>
  );
};