import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Star, User, ThumbsUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface RatingProps {
  orderId: string;
  driverId?: string;
  vendorId?: string;
  onSubmit: (rating: number, review: string) => void;
}

export const RatingForm: React.FC<RatingProps> = ({ orderId, driverId, vendorId, onSubmit }) => {
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [hoveredStar, setHoveredStar] = useState(0);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (rating === 0) return;
    
    setSubmitting(true);
    try {
      const reviewData = {
        order_id: orderId,
        rating,
        review,
        created_at: new Date().toISOString()
      };

      if (driverId) {
        await supabase.from('driver_reviews').insert({ ...reviewData, driver_id: driverId });
      }
      if (vendorId) {
        await supabase.from('vendor_reviews').insert({ ...reviewData, vendor_id: vendorId });
      }

      onSubmit(rating, review);
    } catch (error) {
      console.error('Error submitting review:', error);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Rate Your Experience</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              onClick={() => setRating(star)}
              onMouseEnter={() => setHoveredStar(star)}
              onMouseLeave={() => setHoveredStar(0)}
              className="p-1"
            >
              <Star
                className={`h-8 w-8 ${
                  star <= (hoveredStar || rating)
                    ? 'text-yellow-500 fill-yellow-500'
                    : 'text-gray-300'
                }`}
              />
            </button>
          ))}
        </div>
        
        <Textarea
          placeholder="Share your experience (optional)"
          value={review}
          onChange={(e) => setReview(e.target.value)}
          rows={3}
        />
        
        <Button 
          onClick={handleSubmit}
          disabled={rating === 0 || submitting}
          className="w-full"
        >
          {submitting ? 'Submitting...' : 'Submit Review'}
        </Button>
      </CardContent>
    </Card>
  );
};

interface Review {
  id: string;
  rating: number;
  review: string;
  created_at: string;
  user_name?: string;
}

interface ReviewDisplayProps {
  reviews: Review[];
  averageRating: number;
  totalReviews: number;
}

export const ReviewDisplay: React.FC<ReviewDisplayProps> = ({ 
  reviews, 
  averageRating, 
  totalReviews 
}) => {
  const [showAll, setShowAll] = useState(false);
  const displayedReviews = showAll ? reviews : reviews.slice(0, 3);

  const getRatingDistribution = () => {
    const distribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    reviews.forEach(review => {
      distribution[review.rating as keyof typeof distribution]++;
    });
    return distribution;
  };

  const distribution = getRatingDistribution();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Reviews</span>
          <div className="flex items-center space-x-2">
            <div className="flex items-center">
              <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
              <span className="ml-1 font-semibold">{averageRating.toFixed(1)}</span>
            </div>
            <Badge variant="secondary">{totalReviews} reviews</Badge>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Rating Distribution */}
        <div className="space-y-2">
          {[5, 4, 3, 2, 1].map((stars) => {
            const count = distribution[stars as keyof typeof distribution];
            const percentage = totalReviews > 0 ? (count / totalReviews) * 100 : 0;
            
            return (
              <div key={stars} className="flex items-center space-x-2 text-sm">
                <span className="w-3">{stars}</span>
                <Star className="h-3 w-3 text-yellow-500" />
                <div className="flex-1 bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-yellow-500 h-2 rounded-full" 
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <span className="w-8 text-right">{count}</span>
              </div>
            );
          })}
        </div>

        {/* Individual Reviews */}
        <div className="space-y-4">
          {displayedReviews.map((review) => (
            <div key={review.id} className="border-b pb-4 last:border-b-0">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <User className="h-4 w-4 text-gray-400" />
                  <span className="font-medium">{review.user_name || 'Anonymous'}</span>
                  <div className="flex items-center">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-3 w-3 ${
                          star <= review.rating
                            ? 'text-yellow-500 fill-yellow-500'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <span className="text-sm text-gray-500">
                  {new Date(review.created_at).toLocaleDateString()}
                </span>
              </div>
              {review.review && (
                <p className="text-gray-700 text-sm">{review.review}</p>
              )}
              <div className="flex items-center mt-2">
                <Button size="sm" variant="ghost" className="text-xs">
                  <ThumbsUp className="h-3 w-3 mr-1" />
                  Helpful
                </Button>
              </div>
            </div>
          ))}
        </div>

        {reviews.length > 3 && (
          <Button 
            variant="outline" 
            onClick={() => setShowAll(!showAll)}
            className="w-full"
          >
            {showAll ? 'Show Less' : `Show All ${totalReviews} Reviews`}
          </Button>
        )}
      </CardContent>
    </Card>
  );
};