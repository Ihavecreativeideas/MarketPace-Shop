import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, Pill, Truck, Bell, Bot, ShoppingBag, Music, Package, Heart, Star, Store, Building2, Share2, Zap, FileText } from 'lucide-react';
import { ThemeToggle } from '@/components/ThemeToggle';
import PreLaunchCart from '@/components/PreLaunchCart';
import { useCart } from '@/components/CartContext';

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const { cartItems, openCart } = useCart();

  const navItems = [
    { name: 'Home', path: '/', icon: null },
    { name: 'Marketplace', path: '/marketplace', icon: <ShoppingBag className="w-4 h-4" /> },
    { name: 'PaceMakers', path: '/pacemakers', icon: <Heart className="w-4 h-4" /> },
    { name: 'Musicians', path: '/musicians', icon: <Music className="w-4 h-4" /> },
    { name: 'Subscriptions', path: '/subscriptions', icon: <Star className="w-4 h-4" /> },
    { name: 'Integrations', path: '/integrations', icon: <Zap className="w-4 h-4" /> },
    { name: 'Business Setup', path: '/business-setup', icon: <FileText className="w-4 h-4" /> },
    { name: 'Partner Flyer', path: '/partner-signup', icon: <Share2 className="w-4 h-4" /> },
    { name: 'Partner Signup', path: '/marketplace-partner', icon: <Store className="w-4 h-4" /> },
    { name: 'Business Dashboard', path: '/business-dashboard', icon: <Building2 className="w-4 h-4" /> },
    { name: 'MedPace', path: '/medpace', icon: <Pill className="w-4 h-4" /> },
    { name: 'PostPace', path: '/postpace', icon: <Package className="w-4 h-4" /> },
    { name: 'Driver Portal', path: '/driver-portal', icon: <Truck className="w-4 h-4" /> },
    { name: 'Tracking', path: '/pharmacy-tracking', icon: <Bell className="w-4 h-4" /> },
    { name: 'AI Assistant', path: '/ai-assistant', icon: <Bot className="w-4 h-4" /> }
  ];

  const NavLink = ({ item, mobile = false }: { item: any, mobile?: boolean }) => (
    <Link
      to={item.path}
      className={`flex items-center gap-2 px-2 sm:px-3 py-2 rounded-md text-xs sm:text-sm font-medium transition-colors ${
        location.pathname === item.path
          ? 'bg-blue-100 text-blue-700'
          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
      } ${mobile ? 'w-full justify-start' : ''}`}
      onClick={() => mobile && setIsOpen(false)}
    >
      {item.icon}
      <span className="hidden sm:inline">{item.name}</span>
      {mobile && <span>{item.name}</span>}
    </Link>
  );

  return (
    <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-8">
        <div className="flex justify-between h-14 sm:h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <span className="text-lg sm:text-2xl font-bold text-blue-600">MarketPace</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-2">
            {navItems.map((item) => (
              <NavLink key={item.path} item={item} />
            ))}
            <PreLaunchCart itemCount={cartItems.length} onViewCart={openCart} />
            <ThemeToggle />
          </div>

          {/* Mobile Navigation */}
          <div className="lg:hidden flex items-center space-x-1 sm:space-x-2">
            <PreLaunchCart itemCount={cartItems.length} onViewCart={openCart} />
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="p-2">
                  <Menu className="h-5 w-5 sm:h-6 sm:w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-64 sm:w-80">
                <div className="flex flex-col space-y-3 sm:space-y-4 mt-6 sm:mt-8">
                  {navItems.map((item) => (
                    <NavLink key={item.path} item={item} mobile />
                  ))}
                  <div className="pt-4 border-t">
                    <ThemeToggle />
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;