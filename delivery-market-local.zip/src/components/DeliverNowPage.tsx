import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/components/AuthProvider';
import { Truck, MapPin, Clock, DollarSign, Shield } from 'lucide-react';

interface Product {
  id: string;
  title: string;
  price: number;
  image: string;
  description: string;
  seller: string;
}

export const DeliverNowPage: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();
  const { user, signInWithFacebook, signInWithGoogle } = useAuth();
  const { toast } = useToast();
  const [product, setProduct] = useState<Product | null>(null);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [deliveryNotes, setDeliveryNotes] = useState('');
  const [isOrdering, setIsOrdering] = useState(false);

  useEffect(() => {
    // Mock product data - in real app, fetch from API
    setProduct({
      id: productId || '1',
      title: 'Vintage Leather Jacket',
      price: 85,
      image: '/placeholder.svg',
      description: 'Beautiful vintage leather jacket in excellent condition',
      seller: 'John Doe'
    });
  }, [productId]);

  const handleDeliverNow = async () => {
    if (!user) {
      toast({
        title: 'Sign In Required',
        description: 'Please sign in to place a safe delivery order'
      });
      return;
    }

    if (!deliveryAddress.trim()) {
      toast({
        title: 'Delivery Address Required',
        description: 'Please enter your safe delivery address'
      });
      return;
    }

    setIsOrdering(true);
    try {
      // Create delivery order
      const orderData = {
        productId: product?.id,
        buyerId: user.id,
        deliveryAddress,
        deliveryNotes,
        price: product?.price,
        status: 'pending',
        deliveryType: 'contactless'
      };

      // In real app, call API to create order
      console.log('Creating safe delivery order:', orderData);
      
      toast({
        title: 'Safe Delivery Order Placed!',
        description: 'Your contactless delivery order has been confirmed. We\'ll deliver safely to your door!'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to place delivery order',
        variant: 'destructive'
      });
    } finally {
      setIsOrdering(false);
    }
  };

  if (!product) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      {/* Safety Banner */}
      <div className="max-w-2xl mx-auto mb-6">
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-green-600" />
            <div>
              <h3 className="font-semibold text-green-800">Safe Delivery Only</h3>
              <p className="text-sm text-green-600">
                We keep our customers safe with convenient, affordable delivery services. No pickup required!
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Truck className="h-6 w-6 text-green-600" />
              <Shield className="h-5 w-5 text-green-600" />
              Safe Delivery Service
            </CardTitle>
            <p className="text-sm text-gray-600">Contactless delivery straight to your door</p>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <img 
                  src={product.image} 
                  alt={product.title}
                  className="w-full h-48 object-cover rounded-lg"
                />
              </div>
              <div className="space-y-4">
                <h2 className="text-xl font-bold">{product.title}</h2>
                <p className="text-gray-600">{product.description}</p>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-green-600" />
                  <span className="text-2xl font-bold">${product.price}</span>
                </div>
                <p className="text-sm text-gray-500">Sold by: {product.seller}</p>
                <div className="bg-green-50 p-3 rounded-lg">
                  <div className="flex items-center gap-2 text-green-700">
                    <Shield className="w-4 h-4" />
                    <span className="font-medium text-sm">Safe Delivery Guaranteed</span>
                  </div>
                  <p className="text-xs text-green-600 mt-1">
                    Contactless delivery • No pickup required • Safe & convenient
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {!user ? (
          <Card>
            <CardHeader>
              <CardTitle>Sign In for Safe Delivery</CardTitle>
              <p className="text-sm text-gray-600">Join our secure platform for contactless delivery</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button onClick={signInWithFacebook} className="w-full" variant="outline">
                Sign in with Facebook
              </Button>
              <Button onClick={signInWithGoogle} className="w-full" variant="outline">
                Sign in with Google
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-green-600" />
                <Shield className="h-4 w-4 text-green-600" />
                Safe Delivery Details
              </CardTitle>
              <p className="text-sm text-gray-600">We'll deliver safely and securely to your address</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="address">Safe Delivery Address *</Label>
                <Textarea
                  id="address"
                  placeholder="Enter your full delivery address - we'll deliver safely to your door"
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="notes">Delivery Instructions (Optional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Any special instructions for safe contactless delivery"
                  value={deliveryNotes}
                  onChange={(e) => setDeliveryNotes(e.target.value)}
                />
              </div>
              <div className="bg-green-50 p-3 rounded-lg space-y-2">
                <div className="flex items-center gap-2 text-sm text-green-700">
                  <Clock className="h-4 w-4" />
                  <span>Safe delivery: 30-60 minutes</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-green-700">
                  <Shield className="h-4 w-4" />
                  <span>Contactless delivery to your door</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-green-700">
                  <Truck className="h-4 w-4" />
                  <span>No pickup required - we bring it to you</span>
                </div>
              </div>
              <Button 
                onClick={handleDeliverNow}
                disabled={isOrdering}
                className="w-full bg-green-600 hover:bg-green-700"
                size="lg"
              >
                {isOrdering ? 'Placing Safe Delivery Order...' : `Safe Delivery Now - $${product.price}`}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};