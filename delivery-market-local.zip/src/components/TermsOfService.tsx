import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';

export const TermsOfService = () => {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">
            Terms of Service
          </CardTitle>
          <p className="text-sm text-gray-600 text-center">
            Last updated: {new Date().toLocaleDateString()}
          </p>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px] pr-4">
            <div className="space-y-6">
              <section>
                <h3 className="text-lg font-semibold mb-3">1. Acceptance of Terms</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  By accessing or using our delivery service platform, you agree to be bound by these Terms of Service. 
                  If you do not agree to these terms, please do not use our service.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">2. Service Description</h3>
                <p className="text-sm text-gray-700 leading-relaxed mb-2">
                  Our platform connects customers with local merchants and independent delivery partners to facilitate 
                  the delivery of goods. We provide:
                </p>
                <ul className="list-disc list-inside text-sm text-gray-700 space-y-1 ml-4">
                  <li>Order placement and payment processing</li>
                  <li>Real-time order tracking</li>
                  <li>Communication between parties</li>
                  <li>Customer support services</li>
                </ul>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">3. User Accounts</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  You must create an account to use our services. You are responsible for maintaining the 
                  confidentiality of your account credentials and for all activities under your account.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">4. Orders and Payments</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  All orders are subject to merchant acceptance. Prices include applicable taxes and fees. 
                  Payment is processed when you place an order. Refunds are handled according to our refund policy.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">5. Delivery Partners</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  Delivery partners are independent contractors. We do not employ delivery partners and are not 
                  responsible for their actions beyond what is required by law.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">6. Prohibited Uses</h3>
                <ul className="list-disc list-inside text-sm text-gray-700 space-y-1 ml-4">
                  <li>Fraudulent or illegal activities</li>
                  <li>Harassment of other users</li>
                  <li>Violation of intellectual property rights</li>
                  <li>Circumventing security measures</li>
                </ul>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">7. Limitation of Liability</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  Our liability is limited to the maximum extent permitted by law. We are not liable for 
                  indirect, incidental, or consequential damages arising from your use of our service.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">8. Changes to Terms</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  We reserve the right to modify these terms at any time. Changes will be effective upon posting. 
                  Continued use of our service constitutes acceptance of modified terms.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">9. Contact Information</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  For questions about these Terms of Service, please contact us at legal@deliveryapp.com
                </p>
              </section>
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
};