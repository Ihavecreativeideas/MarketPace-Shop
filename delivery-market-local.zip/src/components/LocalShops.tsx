import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, ExternalLink, Star, ShoppingCart, Crown, Globe, Lock, Coffee, Scissors, Wrench, Heart } from 'lucide-react';
import { useState } from 'react';
import DeliveryPricing from './DeliveryPricing';
import SubscriptionForm from './SubscriptionForm';
import { TikTokShopManager } from './TikTokShopManager';
import { DeliveryRequirements } from './DeliveryRequirements';

const LocalShops: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  const mockBusinesses = [
    { 
      id: 1, 
      name: 'Artisan Coffee Roasters', 
      category: 'Food & Beverage', 
      type: 'restaurant',
      rating: 4.9, 
      deliveryFee: '$3', 
      eta: '20-30 min',
      image: '/placeholder.svg',
      linkedPlatforms: ['Website', 'Instagram'],
      subscribed: true,
      partnerTier: 'gold',
      hasWebIntegration: true,
      services: ['Coffee', 'Pastries', 'Catering']
    },
    { 
      id: 2, 
      name: 'Bella Hair Salon', 
      category: 'Personal Care', 
      type: 'service',
      rating: 4.8, 
      deliveryFee: 'N/A', 
      eta: 'Book Appointment',
      image: '/placeholder.svg',
      linkedPlatforms: ['Instagram', 'Facebook'],
      subscribed: true,
      partnerTier: 'silver',
      hasWebIntegration: true,
      services: ['Haircuts', 'Coloring', 'Styling']
    },
    { 
      id: 3, 
      name: 'Tech Repair Pro', 
      category: 'Professional Services', 
      type: 'service',
      rating: 4.7, 
      deliveryFee: 'Free Pickup', 
      eta: 'Same Day',
      image: '/placeholder.svg',
      linkedPlatforms: ['Website', 'Google Business'],
      subscribed: true,
      partnerTier: 'platinum',
      hasWebIntegration: true,
      services: ['Phone Repair', 'Computer Service', 'Data Recovery']
    },
    {
      id: 4,
      name: 'Wellness Spa',
      category: 'Health & Wellness',
      type: 'service',
      rating: 4.9,
      deliveryFee: 'N/A',
      eta: 'Book Online',
      image: '/placeholder.svg',
      linkedPlatforms: ['Instagram', 'Website'],
      subscribed: false,
      partnerTier: null,
      hasWebIntegration: false,
      services: ['Massage', 'Facials', 'Wellness Coaching']
    },
    {
      id: 5,
      name: 'Local Bakery',
      category: 'Food & Beverage',
      type: 'restaurant',
      rating: 4.6,
      deliveryFee: '$2',
      eta: '15-25 min',
      image: '/placeholder.svg',
      linkedPlatforms: ['Instagram'],
      subscribed: false,
      partnerTier: null,
      hasWebIntegration: false,
      services: ['Fresh Bread', 'Custom Cakes', 'Catering']
    }
  ];

  const getTierBadge = (tier: string | null) => {
    switch (tier) {
      case 'silver':
        return <Badge className="bg-gray-500"><Crown className="w-3 h-3 mr-1" />Silver</Badge>;
      case 'gold':
        return <Badge className="bg-yellow-500"><Crown className="w-3 h-3 mr-1" />Gold</Badge>;
      case 'platinum':
        return <Badge className="bg-purple-500"><Crown className="w-3 h-3 mr-1" />Platinum</Badge>;
      default:
        return null;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Food & Beverage':
        return <Coffee className="w-4 h-4" />;
      case 'Personal Care':
        return <Scissors className="w-4 h-4" />;
      case 'Professional Services':
        return <Wrench className="w-4 h-4" />;
      case 'Health & Wellness':
        return <Heart className="w-4 h-4" />;
      default:
        return <Building2 className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <DeliveryRequirements shopType="local" />
      
      <Tabs defaultValue="browse" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="browse">Browse Businesses</TabsTrigger>
          <TabsTrigger value="tiktok">Social Commerce</TabsTrigger>
          <TabsTrigger value="pricing">Service Pricing</TabsTrigger>
        </TabsList>
        
        <TabsContent value="browse" className="space-y-6">
          <div className="flex items-center gap-4">
            <Input
              placeholder="Search local businesses and services..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
            <Button variant="outline">
              <Building2 className="w-4 h-4 mr-2" />
              Categories
            </Button>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-4">Featured Local Businesses</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockBusinesses.map((business) => (
                <Card key={business.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="p-0 relative">
                    <img src={business.image} alt={business.name} className="w-full h-32 object-cover rounded-t-lg" />
                    <div className="absolute top-2 right-2 flex gap-1 flex-col">
                      {business.subscribed && (
                        <Badge className="bg-green-600">
                          {business.type === 'service' ? 'Service Partner' : 'Delivery Partner'}
                        </Badge>
                      )}
                      {getTierBadge(business.partnerTier)}
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{business.name}</CardTitle>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm">{business.rating}</span>
                        </div>
                      </div>
                      <Badge variant="secondary" className="flex items-center gap-1 w-fit">
                        {getCategoryIcon(business.category)}
                        {business.category}
                      </Badge>
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>{business.type === 'service' ? 'Service' : 'Delivery'}: {business.deliveryFee}</span>
                        <span>{business.eta}</span>
                      </div>
                      <div className="text-xs text-gray-600">
                        <strong>Services:</strong> {business.services.join(', ')}
                      </div>
                      <div className="flex gap-1 flex-wrap">
                        {business.linkedPlatforms.map((platform) => {
                          const isWebsite = platform === 'Website';
                          const canShowWebsite = isWebsite && business.hasWebIntegration;
                          const isRestricted = isWebsite && !business.hasWebIntegration;
                          
                          if (isRestricted) {
                            return (
                              <Badge key={platform} variant="outline" className="text-xs bg-gray-100 text-gray-400">
                                <Lock className="w-3 h-3 mr-1" />
                                {platform} (Partner Only)
                              </Badge>
                            );
                          }
                          
                          return (
                            <Badge key={platform} variant="outline" className="text-xs">
                              {canShowWebsite ? (
                                <Globe className="w-3 h-3 mr-1" />
                              ) : (
                                <ExternalLink className="w-3 h-3 mr-1" />
                              )}
                              {platform}
                            </Badge>
                          );
                        })}
                      </div>
                      <Button className="w-full mt-2">
                        {business.type === 'service' ? 'Book Service' : 'Browse Products'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="tiktok" className="space-y-6">
          <TikTokShopManager />
        </TabsContent>
        
        <TabsContent value="pricing" className="space-y-6">
          <DeliveryPricing />
          <SubscriptionForm />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default LocalShops;