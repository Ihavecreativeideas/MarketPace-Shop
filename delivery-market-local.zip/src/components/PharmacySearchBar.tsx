import React, { useState } from 'react';
import { Search, MapPin, Clock, Star } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';

interface Pharmacy {
  id: string;
  name: string;
  address: string;
  distance: string;
  rating: number;
  hours: string;
  phone: string;
}

const mockPharmacies: Pharmacy[] = [
  {
    id: '1',
    name: 'CVS Pharmacy',
    address: '123 Main St, Your City, ST 12345',
    distance: '0.5 miles',
    rating: 4.2,
    hours: 'Open until 10:00 PM',
    phone: '(555) 123-4567'
  },
  {
    id: '2',
    name: 'Walgreens',
    address: '456 Oak Ave, Your City, ST 12345',
    distance: '0.8 miles',
    rating: 4.0,
    hours: 'Open until 9:00 PM',
    phone: '(555) 234-5678'
  },
  {
    id: '3',
    name: 'Local Family Pharmacy',
    address: '789 Pine Rd, Your City, ST 12345',
    distance: '1.2 miles',
    rating: 4.8,
    hours: 'Open until 7:00 PM',
    phone: '(555) 345-6789'
  }
];

const PharmacySearchBar: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showResults, setShowResults] = useState(false);

  const handleSearch = () => {
    setShowResults(true);
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            type="text"
            placeholder="Search for pharmacies near you..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
          />
        </div>
        <Button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-700">
          Search
        </Button>
      </div>

      {showResults && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">
            Local Pharmacies Near You
          </h3>
          {mockPharmacies.map((pharmacy) => (
            <Card key={pharmacy.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">{pharmacy.name}</h4>
                    <div className="flex items-center text-gray-600 text-sm mb-1">
                      <MapPin className="w-4 h-4 mr-1" />
                      <span>{pharmacy.address}</span>
                    </div>
                    <div className="flex items-center text-gray-600 text-sm mb-2">
                      <Clock className="w-4 h-4 mr-1" />
                      <span>{pharmacy.hours}</span>
                    </div>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-400 mr-1" />
                      <span className="text-sm text-gray-600">{pharmacy.rating} • {pharmacy.distance}</span>
                    </div>
                  </div>
                  <Button size="sm" className="bg-green-600 hover:bg-green-700">
                    Select
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default PharmacySearchBar;