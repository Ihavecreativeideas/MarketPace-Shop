import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Store, Calendar, Mail, Phone } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const SubscriptionForm: React.FC = () => {
  const [formData, setFormData] = useState({
    shop_name: '',
    shop_email: '',
    shop_phone: '',
    plan_type: '',
    preferred_days: [] as string[]
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const plans = {
    weekly_starter: { name: 'Weekly Starter', price: 92, discount: 18 },
    bi_weekly_pro: { name: 'Bi-Weekly Pro', price: 173, discount: 23 },
    premium_daily: { name: 'Premium Daily', price: 244, discount: 27 }
  };

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const handleDayToggle = (day: string) => {
    setFormData(prev => ({
      ...prev,
      preferred_days: prev.preferred_days.includes(day)
        ? prev.preferred_days.filter(d => d !== day)
        : [...prev.preferred_days, day]
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/cc60534d-83d3-4342-9fca-c2a3bacf0388',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'create_subscription',
            data: formData
          })
        }
      );

      const result = await response.json();
      
      if (result.success) {
        toast({
          title: 'Subscription Created!',
          description: `Welcome to MarketPace delivery services, ${formData.shop_name}!`
        });
        setFormData({
          shop_name: '',
          shop_email: '',
          shop_phone: '',
          plan_type: '',
          preferred_days: []
        });
      } else {
        throw new Error(result.error || 'Failed to create subscription');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create subscription. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const selectedPlan = formData.plan_type ? plans[formData.plan_type as keyof typeof plans] : null;

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Store className="w-5 h-5" />
          Subscribe to Delivery Days
        </CardTitle>
        <p className="text-sm text-gray-600">
          Join our local shop delivery network and save on regular deliveries
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="shop_name">Shop Name *</Label>
              <Input
                id="shop_name"
                value={formData.shop_name}
                onChange={(e) => setFormData(prev => ({ ...prev, shop_name: e.target.value }))}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="shop_email">Email *</Label>
              <Input
                id="shop_email"
                type="email"
                value={formData.shop_email}
                onChange={(e) => setFormData(prev => ({ ...prev, shop_email: e.target.value }))}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="shop_phone">Phone Number</Label>
            <Input
              id="shop_phone"
              type="tel"
              value={formData.shop_phone}
              onChange={(e) => setFormData(prev => ({ ...prev, shop_phone: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label>Select Plan *</Label>
            <Select value={formData.plan_type} onValueChange={(value) => setFormData(prev => ({ ...prev, plan_type: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a subscription plan" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(plans).map(([key, plan]) => (
                  <SelectItem key={key} value={key}>
                    <div className="flex items-center justify-between w-full">
                      <span>{plan.name}</span>
                      <Badge variant="secondary">${plan.price}/month</Badge>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedPlan && (
            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="font-semibold text-green-800 mb-2">Selected Plan: {selectedPlan.name}</h4>
              <p className="text-sm text-green-700">
                ${selectedPlan.price}/month ({selectedPlan.discount}% discount included)
              </p>
            </div>
          )}

          <div className="space-y-3">
            <Label className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Preferred Delivery Days
            </Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {daysOfWeek.map((day) => (
                <div key={day} className="flex items-center space-x-2">
                  <Checkbox
                    id={day}
                    checked={formData.preferred_days.includes(day)}
                    onCheckedChange={() => handleDayToggle(day)}
                  />
                  <Label htmlFor={day} className="text-sm">{day}</Label>
                </div>
              ))}
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={loading || !formData.plan_type}>
            {loading ? 'Creating Subscription...' : 'Subscribe Now'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default SubscriptionForm;