import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, TrendingDown, Users, Package, DollarSign, Star } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AnalyticsData {
  totalRevenue: number;
  totalOrders: number;
  totalUsers: number;
  averageRating: number;
  revenueGrowth: number;
  orderGrowth: number;
  userGrowth: number;
  topProducts: Array<{ name: string; sales: number; revenue: number }>;
  recentActivity: Array<{ type: string; description: string; timestamp: string }>;
}

interface AnalyticsDashboardProps {
  vendorId?: string;
  isAdmin?: boolean;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ 
  vendorId, 
  isAdmin = false 
}) => {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');

  useEffect(() => {
    fetchAnalytics();
  }, [vendorId, timeRange]);

  const fetchAnalytics = async () => {
    try {
      const endDate = new Date();
      const startDate = new Date();
      startDate.setDate(endDate.getDate() - parseInt(timeRange));

      // Fetch orders data
      let ordersQuery = supabase
        .from('marketplace_orders')
        .select('*')
        .gte('created_at', startDate.toISOString())
        .lte('created_at', endDate.toISOString());
      
      if (vendorId && !isAdmin) {
        ordersQuery = ordersQuery.eq('vendor_id', vendorId);
      }

      const { data: orders } = await ordersQuery;

      // Fetch users data (admin only)
      let usersData = [];
      if (isAdmin) {
        const { data: users } = await supabase
          .from('users')
          .select('*')
          .gte('created_at', startDate.toISOString());
        usersData = users || [];
      }

      // Fetch reviews data
      let reviewsQuery = supabase
        .from('vendor_reviews')
        .select('rating')
        .gte('created_at', startDate.toISOString());
      
      if (vendorId && !isAdmin) {
        reviewsQuery = reviewsQuery.eq('vendor_id', vendorId);
      }

      const { data: reviews } = await reviewsQuery;

      // Calculate analytics
      const totalRevenue = orders?.reduce((sum, order) => sum + (order.total || 0), 0) || 0;
      const totalOrders = orders?.length || 0;
      const totalUsers = usersData.length;
      const averageRating = reviews?.length 
        ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length 
        : 0;

      // Calculate growth (mock data for now)
      const revenueGrowth = Math.random() * 20 - 10; // -10% to +10%
      const orderGrowth = Math.random() * 30 - 15;
      const userGrowth = Math.random() * 25 - 12;

      // Top products (mock data)
      const topProducts = [
        { name: 'Premium Package', sales: 45, revenue: 2250 },
        { name: 'Standard Delivery', sales: 38, revenue: 1140 },
        { name: 'Express Service', sales: 29, revenue: 1450 }
      ];

      // Recent activity (mock data)
      const recentActivity = [
        { type: 'order', description: 'New order #1234 received', timestamp: new Date().toISOString() },
        { type: 'user', description: 'New user registered', timestamp: new Date(Date.now() - 3600000).toISOString() },
        { type: 'review', description: '5-star review received', timestamp: new Date(Date.now() - 7200000).toISOString() }
      ];

      setAnalytics({
        totalRevenue,
        totalOrders,
        totalUsers,
        averageRating,
        revenueGrowth,
        orderGrowth,
        userGrowth,
        topProducts,
        recentActivity
      });
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const getGrowthIcon = (growth: number) => {
    return growth >= 0 ? 
      <TrendingUp className="h-4 w-4 text-green-500" /> : 
      <TrendingDown className="h-4 w-4 text-red-500" />;
  };

  const getGrowthColor = (growth: number) => {
    return growth >= 0 ? 'text-green-500' : 'text-red-500';
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading analytics...</div>;
  }

  if (!analytics) {
    return <div className="text-center p-8">No analytics data available</div>;
  }

  return (
    <div className="space-y-6">
      {/* Time Range Selector */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Analytics Dashboard</h2>
        <Tabs value={timeRange} onValueChange={(value) => setTimeRange(value as any)}>
          <TabsList>
            <TabsTrigger value="7d">7 Days</TabsTrigger>
            <TabsTrigger value="30d">30 Days</TabsTrigger>
            <TabsTrigger value="90d">90 Days</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                <p className="text-2xl font-bold">{formatCurrency(analytics.totalRevenue)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-500" />
            </div>
            <div className="flex items-center mt-2">
              {getGrowthIcon(analytics.revenueGrowth)}
              <span className={`text-sm ml-1 ${getGrowthColor(analytics.revenueGrowth)}`}>
                {analytics.revenueGrowth > 0 ? '+' : ''}{analytics.revenueGrowth.toFixed(1)}%
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Orders</p>
                <p className="text-2xl font-bold">{analytics.totalOrders}</p>
              </div>
              <Package className="h-8 w-8 text-blue-500" />
            </div>
            <div className="flex items-center mt-2">
              {getGrowthIcon(analytics.orderGrowth)}
              <span className={`text-sm ml-1 ${getGrowthColor(analytics.orderGrowth)}`}>
                {analytics.orderGrowth > 0 ? '+' : ''}{analytics.orderGrowth.toFixed(1)}%
              </span>
            </div>
          </CardContent>
        </Card>

        {isAdmin && (
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Users</p>
                  <p className="text-2xl font-bold">{analytics.totalUsers}</p>
                </div>
                <Users className="h-8 w-8 text-purple-500" />
              </div>
              <div className="flex items-center mt-2">
                {getGrowthIcon(analytics.userGrowth)}
                <span className={`text-sm ml-1 ${getGrowthColor(analytics.userGrowth)}`}>
                  {analytics.userGrowth > 0 ? '+' : ''}{analytics.userGrowth.toFixed(1)}%
                </span>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg Rating</p>
                <p className="text-2xl font-bold">{analytics.averageRating.toFixed(1)}</p>
              </div>
              <Star className="h-8 w-8 text-yellow-500" />
            </div>
            <div className="flex items-center mt-2">
              <Badge variant="secondary">Excellent</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Products */}
        <Card>
          <CardHeader>
            <CardTitle>Top Performing Products</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analytics.topProducts.map((product, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{product.name}</p>
                    <p className="text-sm text-muted-foreground">{product.sales} sales</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{formatCurrency(product.revenue)}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analytics.recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2" />
                  <div className="flex-1">
                    <p className="text-sm">{activity.description}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(activity.timestamp).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};