import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, DollarSign, Gift, Truck } from 'lucide-react';
import { useLaunch } from '@/contexts/LaunchContext';
import { toast } from '@/components/ui/use-toast';

interface CheckoutItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

interface CheckoutWithFeesProps {
  items: CheckoutItem[];
  userId?: string;
  deliveryMiles?: number;
  onCheckout: (total: number) => void;
}

export const CheckoutWithFees: React.FC<CheckoutWithFeesProps> = ({
  items,
  userId,
  deliveryMiles = 3,
  onCheckout
}) => {
  const [loading, setLoading] = useState(false);
  const { isLaunched } = useLaunch();

  // Beta testing pricing structure
  const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const driverPay = deliveryMiles * 1.50; // $1.50 per mile for driver
  const processingFee = 1.50; // Fixed $1.50 processing fee
  const buyerProcessingFee = processingFee / 2; // $0.75 buyer pays
  const sellerProcessingFee = processingFee / 2; // $0.75 seller pays (not shown to buyer)
  
  const total = subtotal + buyerProcessingFee; // Buyer only pays their share

  const handleCheckout = async () => {
    if (!isLaunched) {
      toast({
        title: 'Coming Soon!',
        description: 'Checkout will be available when we launch. Items saved to your cart!',
        variant: 'default'
      });
      return;
    }

    setLoading(true);
    try {
      await onCheckout(total);
      toast({
        title: 'Order Placed!',
        description: `Total: $${total.toFixed(2)} (Beta pricing - no delivery fees!)`,
        variant: 'default'
      });
    } catch (error) {
      toast({
        title: 'Checkout Error',
        description: 'Please try again',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Order Summary</CardTitle>
          <Badge className="bg-green-600 text-white">
            <Gift className="w-3 h-3 mr-1" />
            Beta Pricing
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Beta Pricing Notice */}
        <div className="bg-green-50 p-3 rounded-lg border border-green-200">
          <div className="flex items-center gap-2 mb-1">
            <Gift className="h-4 w-4 text-green-600" />
            <span className="font-semibold text-green-800">🚀 Beta Testing Pricing!</span>
          </div>
          <p className="text-sm text-green-700">
            No delivery fees during beta - only driver pay + small processing fee!
          </p>
        </div>

        {/* Items */}
        <div className="space-y-2">
          {items.map((item) => (
            <div key={item.id} className="flex justify-between">
              <span>{item.name} x{item.quantity}</span>
              <span>${(item.price * item.quantity).toFixed(2)}</span>
            </div>
          ))}
        </div>

        <Separator />

        {/* Subtotal */}
        <div className="flex justify-between">
          <span>Subtotal</span>
          <span>${subtotal.toFixed(2)}</span>
        </div>

        {/* Delivery Information */}
        <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
          <div className="flex items-center gap-2 mb-2">
            <Truck className="h-4 w-4 text-blue-600" />
            <span className="font-medium text-blue-800">Delivery ({deliveryMiles} miles)</span>
          </div>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Driver Pay:</span>
              <span className="text-blue-600">${driverPay.toFixed(2)} (FREE to you!)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Your Processing Fee:</span>
              <span>${buyerProcessingFee.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Fee Breakdown */}
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            <span>Processing Fee (Your Share)</span>
            <Badge variant="secondary" className="bg-orange-100 text-orange-800 text-xs">
              Split 50/50
            </Badge>
          </div>
          <span>${buyerProcessingFee.toFixed(2)}</span>
        </div>

        {/* Savings Display */}
        <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
          <div className="flex items-center gap-2 mb-1">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <span className="font-medium text-yellow-800">Your Beta Savings:</span>
          </div>
          <div className="text-sm text-yellow-700 space-y-1">
            <div className="flex justify-between">
              <span>Delivery Fee (normally $8-12):</span>
              <span className="text-green-600 font-medium">FREE</span>
            </div>
            <div className="flex justify-between">
              <span>Mileage Fee (normally ${(deliveryMiles * 1.25).toFixed(2)}):</span>
              <span className="text-green-600 font-medium">FREE</span>
            </div>
            <div className="flex justify-between">
              <span>Sustainability Fee (normally $4):</span>
              <span className="text-green-600 font-medium">FREE</span>
            </div>
            <div className="flex justify-between font-bold">
              <span>Total Savings:</span>
              <span className="text-green-600">${(12 + (deliveryMiles * 1.25) + 4).toFixed(2)}</span>
            </div>
          </div>
        </div>

        <Separator />

        {/* Total */}
        <div className="flex justify-between text-lg font-bold">
          <span>Total</span>
          <span>${total.toFixed(2)}</span>
        </div>

        <Button 
          onClick={handleCheckout}
          className="w-full bg-green-600 hover:bg-green-700"
          disabled={loading || items.length === 0}
        >
          {loading ? 'Processing...' : 
           !isLaunched ? 'Save to Cart (Launch Soon!)' : 
           `Checkout - $${total.toFixed(2)}`}
        </Button>

        {!isLaunched && (
          <p className="text-sm text-center text-gray-500">
            Purchasing will be enabled when we launch!
          </p>
        )}
        
        <div className="text-center">
          <p className="text-xs text-gray-500">
            ⚡ Limited time beta pricing - take advantage now!
          </p>
          <p className="text-xs text-green-600 font-medium">
            Early supporters get lifetime discounts! 🎉
          </p>
        </div>
      </CardContent>
    </Card>
  );
};