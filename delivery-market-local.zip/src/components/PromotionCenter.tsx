import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FacebookPromotion } from './FacebookPromotion';
import { BackButton } from './BackButton';
import { Users, Store, Facebook, Package } from 'lucide-react';

const mockProducts = [
  { id: '1', title: 'Fresh Organic Apples', price: 4.99, description: 'Locally grown organic apples', shopName: 'Green Valley Farm' },
  { id: '2', title: 'Artisan Bread', price: 6.50, description: 'Handcrafted sourdough bread', shopName: 'Corner Bakery' },
  { id: '3', title: 'Local Honey', price: 12.99, description: 'Pure local honey', shopName: 'Sweet Bee Farm' }
];

const mockPartners = [
  { id: '1', name: 'Green Valley Farm', category: 'Produce' },
  { id: '2', name: 'Corner Bakery', category: 'Bakery' },
  { id: '3', name: 'Tech Repair Pro', category: 'Electronics' }
];

export const PromotionCenter: React.FC = () => {
  const [activeTab, setActiveTab] = useState('member');
  const [selectedProduct, setSelectedProduct] = useState(mockProducts[0]);
  const [selectedPartner, setSelectedPartner] = useState(mockPartners[0]);

  return (
    <div className="container mx-auto px-4 py-8">
      <BackButton to="/" />
      
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <Facebook className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold">Facebook Promotion Center</h1>
          <Badge variant="secondary" className="bg-blue-100 text-blue-800">New</Badge>
        </div>
        <p className="text-muted-foreground text-lg">
          Promote your products and partner shops on Facebook Marketplace
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="member" className="flex items-center gap-2">
            <Users className="h-4 w-4" />Member Promotions
          </TabsTrigger>
          <TabsTrigger value="platform" className="flex items-center gap-2">
            <Store className="h-4 w-4" />Platform Promotions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="member" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5" />Your Products
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {mockProducts.map((product) => (
                  <div key={product.id} className="p-3 border rounded cursor-pointer hover:bg-gray-50" onClick={() => setSelectedProduct(product)}>
                    <div className="font-medium">{product.title}</div>
                    <div className="text-sm text-muted-foreground">${product.price} - {product.shopName}</div>
                  </div>
                ))}
              </CardContent>
            </Card>
            <FacebookPromotion userType="member" product={selectedProduct} />
          </div>
        </TabsContent>

        <TabsContent value="platform" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Store className="h-5 w-5" />Partner Shops
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {mockPartners.map((partner) => (
                  <div key={partner.id} className="p-3 border rounded cursor-pointer hover:bg-gray-50" onClick={() => setSelectedPartner(partner)}>
                    <div className="font-medium">{partner.name}</div>
                    <div className="text-sm text-muted-foreground">{partner.category}</div>
                  </div>
                ))}
              </CardContent>
            </Card>
            <FacebookPromotion userType="platform" shopId={selectedPartner.id} />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};