import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Crown, CheckCircle, AlertCircle } from 'lucide-react';

interface Subscription {
  id: string;
  plan_type?: string;
  plan_id?: string;
  plan_name?: string;
  status: string;
  current_period_end: string;
  created_at: string;
  tier?: string;
}

interface SubscriptionManagerProps {
  userId: string;
  onSubscriptionChange?: (subscription: Subscription | null) => void;
}

const SubscriptionManager: React.FC<SubscriptionManagerProps> = ({
  userId,
  onSubscriptionChange
}) => {
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchSubscription();
  }, [userId]);

  const fetchSubscription = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('shop_subscriptions')
        .select('*')
        .eq('user_id', userId)
        .eq('status', 'active')
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching subscription:', error);
        toast({
          title: 'Error',
          description: 'Failed to fetch subscription data',
          variant: 'destructive'
        });
        return;
      }

      // Handle both old and new subscription formats
      if (data) {
        const formattedSub = {
          ...data,
          plan_name: data.plan_name || data.plan_type || 'Unknown Plan',
          plan_id: data.plan_id || data.plan_type || 'unknown',
          tier: data.tier || getTierFromPlan(data.plan_type || data.plan_id)
        };
        setSubscription(formattedSub);
        onSubscriptionChange?.(formattedSub);
      } else {
        setSubscription(null);
        onSubscriptionChange?.(null);
      }
    } catch (error) {
      console.error('Error fetching subscription:', error);
      setSubscription(null);
      onSubscriptionChange?.(null);
    } finally {
      setLoading(false);
    }
  };

  const getTierFromPlan = (planType: string | undefined): string => {
    if (!planType) return 'starter';
    const plan = planType.toLowerCase();
    if (plan.includes('starter') || plan.includes('basic')) return 'silver';
    if (plan.includes('standard') || plan.includes('pro')) return 'gold';
    if (plan.includes('super') || plan.includes('premium')) return 'platinum';
    return 'silver';
  };

  const getPlanBenefits = (planId: string | undefined) => {
    if (!planId) return { deliveryDiscount: 0, sustainabilityDiscount: 0, searchPriority: 0 };
    
    const plan = planId.toLowerCase();
    if (plan.includes('starter') || plan.includes('basic')) {
      return { deliveryDiscount: 15, sustainabilityDiscount: 25, searchPriority: 1 };
    }
    if (plan.includes('standard') || plan.includes('pro')) {
      return { deliveryDiscount: 25, sustainabilityDiscount: 75, searchPriority: 2 };
    }
    if (plan.includes('super') || plan.includes('premium')) {
      return { deliveryDiscount: 35, sustainabilityDiscount: 100, searchPriority: 3 };
    }
    return { deliveryDiscount: 0, sustainabilityDiscount: 0, searchPriority: 0 };
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Crown className="h-5 w-5" />
          Subscription Status
        </CardTitle>
      </CardHeader>
      <CardContent>
        {subscription ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">{subscription.plan_name || 'Partner Plan'}</h3>
                <p className="text-sm text-gray-600">
                  Active until {new Date(subscription.current_period_end).toLocaleDateString()}
                </p>
              </div>
              <Badge className="bg-green-100 text-green-800">
                <CheckCircle className="h-3 w-3 mr-1" />
                Active
              </Badge>
            </div>
            <div className="text-sm text-gray-600">
              <p>Your business profile benefits:</p>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>{getPlanBenefits(subscription.plan_id).deliveryDiscount}% delivery discount</li>
                <li>{getPlanBenefits(subscription.plan_id).sustainabilityDiscount}% sustainability fee discount</li>
                <li>Priority level {getPlanBenefits(subscription.plan_id).searchPriority} search placement</li>
              </ul>
            </div>
          </div>
        ) : (
          <div className="text-center space-y-4">
            <AlertCircle className="h-12 w-12 text-gray-400 mx-auto" />
            <div>
              <h3 className="font-semibold">No Active Subscription</h3>
              <p className="text-sm text-gray-600">
                Subscribe to a partnership plan to unlock exclusive benefits.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export { SubscriptionManager, type Subscription };
export default SubscriptionManager;