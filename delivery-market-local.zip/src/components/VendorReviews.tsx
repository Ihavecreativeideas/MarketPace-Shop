import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Star, ThumbsUp, MessageSquare } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Review {
  id: string;
  customer_name: string;
  rating: number;
  comment: string;
  created_at: string;
  helpful_count: number;
}

interface BusinessStats {
  average_rating: number;
  total_reviews: number;
  rating_distribution: { [key: number]: number };
}

export default function BusinessReviews({ businessId }: { businessId: string }) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [stats, setStats] = useState<BusinessStats>({
    average_rating: 0,
    total_reviews: 0,
    rating_distribution: {}
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchReviews();
    fetchStats();
  }, [businessId]);

  const fetchReviews = async () => {
    try {
      const { data, error } = await supabase
        .from('business_reviews')
        .select('*')
        .eq('business_id', businessId)
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      setReviews(data || []);
    } catch (error) {
      console.error('Error fetching reviews:', error);
      // Mock data for demo
      setReviews([
        {
          id: '1',
          customer_name: 'John D.',
          rating: 5,
          comment: 'Excellent service and fast delivery!',
          created_at: '2024-01-15',
          helpful_count: 12
        },
        {
          id: '2',
          customer_name: 'Sarah M.',
          rating: 4,
          comment: 'Good quality products, will order again.',
          created_at: '2024-01-14',
          helpful_count: 8
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      // Mock stats for demo
      setStats({
        average_rating: 4.6,
        total_reviews: 247,
        rating_distribution: {
          5: 156,
          4: 67,
          3: 18,
          2: 4,
          1: 2
        }
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  const getRatingPercentage = (rating: number) => {
    return stats.total_reviews > 0 
      ? ((stats.rating_distribution[rating] || 0) / stats.total_reviews) * 100
      : 0;
  };

  if (loading) {
    return <div className="p-6">Loading reviews...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Customer Reviews</h1>
        <Badge variant="outline" className="text-lg px-3 py-1">
          {stats.average_rating.toFixed(1)} ★
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Rating Overview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="text-4xl font-bold">{stats.average_rating.toFixed(1)}</div>
              <div className="flex justify-center mb-2">
                {renderStars(Math.round(stats.average_rating))}
              </div>
              <div className="text-sm text-gray-600">
                Based on {stats.total_reviews} reviews
              </div>
            </div>
            
            <div className="space-y-2">
              {[5, 4, 3, 2, 1].map((rating) => (
                <div key={rating} className="flex items-center gap-2">
                  <span className="text-sm w-3">{rating}</span>
                  <Star className="h-3 w-3 text-yellow-400 fill-current" />
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-yellow-400 h-2 rounded-full"
                      style={{ width: `${getRatingPercentage(rating)}%` }}
                    />
                  </div>
                  <span className="text-sm text-gray-600 w-8">
                    {stats.rating_distribution[rating] || 0}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Recent Reviews</CardTitle>
            <CardDescription>What customers are saying</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {reviews.map((review) => (
              <div key={review.id} className="border-b pb-4 last:border-b-0">
                <div className="flex items-start gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src="" />
                    <AvatarFallback>
                      {review.customer_name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{review.customer_name}</span>
                      <div className="flex">
                        {renderStars(review.rating)}
                      </div>
                      <span className="text-sm text-gray-500">
                        {new Date(review.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-gray-700 mb-2">{review.comment}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <button className="flex items-center gap-1 hover:text-gray-700">
                        <ThumbsUp className="h-3 w-3" />
                        Helpful ({review.helpful_count})
                      </button>
                      <button className="flex items-center gap-1 hover:text-gray-700">
                        <MessageSquare className="h-3 w-3" />
                        Reply
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}