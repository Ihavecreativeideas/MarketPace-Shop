import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Route, Users, TrendingUp, MapPin, Calendar, Heart, Globe, Facebook, BarChart3 } from 'lucide-react';

const GrowingRoutesSection: React.FC = () => {
  return (
    <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-lg p-6 mb-6">
      <div className="text-center mb-6">
        <Badge className="mx-auto mb-3 bg-gradient-to-r from-green-500 to-blue-500 text-white">
          <Route className="w-3 h-3 mr-1" />
          Growing Routes
        </Badge>
        <h3 className="text-2xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-2">
          Strengthen Your Community Presence
        </h3>
        <p className="text-gray-700 text-lg">
          Create weekly scheduled delivery routes with local drivers
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <Card className="border-green-200 bg-white/80">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2 text-green-700">
              <Users className="w-5 h-5" />
              Build Local Relationships
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600">
              Work with the same trusted drivers weekly, creating lasting partnerships that benefit your business and theirs.
            </p>
          </CardContent>
        </Card>
        
        <Card className="border-blue-200 bg-white/80">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2 text-blue-700">
              <TrendingUp className="w-5 h-5" />
              Grow Your Business
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600">
              Expand your reach with reliable delivery routes that customers can count on, increasing repeat business.
            </p>
          </CardContent>
        </Card>
      </div>
      
      <div className="bg-white/90 rounded-lg p-4 mb-4 border border-purple-200">
        <h4 className="font-bold text-purple-700 mb-3 text-center">Strengthen Your Community & Presence</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-3 border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <Globe className="w-4 h-4 text-blue-600" />
              <span className="font-semibold text-blue-700">Website Integration</span>
            </div>
            <p className="text-xs text-gray-600">
              Seamlessly connect your existing website with our delivery platform for unified customer experience
            </p>
          </div>
          
          <div className="bg-gradient-to-br from-blue-50 to-purple-100 rounded-lg p-3 border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <Facebook className="w-4 h-4 text-blue-600" />
              <span className="font-semibold text-blue-700">Facebook Marketplace</span>
            </div>
            <p className="text-xs text-gray-600">
              Promote your business and delivery services directly through Facebook Marketplace integration
            </p>
          </div>
          
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-3 border border-purple-200">
            <div className="flex items-center gap-2 mb-2">
              <BarChart3 className="w-4 h-4 text-purple-600" />
              <span className="font-semibold text-purple-700">AI Analytics</span>
            </div>
            <p className="text-xs text-gray-600">
              Advanced AI-powered insights to optimize routes, predict demand, and grow your community presence
            </p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white/80 rounded-lg p-4 border border-green-100">
          <div className="flex items-center gap-2 mb-2">
            <MapPin className="w-4 h-4 text-green-600" />
            <span className="font-semibold text-green-700">Local Focus</span>
          </div>
          <p className="text-xs text-gray-600">
            Keep delivery jobs in your community, supporting local economy
          </p>
        </div>
        
        <div className="bg-white/80 rounded-lg p-4 border border-blue-100">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="w-4 h-4 text-blue-600" />
            <span className="font-semibold text-blue-700">Weekly Routes</span>
          </div>
          <p className="text-xs text-gray-600">
            Predictable schedules that work for both you and your drivers
          </p>
        </div>
        
        <div className="bg-white/80 rounded-lg p-4 border border-purple-100">
          <div className="flex items-center gap-2 mb-2">
            <Heart className="w-4 h-4 text-purple-600" />
            <span className="font-semibold text-purple-700">Community Impact</span>
          </div>
          <p className="text-xs text-gray-600">
            Create jobs and deliver opportunities to strengthen your area
          </p>
        </div>
      </div>
    </div>
  );
};

export default GrowingRoutesSection;