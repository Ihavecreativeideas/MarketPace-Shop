import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Store, BarChart3, MessageSquare, Settings, Zap, Crown } from 'lucide-react';
import POSIntegration from './POSIntegration';
import VendorReviews from './VendorReviews';
import VendorAnalytics from './VendorAnalytics';
import VendorPartnershipTiers from './VendorPartnershipTiers';
import PlatformDropdown from './PlatformDropdown';

export default function BusinessDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const businessId = 'business-123'; // Mock business ID

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <Store className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold">Business Dashboard</h1>
                <p className="text-gray-600">Manage your business operations</p>
              </div>
            </div>
            <PlatformDropdown />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Store className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="pos" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              POS Integration
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics & AI
            </TabsTrigger>
            <TabsTrigger value="reviews" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Reviews
            </TabsTrigger>
            <TabsTrigger value="partnership" className="flex items-center gap-2">
              <Crown className="h-4 w-4" />
              Partnership
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Quick Stats</CardTitle>
                  <CardDescription>Today's performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Orders:</span>
                      <span className="font-semibold">23</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Revenue:</span>
                      <span className="font-semibold">$1,245</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Rating:</span>
                      <span className="font-semibold">4.6 ★</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>POS Status</CardTitle>
                  <CardDescription>System integration</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span>Square POS</span>
                      <span className="text-green-600 text-sm">Connected</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Last Sync</span>
                      <span className="text-sm">2 min ago</span>
                    </div>
                    <Button size="sm" variant="outline" className="w-full">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>AI Insights</CardTitle>
                  <CardDescription>Latest recommendations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-sm">
                      <div className="font-medium text-blue-600">Peak Hour Alert</div>
                      <div className="text-gray-600">Lunch rush starting soon</div>
                    </div>
                    <div className="text-sm">
                      <div className="font-medium text-green-600">Inventory Tip</div>
                      <div className="text-gray-600">Restock popular items</div>
                    </div>
                    <Button size="sm" variant="outline" className="w-full">
                      View All Insights
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="pos">
            <POSIntegration />
          </TabsContent>

          <TabsContent value="analytics">
            <VendorAnalytics businessId={businessId} />
          </TabsContent>

          <TabsContent value="reviews">
            <VendorReviews businessId={businessId} />
          </TabsContent>

          <TabsContent value="partnership">
            <VendorPartnershipTiers userId={businessId} />
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Business Settings</CardTitle>
                <CardDescription>Manage your account and preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Business Information</h3>
                    <p className="text-sm text-gray-600">Update your business details and contact information</p>
                    <Button variant="outline" className="mt-2">Edit Details</Button>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Payment Settings</h3>
                    <p className="text-sm text-gray-600">Configure payment methods and payout preferences</p>
                    <Button variant="outline" className="mt-2">Manage Payments</Button>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Notification Preferences</h3>
                    <p className="text-sm text-gray-600">Choose how you want to receive notifications</p>
                    <Button variant="outline" className="mt-2">Update Preferences</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}