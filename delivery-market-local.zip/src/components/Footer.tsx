import React from 'react';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { FileText, Shield, Mail, Phone, MapPin } from 'lucide-react';

interface FooterProps {
  onLegalClick?: () => void;
}

const Footer: React.FC<FooterProps> = ({ onLegalClick }) => {
  return (
    <footer className="bg-white border-t border-gray-200 mt-12">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">MarketPace</h3>
            <p className="text-sm text-gray-600">
              Your local delivery and marketplace hub connecting customers, merchants, and drivers.
            </p>
            <div className="flex space-x-4">
              <Button variant="outline" size="sm">
                Download iOS
              </Button>
              <Button variant="outline" size="sm">
                Download Android
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-900">Quick Links</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-gray-900">Marketplace</a></li>
              <li><a href="#" className="hover:text-gray-900">Become a Driver</a></li>
              <li><a href="#" className="hover:text-gray-900">Partner with Us</a></li>
              <li><a href="#" className="hover:text-gray-900">Help Center</a></li>
            </ul>
          </div>

          {/* Legal */}
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-900">Legal</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>
                <button 
                  onClick={onLegalClick}
                  className="hover:text-gray-900 flex items-center gap-2"
                >
                  <FileText className="h-3 w-3" />
                  Terms of Service
                </button>
              </li>
              <li>
                <button 
                  onClick={onLegalClick}
                  className="hover:text-gray-900 flex items-center gap-2"
                >
                  <Shield className="h-3 w-3" />
                  Privacy Policy
                </button>
              </li>
              <li><a href="#" className="hover:text-gray-900">Cookie Policy</a></li>
              <li><a href="#" className="hover:text-gray-900">Accessibility</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-900">Contact Us</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-center gap-2">
                <Mail className="h-3 w-3" />
                support@marketpace.com
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-3 w-3" />
                1-800-MARKET
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-3 w-3" />
                Available in 50+ cities
              </li>
            </ul>
          </div>
        </div>

        <Separator className="my-8" />

        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-sm text-gray-600">
            © {new Date().getFullYear()} MarketPace. All rights reserved.
          </div>
          <div className="flex space-x-6 text-sm text-gray-600">
            <a href="#" className="hover:text-gray-900">Facebook</a>
            <a href="#" className="hover:text-gray-900">Twitter</a>
            <a href="#" className="hover:text-gray-900">Instagram</a>
            <a href="#" className="hover:text-gray-900">LinkedIn</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;