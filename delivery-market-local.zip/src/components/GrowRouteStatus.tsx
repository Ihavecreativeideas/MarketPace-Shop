import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Users, Clock, MapPin, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface GrowRouteStatusProps {
  routeId: string;
  onComplete: () => void;
  onCancel: () => void;
}

interface RouteStatus {
  id: string;
  location: string;
  currentBuyers: number;
  timeRemaining: number;
  discountPercentage: number;
  status: 'waiting' | 'ready' | 'completed';
}

export const GrowRouteStatus: React.FC<GrowRouteStatusProps> = ({
  routeId,
  onComplete,
  onCancel
}) => {
  const [routeStatus, setRouteStatus] = useState<RouteStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchRouteStatus();
    const interval = setInterval(fetchRouteStatus, 15000);
    return () => clearInterval(interval);
  }, [routeId]);

  const fetchRouteStatus = async () => {
    try {
      setError(null);
      
      // Mock data for now - no external API calls
      const mockStatus: RouteStatus = {
        id: routeId,
        location: 'Your Area',
        currentBuyers: Math.floor(Math.random() * 5) + 1,
        timeRemaining: 180 - Math.floor(Math.random() * 60),
        discountPercentage: 0,
        status: 'waiting'
      };
      
      // Calculate discount based on buyers
      if (mockStatus.currentBuyers >= 5) {
        mockStatus.discountPercentage = 25;
        mockStatus.status = 'ready';
      } else if (mockStatus.currentBuyers >= 4) {
        mockStatus.discountPercentage = 20;
      } else if (mockStatus.currentBuyers >= 3) {
        mockStatus.discountPercentage = 15;
      } else {
        mockStatus.discountPercentage = mockStatus.currentBuyers * 5;
      }
      
      setRouteStatus(mockStatus);
    } catch (error) {
      console.error('Error fetching route status:', error);
      setError('Failed to load route status');
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteRoute = () => {
    toast({ 
      title: 'Route Ready!', 
      description: `Your delivery will start soon with ${routeStatus?.discountPercentage}% discount!` 
    });
    onComplete();
  };

  if (loading) {
    return <div className="text-center py-4">Loading route status...</div>;
  }

  if (error) {
    return (
      <Card className="border-red-200 bg-red-50">
        <CardContent className="p-4 text-center">
          <p className="text-red-700">{error}</p>
          <Button onClick={fetchRouteStatus} className="mt-2">Retry</Button>
        </CardContent>
      </Card>
    );
  }

  if (!routeStatus) {
    return <div className="text-center py-4">No route data available</div>;
  }

  const progress = Math.min((routeStatus.currentBuyers / 5) * 100, 100);
  const hoursLeft = Math.floor(routeStatus.timeRemaining / 60);
  const minutesLeft = routeStatus.timeRemaining % 60;

  return (
    <Card className="border-green-200 bg-green-50">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-green-600" />
            Your Growing Route
          </div>
          <Badge 
            variant={routeStatus.status === 'ready' ? 'default' : 'secondary'}
            className={routeStatus.status === 'ready' ? 'bg-green-600' : 'bg-yellow-100 text-yellow-700'}
          >
            {routeStatus.status === 'ready' ? 'Ready!' : 'Growing...'}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-gray-500" />
            <span>{routeStatus.location}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-gray-500" />
            <span>{hoursLeft}h {minutesLeft}m remaining</span>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Buyers Joined: {routeStatus.currentBuyers}</span>
            <div className="text-right">
              <div className="text-lg font-bold text-green-600">{routeStatus.discountPercentage}% OFF</div>
              <div className="text-xs text-gray-600">Split delivery fee</div>
            </div>
          </div>
          
          <Progress value={progress} className="h-3" />
          
          <div className="text-xs text-gray-600 text-center">
            {routeStatus.currentBuyers < 5 
              ? `${5 - routeStatus.currentBuyers} more buyers needed for maximum 25% discount`
              : 'Maximum discount achieved! 🎉'
            }
          </div>
        </div>

        <div className="bg-white p-3 rounded-lg border">
          <h4 className="font-medium text-sm mb-2">Current Savings:</h4>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span>Item Discount:</span>
              <span className="text-green-600 font-medium">{routeStatus.discountPercentage}%</span>
            </div>
            <div className="flex justify-between">
              <span>Delivery Fee:</span>
              <span className="text-green-600 font-medium">Split with seller</span>
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          {routeStatus.status === 'ready' ? (
            <Button onClick={handleCompleteRoute} className="flex-1 bg-green-600 hover:bg-green-700">
              <CheckCircle className="w-4 h-4 mr-2" />
              Complete Order
            </Button>
          ) : (
            <Button disabled className="flex-1">
              Waiting for more buyers...
            </Button>
          )}
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};