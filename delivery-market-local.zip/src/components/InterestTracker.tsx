import React, { useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

interface InterestTrackerProps {
  userId: string;
}

interface BehaviorData {
  searches: string[];
  purchases: Array<{
    category: string;
    item: string;
    price: number;
  }>;
  views: Array<{
    category: string;
    item: string;
    duration: number;
  }>;
  demographics?: {
    age_range?: string;
    gender?: string;
    location?: string;
  };
}

export const InterestTracker: React.FC<InterestTrackerProps> = ({ userId }) => {
  const { toast } = useToast();

  useEffect(() => {
    // Initialize behavior tracking
    initializeTracking();
  }, [userId]);

  const initializeTracking = () => {
    // Track search behavior
    trackSearches();
    // Track page views
    trackPageViews();
    // Track clicks and interactions
    trackInteractions();
  };

  const trackSearches = () => {
    const originalSearch = window.history.pushState;
    window.history.pushState = function(state, title, url) {
      if (url && url.includes('search=')) {
        const searchTerm = new URL(url, window.location.origin).searchParams.get('search');
        if (searchTerm) {
          recordBehavior('search', { query: searchTerm });
        }
      }
      return originalSearch.apply(this, arguments as any);
    };
  };

  const trackPageViews = () => {
    const startTime = Date.now();
    
    const handleBeforeUnload = () => {
      const duration = Date.now() - startTime;
      const category = inferCategoryFromPath(window.location.pathname);
      if (category && duration > 5000) { // Only track if viewed for 5+ seconds
        recordBehavior('view', { category, duration });
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  };

  const trackInteractions = () => {
    document.addEventListener('click', (event) => {
      const target = event.target as HTMLElement;
      
      // Track clicks on items, categories, etc.
      if (target.closest('[data-category]')) {
        const category = target.closest('[data-category]')?.getAttribute('data-category');
        const item = target.closest('[data-item]')?.getAttribute('data-item');
        
        if (category) {
          recordBehavior('click', { category, item });
        }
      }
    });
  };

  const inferCategoryFromPath = (path: string): string | null => {
    if (path.includes('musician')) return 'music';
    if (path.includes('medpace')) return 'health';
    if (path.includes('marketplace')) return 'general';
    return null;
  };

  const recordBehavior = async (type: string, data: any) => {
    try {
      // Collect behavior data
      const behaviorData: BehaviorData = {
        searches: type === 'search' ? [data.query] : [],
        purchases: [],
        views: type === 'view' ? [data] : [],
        demographics: {
          location: 'user_location' // This would come from user profile
        }
      };

      // Send to AI analyzer
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/2b57bae7-1e74-475e-8bb1-58911db94f6d',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId,
            action: 'analyze_behavior',
            data: behaviorData
          })
        }
      );

      const result = await response.json();
      if (result.success && result.interests.length > 0) {
        // Optionally show a subtle notification about learning preferences
        console.log('Updated user interests:', result.interests);
      }
    } catch (error) {
      console.error('Failed to record behavior:', error);
    }
  };

  // This component doesn't render anything visible
  return null;
};

// Hook for manual interest tracking
export const useInterestTracker = (userId: string) => {
  const trackPurchase = async (category: string, item: string, price: number) => {
    const behaviorData: BehaviorData = {
      searches: [],
      purchases: [{ category, item, price }],
      views: []
    };

    try {
      await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/2b57bae7-1e74-475e-8bb1-58911db94f6d',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId,
            action: 'analyze_behavior',
            data: behaviorData
          })
        }
      );
    } catch (error) {
      console.error('Failed to track purchase:', error);
    }
  };

  const trackDemographics = async (demographics: { age_range?: string; gender?: string; location?: string }) => {
    const behaviorData: BehaviorData = {
      searches: [],
      purchases: [],
      views: [],
      demographics
    };

    try {
      await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/2b57bae7-1e74-475e-8bb1-58911db94f6d',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId,
            action: 'analyze_behavior',
            data: behaviorData
          })
        }
      );
    } catch (error) {
      console.error('Failed to track demographics:', error);
    }
  };

  return { trackPurchase, trackDemographics };
};