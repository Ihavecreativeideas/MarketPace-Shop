import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Bell, Heart, Star, MapPin } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Recommendation {
  id: string;
  item_title: string;
  item_description: string;
  item_price: number;
  item_category: string;
  match_score: number;
  match_reasons: string[];
  seller_location?: string;
  created_at: string;
}

interface ForYouSectionProps {
  userId: string;
}

export const ForYouSection: React.FC<ForYouSectionProps> = ({ userId }) => {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadRecommendations();
  }, [userId]);

  const loadRecommendations = () => {
    setLoading(true);
    
    // Use static mock data to prevent fetch errors
    const mockRecommendations: Recommendation[] = [
      {
        id: '1',
        item_title: 'Organic Coffee Beans',
        item_description: 'Premium single-origin coffee beans from local roasters',
        item_price: 18.99,
        item_category: 'Food & Beverages',
        match_score: 0.92,
        match_reasons: ['You frequently buy coffee', 'Matches your organic preferences'],
        seller_location: 'Downtown Coffee Co.',
        created_at: new Date().toISOString()
      },
      {
        id: '2',
        item_title: 'Handmade Ceramic Mug',
        item_description: 'Beautiful handcrafted ceramic mug perfect for your morning coffee',
        item_price: 24.50,
        item_category: 'Home & Kitchen',
        match_score: 0.85,
        match_reasons: ['Complements your coffee purchases', 'Local artisan product'],
        seller_location: 'Clay & Craft Studio',
        created_at: new Date().toISOString()
      },
      {
        id: '3',
        item_title: 'Fresh Pastries',
        item_description: 'Daily fresh baked croissants and pastries from local bakery',
        item_price: 8.75,
        item_category: 'Food & Beverages',
        match_score: 0.78,
        match_reasons: ['Perfect with coffee', 'Popular in your area'],
        seller_location: 'Morning Glory Bakery',
        created_at: new Date().toISOString()
      }
    ];
    
    // Simulate brief loading
    setTimeout(() => {
      setRecommendations(mockRecommendations);
      setLoading(false);
    }, 500);
  };

  const handleNotifyMe = (item: Recommendation) => {
    toast({
      title: "Notification Set!",
      description: `We'll notify you about similar items to "${item.item_title}"`
    });
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="h-6 bg-gray-200 rounded animate-pulse"></div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-48 bg-gray-200 rounded animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Star className="h-6 w-6 text-yellow-500" />
        <h2 className="text-2xl font-bold">For You</h2>
        <Badge variant="secondary">AI Powered</Badge>
      </div>
      
      <p className="text-muted-foreground">
        Personalized recommendations based on your interests and activity
      </p>

      {recommendations.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Heart className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">Building Your Profile</h3>
            <p className="text-muted-foreground">
              Browse and interact with items to get personalized recommendations!
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {recommendations.map((item, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{item.item_title}</CardTitle>
                  <Badge variant="outline">
                    {Math.round(item.match_score * 100)}% match
                  </Badge>
                </div>
                <p className="text-2xl font-bold text-green-600">
                  ${item.item_price.toFixed(2)}
                </p>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  {item.item_description}
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>{item.seller_location || 'Local area'}</span>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Why this matches you:</p>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {item.match_reasons.map((reason, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <div className="w-1 h-1 bg-current rounded-full" />
                          {reason}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button className="flex-1">View Item</Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleNotifyMe(item)}
                    >
                      <Bell className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};