import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Store, Truck, Leaf, Search, TrendingUp, Crown, Globe, Zap } from 'lucide-react';
import FoodServiceIntegration from './FoodServiceIntegration';
import DeliveryServiceSelector from './DeliveryServiceSelector';
import DoorDashIntegration from './DoorDashIntegration';

interface BusinessProfileProps {
  userId: string;
}

interface UserProfile {
  id: string;
  subscription_tier?: string;
  business_type?: string;
  delivery_discount?: number;
  sustainability_fee_discount?: number;
  search_priority?: number;
  web_integration_enabled?: boolean;
  updated_at?: string;
}

const BusinessProfile: React.FC<BusinessProfileProps> = ({ userId }) => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedDeliveryMethod, setSelectedDeliveryMethod] = useState('marketplace');
  const { toast } = useToast();

  useEffect(() => {
    fetchProfile();
  }, [userId]);

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) throw error;
      setProfile(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
      toast({
        title: 'Error',
        description: 'Could not load business profile',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const getTierName = (tier?: string) => {
    return 'MarketPlace Partner';
  };

  const getTierColor = (tier?: string) => {
    return 'bg-blue-100 text-blue-800';
  };

  const handleDeliveryMethodChange = (method: string) => {
    setSelectedDeliveryMethod(method);
    toast({
      title: 'Delivery Method Updated',
      description: `Selected ${method} as your delivery method`
    });
  };

  const isFoodBusiness = profile?.business_type === 'restaurant' || profile?.business_type === 'food';

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Store className="h-5 w-5" />
            Business Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-lg">Partnership Status</h3>
              <p className="text-sm text-gray-600">FREE MarketPlace Partner</p>
            </div>
            <Badge className={getTierColor()}>
              <Crown className="h-3 w-3 mr-1" />
              {getTierName()}
            </Badge>
          </div>

          <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg">
            <h4 className="font-semibold text-gray-900 mb-2">🚀 Platform Benefits</h4>
            <p className="text-sm text-gray-700 mb-3">
              Use MarketPlace as your promotional platform to reach more customers. 
              Choose any delivery method that works best for your business - it's not mandatory to use our drivers!
            </p>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• Reach customers through our platform</li>
              <li>• Choose your preferred delivery service</li>
              <li>• UPS, FedEx, USPS, or self-delivery options</li>
              <li>• Keep your existing delivery partnerships</li>
            </ul>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Truck className="h-5 w-5 text-green-600" />
                <span className="font-semibold text-green-800">Flexible Delivery</span>
              </div>
              <p className="text-2xl font-bold text-green-600">
                Your Choice
              </p>
              <p className="text-sm text-green-700">Any delivery service</p>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Leaf className="h-5 w-5 text-blue-600" />
                <span className="font-semibold text-blue-800">Platform Access</span>
              </div>
              <p className="text-2xl font-bold text-blue-600">
                100%
              </p>
              <p className="text-sm text-blue-700">Full promotional platform</p>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Search className="h-5 w-5 text-purple-600" />
                <span className="font-semibold text-purple-800">Analytics</span>
              </div>
              <p className="text-2xl font-bold text-purple-600">
                Included
              </p>
              <p className="text-sm text-purple-700">Business insights</p>
            </div>

            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Globe className="h-5 w-5 text-orange-600" />
                <span className="font-semibold text-orange-800">Web Integration</span>
              </div>
              <p className="text-2xl font-bold text-orange-600">
                Enabled
              </p>
              <p className="text-sm text-orange-700">Website sync included</p>
            </div>
          </div>

          {profile?.updated_at && (
            <div className="text-xs text-gray-500 text-center">
              Profile last updated: {new Date(profile.updated_at).toLocaleString()}
            </div>
          )}
        </CardContent>
      </Card>

      <DeliveryServiceSelector 
        businessType={profile?.business_type}
        onDeliveryMethodChange={handleDeliveryMethodChange}
        selectedMethod={selectedDeliveryMethod}
      />

      {isFoodBusiness && (
        <>
          <FoodServiceIntegration 
            businessType={profile?.business_type}
          />
          <DoorDashIntegration 
            businessType={profile?.business_type}
          />
        </>
      )}
    </div>
  );
};

export default BusinessProfile;