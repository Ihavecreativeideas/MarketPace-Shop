import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Truck, Package, Users, ExternalLink, Info } from 'lucide-react';

interface DeliveryServiceSelectorProps {
  businessType?: string;
  onDeliveryMethodChange?: (method: string) => void;
  selectedMethod?: string;
}

const DeliveryServiceSelector: React.FC<DeliveryServiceSelectorProps> = ({
  businessType,
  onDeliveryMethodChange,
  selectedMethod = 'marketplace'
}) => {
  const [deliveryMethod, setDeliveryMethod] = useState(selectedMethod);
  const [connectedServices, setConnectedServices] = useState<string[]>([]);

  const isFoodService = businessType === 'restaurant' || businessType === 'food';

  const handleMethodChange = (method: string) => {
    setDeliveryMethod(method);
    onDeliveryMethodChange?.(method);
  };

  const connectService = (service: string) => {
    setConnectedServices(prev => [...prev, service]);
  };

  const deliveryOptions = [
    {
      id: 'marketplace',
      name: 'MarketPlace Drivers',
      icon: Users,
      description: 'Use our local driver network',
      disabled: isFoodService,
      disabledReason: 'Food delivery not permitted'
    },
    {
      id: 'ups',
      name: 'UPS',
      icon: Package,
      description: 'Professional shipping service',
      disabled: false
    },
    {
      id: 'fedex',
      name: 'FedEx',
      icon: Package,
      description: 'Express delivery options',
      disabled: false
    },
    {
      id: 'usps',
      name: 'USPS',
      icon: Package,
      description: 'Affordable mail service',
      disabled: false
    },
    {
      id: 'self',
      name: 'Self Delivery',
      icon: Truck,
      description: 'Handle delivery yourself',
      disabled: false
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Truck className="h-5 w-5" />
          Delivery Options
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {isFoodService && (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Food businesses must use specialized food delivery services like Uber Eats or DoorDash.
            </AlertDescription>
          </Alert>
        )}

        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-semibold text-blue-900 mb-2">Platform Benefits</h4>
          <p className="text-sm text-blue-800">
            Use MarketPlace as your platform to reach more customers. 
            Choose any delivery method that works best for your business.
          </p>
        </div>

        <RadioGroup value={deliveryMethod} onValueChange={handleMethodChange}>
          <div className="grid gap-3">
            {deliveryOptions.map((option) => {
              const IconComponent = option.icon;
              return (
                <div key={option.id} className="flex items-center space-x-3">
                  <RadioGroupItem 
                    value={option.id} 
                    id={option.id}
                    disabled={option.disabled}
                  />
                  <Label 
                    htmlFor={option.id} 
                    className={`flex-1 cursor-pointer ${
                      option.disabled ? 'opacity-50' : ''
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <IconComponent className="h-5 w-5" />
                        <div>
                          <div className="font-medium">{option.name}</div>
                          <div className="text-sm text-gray-600">
                            {option.description}
                          </div>
                          {option.disabled && option.disabledReason && (
                            <div className="text-xs text-red-600">
                              {option.disabledReason}
                            </div>
                          )}
                        </div>
                      </div>
                      {connectedServices.includes(option.id) && (
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          Connected
                        </Badge>
                      )}
                    </div>
                  </Label>
                </div>
              );
            })}
          </div>
        </RadioGroup>

        {deliveryMethod === 'ups' && (
          <Card className="border-orange-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold">UPS Integration</h4>
                <Button 
                  size="sm" 
                  onClick={() => {
                    window.open('https://www.ups.com/us/en/services/small-business.page', '_blank');
                    connectService('ups');
                  }}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Connect UPS
                </Button>
              </div>
              <p className="text-sm text-gray-600">
                Connect your UPS account for automated shipping labels and tracking.
              </p>
            </CardContent>
          </Card>
        )}

        {deliveryMethod === 'fedex' && (
          <Card className="border-purple-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold">FedEx Integration</h4>
                <Button 
                  size="sm" 
                  onClick={() => {
                    window.open('https://www.fedex.com/en-us/small-business.html', '_blank');
                    connectService('fedex');
                  }}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Connect FedEx
                </Button>
              </div>
              <p className="text-sm text-gray-600">
                Connect your FedEx account for express shipping options.
              </p>
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  );
};

export default DeliveryServiceSelector;