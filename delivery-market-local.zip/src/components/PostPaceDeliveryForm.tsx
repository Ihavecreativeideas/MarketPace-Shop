import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { Package, MapPin, AlertTriangle, Clock, Zap } from 'lucide-react';
import PostOfficeSelector from './PostOfficeSelector';

interface PostOffice {
  id: string;
  name: string;
  address: string;
  distance: number;
  type: 'usps' | 'fedex' | 'ups';
  hours: string;
  services: string[];
}

const PostPaceDeliveryForm: React.FC = () => {
  const [formData, setFormData] = useState({
    pickupAddress: '',
    packageType: '',
    description: '',
    urgency: 'grow-routes'
  });
  const [selectedOffice, setSelectedOffice] = useState<PostOffice | undefined>();
  const [cost, setCost] = useState(0);
  const [errors, setErrors] = useState<string[]>([]);

  const prohibitedItems = [
    'alcohol', 'beer', 'wine', 'liquor', 'spirits',
    'hazardous', 'flammable', 'explosive', 'toxic',
    'chemical', 'battery', 'lithium', 'gas', 'fuel'
  ];

  const calculateCost = (distance: number) => {
    const baseCost = 14; // $14 for first 8 miles
    const extraMiles = Math.max(0, distance - 8);
    const extraCost = extraMiles * 1.25;
    return baseCost + extraCost;
  };

  const validateItems = (description: string) => {
    const newErrors: string[] = [];
    const lowerDesc = description.toLowerCase();
    
    prohibitedItems.forEach(item => {
      if (lowerDesc.includes(item)) {
        newErrors.push(`${item.charAt(0).toUpperCase() + item.slice(1)} items cannot be shipped`);
      }
    });
    
    setErrors(newErrors);
    return newErrors.length === 0;
  };

  const handleDescriptionChange = (value: string) => {
    setFormData(prev => ({ ...prev, description: value }));
    validateItems(value);
  };

  const handleOfficeSelect = (office: PostOffice) => {
    setSelectedOffice(office);
    setCost(calculateCost(office.distance));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (errors.length > 0) {
      alert('Please remove prohibited items before submitting.');
      return;
    }
    if (!formData.pickupAddress || !selectedOffice) {
      alert('Please provide pickup address and select a drop-off location.');
      return;
    }
    console.log('Delivery request submitted:', { ...formData, dropoffLocation: selectedOffice });
    alert(`Delivery request submitted! Total cost: $${cost.toFixed(2)}`);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            PostPace Delivery Request
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="pickup">Pickup Address *</Label>
              <Input
                id="pickup"
                placeholder="Enter pickup address"
                value={formData.pickupAddress}
                onChange={(e) => setFormData(prev => ({ ...prev, pickupAddress: e.target.value }))}
                required
              />
            </div>

            <div>
              <Label htmlFor="urgency">Delivery Priority</Label>
              <Select value={formData.urgency} onValueChange={(value) => setFormData(prev => ({ ...prev, urgency: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="urgent">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-red-500" />
                      Urgent
                    </div>
                  </SelectItem>
                  <SelectItem value="grow-routes">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-green-500" />
                      Grow Routes
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="description">Package Description *</Label>
              <Textarea
                id="description"
                placeholder="Describe what you're shipping (required for safety check)"
                value={formData.description}
                onChange={(e) => handleDescriptionChange(e.target.value)}
                required
              />
            </div>

            {errors.length > 0 && (
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="w-4 h-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  <ul className="list-disc list-inside">
                    {errors.map((error, index) => (
                      <li key={index}>{error}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}
          </form>
        </CardContent>
      </Card>

      <PostOfficeSelector onSelect={handleOfficeSelect} selectedOffice={selectedOffice} />

      {selectedOffice && cost > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-blue-900">Delivery Summary</CardTitle>
          </CardHeader>
          <CardContent className="bg-blue-50">
            <div className="text-blue-800 space-y-2">
              <p><strong>Drop-off:</strong> {selectedOffice.name}</p>
              <p><strong>Distance:</strong> {selectedOffice.distance} miles</p>
              <p>Base cost (8 miles): $14.00</p>
              {selectedOffice.distance > 8 && (
                <p>Extra miles ({(selectedOffice.distance - 8).toFixed(1)}): ${((selectedOffice.distance - 8) * 1.25).toFixed(2)}</p>
              )}
              <p className="font-bold text-lg border-t pt-2">Total: ${cost.toFixed(2)}</p>
            </div>
            <Button 
              onClick={handleSubmit} 
              className="w-full mt-4" 
              disabled={errors.length > 0 || !formData.pickupAddress || !selectedOffice}
            >
              Request Pickup & Delivery
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PostPaceDeliveryForm;