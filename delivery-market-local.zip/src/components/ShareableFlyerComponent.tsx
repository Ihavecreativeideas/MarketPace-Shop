import React from 'react';
import { Button } from './ui/button';
import { Car, Clock, DollarSign, MapPin, Users } from 'lucide-react';

interface ShareableFlyerComponentProps {
  onApplyNow: () => void;
  onShare: () => void;
}

const ShareableFlyerComponent: React.FC<ShareableFlyerComponentProps> = ({ onApplyNow, onShare }) => {
  return (
    <div className="bg-gradient-to-br from-orange-400 via-pink-500 to-purple-600 p-8 rounded-2xl text-white shadow-2xl max-w-md mx-auto">
      {/* Header */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-4 animate-bounce">
          <Car className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold mb-2">
          MarketPace: Delivering Opportunities
        </h1>
        <p className="text-lg opacity-90">
          to a town near you!
        </p>
      </div>

      {/* Main Message */}
      <div className="text-center mb-6">
        <p className="text-lg font-semibold mb-2">
          Apply to become a driver today!
        </p>
        <p className="text-sm opacity-90">
          Flexible hours, competitive pay, and the chance to support your local community.
        </p>
      </div>

      {/* Benefits Grid */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="text-center">
          <Clock className="h-6 w-6 mx-auto mb-2 text-yellow-300" />
          <p className="text-sm font-semibold">Flexible Hours</p>
        </div>
        <div className="text-center">
          <DollarSign className="h-6 w-6 mx-auto mb-2 text-green-300" />
          <p className="text-sm font-semibold">Great Pay</p>
        </div>
        <div className="text-center">
          <MapPin className="h-6 w-6 mx-auto mb-2 text-blue-300" />
          <p className="text-sm font-semibold">Local Routes</p>
        </div>
        <div className="text-center">
          <Users className="h-6 w-6 mx-auto mb-2 text-pink-300" />
          <p className="text-sm font-semibold">Community Impact</p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button 
          onClick={onApplyNow}
          className="w-full bg-white text-purple-600 hover:bg-gray-100 font-bold py-3 text-lg"
        >
          Apply to Drive Now
        </Button>
        <Button 
          onClick={onShare}
          variant="outline"
          className="w-full border-white text-white hover:bg-white/10 font-semibold"
        >
          Join the Campaign
        </Button>
      </div>
    </div>
  );
};

export default ShareableFlyerComponent;