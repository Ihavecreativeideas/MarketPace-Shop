import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, CheckCircle, XCircle } from 'lucide-react';

interface AvailabilitySlot {
  date: string;
  time: string;
  status: 'available' | 'booked' | 'pending';
  price?: number;
}

interface AvailabilityCalendarProps {
  musicianId: number;
  onBookSlot: (date: string, time: string) => void;
}

const AvailabilityCalendar: React.FC<AvailabilityCalendarProps> = ({ musicianId, onBookSlot }) => {
  const [selectedDate, setSelectedDate] = useState<string>('');
  
  // Mock availability data
  const availability: AvailabilitySlot[] = [
    { date: '2024-01-15', time: '7:00 PM', status: 'available', price: 250 },
    { date: '2024-01-16', time: '8:00 PM', status: 'booked' },
    { date: '2024-01-18', time: '6:00 PM', status: 'available', price: 300 },
    { date: '2024-01-20', time: '7:30 PM', status: 'pending', price: 275 },
    { date: '2024-01-22', time: '8:00 PM', status: 'available', price: 250 },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'available': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'booked': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'pending': return <Clock className="w-4 h-4 text-yellow-500" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-50 border-green-200';
      case 'booked': return 'bg-red-50 border-red-200';
      case 'pending': return 'bg-yellow-50 border-yellow-200';
      default: return 'bg-gray-50';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Availability Calendar
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex gap-4 text-sm">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Available</span>
            </div>
            <div className="flex items-center gap-2">
              <XCircle className="w-4 h-4 text-red-500" />
              <span>Booked</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-yellow-500" />
              <span>Pending</span>
            </div>
          </div>
          
          <div className="space-y-2">
            {availability.map((slot, index) => (
              <div key={index} className={`p-3 rounded-lg border ${getStatusColor(slot.status)}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(slot.status)}
                    <div>
                      <p className="font-medium">{new Date(slot.date).toLocaleDateString()}</p>
                      <p className="text-sm text-gray-600">{slot.time}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {slot.price && (
                      <span className="font-semibold text-green-600">${slot.price}</span>
                    )}
                    {slot.status === 'available' && (
                      <Button 
                        size="sm" 
                        onClick={() => onBookSlot(slot.date, slot.time)}
                      >
                        Book Now
                      </Button>
                    )}
                    {slot.status === 'pending' && (
                      <Badge variant="outline">Pending</Badge>
                    )}
                    {slot.status === 'booked' && (
                      <Badge variant="destructive">Booked</Badge>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AvailabilityCalendar;