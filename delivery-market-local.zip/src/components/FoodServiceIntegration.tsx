import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ExternalLink, Utensils, AlertTriangle, CheckCircle } from 'lucide-react';

interface FoodServiceIntegrationProps {
  businessType?: string;
  onIntegrationUpdate?: (platform: string, connected: boolean) => void;
}

const FoodServiceIntegration: React.FC<FoodServiceIntegrationProps> = ({
  businessType,
  onIntegrationUpdate
}) => {
  const [uberEatsConnected, setUberEatsConnected] = useState(false);
  const [doorDashConnected, setDoorDashConnected] = useState(false);

  const isFoodService = businessType === 'restaurant' || businessType === 'food';

  const handleUberEatsConnect = () => {
    // In a real app, this would open OAuth flow
    window.open('https://merchants.ubereats.com/us/en/signup/', '_blank');
    setUberEatsConnected(true);
    onIntegrationUpdate?.('ubereats', true);
  };

  const handleDoorDashConnect = () => {
    // In a real app, this would open OAuth flow
    window.open('https://get.doordash.com/en-us/products/business/restaurants', '_blank');
    setDoorDashConnected(true);
    onIntegrationUpdate?.('doordash', true);
  };

  if (!isFoodService) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Utensils className="h-5 w-5" />
          Food Delivery Integration
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Important:</strong> MarketPlace drivers cannot deliver food products. 
            Please connect with Uber Eats or DoorDash for food delivery services.
          </AlertDescription>
        </Alert>

        <div className="grid gap-4 md:grid-cols-2">
          <Card className="border-2">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold">Uber Eats</h3>
                {uberEatsConnected ? (
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Connected
                  </Badge>
                ) : (
                  <Badge variant="outline">Not Connected</Badge>
                )}
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Connect your restaurant to Uber Eats for professional food delivery.
              </p>
              <Button 
                onClick={handleUberEatsConnect}
                className="w-full"
                variant={uberEatsConnected ? "outline" : "default"}
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                {uberEatsConnected ? 'Manage Account' : 'Connect Uber Eats'}
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold">DoorDash</h3>
                {doorDashConnected ? (
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Connected
                  </Badge>
                ) : (
                  <Badge variant="outline">Not Connected</Badge>
                )}
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Connect your restaurant to DoorDash for reliable food delivery.
              </p>
              <Button 
                onClick={handleDoorDashConnect}
                className="w-full"
                variant={doorDashConnected ? "outline" : "default"}
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                {doorDashConnected ? 'Manage Account' : 'Connect DoorDash'}
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-semibold text-blue-900 mb-2">Why Use Third-Party Food Delivery?</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Specialized food handling and temperature control</li>
            <li>• Licensed food delivery drivers</li>
            <li>• Insurance coverage for food products</li>
            <li>• Faster delivery times for hot food</li>
            <li>• Compliance with food safety regulations</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};

export default FoodServiceIntegration;