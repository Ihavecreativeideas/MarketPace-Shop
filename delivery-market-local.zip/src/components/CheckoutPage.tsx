import { useState } from 'react';
import { useCart } from '@/components/CartContext';
import { PaymentMethods } from '@/components/PaymentMethods';
import { OrderSummary } from '@/components/OrderSummary';
import { DeliveryOptionsModal } from '@/components/DeliveryOptionsModal';
import { GrowRouteStatus } from '@/components/GrowRouteStatus';
import { GrowRouteNotification } from '@/components/GrowRouteNotification';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, MapPin, Crown, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

interface CheckoutPageProps {
  onBack: () => void;
  isPartnerShop?: boolean;
  customShippingFee?: number;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({ 
  onBack, 
  isPartnerShop = false,
  customShippingFee = 0
}) => {
  const { cartItems, getCartTotal, clearCart } = useCart();
  const { toast } = useToast();
  const [paymentMethod, setPaymentMethod] = useState('');
  const [loading, setLoading] = useState(false);
  const [tip, setTip] = useState(0);
  const [showDeliveryOptions, setShowDeliveryOptions] = useState(false);
  const [deliveryMode, setDeliveryMode] = useState<'urgent' | 'grow' | null>(null);
  const [activeRouteId, setActiveRouteId] = useState<string | null>(null);
  const [growRouteDiscount, setGrowRouteDiscount] = useState(0);
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    zipCode: ''
  });

  const subtotal = getCartTotal();
  
  const calculateDeliveryFee = () => {
    const estimatedMiles = 5;
    const baseFee = 10;
    const mileageFee = estimatedMiles * 1.25;
    const sustainabilityFee = 4;
    
    const sharedFees = baseFee + mileageFee;
    const buyerShare = sharedFees / 2;
    
    let sellerShare;
    let actualSustainabilityFee;
    
    if (isPartnerShop) {
      sellerShare = (sharedFees / 2) * 0.8;
      actualSustainabilityFee = 0;
    } else {
      sellerShare = sharedFees / 2 + sustainabilityFee;
      actualSustainabilityFee = sustainabilityFee;
    }
    
    return {
      baseFee,
      mileageFee,
      sustainabilityFee: actualSustainabilityFee,
      buyerShare,
      sellerShare,
      totalDeliveryFee: buyerShare + sellerShare,
      estimatedMiles
    };
  };
  
  const deliveryInfo = calculateDeliveryFee();
  const discountedSubtotal = deliveryMode === 'grow' ? subtotal * (1 - growRouteDiscount / 100) : subtotal;
  const shippingFee = isPartnerShop ? customShippingFee : 0;
  const tax = discountedSubtotal * 0.08;
  const total = discountedSubtotal + deliveryInfo.buyerShare + shippingFee + tip + tax;

  const handleSelectUrgent = () => {
    setDeliveryMode('urgent');
    setShowDeliveryOptions(false);
    setGrowRouteDiscount(0);
    toast({ title: 'Safe Urgent Delivery Selected - Contactless delivery to your door!' });
  };

  const handleSelectGrowRoute = async () => {
    setDeliveryMode('grow');
    setShowDeliveryOptions(false);
    setActiveRouteId('route-123');
    setGrowRouteDiscount(5);
    toast({ title: 'Safe Group Route Started - Affordable delivery with others!' });
  };

  const handleJoinRoute = (routeId: string) => {
    setActiveRouteId(routeId);
    setDeliveryMode('grow');
    setGrowRouteDiscount(15);
  };

  const handleCompleteGrowRoute = () => {
    setGrowRouteDiscount(25);
  };

  const handleCancelGrowRoute = () => {
    setDeliveryMode(null);
    setActiveRouteId(null);
    setGrowRouteDiscount(0);
  };

  const handlePayment = async () => {
    if (!deliveryMode) {
      setShowDeliveryOptions(true);
      return;
    }

    if (!paymentMethod || !customerInfo.name || !customerInfo.email || !customerInfo.address) {
      toast({ title: 'Please fill in required fields', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from('orders').insert({
        customer_name: customerInfo.name,
        customer_email: customerInfo.email,
        delivery_address: customerInfo.address,
        subtotal: discountedSubtotal,
        delivery_fee: deliveryInfo.buyerShare,
        shipping_fee: shippingFee,
        tip_amount: tip,
        total,
        delivery_mode: deliveryMode,
        grow_route_discount: growRouteDiscount,
        is_partner_shop: isPartnerShop,
        status: 'confirmed'
      });

      if (!error) {
        toast({ title: 'Order placed successfully! Safe contactless delivery confirmed.' });
        clearCart();
        onBack();
      }
    } catch (error) {
      toast({ title: 'Payment failed', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-4">
      {/* Safety Banner */}
      <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-center gap-3">
          <Shield className="w-6 h-6 text-green-600" />
          <div>
            <h3 className="font-semibold text-green-800">Safe Delivery Only</h3>
            <p className="text-sm text-green-600">
              We keep our customers safe with convenient, affordable delivery services. No pickup required!
            </p>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <Button variant="ghost" onClick={onBack} className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Cart
        </Button>
        <div className="flex items-center gap-3">
          <h1 className="text-3xl font-bold">Safe Delivery Checkout</h1>
          {isPartnerShop && (
            <Badge className="bg-purple-600">
              <Crown className="w-3 h-3 mr-1" />
              Partner Shop Benefits
            </Badge>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-6">
          {!activeRouteId && deliveryMode !== 'urgent' && customerInfo.city && (
            <GrowRouteNotification 
              userLocation={`${customerInfo.city}, ${customerInfo.zipCode}`}
              onJoinRoute={handleJoinRoute}
            />
          )}

          {activeRouteId && deliveryMode === 'grow' && (
            <GrowRouteStatus 
              routeId={activeRouteId}
              onComplete={handleCompleteGrowRoute}
              onCancel={handleCancelGrowRoute}
            />
          )}

          <Card className={isPartnerShop ? 'bg-purple-50 border-purple-200' : ''}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {isPartnerShop && <Crown className="w-5 h-5 text-purple-600" />}
                <Shield className="w-5 h-5 text-green-600" />
                {isPartnerShop ? 'Partner Shop Safe Delivery' : 'Safe Delivery Pricing'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`p-4 rounded-lg space-y-2 text-sm ${
                isPartnerShop ? 'bg-purple-100' : 'bg-green-50'
              }`}>
                <div className="flex justify-between">
                  <span>Base Fee (split):</span>
                  <span>${deliveryInfo.baseFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Mileage Fee (split):</span>
                  <span>${deliveryInfo.mileageFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-green-600">
                  <span>Your Delivery Share:</span>
                  <span>${deliveryInfo.buyerShare.toFixed(2)}</span>
                </div>
                <div className={`flex justify-between ${
                  isPartnerShop ? 'text-purple-600' : 'text-blue-600'
                }`}>
                  <span>Seller Pays:</span>
                  <span>
                    ${deliveryInfo.sellerShare.toFixed(2)}
                    {isPartnerShop && ' (20% off)'}
                  </span>
                </div>
                <div className="text-xs text-green-600 mt-2 border-t pt-2">
                  <Shield className="w-3 h-3 inline mr-1" />
                  • Contactless delivery to your door
                  • Driver gets paid instantly upon delivery
                  • Tips go directly to driver's account
                  • Safe, convenient, affordable
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Safe Delivery Address
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={customerInfo.phone}
                    onChange={(e) => setCustomerInfo(prev => ({ ...prev, phone: e.target.value }))}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={customerInfo.email}
                  onChange={(e) => setCustomerInfo(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="address">Delivery Address *</Label>
                <Input
                  id="address"
                  value={customerInfo.address}
                  onChange={(e) => setCustomerInfo(prev => ({ ...prev, address: e.target.value }))}
                  placeholder="We'll deliver safely to your door"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    value={customerInfo.city}
                    onChange={(e) => setCustomerInfo(prev => ({ ...prev, city: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="zipCode">ZIP Code</Label>
                  <Input
                    id="zipCode"
                    value={customerInfo.zipCode}
                    onChange={(e) => setCustomerInfo(prev => ({ ...prev, zipCode: e.target.value }))}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <PaymentMethods
            selectedMethod={paymentMethod}
            onMethodChange={setPaymentMethod}
            onPayment={handlePayment}
            total={total}
            loading={loading}
          />
        </div>

        <div>
          <OrderSummary
            items={cartItems}
            subtotal={discountedSubtotal}
            deliveryFee={deliveryInfo.buyerShare}
            sustainabilityFee={0}
            tip={tip}
            tax={tax}
            total={total}
            growRouteDiscount={growRouteDiscount}
            buyerDeliveryShare={deliveryInfo.buyerShare}
            sellerDeliveryShare={deliveryInfo.sellerShare}
            isPartnerShop={isPartnerShop}
            customShippingFee={shippingFee}
          />
        </div>
      </div>

      <DeliveryOptionsModal
        isOpen={showDeliveryOptions}
        onClose={() => setShowDeliveryOptions(false)}
        onSelectUrgent={handleSelectUrgent}
        onSelectGrowRoute={handleSelectGrowRoute}
        deliveryFee={deliveryInfo.totalDeliveryFee}
      />
    </div>
  );
};