import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, AlertTriangle, QrCode, Pill, MapPin, Star, Clock } from 'lucide-react';

const PharmacyCheckoutEnhanced: React.FC = () => {
  const [step, setStep] = useState<'pharmacy' | 'prescription' | 'payment' | 'confirmation'>('pharmacy');
  const [selectedPharmacy, setSelectedPharmacy] = useState<any>();
  const [formData, setFormData] = useState({
    patientName: '',
    dateOfBirth: '',
    prescriptionNumber: '',
    medicationName: '',
    doctorName: '',
    customerAddress: '',
    customerPhone: ''
  });
  const [pickupCode, setPickupCode] = useState<string>();
  const [isEligible, setIsEligible] = useState<boolean>();
  const [deliveryId, setDeliveryId] = useState<string>();
  const [estimatedDeliveryTime, setEstimatedDeliveryTime] = useState<string>();

  const pharmacies = [
    { id: 1, name: 'CVS Pharmacy', address: '123 Main St', distance: '0.5 miles', rating: 4.8, phone: '(555) 123-4567', driveThru: true },
    { id: 2, name: 'Walgreens', address: '456 Oak Ave', distance: '1.2 miles', rating: 4.6, phone: '(555) 234-5678', driveThru: true }
  ];

  const controlledSubstances = ['oxycodone', 'adderall', 'xanax', 'morphine', 'fentanyl'];

  const handlePrescriptionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const medicationLower = formData.medicationName.toLowerCase();
    const isControlled = controlledSubstances.some(substance => medicationLower.includes(substance));
    setIsEligible(!isControlled);
    if (!isControlled) {
      setStep('payment');
    }
  };

  const handlePayment = async () => {
    const code = `PU${Date.now().toString().slice(-6)}`;
    setPickupCode(code);
    
    try {
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/eaebc7e9-4820-49ae-a9f0-20d47dc5c702',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'create_delivery',
            pickupCode: code,
            patientName: formData.patientName,
            medicationName: formData.medicationName,
            pharmacyName: selectedPharmacy.name,
            pharmacyAddress: selectedPharmacy.address,
            customerAddress: formData.customerAddress,
            customerPhone: formData.customerPhone,
            prescriptionNumber: formData.prescriptionNumber,
            doctorName: formData.doctorName,
            distanceMiles: parseFloat(selectedPharmacy.distance)
          })
        }
      );
      
      const result = await response.json();
      if (result.success) {
        setDeliveryId(result.delivery.id);
        const deliveryTime = new Date(Date.now() + 45 * 60000);
        setEstimatedDeliveryTime(deliveryTime.toLocaleTimeString());
      }
    } catch (error) {
      console.error('Failed to create delivery:', error);
    }
    
    setStep('confirmation');
  };

  const calculateDeliveryTime = () => {
    const baseTime = 25; // Base pickup time
    const travelTime = Math.ceil(parseFloat(selectedPharmacy?.distance || '1') * 5); // 5 min per mile
    return baseTime + travelTime;
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Card className="bg-gradient-to-r from-blue-50 to-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Pill className="w-5 h-5" />
            Pharmacy Pickup Service - $14.00
          </CardTitle>
        </CardHeader>
      </Card>

      {step === 'pharmacy' && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Select Pharmacy</h3>
          {pharmacies.map((pharmacy) => (
            <Card key={pharmacy.id} className={`cursor-pointer transition-all hover:shadow-md ${
              selectedPharmacy?.id === pharmacy.id ? 'ring-2 ring-blue-500' : ''
            }`} onClick={() => setSelectedPharmacy(pharmacy)}>
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold">{pharmacy.name}</h4>
                    <p className="text-sm text-gray-600">{pharmacy.address}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {pharmacy.distance}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        Est. {Math.ceil(parseFloat(pharmacy.distance) * 5 + 25)} min delivery
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary">
                      <Star className="w-3 h-3 mr-1" />
                      {pharmacy.rating}
                    </Badge>
                    {pharmacy.driveThru && (
                      <Badge variant="outline" className="text-xs mt-1">Drive-Thru</Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {selectedPharmacy && (
            <Button onClick={() => setStep('prescription')} className="w-full">
              Continue with {selectedPharmacy.name}
            </Button>
          )}
        </div>
      )}

      {step === 'prescription' && (
        <Card>
          <CardHeader>
            <CardTitle>Prescription & Delivery Information</CardTitle>
          </CardHeader>
          <CardContent>
            <Alert className="mb-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Controlled substances cannot be picked up by third parties for legal compliance.
              </AlertDescription>
            </Alert>
            <form onSubmit={handlePrescriptionSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Patient Name</Label>
                  <Input value={formData.patientName} onChange={(e) => setFormData({...formData, patientName: e.target.value})} required />
                </div>
                <div>
                  <Label>Date of Birth</Label>
                  <Input type="date" value={formData.dateOfBirth} onChange={(e) => setFormData({...formData, dateOfBirth: e.target.value})} required />
                </div>
              </div>
              <div>
                <Label>Prescription Number</Label>
                <Input value={formData.prescriptionNumber} onChange={(e) => setFormData({...formData, prescriptionNumber: e.target.value})} required />
              </div>
              <div>
                <Label>Medication Name</Label>
                <Input value={formData.medicationName} onChange={(e) => setFormData({...formData, medicationName: e.target.value})} required />
              </div>
              <div>
                <Label>Doctor Name</Label>
                <Input value={formData.doctorName} onChange={(e) => setFormData({...formData, doctorName: e.target.value})} required />
              </div>
              <div>
                <Label>Delivery Address</Label>
                <Input value={formData.customerAddress} onChange={(e) => setFormData({...formData, customerAddress: e.target.value})} placeholder="123 Your Street, City, State" required />
              </div>
              <div>
                <Label>Phone Number</Label>
                <Input value={formData.customerPhone} onChange={(e) => setFormData({...formData, customerPhone: e.target.value})} placeholder="(555) 123-4567" required />
              </div>
              <Button type="submit" className="w-full">Continue to Payment</Button>
            </form>
            {isEligible === false && (
              <Alert className="mt-4" variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  This medication requires patient pickup only. Controlled substances cannot be picked up by third parties.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {step === 'payment' && (
        <Card>
          <CardHeader>
            <CardTitle>Payment Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm mb-4">
              <div className="flex justify-between">
                <span>Medication:</span>
                <span>{formData.medicationName}</span>
              </div>
              <div className="flex justify-between">
                <span>Pharmacy:</span>
                <span>{selectedPharmacy?.name}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Address:</span>
                <span>{formData.customerAddress}</span>
              </div>
              <div className="flex justify-between">
                <span>Estimated Delivery:</span>
                <span>{calculateDeliveryTime()} minutes</span>
              </div>
              <div className="flex justify-between font-semibold border-t pt-2">
                <span>Pickup Fee:</span>
                <span>$14.00</span>
              </div>
            </div>
            <Button onClick={handlePayment} className="w-full">Pay $14.00</Button>
          </CardContent>
        </Card>
      )}

      {step === 'confirmation' && pickupCode && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-600">
              <CheckCircle className="w-5 h-5" />
              Order Confirmed!
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="border-green-200 bg-green-50">
              <QrCode className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                Pickup Code: <strong className="text-lg">{pickupCode}</strong>
              </AlertDescription>
            </Alert>
            <div className="text-sm space-y-2">
              <p><strong>Patient:</strong> {formData.patientName}</p>
              <p><strong>Medication:</strong> {formData.medicationName}</p>
              <p><strong>Pharmacy:</strong> {selectedPharmacy?.name}</p>
              <p><strong>Address:</strong> {selectedPharmacy?.address}</p>
              <p><strong>Phone:</strong> {selectedPharmacy?.phone}</p>
              <p><strong>Delivery To:</strong> {formData.customerAddress}</p>
              {estimatedDeliveryTime && (
                <p><strong>Estimated Delivery:</strong> {estimatedDeliveryTime}</p>
              )}
            </div>
            <Alert>
              <AlertDescription>
                🚗 A driver will be assigned shortly and will present pickup code <strong>{pickupCode}</strong> at the pharmacy drive-thru.
                <br/><br/>
                📱 You'll receive notifications when:
                <br/>• Driver is assigned to your order
                <br/>• Driver picks up your prescription
                <br/>• Driver is en route to your address
                <br/>• Delivery is completed
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PharmacyCheckoutEnhanced;