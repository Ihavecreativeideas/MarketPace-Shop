import React from 'react';
import { Button } from './ui/button';
import { Building2, Car, Users, TrendingUp, MapPin, Heart, Globe, Share2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface RecruitTownFlyerProps {
  onJoinCampaign?: () => void;
  onShare: () => void;
}

const RecruitTownFlyer: React.FC<RecruitTownFlyerProps> = ({ onJoinCampaign, onShare }) => {
  const navigate = useNavigate();
  
  const handleApplyToDrive = () => {
    navigate('/driver-job');
  };

  const handleFacebookShare = () => {
    const flyerUrl = `${window.location.origin}/flyer`;
    const shareText = "🏢🚗 Join the MarketPace Launch Campaign! We're bringing local delivery and business opportunities to our community. Help us create local jobs, boost our economy, and support neighborhood businesses and services! #RecruitYourTown #ShopLocal #MarketPace";
    
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(flyerUrl)}&quote=${encodeURIComponent(shareText)}`;
    window.open(facebookUrl, '_blank', 'width=600,height=400');
  };

  return (
    <div className="bg-gradient-to-br from-slate-800 via-slate-700 to-slate-900 p-8 rounded-3xl text-white shadow-2xl max-w-lg mx-auto border border-slate-600">
      {/* Header with Icons */}
      <div className="text-center mb-6">
        <div className="flex justify-center items-center gap-4 mb-4">
          <div className="relative">
            <Building2 className="h-12 w-12 text-yellow-400 animate-pulse" />
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
              <Heart className="h-2 w-2 text-white" />
            </div>
          </div>
          <div className="relative">
            <Car className="h-12 w-12 text-cyan-400" />
            <div className="absolute -bottom-1 -right-1 bg-orange-500 text-xs px-2 py-1 rounded-full font-bold">
              PACE
            </div>
          </div>
        </div>
        <h1 className="text-3xl font-bold mb-2 text-white drop-shadow-lg">
          Recruit Your Town
        </h1>
        <p className="text-lg font-semibold text-cyan-300">
          Launch Campaign
        </p>
      </div>

      {/* Main Description */}
      <div className="bg-slate-800/60 backdrop-blur-sm rounded-2xl p-6 mb-6 border border-slate-600">
        <p className="text-sm leading-relaxed mb-4 text-gray-100">
          We're preparing to launch a delivery business that focuses on <span className="font-semibold text-yellow-400">supporting local businesses</span> and delivering opportunities to communities.
        </p>
        <p className="text-sm leading-relaxed mb-4 text-gray-100">
          Join us in <span className="font-semibold text-green-400">creating local jobs</span>, <span className="font-semibold text-cyan-400">boosting local economy</span>, and helping promote local businesses and services by giving them a platform to grow!
        </p>
        <div className="bg-slate-700/50 rounded-xl p-4 border border-slate-500">
          <div className="flex items-center gap-2 mb-2">
            <Globe className="h-5 w-5 text-yellow-400" />
            <span className="font-bold text-yellow-400">Coming Soon!</span>
          </div>
          <p className="text-xs leading-relaxed text-gray-200">
            <span className="font-semibold text-white">MarketPace</span> is gearing up to integrate with local business websites, <span className="font-semibold text-cyan-400">Facebook Marketplace</span>, <span className="font-semibold text-pink-400">Etsy</span>, and <span className="font-semibold text-purple-400">TikTok Shops</span>!
          </p>
        </div>
      </div>

      {/* Benefits */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="text-center bg-slate-800/60 rounded-xl p-3 border border-slate-600">
          <Users className="h-6 w-6 mx-auto mb-2 text-yellow-400" />
          <p className="text-xs font-semibold text-gray-100">Local Jobs</p>
        </div>
        <div className="text-center bg-slate-800/60 rounded-xl p-3 border border-slate-600">
          <TrendingUp className="h-6 w-6 mx-auto mb-2 text-green-400" />
          <p className="text-xs font-semibold text-gray-100">Economic Growth</p>
        </div>
        <div className="text-center bg-slate-800/60 rounded-xl p-3 border border-slate-600">
          <Building2 className="h-6 w-6 mx-auto mb-2 text-cyan-400" />
          <p className="text-xs font-semibold text-gray-100">Support Local</p>
        </div>
        <div className="text-center bg-slate-800/60 rounded-xl p-3 border border-slate-600">
          <MapPin className="h-6 w-6 mx-auto mb-2 text-pink-400" />
          <p className="text-xs font-semibold text-gray-100">Community Focus</p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button 
          onClick={handleApplyToDrive}
          className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 text-white hover:from-yellow-600 hover:to-orange-600 font-bold py-3 text-lg shadow-lg"
        >
          Apply to Drive
        </Button>
        <Button 
          onClick={onJoinCampaign || (() => {})}
          className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white hover:from-green-600 hover:to-blue-600 font-bold py-3 text-lg shadow-lg"
        >
          Join the Campaign
        </Button>
        <Button 
          onClick={handleFacebookShare}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 shadow-lg"
        >
          <Share2 className="h-4 w-4 mr-2" />
          Share Full Flyer on Facebook
        </Button>
      </div>
    </div>
  );
};

export default RecruitTownFlyer;