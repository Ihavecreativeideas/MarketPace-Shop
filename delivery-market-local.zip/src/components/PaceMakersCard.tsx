import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Phone, Mail, Globe, Facebook, Instagram, Clock } from 'lucide-react';

export interface PaceMakerBusiness {
  id: string;
  business_name: string;
  description: string;
  category: string;
  is_service_business: boolean;
  contact_email?: string;
  contact_phone?: string;
  address?: string;
  city?: string;
  state?: string;
  website_url?: string;
  facebook_url?: string;
  instagram_url?: string;
  business_hours?: any;
  services?: string[];
  is_partner: boolean;
  partner_tier: string;
}

interface PaceMakersCardProps {
  business: PaceMakerBusiness;
  onViewDetails: (business: PaceMakerBusiness) => void;
  onShareToFacebook: (business: PaceMakerBusiness) => void;
}

export const PaceMakersCard: React.FC<PaceMakersCardProps> = ({
  business,
  onViewDetails,
  onShareToFacebook
}) => {
  return (
    <Card className="h-full hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{business.business_name}</CardTitle>
          <div className="flex gap-1">
            <Badge variant={business.is_service_business ? 'secondary' : 'default'}>
              {business.is_service_business ? 'Service' : 'Product'}
            </Badge>
            {business.is_partner && (
              <Badge variant="outline" className="text-xs">
                {business.partner_tier.toUpperCase()}
              </Badge>
            )}
          </div>
        </div>
        <p className="text-sm text-muted-foreground">{business.category}</p>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm line-clamp-2">{business.description}</p>
        
        {business.address && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span>{business.city}, {business.state}</span>
          </div>
        )}
        
        <div className="flex flex-wrap gap-2">
          {business.contact_phone && (
            <Button variant="outline" size="sm" className="h-8">
              <Phone className="h-3 w-3 mr-1" />
              Call
            </Button>
          )}
          {business.website_url && (
            <Button variant="outline" size="sm" className="h-8">
              <Globe className="h-3 w-3 mr-1" />
              Website
            </Button>
          )}
        </div>
        
        <div className="flex gap-2 pt-2">
          <Button 
            variant="default" 
            size="sm" 
            className="flex-1"
            onClick={() => onViewDetails(business)}
          >
            View Details
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onShareToFacebook(business)}
          >
            <Facebook className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};