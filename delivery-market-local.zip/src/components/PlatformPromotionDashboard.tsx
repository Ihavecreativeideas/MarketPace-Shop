import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { FacebookPromotion } from './FacebookPromotion';
import { supabase } from '@/lib/supabase';
import { Store, Users, TrendingUp, Search } from 'lucide-react';

interface Partner {
  id: string;
  name: string;
  category: string;
  location: string;
  memberSince: string;
  totalOrders: number;
  rating: number;
  specialties: string[];
}

export const PlatformPromotionDashboard: React.FC = () => {
  const [partners, setPartners] = useState<Partner[]>([]);
  const [selectedPartner, setSelectedPartner] = useState<Partner | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPartners();
  }, []);

  const fetchPartners = async () => {
    try {
      const { data, error } = await supabase
        .from('shop_subscriptions')
        .select('*')
        .eq('status', 'active');
      
      // Mock data for demonstration
      const mockPartners: Partner[] = [
        {
          id: '1',
          name: 'Green Valley Farm',
          category: 'Produce',
          location: 'Downtown',
          memberSince: '2024-01-15',
          totalOrders: 245,
          rating: 4.8,
          specialties: ['Organic Vegetables', 'Fresh Fruits', 'Herbs']
        },
        {
          id: '2',
          name: 'Corner Bakery',
          category: 'Bakery',
          location: 'Main Street',
          memberSince: '2024-02-01',
          totalOrders: 189,
          rating: 4.9,
          specialties: ['Artisan Bread', 'Pastries', 'Custom Cakes']
        },
        {
          id: '3',
          name: 'Tech Repair Pro',
          category: 'Electronics',
          location: 'Tech District',
          memberSince: '2024-03-10',
          totalOrders: 156,
          rating: 4.7,
          specialties: ['Phone Repair', 'Laptop Service', 'Data Recovery']
        }
      ];
      setPartners(mockPartners);
    } catch (error) {
      console.error('Error fetching partners:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredPartners = partners.filter(partner =>
    partner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    partner.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Store className="h-5 w-5" />
            Platform Promotion Dashboard
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Promote partner shops on MarketPace's official Facebook page
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search partners by name or category..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredPartners.map((partner) => (
                <Card key={partner.id} className="cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => setSelectedPartner(partner)}>
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium">{partner.name}</h3>
                        <Badge variant="outline">{partner.category}</Badge>
                      </div>
                      
                      <div className="space-y-1 text-sm text-muted-foreground">
                        <p>📍 {partner.location}</p>
                        <p>⭐ {partner.rating}/5.0 ({partner.totalOrders} orders)</p>
                        <p>📅 Member since {new Date(partner.memberSince).toLocaleDateString()}</p>
                      </div>
                      
                      <div className="flex flex-wrap gap-1">
                        {partner.specialties.slice(0, 2).map((specialty, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {specialty}
                          </Badge>
                        ))}
                        {partner.specialties.length > 2 && (
                          <Badge variant="secondary" className="text-xs">
                            +{partner.specialties.length - 2} more
                          </Badge>
                        )}
                      </div>
                      
                      <Button size="sm" className="w-full">
                        <TrendingUp className="h-3 w-3 mr-1" />
                        Promote Partner
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {selectedPartner && (
        <div className="flex justify-center">
          <FacebookPromotion 
            userType="platform"
            shopId={selectedPartner.id}
          />
        </div>
      )}

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>Select a partner above to promote them on MarketPace's Facebook page</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};