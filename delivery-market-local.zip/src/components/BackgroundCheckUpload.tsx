import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Upload, FileText, X } from 'lucide-react';

interface BackgroundCheckUploadProps {
  onFileUpload: (file: File | null) => void;
  uploadedFile: File | null;
}

const BackgroundCheckUpload: React.FC<BackgroundCheckUploadProps> = ({ onFileUpload, uploadedFile }) => {
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      handleFile(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      handleFile(files[0]);
    }
  };

  const handleFile = (file: File) => {
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/gif'];
    if (allowedTypes.includes(file.type)) {
      onFileUpload(file);
    } else {
      alert('Please upload a PDF or image file');
    }
  };

  const removeFile = () => {
    onFileUpload(null);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="w-5 h-5" />
          Background Check Document *
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!uploadedFile ? (
          <div
            className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
              dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <p className="text-gray-600 mb-4">
              Upload your background check document
            </p>
            <Input
              type="file"
              accept=".pdf,image/*"
              onChange={handleFileInput}
              className="hidden"
              id="background-upload"
            />
            <Label htmlFor="background-upload">
              <Button type="button" variant="outline" className="cursor-pointer">
                Select File
              </Button>
            </Label>
            <p className="text-sm text-gray-500 mt-2">
              Accepted formats: PDF, JPG, PNG (Max 10MB)
            </p>
            <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded text-sm">
              <p className="text-yellow-800">
                <strong>Note:</strong> You must obtain your own background check from an approved provider.
                Common providers include: Checkr, Sterling, or your local police department.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-green-600" />
                <span className="text-green-800">{uploadedFile.name}</span>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={removeFile}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-green-600 text-center">
              ✓ Background check document uploaded successfully
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default BackgroundCheckUpload;