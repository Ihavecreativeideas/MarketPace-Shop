import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Check, Star, Crown, Diamond, Bot, Zap, Gift } from 'lucide-react';
import { BackButton } from './BackButton';

interface BusinessPartnershipTiersProps {
  userId?: string;
  onSubscriptionChange?: () => void;
  showSubscribeButtons?: boolean;
}

const BusinessPartnershipTiers: React.FC<BusinessPartnershipTiersProps> = ({ 
  userId, 
  onSubscriptionChange,
  showSubscribeButtons = true 
}) => {
  const tiers = [
    {
      name: 'Silver',
      price: 0,
      originalPrice: 28.68,
      subtitle: 'FREE Beta Testing',
      tags: ['Beta Tester', 'Early Access', 'Lifetime Benefits'],
      icon: Star,
      color: 'from-gray-400 to-gray-600',
      features: [
        'FREE during beta testing period',
        '20% discount on local deliveries',
        'Basic website integration',
        'Access to standard delivery services',
        'Platform access to reach customers',
        'Standard search placement',
        '25% off sustainability fee',
        'Set custom shipping & handling fees',
        '🎁 Lifetime 50% discount after beta'
      ],
      aiFeature: false
    },
    {
      name: 'Gold',
      price: 0,
      originalPrice: 38.98,
      subtitle: 'FREE Beta - Most Popular',
      tags: ['Beta Tester', 'Priority Features', 'AI Assistant'],
      icon: Crown,
      color: 'from-yellow-400 to-yellow-600',
      popular: true,
      features: [
        'FREE during beta testing period',
        'All Silver Partner features',
        '20% discount on local deliveries',
        'Priority placement in search results',
        'Free local delivery returns',
        '75% off sustainability fee',
        'Enhanced customer support',
        'Bi-weekly performance reports',
        'Advanced website integration',
        '🎁 Lifetime 60% discount after beta'
      ],
      aiFeature: 'AI Integration Assistant'
    },
    {
      name: 'Platinum',
      price: 0,
      originalPrice: 68.22,
      subtitle: 'FREE Beta - Premium',
      tags: ['Beta Tester', 'Maximum Savings', 'Premium AI'],
      icon: Diamond,
      color: 'from-purple-400 to-purple-600',
      features: [
        'FREE during beta testing period',
        'All Silver and Gold Partner features',
        '20% discount on local deliveries',
        'Top-tier search placement',
        'No sustainability fee (100% waived)',
        'Exclusive access to beta features',
        'Advanced analytics dashboard',
        'Premium marketing opportunities',
        'Monthly exclusive merch drops',
        'Dedicated account manager',
        'Custom branding options',
        '🎁 Lifetime 70% discount after beta'
      ],
      aiFeature: 'Premium AI Integration Assistant'
    }
  ];

  const handleSubscribe = (tierName: string) => {
    console.log(`Signing up for FREE ${tierName} beta plan`);
    if (onSubscriptionChange) {
      onSubscriptionChange();
    }
  };

  return (
    <div className="py-12">
      <BackButton to="/" />
      
      <div className="text-center mb-12">
        <div className="bg-gradient-to-r from-green-400 to-blue-500 text-white p-6 rounded-lg mb-6 max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-2">🚀 FREE Beta Testing Program!</h2>
          <p className="text-xl mb-2">
            Join our startup campaign - ALL partnership tiers are completely FREE during beta testing!
          </p>
          <div className="flex items-center justify-center gap-2 text-lg font-semibold">
            <Gift className="w-6 h-6" />
            <span>Early supporters get LIFETIME discounts when we launch!</span>
          </div>
        </div>
        
        <h3 className="text-2xl font-bold text-gray-900 mb-4">
          Business Partnership Tiers
        </h3>
        <p className="text-lg text-gray-600 mb-4">
          Help us test our platform and unlock exclusive lifetime benefits!
        </p>
        
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 max-w-md mx-auto">
          <h4 className="font-semibold text-green-800 mb-2">🎉 Beta Testing Benefits</h4>
          <p className="text-green-600 font-medium">All Features FREE</p>
          <p className="text-sm text-green-600 mt-1">
            Plus lifetime discounts for early supporters!
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
        {tiers.map((tier) => {
          const IconComponent = tier.icon;
          return (
            <Card key={tier.name} className={`relative ${tier.popular ? 'ring-2 ring-green-500 scale-105' : ''}`}>
              {tier.popular && (
                <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-green-500">
                  🎯 Most Popular
                </Badge>
              )}
              <CardHeader className="text-center">
                <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-r ${tier.color} flex items-center justify-center mb-4`}>
                  <IconComponent className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-2xl">{tier.name}</CardTitle>
                <div className="text-center">
                  <div className="text-4xl font-bold text-green-600 mb-1">
                    FREE
                  </div>
                  <div className="text-sm text-gray-500 line-through">
                    Was ${tier.originalPrice}/month
                  </div>
                </div>
                <p className="text-sm font-semibold text-green-600">{tier.subtitle}</p>
                <div className="flex flex-wrap gap-1 justify-center mt-2">
                  {tier.tags.map((tag, index) => (
                    <Badge key={index} variant="secondary" className="text-xs bg-green-100 text-green-800">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {tier.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                {tier.aiFeature && (
                  <div className="bg-blue-50 p-3 rounded-lg mb-4">
                    <div className="flex items-center gap-2 mb-1">
                      <Bot className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-800">{tier.aiFeature}</span>
                    </div>
                  </div>
                )}
                
                <Button 
                  className={`w-full ${tier.popular ? 'bg-green-600 hover:bg-green-700' : 'bg-green-500 hover:bg-green-600'} text-white`}
                  onClick={() => handleSubscribe(tier.name)}
                >
                  <Gift className="w-4 h-4 mr-2" />
                  {tier.popular ? '🚀 Join FREE Beta!' : 'Start FREE Beta'}
                </Button>
                
                <p className="text-xs text-center text-gray-500 mt-2">
                  No credit card required • Cancel anytime
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>
      
      <div className="text-center mt-12 max-w-2xl mx-auto">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
          <h4 className="font-bold text-yellow-800 mb-2">⚡ Limited Time Beta Offer</h4>
          <p className="text-yellow-700 mb-2">
            This is temporary app testing pricing - take advantage of the early sign up!
          </p>
          <p className="text-sm text-yellow-600">
            Early sign up members will get lifetime discounts for supporting and helping our app be successful!
          </p>
        </div>
      </div>
    </div>
  );
};

export default BusinessPartnershipTiers;