import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Users, MapPin, Clock, ShoppingCart } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

interface GrowRoute {
  id: string;
  created_at: string;
  location: string;
  current_buyers: number;
  max_discount: number;
  time_remaining: number;
  items_count: number;
}

interface GrowRouteNotificationProps {
  userLocation: string;
  onJoinRoute: (routeId: string) => void;
}

export const GrowRouteNotification: React.FC<GrowRouteNotificationProps> = ({
  userLocation,
  onJoinRoute
}) => {
  const [activeRoutes, setActiveRoutes] = useState<GrowRoute[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchActiveRoutes();
    const interval = setInterval(fetchActiveRoutes, 30000);
    return () => clearInterval(interval);
  }, [userLocation]);

  const fetchActiveRoutes = async () => {
    try {
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/62f156a0-16cc-435f-97e5-6b786bd7987e',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'get_nearby_routes',
            location: userLocation,
            radius: 20
          })
        }
      );
      
      const data = await response.json();
      if (data.success) {
        setActiveRoutes(data.routes || []);
      }
    } catch (error) {
      console.error('Error fetching routes:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateDiscount = (buyerCount: number) => {
    if (buyerCount >= 5) return 25;
    if (buyerCount >= 4) return 20;
    if (buyerCount >= 3) return 15;
    return 5 * buyerCount;
  };

  const handleJoinRoute = async (routeId: string) => {
    try {
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/62f156a0-16cc-435f-97e5-6b786bd7987e',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'join_route',
            routeId,
            userLocation
          })
        }
      );
      
      const data = await response.json();
      if (data.success) {
        toast({ title: 'Joined Route!', description: 'You\'ve successfully joined the growing route.' });
        onJoinRoute(routeId);
        fetchActiveRoutes();
      } else {
        toast({ title: 'Failed to join', description: data.error, variant: 'destructive' });
      }
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to join route', variant: 'destructive' });
    }
  };

  if (loading) {
    return <div className="text-center py-4">Loading nearby routes...</div>;
  }

  if (activeRoutes.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-green-600">🌱 Growing Routes Near You</h3>
      {activeRoutes.map((route) => {
        const discount = calculateDiscount(route.current_buyers);
        const progress = Math.min((route.current_buyers / 5) * 100, 100);
        
        return (
          <Card key={route.id} className="border-green-200 bg-green-50">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="w-5 h-5 text-green-600" />
                  Route in Progress
                  <Badge variant="secondary" className="bg-green-100 text-green-700">
                    {discount}% OFF
                  </Badge>
                </CardTitle>
                <div className="text-right text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {Math.floor(route.time_remaining / 60)}h {route.time_remaining % 60}m left
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-gray-500" />
                  <span>{route.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-4 h-4 text-gray-500" />
                  <span>{route.items_count} items</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Buyers joined: {route.current_buyers}</span>
                  <span className="text-green-600 font-medium">Split delivery fee!</span>
                </div>
                <Progress value={progress} className="h-2" />
                <div className="text-xs text-gray-600">
                  {5 - route.current_buyers > 0 
                    ? `${5 - route.current_buyers} more buyers needed for max discount`
                    : 'Maximum discount reached!'
                  }
                </div>
              </div>
              
              <div className="bg-white p-2 rounded text-xs text-gray-600">
                <div>💡 Join this route to get:</div>
                <div>• {discount}% off your items</div>
                <div>• Split delivery fee with seller</div>
                <div>• 5% discount for joining existing route</div>
              </div>
              
              <Button 
                onClick={() => handleJoinRoute(route.id)}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                Join Route & Save {discount}%
              </Button>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};