import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, Clock, Pill, Users, CheckCircle, ArrowRight, Phone, CreditCard } from 'lucide-react';
import PharmacyCheckoutEnhanced from './PharmacyCheckoutEnhanced';
import PharmacyPickupNotification from './PharmacyPickupNotification';

const MedPaceEnhanced: React.FC = () => {
  const [location, setLocation] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [isSignedUp, setIsSignedUp] = useState(false);
  const [activeView, setActiveView] = useState<'landing' | 'checkout' | 'notifications'>('landing');

  const handleEarlyAccess = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSignedUp(true);
    setTimeout(() => setIsSignedUp(false), 3000);
  };

  const features = [
    {
      icon: <Pill className="w-6 h-6 text-blue-600" />,
      title: 'Prescription Pickup',
      description: 'Drivers collect your prescriptions with secure pickup codes'
    },
    {
      icon: <Clock className="w-6 h-6 text-green-600" />,
      title: 'Real-time Tracking',
      description: 'Get notified when driver picks up and delivers your medication'
    },
    {
      icon: <CreditCard className="w-6 h-6 text-purple-600" />,
      title: 'Prepay System',
      description: 'Pay through pharmacy website, driver uses pickup code'
    }
  ];

  const howItWorks = [
    {
      step: 1,
      title: 'Prepay at Pharmacy',
      description: 'Visit your pharmacy website or call to prepay for your prescription'
    },
    {
      step: 2,
      title: 'Get Pickup Code',
      description: 'Receive a unique pickup code and schedule delivery through MedPace'
    },
    {
      step: 3,
      title: 'Driver Collects',
      description: 'Our driver presents the pickup code at pharmacy drive-thru'
    },
    {
      step: 4,
      title: 'You Get Notified',
      description: 'Receive notifications when picked up and estimated delivery time'
    }
  ];

  if (activeView === 'checkout') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveView('landing')}
              className="flex items-center gap-2"
            >
              ← Back
            </Button>
            <h1 className="text-2xl font-bold text-blue-900">MedPace Checkout</h1>
          </div>
          <PharmacyCheckoutEnhanced />
        </div>
      </div>
    );
  }

  if (activeView === 'notifications') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveView('landing')}
              className="flex items-center gap-2"
            >
              ← Back
            </Button>
            <h1 className="text-2xl font-bold text-blue-900">Delivery Tracking</h1>
          </div>
          <PharmacyPickupNotification />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-200">
              🚀 Coming Soon to Your Area
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-blue-900 mb-6">
              MedPace
            </h1>
            <p className="text-xl md:text-2xl text-blue-700 mb-4">
              Prescription Delivery Made Simple
            </p>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Prepay at your pharmacy, get a pickup code, and we'll deliver your medication safely to your door.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button 
                onClick={() => setActiveView('checkout')}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg"
              >
                Try Demo Checkout
              </Button>
              <Button 
                onClick={() => setActiveView('notifications')}
                variant="outline"
                className="border-blue-600 text-blue-600 hover:bg-blue-50 px-8 py-3 text-lg"
              >
                View Tracking Demo
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How MedPace Works</h2>
            <p className="text-lg text-gray-600">Simple, secure prescription delivery in 4 easy steps</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {howItWorks.map((step, index) => (
              <div key={step.step} className="text-center">
                <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-600 font-bold text-lg">{step.step}</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">{step.title}</h3>
                <p className="text-gray-600 text-sm">{step.description}</p>
                {index < howItWorks.length - 1 && (
                  <ArrowRight className="w-6 h-6 text-blue-300 mx-auto mt-4 hidden lg:block" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose MedPace?</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex justify-center mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Location Search & Early Access */}
      <div className="py-16 bg-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Get Early Access</h2>
          <p className="text-blue-100 mb-8 text-lg">
            Be the first to know when MedPace launches in your area
          </p>
          
          {!isSignedUp ? (
            <form onSubmit={handleEarlyAccess} className="max-w-md mx-auto space-y-4">
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder="Enter your city or zip code"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="pl-10 py-3 text-lg"
                  required
                />
              </div>
              <Input
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="py-3 text-lg"
                required
              />
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="tel"
                  placeholder="Phone number (optional)"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="pl-10 py-3 text-lg"
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-white text-blue-600 hover:bg-gray-100 py-3 text-lg font-semibold"
              >
                Join Early Access List
              </Button>
            </form>
          ) : (
            <Alert className="max-w-md mx-auto border-green-200 bg-green-50">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <AlertDescription className="text-green-800 font-medium">
                🎉 You're on the list! We'll notify you when MedPace launches in {location}.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-400">
            © 2024 MedPace. Prescription delivery service coming soon.
          </p>
        </div>
      </div>
    </div>
  );
};

export default MedPaceEnhanced;