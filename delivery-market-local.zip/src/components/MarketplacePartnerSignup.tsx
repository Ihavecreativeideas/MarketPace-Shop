import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Check, Store, Zap, Gift, TrendingUp, Globe, BarChart3, Truck, Package } from 'lucide-react';
import { BackButton } from './BackButton';

interface MarketplacePartnerSignupProps {
  onSignupComplete?: () => void;
}

const MarketplacePartnerSignup: React.FC<MarketplacePartnerSignupProps> = ({ onSignupComplete }) => {
  const [formData, setFormData] = useState({
    businessName: '',
    ownerName: '',
    email: '',
    phone: '',
    businessType: '',
    description: '',
    preferredDelivery: 'flexible'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const benefits = [
    {
      icon: Globe,
      title: 'Platform to Reach Customers',
      description: 'Use MarketPlace to promote and reach more customers'
    },
    {
      icon: Package,
      title: 'Choose Your Delivery',
      description: 'Use UPS, FedEx, DoorDash, or your own delivery method'
    },
    {
      icon: Truck,
      title: 'No Mandatory Drivers',
      description: 'Not required to use our drivers - your choice!'
    },
    {
      icon: BarChart3,
      title: 'Analytics & Insights',
      description: 'Track performance and customer behavior'
    }
  ];

  const deliveryOptions = [
    { value: 'flexible', label: 'Flexible - I want options' },
    { value: 'marketplace', label: 'MarketPlace Drivers (non-food only)' },
    { value: 'ups', label: 'UPS Shipping' },
    { value: 'fedex', label: 'FedEx Shipping' },
    { value: 'usps', label: 'USPS Mail' },
    { value: 'doordash', label: 'DoorDash (food businesses)' },
    { value: 'self', label: 'Self Delivery' }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      console.log('MarketPlace Partner signup:', formData);
      setIsSubmitting(false);
      if (onSignupComplete) {
        onSignupComplete();
      }
    }, 1500);
  };

  return (
    <div className="py-12 max-w-4xl mx-auto">
      <BackButton to="/" />
      
      <div className="text-center mb-8">
        <div className="bg-gradient-to-r from-green-400 to-blue-500 text-white p-6 rounded-lg mb-6">
          <h1 className="text-3xl font-bold mb-2">🚀 Join as a MarketPlace Partner</h1>
          <p className="text-xl mb-2">
            FREE Platform Access - Choose Your Own Delivery!
          </p>
          <div className="flex items-center justify-center gap-2 text-lg font-semibold">
            <Gift className="w-6 h-6" />
            <span>Use any delivery service you prefer!</span>
          </div>
        </div>
        
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
          <h3 className="font-bold text-blue-800 mb-2">📦 Delivery Freedom</h3>
          <p className="text-blue-700 mb-2">
            Use MarketPlace as your promotional platform. Choose UPS, FedEx, DoorDash, or any delivery method that works for your business.
          </p>
          <p className="text-sm text-blue-600">
            It's NOT mandatory to use our drivers - you have complete flexibility!
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Benefits Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Store className="w-6 h-6 text-green-600" />
              What You Get (FREE)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {benefits.map((benefit, index) => {
                const IconComponent = benefit.icon;
                return (
                  <div key={index} className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <IconComponent className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{benefit.title}</h4>
                      <p className="text-sm text-gray-600">{benefit.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="mt-6 p-4 bg-green-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Check className="w-5 h-5 text-green-600" />
                <span className="font-semibold text-green-800">Delivery Options:</span>
              </div>
              <ul className="text-sm text-green-700 space-y-1">
                <li>• UPS & FedEx integration available</li>
                <li>• DoorDash for food businesses</li>
                <li>• USPS for mail delivery</li>
                <li>• Self-delivery options</li>
                <li>• MarketPlace drivers (optional)</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Signup Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-6 h-6 text-blue-600" />
              Start Your FREE Trial
            </CardTitle>
            <Badge className="w-fit bg-green-100 text-green-800">
              No Credit Card Required
            </Badge>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="businessName">Business Name *</Label>
                <Input
                  id="businessName"
                  name="businessName"
                  value={formData.businessName}
                  onChange={handleInputChange}
                  required
                  placeholder="Your business name"
                />
              </div>
              
              <div>
                <Label htmlFor="ownerName">Owner Name *</Label>
                <Input
                  id="ownerName"
                  name="ownerName"
                  value={formData.ownerName}
                  onChange={handleInputChange}
                  required
                  placeholder="Your full name"
                />
              </div>
              
              <div>
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  placeholder="your@email.com"
                />
              </div>
              
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={handleInputChange}
                  required
                  placeholder="(555) 123-4567"
                />
              </div>
              
              <div>
                <Label htmlFor="businessType">Business Type</Label>
                <Input
                  id="businessType"
                  name="businessType"
                  value={formData.businessType}
                  onChange={handleInputChange}
                  placeholder="Restaurant, Retail, Service, etc."
                />
              </div>

              <div>
                <Label htmlFor="preferredDelivery">Preferred Delivery Method</Label>
                <Select onValueChange={(value) => handleSelectChange('preferredDelivery', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose your delivery preference" />
                  </SelectTrigger>
                  <SelectContent>
                    {deliveryOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="description">Brief Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Tell us about your business..."
                  rows={3}
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-green-600 hover:bg-green-700 text-white"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Setting up your account...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Gift className="w-4 h-4" />
                    Join FREE Platform Now!
                  </div>
                )}
              </Button>
              
              <p className="text-xs text-center text-gray-500">
                By signing up, you agree to our Terms of Service and Privacy Policy
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MarketplacePartnerSignup;