import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Route, Clock, DollarSign, Zap } from 'lucide-react';
import { useState } from 'react';

interface Delivery {
  id: string;
  type: string;
  pickup: string;
  dropoff: string;
  fee: number;
  distance: number;
  priority: 'low' | 'medium' | 'high';
}

const RouteOptimizer: React.FC = () => {
  const [deliveries] = useState<Delivery[]>([
    { id: '1', type: 'PostPace', pickup: '123 Main St', dropoff: 'UPS Store', fee: 8, distance: 2.1, priority: 'medium' },
    { id: '2', type: 'MedPace', pickup: 'CVS Pharmacy', dropoff: '456 Oak Ave', fee: 12, distance: 1.8, priority: 'high' },
    { id: '3', type: 'LocalShops', pickup: 'Coffee Corner', dropoff: '789 Pine Rd', fee: 6, distance: 3.2, priority: 'low' },
    { id: '4', type: 'Marketplace', pickup: '321 Elm St', dropoff: '654 Maple Dr', fee: 10, distance: 2.8, priority: 'medium' }
  ]);

  const [selected, setSelected] = useState<string[]>([]);
  const [optimized, setOptimized] = useState<Delivery[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const toggleDelivery = (id: string) => {
    setSelected(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const optimizeRoute = async () => {
    if (selected.length < 2) return;
    
    setLoading(true);
    setError(null);
    const selectedDeliveries = deliveries.filter(d => selected.includes(d.id));
    
    try {
      // Simple fallback optimization without external API call
      const sorted = [...selectedDeliveries].sort((a, b) => {
        const priorityWeight = { high: 3, medium: 2, low: 1 };
        return priorityWeight[b.priority] - priorityWeight[a.priority];
      });
      
      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setOptimized(sorted);
    } catch (error) {
      console.error('Route optimization error:', error);
      setError('Failed to optimize route. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const totalFee = optimized?.reduce((sum, d) => sum + d.fee, 0) || 0;
  const totalDistance = optimized?.reduce((sum, d) => sum + d.distance, 0) || 0;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-6 h-6" />
            AI Route Optimizer
          </CardTitle>
        </CardHeader>
        <CardContent>
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold">Available Deliveries</h3>
              {deliveries.map((delivery) => (
                <Card 
                  key={delivery.id} 
                  className={`cursor-pointer transition-all ${
                    selected.includes(delivery.id) ? 'ring-2 ring-blue-500 bg-blue-50' : 'hover:shadow-md'
                  }`}
                  onClick={() => toggleDelivery(delivery.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{delivery.type}</Badge>
                          <Badge className={getPriorityColor(delivery.priority)}>
                            {delivery.priority}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin className="w-4 h-4" />
                          {delivery.pickup} → {delivery.dropoff}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-green-600">${delivery.fee}</div>
                        <div className="text-sm text-gray-600">{delivery.distance} mi</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold">Route Optimization</h3>
                <Button 
                  onClick={optimizeRoute}
                  disabled={selected.length < 2 || loading}
                  className="bg-gradient-to-r from-blue-600 to-green-600"
                >
                  {loading ? 'Optimizing...' : 'Optimize Route'}
                </Button>
              </div>
              
              {selected.length < 2 && (
                <Card className="bg-gray-50">
                  <CardContent className="p-4 text-center text-gray-600">
                    Select at least 2 deliveries
                  </CardContent>
                </Card>
              )}
              
              {optimized && (
                <div className="space-y-4">
                  <Card className="bg-gradient-to-r from-green-50 to-blue-50">
                    <CardContent className="p-4">
                      <div className="grid grid-cols-2 gap-4 text-center">
                        <div>
                          <div className="text-2xl font-bold text-green-600">${totalFee}</div>
                          <div className="text-sm text-gray-600">Total Earnings</div>
                        </div>
                        <div>
                          <div className="text-2xl font-bold text-blue-600">{totalDistance.toFixed(1)} mi</div>
                          <div className="text-sm text-gray-600">Total Distance</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Optimized Route</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {optimized.map((delivery, index) => (
                        <div key={delivery.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                          <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                            {index + 1}
                          </div>
                          <div className="flex-1">
                            <Badge variant="outline">{delivery.type}</Badge>
                            <div className="text-sm text-gray-600 mt-1">
                              {delivery.pickup} → {delivery.dropoff}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-green-600">${delivery.fee}</div>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                  
                  <Button className="w-full bg-gradient-to-r from-green-600 to-blue-600">
                    Accept Route
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default RouteOptimizer;