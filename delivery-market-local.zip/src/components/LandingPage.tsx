import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { ChevronDown, Heart, Users, Music, Truck, ShoppingBag, Pill, Package, MapPin, Clock, Shield } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import PlatformDropdown from './PlatformDropdown';
import EarlyPartnerPromo from './EarlyPartnerPromo';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  const handleStartShopping = () => {
    navigate('/marketplace');
  };

  const handleBecomeDriver = () => {
    navigate('/driver-application');
  };

  const handleUpgradeToPartner = () => {
    navigate('/vendor-partnership');
  };

  const handleMedPace = () => {
    navigate('/medpace');
  };

  const handlePostPace = () => {
    navigate('/postpace');
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header with Platform Dropdown */}
      <header className="bg-gradient-to-r from-blue-600 to-purple-700 text-white">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-xl sm:text-2xl font-bold">MarketPace</div>
          <PlatformDropdown />
        </div>
      </header>

      {/* Hero Section - Mobile Optimized */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-purple-50 py-12 sm:py-20">
        <div className="max-w-6xl mx-auto px-4 grid lg:grid-cols-2 gap-8 sm:gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-3xl sm:text-4xl lg:text-6xl font-bold text-gray-900 mb-4 sm:mb-6 leading-tight">
              Delivering opportunities to <span className="text-blue-600">Local</span> <span className="text-purple-600">Communities</span>
            </h1>
            <p className="text-base sm:text-xl text-gray-600 mb-6 sm:mb-8 leading-relaxed px-2 sm:px-0">
              Connect with local businesses, earn income as a driver, and build stronger communities together.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 mb-6 sm:mb-8 px-2 sm:px-0">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-base sm:text-lg px-6 sm:px-8 py-3 sm:py-4 w-full sm:w-auto" onClick={handleStartShopping}>
                <ShoppingBag className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
                Start Shopping
              </Button>
              <Button size="lg" variant="outline" className="text-base sm:text-lg px-6 sm:px-8 py-3 sm:py-4 w-full sm:w-auto" onClick={handleBecomeDriver}>
                <Truck className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
                Drive & Earn
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3 sm:gap-4 px-2 sm:px-0">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-3 sm:p-6 text-center">
                <MapPin className="h-8 w-8 sm:h-12 sm:w-12 text-blue-600 mx-auto mb-2 sm:mb-3" />
                <h3 className="font-semibold mb-1 sm:mb-2 text-sm sm:text-base">Local Focus</h3>
                <p className="text-xs sm:text-sm text-gray-600">Supporting neighborhood businesses</p>
              </CardContent>
            </Card>
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-3 sm:p-6 text-center">
                <Clock className="h-8 w-8 sm:h-12 sm:w-12 text-green-600 mx-auto mb-2 sm:mb-3" />
                <h3 className="font-semibold mb-1 sm:mb-2 text-sm sm:text-base">Fast Delivery</h3>
                <p className="text-xs sm:text-sm text-gray-600">Quick community connections</p>
              </CardContent>
            </Card>
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-3 sm:p-6 text-center">
                <Shield className="h-8 w-8 sm:h-12 sm:w-12 text-purple-600 mx-auto mb-2 sm:mb-3" />
                <h3 className="font-semibold mb-1 sm:mb-2 text-sm sm:text-base">Safe & Secure</h3>
                <p className="text-xs sm:text-sm text-gray-600">Trusted platform for all</p>
              </CardContent>
            </Card>
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-3 sm:p-6 text-center">
                <Heart className="h-8 w-8 sm:h-12 sm:w-12 text-red-600 mx-auto mb-2 sm:mb-3" />
                <h3 className="font-semibold mb-1 sm:mb-2 text-sm sm:text-base">Community</h3>
                <p className="text-xs sm:text-sm text-gray-600">Building stronger neighborhoods</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Services Section - Mobile Optimized */}
      <section className="py-12 sm:py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-2xl sm:text-4xl font-bold text-center mb-8 sm:mb-12 text-gray-900">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
            <Card className="hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
              <CardContent className="p-6 sm:p-8">
                <div className="flex items-center mb-4">
                  <Pill className="h-6 w-6 sm:h-8 sm:w-8 text-red-600 mr-3" />
                  <h3 className="text-xl sm:text-2xl font-bold text-red-600">MedPace</h3>
                </div>
                <p className="text-gray-600 mb-6 text-sm sm:text-base">Quick and reliable pharmacy pickup service for your medical needs.</p>
                <Button onClick={handleMedPace} className="bg-red-600 hover:bg-red-700 w-full">
                  Learn More
                </Button>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
              <CardContent className="p-6 sm:p-8">
                <div className="flex items-center mb-4">
                  <Package className="h-6 w-6 sm:h-8 sm:w-8 text-orange-600 mr-3" />
                  <h3 className="text-xl sm:text-2xl font-bold text-orange-600">PostPace</h3>
                </div>
                <p className="text-gray-600 mb-6 text-sm sm:text-base">Convenient package drop-off service for all your shipping needs.</p>
                <Button onClick={handlePostPace} className="bg-orange-600 hover:bg-orange-700 w-full">
                  Learn More
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Early Partner Promotion */}
      <section className="py-8 sm:py-12">
        <div className="max-w-4xl mx-auto px-4">
          <EarlyPartnerPromo />
        </div>
      </section>

      {/* Partnership CTA - Mobile Optimized */}
      <section className="bg-gradient-to-r from-orange-500 via-red-500 to-pink-600 text-white py-12 sm:py-20">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-2xl sm:text-4xl font-bold mb-4 sm:mb-6">
            Partner With Us to Launch Something Amazing!
          </h2>
          <p className="text-lg sm:text-xl mb-6 sm:mb-8 opacity-90">
            Early partners receive exclusive benefits and priority support
          </p>
          <Button 
            size="lg" 
            onClick={handleUpgradeToPartner}
            className="bg-white hover:bg-gray-100 text-gray-900 font-bold px-8 sm:px-12 py-3 sm:py-4 text-lg sm:text-xl shadow-2xl transform hover:scale-105 transition-all duration-300 w-full sm:w-auto"
          >
            Become a Partner
          </Button>
        </div>
      </section>

      {/* Final CTA Section - Mobile Optimized */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-12 sm:py-20">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-2xl sm:text-4xl font-bold mb-4 sm:mb-6">Join the Movement</h2>
          <p className="text-lg sm:text-xl mb-6 sm:mb-10 opacity-90">Be part of building stronger, more connected communities</p>
          <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center">
            <Button 
              size="lg" 
              variant="secondary"
              onClick={handleBecomeDriver}
              className="bg-white text-blue-600 hover:bg-gray-100 font-semibold px-8 sm:px-10 py-3 sm:py-4 text-base sm:text-lg transform hover:scale-105 transition-all duration-200 w-full sm:w-auto"
            >
              <Truck className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
              Start Driving
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              onClick={handleUpgradeToPartner}
              className="border-2 border-white text-blue-600 hover:bg-white hover:text-blue-600 font-semibold px-8 sm:px-10 py-3 sm:py-4 text-base sm:text-lg transition-all duration-200 w-full sm:w-auto"
            >
              <Users className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
              Partner With Us
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;