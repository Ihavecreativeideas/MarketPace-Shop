import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CreditCard, Shield, Lock } from 'lucide-react';

const stripePromise = loadStripe('pk_test_51234567890abcdef');

interface PaymentFormProps {
  amount: number;
  onSuccess: (paymentIntent: any) => void;
  onError: (error: string) => void;
}

const PaymentForm: React.FC<PaymentFormProps> = ({ amount, onSuccess, onError }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [billingDetails, setBillingDetails] = useState({
    name: '',
    email: '',
    address: {
      line1: '',
      city: '',
      state: '',
      postal_code: ''
    }
  });

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    
    if (!stripe || !elements) return;
    
    setLoading(true);
    
    try {
      // Create payment intent
      const response = await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/b10ed84c-aa10-492f-bec6-c2da26cd3d33', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: amount * 100 }) // Convert to cents
      });
      
      const { client_secret } = await response.json();
      
      const cardElement = elements.getElement(CardElement);
      
      const { error, paymentIntent } = await stripe.confirmCardPayment(client_secret, {
        payment_method: {
          card: cardElement!,
          billing_details: billingDetails
        }
      });
      
      if (error) {
        onError(error.message || 'Payment failed');
      } else {
        onSuccess(paymentIntent);
      }
    } catch (err) {
      onError('Payment processing failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Full Name</Label>
          <Input
            id="name"
            value={billingDetails.name}
            onChange={(e) => setBillingDetails({...billingDetails, name: e.target.value})}
            required
          />
        </div>
        <div>
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={billingDetails.email}
            onChange={(e) => setBillingDetails({...billingDetails, email: e.target.value})}
            required
          />
        </div>
      </div>
      
      <div>
        <Label htmlFor="address">Address</Label>
        <Input
          id="address"
          value={billingDetails.address.line1}
          onChange={(e) => setBillingDetails({
            ...billingDetails,
            address: {...billingDetails.address, line1: e.target.value}
          })}
          required
        />
      </div>
      
      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label htmlFor="city">City</Label>
          <Input
            id="city"
            value={billingDetails.address.city}
            onChange={(e) => setBillingDetails({
              ...billingDetails,
              address: {...billingDetails.address, city: e.target.value}
            })}
            required
          />
        </div>
        <div>
          <Label htmlFor="state">State</Label>
          <Input
            id="state"
            value={billingDetails.address.state}
            onChange={(e) => setBillingDetails({
              ...billingDetails,
              address: {...billingDetails.address, state: e.target.value}
            })}
            required
          />
        </div>
        <div>
          <Label htmlFor="zip">ZIP Code</Label>
          <Input
            id="zip"
            value={billingDetails.address.postal_code}
            onChange={(e) => setBillingDetails({
              ...billingDetails,
              address: {...billingDetails.address, postal_code: e.target.value}
            })}
            required
          />
        </div>
      </div>
      
      <div className="border rounded-lg p-4">
        <Label className="flex items-center mb-2">
          <CreditCard className="h-4 w-4 mr-2" />
          Card Information
        </Label>
        <CardElement
          options={{
            style: {
              base: {
                fontSize: '16px',
                color: '#424770',
                '::placeholder': { color: '#aab7c4' }
              }
            }
          }}
        />
      </div>
      
      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription className="flex items-center">
          <Lock className="h-3 w-3 mr-1" />
          Your payment information is encrypted and secure
        </AlertDescription>
      </Alert>
      
      <Button 
        type="submit" 
        className="w-full" 
        disabled={!stripe || loading}
      >
        {loading ? 'Processing...' : `Pay $${amount.toFixed(2)}`}
      </Button>
    </form>
  );
};

interface SecurePaymentProps {
  amount: number;
  onSuccess: (paymentIntent: any) => void;
  onError: (error: string) => void;
}

export const SecurePayment: React.FC<SecurePaymentProps> = ({ amount, onSuccess, onError }) => {
  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Shield className="h-5 w-5 mr-2" />
          Secure Payment
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Elements stripe={stripePromise}>
          <PaymentForm amount={amount} onSuccess={onSuccess} onError={onError} />
        </Elements>
      </CardContent>
    </Card>
  );
};