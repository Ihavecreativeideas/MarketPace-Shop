import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import MarketplaceOrder from './MarketplaceOrder';
import DriverNotifications from './DriverNotifications';
import { ShoppingCart, Truck, Store } from 'lucide-react';

const MarketplaceDemo: React.FC = () => {
  const [activeTab, setActiveTab] = useState('buyer');

  // Sample order data
  const sampleOrder = {
    orderId: 'MP-001',
    itemTitle: 'iPhone 13 Pro',
    itemPrice: 800,
    deliveryFee: 12,
    buyerShare: 6,
    sellerShare: 6,
    status: 'delivered' as const
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>MarketPlace Delivery System Demo</CardTitle>
          <p className="text-sm text-gray-600">
            Experience the new marketplace delivery flow with split fees, tips, and return coverage.
          </p>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="buyer" className="flex items-center gap-2">
            <ShoppingCart className="w-4 h-4" />
            Buyer View
          </TabsTrigger>
          <TabsTrigger value="seller" className="flex items-center gap-2">
            <Store className="w-4 h-4" />
            Seller View
          </TabsTrigger>
          <TabsTrigger value="driver" className="flex items-center gap-2">
            <Truck className="w-4 h-4" />
            Driver View
          </TabsTrigger>
        </TabsList>

        <TabsContent value="buyer" className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="font-medium text-blue-900 mb-2">Buyer Experience</h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Pay only half the delivery fee</li>
              <li>• Accept or return items upon delivery</li>
              <li>• Tip and rate drivers after accepting</li>
              <li>• Returns covered by MarketPace</li>
            </ul>
          </div>
          <MarketplaceOrder {...sampleOrder} userType="buyer" />
        </TabsContent>

        <TabsContent value="seller" className="space-y-4">
          <div className="bg-green-50 p-4 rounded-lg">
            <h3 className="font-medium text-green-900 mb-2">Seller Experience</h3>
            <ul className="text-sm text-green-800 space-y-1">
              <li>• Pay only half the delivery fee</li>
              <li>• Track delivery status in real-time</li>
              <li>• Option to tip drivers</li>
              <li>• No return handling costs</li>
            </ul>
          </div>
          <MarketplaceOrder {...sampleOrder} userType="seller" status="in_route" />
        </TabsContent>

        <TabsContent value="driver" className="space-y-4">
          <div className="bg-orange-50 p-4 rounded-lg">
            <h3 className="font-medium text-orange-900 mb-2">Driver Experience</h3>
            <ul className="text-sm text-orange-800 space-y-1">
              <li>• Receive pickup notifications</li>
              <li>• Update delivery status easily</li>
              <li>• Earn tips from both buyers and sellers</li>
              <li>• Handle return deliveries when needed</li>
            </ul>
          </div>
          <DriverNotifications driverId="driver-123" />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MarketplaceDemo;