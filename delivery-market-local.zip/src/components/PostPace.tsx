import React from 'react';
import { BackButton } from './BackButton';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Package, Truck, Clock } from 'lucide-react';
import PostPaceDeliveryForm from './PostPaceDeliveryForm';

const PostPace: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <BackButton to="/" />
        
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">PostPace Delivery</h1>
          <p className="text-xl text-gray-600">Fast, reliable local delivery service</p>
          <div className="mt-4 p-4 bg-blue-50 rounded-lg">
            <p className="text-blue-800 font-semibold">$14 for first 8 miles + $1.25 per extra mile</p>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5" />
                Small Items
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">Documents, small packages under 10 lbs</p>
              <p className="text-green-600 font-semibold">✓ Eligible for PostPace</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5" />
                Medium Items
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">Boxes, bags 10-50 lbs</p>
              <p className="text-green-600 font-semibold">✓ Eligible for PostPace</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="w-5 h-5" />
                Large Items
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">Furniture, appliances 50+ lbs</p>
              <p className="text-orange-600 font-semibold">Use Large Item Delivery</p>
            </CardContent>
          </Card>
        </div>

        <PostPaceDeliveryForm />
      </div>
    </div>
  );
};

export default PostPace;