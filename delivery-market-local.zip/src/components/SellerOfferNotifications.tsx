import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Bell, DollarSign, Clock, Check, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CounterOffer {
  id: string;
  product_id: string;
  product_title: string;
  original_price: number;
  buyer_offer_price: number;
  buyer_discount_percent: number;
  seller_counter_price?: number;
  seller_counter_percent?: number;
  status: string;
  buyer_id: string;
  created_at: string;
  expires_at?: string;
}

interface SellerOfferNotificationsProps {
  sellerId: string;
}

const SellerOfferNotifications: React.FC<SellerOfferNotificationsProps> = ({ sellerId }) => {
  const [offers, setOffers] = useState<CounterOffer[]>([]);
  const [loading, setLoading] = useState(true);
  const [counterPrices, setCounterPrices] = useState<{[key: string]: string}>({});
  const { toast } = useToast();

  const fetchOffers = async () => {
    try {
      const response = await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/8c8c05c5-276b-4a02-9305-2c694df852cf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'get_seller_offers', sellerId })
      });
      const data = await response.json();
      setOffers(data || []);
    } catch (error) {
      console.error('Error fetching offers:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOffers();
    const interval = setInterval(fetchOffers, 30000);
    return () => clearInterval(interval);
  }, [sellerId]);

  const handleSellerResponse = async (offerId: string, response: string, counterPrice?: number, counterPercent?: number) => {
    try {
      await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/8c8c05c5-276b-4a02-9305-2c694df852cf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'seller_response',
          offerId,
          response,
          counterPrice,
          counterPercent
        })
      });
      
      toast({ title: `Offer ${response === 'accepted' ? 'accepted' : response === 'denied' ? 'denied' : 'countered'}!` });
      fetchOffers();
    } catch (error) {
      toast({ title: 'Error processing response', variant: 'destructive' });
    }
  };

  const handleCounterOffer = (offerId: string, originalPrice: number) => {
    const counterPriceStr = counterPrices[offerId];
    if (!counterPriceStr) return;
    
    const counterPrice = parseFloat(counterPriceStr);
    const counterPercent = Math.round(((originalPrice - counterPrice) / originalPrice) * 100);
    
    handleSellerResponse(offerId, 'seller_countered', counterPrice, counterPercent);
  };

  if (loading) return <div className="p-4">Loading offers...</div>;

  const pendingOffers = offers.filter(offer => offer.status === 'pending');

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Bell className="w-5 h-5" />
        <h2 className="text-xl font-bold">Counter Offer Notifications</h2>
        <Badge variant="outline">{pendingOffers.length}</Badge>
      </div>
      
      {pendingOffers.length === 0 ? (
        <Card>
          <CardContent className="p-6 text-center text-gray-500">
            No pending offers
          </CardContent>
        </Card>
      ) : (
        pendingOffers.map((offer) => (
          <Card key={offer.id} className="border-l-4 border-l-orange-500">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="text-lg">{offer.product_title}</span>
                <Badge variant="secondary">
                  {offer.buyer_discount_percent}% off
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Original Price:</p>
                  <p className="font-semibold">${offer.original_price}</p>
                </div>
                <div>
                  <p className="text-gray-600">Buyer's Offer:</p>
                  <p className="font-semibold text-green-600">${offer.buyer_offer_price}</p>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Label htmlFor={`counter-${offer.id}`}>Your Counter Offer ($):</Label>
                  <Input
                    id={`counter-${offer.id}`}
                    type="number"
                    placeholder="Enter amount"
                    value={counterPrices[offer.id] || ''}
                    onChange={(e) => setCounterPrices(prev => ({ ...prev, [offer.id]: e.target.value }))}
                    className="w-32"
                  />
                </div>
                
                <div className="flex gap-2">
                  <Button
                    onClick={() => handleSellerResponse(offer.id, 'accepted')}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    <Check className="w-4 h-4 mr-1" />
                    Accept ${offer.buyer_offer_price}
                  </Button>
                  <Button
                    onClick={() => handleCounterOffer(offer.id, offer.original_price)}
                    disabled={!counterPrices[offer.id]}
                    variant="outline"
                    className="flex-1"
                  >
                    <DollarSign className="w-4 h-4 mr-1" />
                    Counter Offer
                  </Button>
                  <Button
                    onClick={() => handleSellerResponse(offer.id, 'denied')}
                    variant="destructive"
                    className="flex-1"
                  >
                    <X className="w-4 h-4 mr-1" />
                    Deny
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  );
};

export default SellerOfferNotifications;