import { Card, CardContent } from './ui/card';
import { Heart, Users, Clock, Shield, MapPin, CreditCard, Bell } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { useState } from 'react';
import MedPaceDeliveryForm from './MedPaceDeliveryForm';

const MedPace: React.FC = () => {
  const [location, setLocation] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', { location, name, email, phone });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 py-12">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-100 rounded-full mb-6">
            <Heart className="w-10 h-10 text-blue-600" />
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">MedPace</h1>
          <div className="mt-4 p-4 bg-blue-50 rounded-lg">
            <p className="text-blue-800 font-semibold">$14 for first 8 miles + $1.25 per extra mile</p>
          </div>
        </div>

        {/* Location Search */}
        <Card className="mb-8 shadow-lg">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              Find Your Location
            </h3>
            <div className="flex items-center space-x-4 max-w-md mx-auto">
              <MapPin className="w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Enter your city or zip code"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="flex-1"
              />
              <Button>Search</Button>
            </div>
          </CardContent>
        </Card>

        {/* Delivery Form */}
        <MedPaceDeliveryForm />

        {/* How It Works */}
        <Card className="mb-8 shadow-lg">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              How MedPace Works
            </h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-4">
                <CreditCard className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                <h4 className="font-semibold text-gray-900 mb-2">1. Prepay Online</h4>
                <p className="text-gray-600 text-sm">Order and pay for your prescription through your pharmacy's website. You'll receive a pickup code.</p>
              </div>
              <div className="text-center p-4">
                <Users className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h4 className="font-semibold text-gray-900 mb-2">2. Driver Pickup</h4>
                <p className="text-gray-600 text-sm">Our verified driver receives your pickup code and collects your order from the pharmacy.</p>
              </div>
              <div className="text-center p-4">
                <Bell className="w-12 h-12 text-purple-600 mx-auto mb-4" />
                <h4 className="font-semibold text-gray-900 mb-2">3. Get Notified</h4>
                <p className="text-gray-600 text-sm">You'll receive instant notifications when your driver picks up and delivers your medication.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Early Access Form */}
        <Card className="mb-8 shadow-lg">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              Get Early Access
            </h3>
            <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-4">
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Join Waitlist
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="text-center">
          <p className="text-gray-600 mb-4">Caring for your community, one delivery at a time</p>
          <div className="inline-flex items-center space-x-2 text-blue-600">
            <Heart className="w-5 h-5" />
            <span className="font-medium">Safe, secure prescription delivery</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MedPace;