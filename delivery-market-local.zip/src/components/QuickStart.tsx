import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ExternalLink, Download, Database, Settings } from 'lucide-react';
import DatabaseSetup from '@/components/DatabaseSetup';
import { isDemoMode } from '@/lib/supabase';

export default function QuickStart() {
  const steps = [
    {
      title: '1. Get Your Code',
      description: 'Download from Famous.AI dashboard or clone repository',
      action: 'Download/Clone',
      icon: Download
    },
    {
      title: '2. Install Dependencies', 
      description: 'Run npm install in your project directory',
      action: 'npm install',
      icon: Settings
    },
    {
      title: '3. Configure Supabase',
      description: 'Create project and update credentials',
      action: isDemoMode() ? 'Setup Required' : 'Configured',
      icon: Database,
      status: isDemoMode() ? 'pending' : 'complete'
    },
    {
      title: '4. Start Development',
      description: 'Run npm run dev to start the server',
      action: 'npm run dev',
      icon: ExternalLink
    }
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>MarketPace Quick Start Guide</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="flex items-center gap-4 p-4 border rounded-lg">
                  <Icon className="h-6 w-6 text-blue-600" />
                  <div className="flex-1">
                    <h3 className="font-semibold">{step.title}</h3>
                    <p className="text-sm text-gray-600">{step.description}</p>
                  </div>
                  <div className="text-sm font-mono bg-gray-100 px-3 py-1 rounded">
                    {step.action}
                  </div>
                </div>
              );
            })}
          </div>
          
          {isDemoMode() && (
            <Alert className="mt-4">
              <AlertDescription>
                <strong>Important:</strong> You're using demo credentials. Create your own Supabase project and update the credentials in src/lib/supabase.ts
              </AlertDescription>
            </Alert>
          )}
          
          <div className="mt-6 flex gap-2">
            <Button asChild>
              <a href="https://supabase.com" target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-4 w-4 mr-2" />
                Create Supabase Project
              </a>
            </Button>
            <Button variant="outline" asChild>
              <a href="/SETUP.md" target="_blank" rel="noopener noreferrer">
                View Full Guide
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <DatabaseSetup />
    </div>
  );
}
