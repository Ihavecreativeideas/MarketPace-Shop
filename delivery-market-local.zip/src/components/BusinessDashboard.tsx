import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, BarChart3, MessageSquare, Settings, Zap, Crown, Users, TrendingUp, Calendar, FileText, CreditCard, Bell } from 'lucide-react';
import POSIntegration from './POSIntegration';
import VendorReviews from './VendorReviews';
import VendorAnalytics from './VendorAnalytics';
import VendorPartnershipTiers from './VendorPartnershipTiers';
import PlatformDropdown from './PlatformDropdown';

export default function BusinessDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const businessId = 'business-123';

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <Building2 className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold">Business Dashboard</h1>
                <p className="text-gray-600">Manage your business operations</p>
              </div>
            </div>
            <PlatformDropdown />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="pos" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              POS Integration
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics & AI
            </TabsTrigger>
            <TabsTrigger value="reviews" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Reviews
            </TabsTrigger>
            <TabsTrigger value="partnership" className="flex items-center gap-2">
              <Crown className="h-4 w-4" />
              Partnership
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Today's Stats
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Orders:</span>
                      <span className="font-semibold">23</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Revenue:</span>
                      <span className="font-semibold">$1,245</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Rating:</span>
                      <span className="font-semibold">4.6 ★</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Customer Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>New Customers:</span>
                      <span className="font-semibold">8</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Returning:</span>
                      <span className="font-semibold">15</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Satisfaction:</span>
                      <span className="font-semibold text-green-600">92%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Upcoming Events
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div>Staff Meeting - 2:00 PM</div>
                    <div>Inventory Check - 4:00 PM</div>
                    <div>Marketing Review - Tomorrow</div>
                    <Button size="sm" variant="outline" className="w-full mt-2">
                      View Calendar
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="h-5 w-5" />
                    Notifications
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="text-orange-600">Low inventory alert</div>
                    <div className="text-blue-600">New review received</div>
                    <div className="text-green-600">Payment processed</div>
                    <Button size="sm" variant="outline" className="w-full mt-2">
                      View All
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Recent Orders
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                      <div>
                        <div className="font-medium">#ORD-001</div>
                        <div className="text-sm text-gray-600">John Doe - $45.99</div>
                      </div>
                      <span className="text-green-600 text-sm">Completed</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                      <div>
                        <div className="font-medium">#ORD-002</div>
                        <div className="text-sm text-gray-600">Jane Smith - $32.50</div>
                      </div>
                      <span className="text-blue-600 text-sm">Processing</span>
                    </div>
                    <Button variant="outline" className="w-full">
                      View All Orders
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Financial Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Today's Revenue:</span>
                      <span className="font-semibold">$1,245.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>This Week:</span>
                      <span className="font-semibold">$8,750.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>This Month:</span>
                      <span className="font-semibold">$32,450.00</span>
                    </div>
                    <div className="flex justify-between text-green-600">
                      <span>Growth:</span>
                      <span className="font-semibold">+12.5%</span>
                    </div>
                    <Button variant="outline" className="w-full">
                      View Financial Reports
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="pos">
            <POSIntegration />
          </TabsContent>

          <TabsContent value="analytics">
            <VendorAnalytics vendorId={businessId} />
          </TabsContent>

          <TabsContent value="reviews">
            <VendorReviews vendorId={businessId} />
          </TabsContent>

          <TabsContent value="partnership">
            <VendorPartnershipTiers userId={businessId} />
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Business Settings</CardTitle>
                <CardDescription>Manage your account and preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Business Information</h3>
                    <p className="text-sm text-gray-600">Update your business details and contact information</p>
                    <Button variant="outline" className="mt-2">Edit Details</Button>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Payment Settings</h3>
                    <p className="text-sm text-gray-600">Configure payment methods and payout preferences</p>
                    <Button variant="outline" className="mt-2">Manage Payments</Button>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Staff Management</h3>
                    <p className="text-sm text-gray-600">Add and manage staff accounts and permissions</p>
                    <Button variant="outline" className="mt-2">Manage Staff</Button>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Inventory Management</h3>
                    <p className="text-sm text-gray-600">Track and manage your product inventory</p>
                    <Button variant="outline" className="mt-2">Manage Inventory</Button>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Marketing Tools</h3>
                    <p className="text-sm text-gray-600">Create promotions and marketing campaigns</p>
                    <Button variant="outline" className="mt-2">Marketing Center</Button>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Notification Preferences</h3>
                    <p className="text-sm text-gray-600">Choose how you want to receive notifications</p>
                    <Button variant="outline" className="mt-2">Update Preferences</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}