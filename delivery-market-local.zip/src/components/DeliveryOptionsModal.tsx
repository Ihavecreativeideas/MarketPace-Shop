import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, Users, Zap, MapPin, Shield, Crown, Lock } from 'lucide-react';

interface DeliveryOptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectUrgent: () => void;
  onSelectGrowRoute: () => void;
  deliveryFee: number;
  userMembershipType?: 'standard' | 'partner';
}

export const DeliveryOptionsModal: React.FC<DeliveryOptionsModalProps> = ({
  isOpen,
  onClose,
  onSelectUrgent,
  onSelectGrowRoute,
  deliveryFee,
  userMembershipType = 'standard'
}) => {
  const buyerShare = deliveryFee / 2;
  const sellerShare = deliveryFee / 2;
  const isStandardMember = userMembershipType === 'standard';

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-green-600" />
            Safe Delivery Options - We Keep You Protected
          </DialogTitle>
          <p className="text-sm text-gray-600 mt-2">
            For your safety and convenience, we only offer delivery services. No pickup required!
          </p>
        </DialogHeader>
        
        {isStandardMember && (
          <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center gap-2 text-blue-700">
              <MapPin className="w-4 h-4" />
              <span className="font-medium">Standard Membership - Local Delivery Only</span>
            </div>
            <p className="text-sm text-blue-600 mt-1">
              Your current plan includes local delivery only (5 mile radius). 
              <Button variant="link" className="p-0 h-auto text-blue-600 underline">
                Become a partner for extended delivery privileges!
              </Button>
            </p>
          </div>
        )}
        
        <div className="grid md:grid-cols-2 gap-4">
          <Card className={`cursor-pointer hover:shadow-lg transition-shadow ${
            isStandardMember ? 'opacity-50' : ''
          }`} onClick={isStandardMember ? undefined : onSelectUrgent}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-orange-500" />
                Urgent Delivery
                {isStandardMember && (
                  <Badge variant="outline" className="text-xs">
                    <Crown className="w-3 h-3 mr-1" />
                    Partner Only
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm text-gray-600">
                  {isStandardMember 
                    ? 'Extended range delivery - upgrade to partner membership to access'
                    : 'Safe delivery straight to your door - no contact needed'
                  }
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">30-60 minutes</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">
                      {isStandardMember ? 'Up to 20 miles' : 'Extended range'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Contactless delivery</span>
                  </div>
                  {!isStandardMember && (
                    <div className="space-y-1">
                      <div className="text-sm font-medium">Your delivery cost: ${buyerShare.toFixed(2)}</div>
                      <div className="text-xs text-gray-500">Split with seller (${sellerShare.toFixed(2)})</div>
                    </div>
                  )}
                </div>
                <Button 
                  className="w-full" 
                  onClick={isStandardMember ? undefined : onSelectUrgent}
                  disabled={isStandardMember}
                >
                  {isStandardMember ? (
                    <><Lock className="w-4 h-4 mr-2" /> Upgrade to Access</>
                  ) : (
                    'Select Safe Urgent Delivery'
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow border-green-200" onClick={onSelectGrowRoute}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-green-500" />
                Grow Routes
                <Badge variant="secondary" className="bg-green-100 text-green-700">Save up to 25%</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm text-gray-600">
                  Join with other buyers in your area for safe, affordable delivery
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">
                      {isStandardMember ? '5 mile local radius' : '20 mile radius'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">2-4 hours</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Safe group delivery</span>
                  </div>
                  <div className="text-sm">
                    <div className="font-medium text-green-600">Discount Structure:</div>
                    <div className="text-xs space-y-1 mt-1">
                      <div>• 3 buyers: 15% off + split delivery fee</div>
                      <div>• 4 buyers: 20% off + split delivery fee</div>
                      <div>• 5+ buyers: 25% off + split delivery fee</div>
                    </div>
                    <div className="text-xs text-gray-500 mt-2">
                      Your delivery share: ${buyerShare.toFixed(2)}
                    </div>
                  </div>
                </div>
                <Button className="w-full bg-green-600 hover:bg-green-700" onClick={onSelectGrowRoute}>
                  Start Safe Group Route
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex items-center gap-2 text-green-700">
            <Shield className="w-4 h-4" />
            <span className="font-medium">Safety First Policy</span>
          </div>
          <p className="text-sm text-green-600 mt-1">
            We prioritize your safety with contactless delivery options only. No pickup required - we bring everything safely to your door!
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};