import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, Clock, MapPin, Pill, User } from 'lucide-react';

interface PharmacyPickup {
  id: string;
  pickupCode: string;
  patientName: string;
  medicationName: string;
  pharmacyName: string;
  pharmacyAddress: string;
  customerAddress: string;
  status: 'pending' | 'picked_up' | 'delivered';
  pickupTime?: string;
  estimatedDeliveryTime?: string;
  driverId?: string;
}

const PharmacyPickupNotification: React.FC = () => {
  const [pickups, setPickups] = useState<PharmacyPickup[]>([
    {
      id: 'PU123456',
      pickupCode: 'PU123456',
      patientName: 'John Smith',
      medicationName: 'Amoxicillin 500mg',
      pharmacyName: 'CVS Pharmacy',
      pharmacyAddress: '123 Main St',
      customerAddress: '456 Oak Ave',
      status: 'pending'
    }
  ]);

  const [notifications, setNotifications] = useState<string[]>([]);

  const simulatePickup = (pickupId: string) => {
    setPickups(prev => prev.map(pickup => {
      if (pickup.id === pickupId) {
        const now = new Date();
        const deliveryTime = new Date(now.getTime() + 25 * 60000); // 25 minutes from now
        
        setNotifications(prev => [...prev, 
          `Driver has picked up your prescription: ${pickup.medicationName}`
        ]);
        
        return {
          ...pickup,
          status: 'picked_up' as const,
          pickupTime: now.toLocaleTimeString(),
          estimatedDeliveryTime: deliveryTime.toLocaleTimeString(),
          driverId: 'DRV001'
        };
      }
      return pickup;
    }));
  };

  const calculateDeliveryTime = (pharmacyAddress: string, customerAddress: string) => {
    // Simple distance calculation simulation
    const baseTime = 15; // Base 15 minutes
    const additionalTime = Math.floor(Math.random() * 20); // 0-20 additional minutes
    return baseTime + additionalTime;
  };

  useEffect(() => {
    // Simulate automatic pickup after 30 seconds for demo
    const timer = setTimeout(() => {
      if (pickups.some(p => p.status === 'pending')) {
        simulatePickup('PU123456');
      }
    }, 30000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Pill className="w-5 h-5" />
            Pharmacy Pickup Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          {notifications.length > 0 && (
            <div className="mb-4 space-y-2">
              {notifications.map((notification, index) => (
                <Alert key={index} className="border-green-200 bg-green-50">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    {notification}
                  </AlertDescription>
                </Alert>
              ))}
            </div>
          )}

          <div className="space-y-4">
            {pickups.map((pickup) => {
              const deliveryTime = calculateDeliveryTime(pickup.pharmacyAddress, pickup.customerAddress);
              
              return (
                <div key={pickup.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-semibold flex items-center gap-2">
                        <User className="w-4 h-4" />
                        {pickup.patientName}
                      </h3>
                      <p className="text-sm text-gray-600">Pickup Code: {pickup.pickupCode}</p>
                    </div>
                    <Badge 
                      variant={pickup.status === 'picked_up' ? 'default' : 'secondary'}
                      className={pickup.status === 'picked_up' ? 'bg-green-600' : ''}
                    >
                      {pickup.status === 'pending' ? 'Awaiting Pickup' : 
                       pickup.status === 'picked_up' ? 'Picked Up' : 'Delivered'}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                    <div>
                      <div className="text-sm text-gray-600">Medication</div>
                      <div className="font-medium">{pickup.medicationName}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Pharmacy</div>
                      <div className="font-medium">{pickup.pharmacyName}</div>
                      <div className="text-sm text-gray-500">{pickup.pharmacyAddress}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      <span>Delivery to: {pickup.customerAddress}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>Est. {deliveryTime} min delivery</span>
                    </div>
                  </div>

                  {pickup.status === 'picked_up' && (
                    <div className="mt-3 p-3 bg-green-50 rounded-lg">
                      <div className="text-sm">
                        <strong>Picked up at:</strong> {pickup.pickupTime}<br/>
                        <strong>Estimated delivery:</strong> {pickup.estimatedDeliveryTime}<br/>
                        <strong>Driver ID:</strong> {pickup.driverId}
                      </div>
                    </div>
                  )}

                  {pickup.status === 'pending' && (
                    <button 
                      onClick={() => simulatePickup(pickup.id)}
                      className="mt-3 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm"
                    >
                      Simulate Driver Pickup
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PharmacyPickupNotification;