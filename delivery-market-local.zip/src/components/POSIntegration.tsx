import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, AlertCircle, RefreshCw, DollarSign, Package, Settings } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface POSSystem {
  id: string;
  name: string;
  status: 'connected' | 'disconnected' | 'syncing';
  lastSync: string;
  orders: number;
  revenue: number;
}

export default function POSIntegration() {
  const [posSystems, setPOSSystems] = useState<POSSystem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPOSSystems();
  }, []);

  const fetchPOSSystems = async () => {
    try {
      const { data, error } = await supabase
        .from('pos_transactions')
        .select('*')
        .limit(10);
      
      if (error) throw error;
      
      // Mock data for demo
      setPOSSystems([
        {
          id: '1',
          name: 'Square POS',
          status: 'connected',
          lastSync: '2 minutes ago',
          orders: 45,
          revenue: 1250.50
        },
        {
          id: '2', 
          name: 'Toast POS',
          status: 'syncing',
          lastSync: '5 minutes ago',
          orders: 32,
          revenue: 890.25
        }
      ]);
    } catch (error) {
      console.error('Error fetching POS systems:', error);
    } finally {
      setLoading(false);
    }
  };

  const syncPOS = async (posId: string) => {
    try {
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/b1ba7508-93dd-4907-9529-858af30bb0c0',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ posId, action: 'sync' })
        }
      );
      
      if (response.ok) {
        fetchPOSSystems();
      }
    } catch (error) {
      console.error('Sync failed:', error);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">POS Integration</h1>
        <Button onClick={() => fetchPOSSystems()}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh
        </Button>
      </div>

      <Tabs defaultValue="systems" className="space-y-4">
        <TabsList>
          <TabsTrigger value="systems">Connected Systems</TabsTrigger>
          <TabsTrigger value="inventory">Inventory Sync</TabsTrigger>
          <TabsTrigger value="payments">Payment Reconciliation</TabsTrigger>
        </TabsList>

        <TabsContent value="systems" className="space-y-4">
          {posSystems.map((pos) => (
            <Card key={pos.id}>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    {pos.name}
                    <Badge variant={pos.status === 'connected' ? 'default' : 'secondary'}>
                      {pos.status === 'connected' && <CheckCircle className="h-3 w-3 mr-1" />}
                      {pos.status === 'syncing' && <RefreshCw className="h-3 w-3 mr-1 animate-spin" />}
                      {pos.status === 'disconnected' && <AlertCircle className="h-3 w-3 mr-1" />}
                      {pos.status}
                    </Badge>
                  </CardTitle>
                  <CardDescription>Last sync: {pos.lastSync}</CardDescription>
                </div>
                <Button 
                  variant="outline" 
                  onClick={() => syncPOS(pos.id)}
                  disabled={pos.status === 'syncing'}
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Sync Now
                </Button>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <Package className="h-4 w-4 text-blue-500" />
                    <span className="text-sm">{pos.orders} orders today</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-green-500" />
                    <span className="text-sm">${pos.revenue.toFixed(2)} revenue</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="inventory">
          <Card>
            <CardHeader>
              <CardTitle>Inventory Management</CardTitle>
              <CardDescription>Real-time inventory sync across all platforms</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Inventory sync features coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments">
          <Card>
            <CardHeader>
              <CardTitle>Payment Reconciliation</CardTitle>
              <CardDescription>Automated payment matching and reporting</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Payment reconciliation dashboard coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}