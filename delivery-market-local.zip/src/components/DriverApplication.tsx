import React, { useState } from 'react';
import { BackButton } from './BackButton';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Alert, AlertDescription } from './ui/alert';
import { UserCheck, Shield, Truck, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import DriverLicenseUpload from './DriverLicenseUpload';
import BackgroundCheckUpload from './BackgroundCheckUpload';

const DriverApplication: React.FC = () => {
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', phone: '',
    hasInsurance: false, hasDriversLicense: false, hasBackgroundCheck: false, canDeliverLargeItems: false
  });
  const [licenseFile, setLicenseFile] = useState<File | null>(null);
  const [backgroundFile, setBackgroundFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!licenseFile || !backgroundFile) {
      alert('Please upload both your driver\'s license and background check documents.');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const formDataToSend = new FormData();
      formDataToSend.append('firstName', formData.firstName);
      formDataToSend.append('lastName', formData.lastName);
      formDataToSend.append('email', formData.email);
      formDataToSend.append('phone', formData.phone);
      formDataToSend.append('hasInsurance', formData.hasInsurance.toString());
      formDataToSend.append('hasDriversLicense', formData.hasDriversLicense.toString());
      formDataToSend.append('hasBackgroundCheck', formData.hasBackgroundCheck.toString());
      formDataToSend.append('canDeliverLargeItems', formData.canDeliverLargeItems.toString());
      formDataToSend.append('licenseFile', licenseFile);
      formDataToSend.append('backgroundFile', backgroundFile);
      
      const response = await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/51d6fcfa-3d43-48d1-8f8b-5457c6b3c25b', {
        method: 'POST',
        body: formDataToSend
      });
      
      const result = await response.json();
      if (result.success) {
        alert(`Application approved! Username: ${result.credentials.username}, Password: ${result.credentials.password}`);
        navigate('/driver-login');
      } else {
        alert('Application rejected: ' + result.message);
      }
    } catch (error) {
      alert('Error submitting application. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isFormValid = formData.hasInsurance && formData.hasDriversLicense && formData.hasBackgroundCheck && licenseFile && backgroundFile;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <BackButton to="/driver-job" />
        
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Driver Application</h1>
          <p className="text-gray-600">Apply to join PostPace as an Independent Contractor</p>
        </div>

        <Alert className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Important:</strong> You will be hired as an Independent Contractor. You must have valid insurance, 
            driver's license, and provide your own background check.
          </AlertDescription>
        </Alert>

        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCheck className="w-5 h-5" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input 
                    id="firstName" 
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input 
                    id="lastName" 
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input 
                  id="email" 
                  type="email" 
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input 
                  id="phone" 
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                />
              </div>
            </CardContent>
          </Card>

          <div className="mt-6 space-y-6">
            <DriverLicenseUpload 
              onFileUpload={setLicenseFile} 
              uploadedFile={licenseFile} 
            />
            
            <BackgroundCheckUpload 
              onFileUpload={setBackgroundFile} 
              uploadedFile={backgroundFile} 
            />
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Requirements
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="insurance" 
                  checked={formData.hasInsurance}
                  onCheckedChange={(checked) => setFormData({...formData, hasInsurance: !!checked})}
                />
                <Label htmlFor="insurance">I have valid vehicle insurance *</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="license" 
                  checked={formData.hasDriversLicense}
                  onCheckedChange={(checked) => setFormData({...formData, hasDriversLicense: !!checked})}
                />
                <Label htmlFor="license">I have a valid driver's license *</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="background" 
                  checked={formData.hasBackgroundCheck}
                  onCheckedChange={(checked) => setFormData({...formData, hasBackgroundCheck: !!checked})}
                />
                <Label htmlFor="background">I have provided my own background check *</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="largeItems" 
                  checked={formData.canDeliverLargeItems}
                  onCheckedChange={(checked) => setFormData({...formData, canDeliverLargeItems: !!checked})}
                />
                <Label htmlFor="largeItems">I can deliver large items (couches, mattresses, workout equipment, etc.)</Label>
              </div>
            </CardContent>
          </Card>

          <div className="mt-8 text-center">
            <Button 
              type="submit" 
              size="lg" 
              className="bg-blue-600 hover:bg-blue-700"
              disabled={isSubmitting || !isFormValid}
            >
              {isSubmitting ? 'Submitting...' : 'Submit Application'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DriverApplication;