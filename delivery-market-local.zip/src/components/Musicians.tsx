import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Music, Calendar, Bell, ExternalLink, ShoppingBag, Crown, Star, MapPin, MessageCircle, FileText, CheckCircle, Clock } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import EquipmentShareModal from './EquipmentShareModal';
import MusicianStartupCampaign from './MusicianStartupCampaign';
import MusicianFreeSignupModal from './MusicianFreeSignupModal';
import { toast } from '@/hooks/use-toast';

const Musicians: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMusician, setSelectedMusician] = useState<any>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showEquipmentModal, setShowEquipmentModal] = useState(false);
  const [showSignupModal, setShowSignupModal] = useState(false);
  const [bookingForm, setBookingForm] = useState({ eventType: '', venue: '', message: '' });
  const [hasJoinedCampaign, setHasJoinedCampaign] = useState(false);
  
  const mockMusicians = [
    { 
      id: 1, 
      name: 'The Midnight Blues', 
      genre: 'Blues Rock', 
      followers: 1250, 
      image: '/placeholder.svg',
      hasNewRelease: true,
      nextShow: 'Dec 15 - Blue Note Cafe',
      isPro: true,
      bio: 'Professional blues rock band with 10+ years of experience.',
      rating: 4.8,
      totalGigs: 156,
      venues: [
        { name: 'Blue Note Cafe', location: 'Downtown', date: '2023-12-01', type: 'Concert' },
        { name: 'Grand Hotel', location: 'Uptown', date: '2023-11-15', type: 'Wedding' }
      ]
    },
    { 
      id: 2, 
      name: 'Sarah Chen', 
      genre: 'Indie Folk', 
      followers: 890, 
      image: '/placeholder.svg',
      hasNewRelease: false,
      nextShow: 'Dec 22 - The Venue',
      isPro: true,
      bio: 'Singer-songwriter specializing in acoustic performances.',
      rating: 4.9,
      totalGigs: 89,
      venues: [{ name: 'Coffee Corner', location: 'Arts District', date: '2023-11-28', type: 'Acoustic' }]
    },
    { 
      id: 3, 
      name: 'Electric Dreams', 
      genre: 'Electronic', 
      followers: 2100, 
      image: '/placeholder.svg',
      hasNewRelease: true,
      nextShow: 'Jan 5 - Metro Club',
      isPro: false,
      bio: 'Electronic music duo.',
      rating: 4.5,
      totalGigs: 34,
      venues: []
    }
  ];

  const handleBookNow = (musician: any) => {
    setSelectedMusician(musician);
    setShowBookingModal(true);
  };

  const handleShareEquipment = () => {
    setShowEquipmentModal(true);
  };

  const handleEquipmentShared = (equipment: any) => {
    toast({ title: 'Equipment shared successfully!', description: 'Your equipment is now available on the marketplace.' });
    navigate('/marketplace');
  };

  const handleCampaignSignup = () => {
    setShowSignupModal(true);
  };

  const handleSignupComplete = (musicianData: any) => {
    setHasJoinedCampaign(true);
    console.log('Musician signed up:', musicianData);
  };

  const submitBooking = async () => {
    alert('Booking request sent successfully!');
    setShowBookingModal(false);
    setBookingForm({ eventType: '', venue: '', message: '' });
  };

  return (
    <div className="space-y-6">
      {/* Startup Campaign Banner - Show if not joined yet */}
      {!hasJoinedCampaign && (
        <MusicianStartupCampaign onSignup={handleCampaignSignup} />
      )}

      {/* Success Message for Campaign Members */}
      {hasJoinedCampaign && (
        <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-2 border-green-300">
          <CardContent className="p-6 text-center">
            <div className="flex justify-center mb-3">
              <div className="bg-green-500 p-3 rounded-full">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-green-800 mb-2">
              🎉 Welcome to MarketPace - Startup Campaign Member!
            </h3>
            <p className="text-green-700">
              You now have <span className="font-bold">lifetime access</span> to all MarketPace Musician Pro features. 
              Start building your professional musician profile!
            </p>
          </CardContent>
        </Card>
      )}

      {/* Share Equipment Banner */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShoppingBag className="w-6 h-6 text-green-600" />
            <div>
              <h3 className="font-semibold text-green-800">
                Share Your Equipment on Marketplace
              </h3>
              <p className="text-sm text-green-600">
                Sell or rent your musical equipment directly to Facebook Marketplace!
              </p>
            </div>
          </div>
          <Button 
            onClick={handleShareEquipment}
            className="bg-green-600 hover:bg-green-700"
          >
            <ShoppingBag className="w-4 h-4 mr-2" />
            Share Equipment
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <Input
          placeholder="Search musicians..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1"
        />
      </div>

      <div>
        <h3 className="text-xl font-semibold mb-4">Local Musicians</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mockMusicians.map((musician) => (
            <Card key={musician.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="p-0 relative">
                <img src={musician.image} alt={musician.name} className="w-full h-40 object-cover rounded-t-lg" />
                <div className="absolute top-2 right-2 flex gap-2">
                  {musician.hasNewRelease && <Badge className="bg-red-500">New!</Badge>}
                  {musician.isPro && <Badge className="bg-purple-600"><Crown className="w-3 h-3 mr-1" />PRO</Badge>}
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div>
                    <CardTitle className="text-lg">{musician.name}</CardTitle>
                    <p className="text-sm text-gray-600">{musician.genre}</p>
                    {musician.isPro && (
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        <span>{musician.rating} • {musician.totalGigs} gigs</span>
                      </div>
                    )}
                  </div>
                  
                  {musician.isPro && (
                    <div className="space-y-2">
                      <p className="text-sm text-gray-700">{musician.bio}</p>
                      <div className="space-y-1">
                        <p className="text-xs font-medium text-gray-600">Recent Venues:</p>
                        {musician.venues.slice(0, 2).map((venue: any, idx: number) => (
                          <div key={idx} className="text-xs text-gray-500 flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            <span>{venue.name} - {venue.type}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4" />
                    <span>{musician.nextShow}</span>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <Bell className="w-4 h-4 mr-1" />Follow
                    </Button>
                    {musician.isPro && (
                      <Button size="sm" onClick={() => handleBookNow(musician)} className="bg-blue-600">
                        Book Now
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <Dialog open={showBookingModal} onOpenChange={setShowBookingModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Book {selectedMusician?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Event Type</Label>
              <Input 
                placeholder="Wedding, Party, etc."
                value={bookingForm.eventType}
                onChange={(e) => setBookingForm({...bookingForm, eventType: e.target.value})}
              />
            </div>
            <div>
              <Label>Venue</Label>
              <Input 
                placeholder="Event location"
                value={bookingForm.venue}
                onChange={(e) => setBookingForm({...bookingForm, venue: e.target.value})}
              />
            </div>
            <div>
              <Label>Message</Label>
              <Textarea 
                placeholder="Tell them about your event..."
                value={bookingForm.message}
                onChange={(e) => setBookingForm({...bookingForm, message: e.target.value})}
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowBookingModal(false)} className="flex-1">Cancel</Button>
              <Button onClick={submitBooking} className="flex-1">
                <MessageCircle className="w-4 h-4 mr-2" />Send Request
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <EquipmentShareModal 
        isOpen={showEquipmentModal}
        onClose={() => setShowEquipmentModal(false)}
        onEquipmentShared={handleEquipmentShared}
      />

      <MusicianFreeSignupModal
        isOpen={showSignupModal}
        onClose={() => setShowSignupModal(false)}
        onSignupComplete={handleSignupComplete}
      />
    </div>
  );
};

export default Musicians;