import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Download, Bell, Wifi, WifiOff, Smartphone } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export const PWAInstaller: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handler);
    
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
      setIsInstalled(true);
    }
  };

  if (isInstalled) {
    return (
      <Alert className="mb-4">
        <Smartphone className="h-4 w-4" />
        <AlertDescription>
          MarketPace is installed! Access it from your home screen.
        </AlertDescription>
      </Alert>
    );
  }

  if (!deferredPrompt) return null;

  return (
    <Card className="mb-4">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Download className="h-5 w-5 mr-2" />
          Install MarketPace App
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">
          Install our app for faster access, offline support, and push notifications.
        </p>
        <Button onClick={handleInstall} className="w-full">
          Install App
        </Button>
      </CardContent>
    </Card>
  );
};

export const NotificationManager: React.FC = () => {
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [supported, setSupported] = useState(false);

  useEffect(() => {
    setSupported('Notification' in window);
    if ('Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const requestPermission = async () => {
    if (!supported) return;
    
    const result = await Notification.requestPermission();
    setPermission(result);
    
    if (result === 'granted') {
      // Register for push notifications
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        // Subscribe to push notifications here
      }
    }
  };

  const sendTestNotification = () => {
    if (permission === 'granted') {
      new Notification('MarketPace', {
        body: 'Your delivery is on the way!',
        icon: '/placeholder.svg',
        badge: '/placeholder.svg'
      });
    }
  };

  if (!supported) {
    return (
      <Alert>
        <Bell className="h-4 w-4" />
        <AlertDescription>
          Notifications are not supported in this browser.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bell className="h-5 w-5 mr-2" />
          Push Notifications
          <Badge variant={permission === 'granted' ? 'default' : 'secondary'} className="ml-2">
            {permission}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground">
          Get notified about order updates, delivery status, and special offers.
        </p>
        
        {permission === 'default' && (
          <Button onClick={requestPermission} className="w-full">
            Enable Notifications
          </Button>
        )}
        
        {permission === 'granted' && (
          <Button onClick={sendTestNotification} variant="outline" className="w-full">
            Test Notification
          </Button>
        )}
        
        {permission === 'denied' && (
          <Alert>
            <AlertDescription>
              Notifications are blocked. Please enable them in your browser settings.
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
};

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline) return null;

  return (
    <Alert className="mb-4 border-orange-200 bg-orange-50">
      <WifiOff className="h-4 w-4" />
      <AlertDescription>
        You're offline. Some features may be limited until you reconnect.
      </AlertDescription>
    </Alert>
  );
};