import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, ExternalLink, Music, Play, Share } from 'lucide-react';
import { useState } from 'react';

interface MusicLink {
  id: number;
  title: string;
  platform: string;
  url: string;
  type: 'song' | 'album' | 'playlist' | 'video';
  releaseDate?: string;
}

const MusicLinks = () => {
  const [links, setLinks] = useState<MusicLink[]>([
    {
      id: 1,
      title: 'Midnight Blues',
      platform: 'Spotify',
      url: 'https://spotify.com/track/123',
      type: 'song',
      releaseDate: '2024-11-15'
    },
    {
      id: 2,
      title: 'Live at Blue Note',
      platform: 'YouTube',
      url: 'https://youtube.com/watch?v=abc',
      type: 'video',
      releaseDate: '2024-10-20'
    }
  ]);
  
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    platform: '',
    url: '',
    type: 'song' as 'song' | 'album' | 'playlist' | 'video',
    releaseDate: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newLink: MusicLink = {
      id: Date.now(),
      ...formData
    };
    setLinks([...links, newLink]);
    setFormData({
      title: '',
      platform: '',
      url: '',
      type: 'song',
      releaseDate: ''
    });
    setIsOpen(false);
  };

  const getPlatformColor = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'spotify': return 'bg-green-100 text-green-800';
      case 'apple music': return 'bg-gray-100 text-gray-800';
      case 'youtube': return 'bg-red-100 text-red-800';
      case 'soundcloud': return 'bg-orange-100 text-orange-800';
      case 'bandcamp': return 'bg-blue-100 text-blue-800';
      default: return 'bg-purple-100 text-purple-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'video': return <Play className="w-4 h-4" />;
      case 'album': return <Music className="w-4 h-4" />;
      default: return <Music className="w-4 h-4" />;
    }
  };

  const shareLink = (link: MusicLink) => {
    if (navigator.share) {
      navigator.share({
        title: link.title,
        text: `Check out "${link.title}" on ${link.platform}`,
        url: link.url
      });
    } else {
      navigator.clipboard.writeText(link.url);
      alert('Link copied to clipboard!');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Music Links</h3>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Music Link
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Share Your Music</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Song/Album Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  placeholder="My New Song"
                  required
                />
              </div>
              <div>
                <Label htmlFor="platform">Platform</Label>
                <Input
                  id="platform"
                  value={formData.platform}
                  onChange={(e) => setFormData({...formData, platform: e.target.value})}
                  placeholder="Spotify, YouTube, SoundCloud..."
                  required
                />
              </div>
              <div>
                <Label htmlFor="url">Link URL</Label>
                <Input
                  id="url"
                  type="url"
                  value={formData.url}
                  onChange={(e) => setFormData({...formData, url: e.target.value})}
                  placeholder="https://..."
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="type">Type</Label>
                  <select
                    id="type"
                    value={formData.type}
                    onChange={(e) => setFormData({...formData, type: e.target.value as any})}
                    className="w-full p-2 border rounded-md"
                  >
                    <option value="song">Song</option>
                    <option value="album">Album</option>
                    <option value="playlist">Playlist</option>
                    <option value="video">Video</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="releaseDate">Release Date</Label>
                  <Input
                    id="releaseDate"
                    type="date"
                    value={formData.releaseDate}
                    onChange={(e) => setFormData({...formData, releaseDate: e.target.value})}
                  />
                </div>
              </div>
              <Button type="submit" className="w-full">
                Add Link
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {links.map((link) => (
          <Card key={link.id}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {getTypeIcon(link.type)}
                {link.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Badge className={getPlatformColor(link.platform)}>
                    {link.platform}
                  </Badge>
                  <Badge variant="outline">
                    {link.type}
                  </Badge>
                </div>
                {link.releaseDate && (
                  <p className="text-sm text-gray-600">
                    Released: {new Date(link.releaseDate).toLocaleDateString()}
                  </p>
                )}
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1"
                    onClick={() => window.open(link.url, '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Listen
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => shareLink(link)}
                  >
                    <Share className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {links.length === 0 && (
        <Card className="text-center py-8">
          <CardContent>
            <Music className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium mb-2">No music links yet</h3>
            <p className="text-gray-600 mb-4">
              Share your music with fans by adding links to your songs, albums, and videos.
            </p>
            <Button onClick={() => setIsOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Your First Link
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default MusicLinks;