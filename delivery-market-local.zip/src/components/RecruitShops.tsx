import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Building2, ShoppingBag, Zap, Check, Star, AlertCircle, Scissors, Wrench, Heart, Coffee } from 'lucide-react';
import VendorPartnershipTiers from './VendorPartnershipTiers';

const RecruitShops: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Partner with MarketPace
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Connect your local business or service to customers in your community
          </p>
        </div>

        {/* Business Types */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          <Card className="hover:shadow-lg transition-shadow text-center">
            <CardContent className="p-6">
              <Coffee className="w-8 h-8 text-orange-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900">Restaurants & Cafes</h3>
              <p className="text-sm text-gray-600 mt-2">Food delivery & pickup</p>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow text-center">
            <CardContent className="p-6">
              <Scissors className="w-8 h-8 text-purple-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900">Personal Services</h3>
              <p className="text-sm text-gray-600 mt-2">Salons, spas, fitness</p>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow text-center">
            <CardContent className="p-6">
              <Wrench className="w-8 h-8 text-blue-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900">Professional Services</h3>
              <p className="text-sm text-gray-600 mt-2">Repair, maintenance, consulting</p>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow text-center">
            <CardContent className="p-6">
              <Heart className="w-8 h-8 text-red-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900">Health & Wellness</h3>
              <p className="text-sm text-gray-600 mt-2">Healthcare, therapy, wellness</p>
            </CardContent>
          </Card>
        </div>

        {/* Basic Integration Options */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-orange-600" />
                Business Integration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Connect your existing business systems to MarketPace
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" />
                  <span className="text-sm">Service booking system</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" />
                  <span className="text-sm">Inventory management</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-purple-600" />
                Social Media
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Link your Facebook, Instagram, and other social profiles
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" />
                  <span className="text-sm">Cross-platform posting</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" />
                  <span className="text-sm">Social commerce tools</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Website Integration Notice */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-12">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-lg font-semibold text-blue-900 mb-2">
                Advanced Integration Available for Partners Only
              </h3>
              <p className="text-blue-800 mb-4">
                Website integration, API access, and premium business tools are exclusively 
                available to our Partner Businesses through our subscription tiers.
              </p>
            </div>
          </div>
        </div>

        {/* Partnership Tiers */}
        <VendorPartnershipTiers />

        {/* CTA Section */}
        <div className="text-center bg-white rounded-lg p-8 shadow-lg mt-12">
          <div className="flex justify-center mb-4">
            <Star className="w-12 h-12 text-yellow-500" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Start Your Business Partnership Today
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Choose a partnership tier to unlock premium features and grow your local business
          </p>
          <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
            <Zap className="w-5 h-5 mr-2" />
            Get Started
          </Button>
        </div>
      </div>
    </div>
  );
};

export default RecruitShops;