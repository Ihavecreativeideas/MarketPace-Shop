import { useState, useEffect } from 'react';
import { MapPin, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

interface LocationPersonalizerProps {
  onLocationChange: (location: string, coordinates?: { lat: number; lng: number }) => void;
  currentLocation?: string;
}

const LocationPersonalizer: React.FC<LocationPersonalizerProps> = ({ onLocationChange, currentLocation }) => {
  const [location, setLocation] = useState(currentLocation || '');
  const [isDetecting, setIsDetecting] = useState(false);
  const { toast } = useToast();

  const detectLocation = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Location not supported",
        description: "Your browser doesn't support location detection",
        variant: "destructive"
      });
      return;
    }

    setIsDetecting(true);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        
        // Simulate reverse geocoding
        setTimeout(() => {
          const mockAddress = `${Math.floor(Math.random() * 9999)} Main St, City, State`;
          setLocation(mockAddress);
          onLocationChange(mockAddress, { lat: latitude, lng: longitude });
          setIsDetecting(false);
          
          toast({
            title: "Location detected",
            description: "Marketplace personalized to your area"
          });
        }, 1000);
      },
      (error) => {
        setIsDetecting(false);
        toast({
          title: "Location detection failed",
          description: "Please enter your location manually",
          variant: "destructive"
        });
      }
    );
  };

  const handleLocationSubmit = () => {
    if (location.trim()) {
      onLocationChange(location.trim());
      toast({
        title: "Location updated",
        description: "Marketplace personalized to your area"
      });
    }
  };

  return (
    <div className="bg-blue-50 p-4 rounded-lg border mb-6">
      <div className="flex items-center gap-2 mb-3">
        <MapPin className="w-5 h-5 text-blue-600" />
        <h3 className="font-semibold text-blue-900">Personalize Your Marketplace</h3>
      </div>
      
      <div className="flex gap-2 mb-2">
        <Input
          placeholder="Enter your location for personalized results"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="flex-1"
        />
        <Button 
          variant="outline" 
          onClick={detectLocation}
          disabled={isDetecting}
        >
          <Target className="w-4 h-4 mr-2" />
          {isDetecting ? 'Detecting...' : 'Detect'}
        </Button>
        <Button onClick={handleLocationSubmit} disabled={!location.trim()}>
          Update
        </Button>
      </div>
      
      {location && (
        <div className="flex items-center gap-2">
          <Badge variant="secondary">Current Location:</Badge>
          <span className="text-sm text-gray-600">{location}</span>
        </div>
      )}
    </div>
  );
};

export default LocationPersonalizer;