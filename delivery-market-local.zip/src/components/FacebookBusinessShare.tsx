import React from 'react';
import { Button } from '@/components/ui/button';
import { Facebook } from 'lucide-react';
import { PaceMakerBusiness } from './PaceMakersCard';

interface FacebookBusinessShareProps {
  business: PaceMakerBusiness;
}

export const FacebookBusinessShare: React.FC<FacebookBusinessShareProps> = ({ business }) => {
  const handleShare = () => {
    const shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${encodeURIComponent(`Check out ${business.business_name} on PaceMakers! ${business.description} Visit: ${window.location.origin}/pacemakers`)}`;
    window.open(shareUrl, '_blank', 'width=600,height=400');
  };

  return (
    <Button 
      variant="outline" 
      size="sm"
      onClick={handleShare}
      className="flex items-center gap-2"
    >
      <Facebook className="h-4 w-4" />
      Share to Facebook
    </Button>
  );
};

// Enhanced share with marketplace integration
export const shareBusinessToMarketplace = async (business: PaceMakerBusiness) => {
  try {
    const response = await fetch(
      'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/b9a45770-22d6-498a-beb4-39ad195a36cd',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'share_to_facebook',
          businessData: business
        })
      }
    );
    
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error sharing business:', error);
    return { success: false, error: 'Failed to share business' };
  }
};