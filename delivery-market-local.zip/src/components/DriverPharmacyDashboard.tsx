import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, Clock, MapPin, Pill, QrCode, Navigation } from 'lucide-react';

interface PharmacyDelivery {
  id: string;
  pickupCode: string;
  patientName: string;
  medicationName: string;
  pharmacyName: string;
  pharmacyAddress: string;
  customerAddress: string;
  status: 'assigned' | 'en_route_pickup' | 'picked_up' | 'en_route_delivery' | 'delivered';
  assignedTime: string;
  estimatedPickupTime: string;
  estimatedDeliveryTime: string;
  distance: number;
  pickupFee: number;
  dropoffFee: number;
  mileageRate: number;
  totalDriverPay: number;
  deliveryRate: number;
  platformFee: number;
}

const DriverPharmacyDashboard: React.FC = () => {
  const [deliveries, setDeliveries] = useState<PharmacyDelivery[]>([]);

  // Calculate correct driver pay based on current rates
  const calculateDriverPay = (distance: number) => {
    const pickupFee = 4.00;
    const dropoffFee = 2.00;
    const mileageRate = 0.75;
    const mileagePay = distance * mileageRate;
    return {
      pickupFee,
      dropoffFee,
      mileageRate,
      mileagePay,
      totalDriverPay: pickupFee + dropoffFee + mileagePay
    };
  };

  useEffect(() => {
    // Initialize with corrected pay calculation
    const sampleDelivery = {
      id: 'PH001',
      pickupCode: 'PU123456',
      patientName: 'John Smith',
      medicationName: 'Amoxicillin 500mg',
      pharmacyName: 'CVS Pharmacy',
      pharmacyAddress: '123 Main St',
      customerAddress: '456 Oak Ave',
      status: 'assigned' as const,
      assignedTime: new Date().toLocaleTimeString(),
      estimatedPickupTime: new Date(Date.now() + 15 * 60000).toLocaleTimeString(),
      estimatedDeliveryTime: new Date(Date.now() + 40 * 60000).toLocaleTimeString(),
      distance: 3.2,
      deliveryRate: 14.00,
      platformFee: 0
    };

    const payBreakdown = calculateDriverPay(sampleDelivery.distance);
    const updatedDelivery = {
      ...sampleDelivery,
      ...payBreakdown,
      platformFee: sampleDelivery.deliveryRate - payBreakdown.totalDriverPay
    };

    setDeliveries([updatedDelivery]);
  }, []);

  const updateDeliveryStatus = async (deliveryId: string, newStatus: PharmacyDelivery['status']) => {
    setDeliveries(prev => prev.map(delivery => {
      if (delivery.id === deliveryId) {
        return { ...delivery, status: newStatus };
      }
      return delivery;
    }));

    try {
      await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/f25d0e95-bbd0-4690-b364-e8feb61dcd2f',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            deliveryId,
            status: newStatus,
            timestamp: new Date().toISOString(),
            driverId: 'DRV001'
          })
        }
      );
    } catch (error) {
      console.error('Failed to update delivery status:', error);
    }
  };

  const getStatusColor = (status: PharmacyDelivery['status']) => {
    switch (status) {
      case 'assigned': return 'bg-blue-100 text-blue-800';
      case 'en_route_pickup': return 'bg-yellow-100 text-yellow-800';
      case 'picked_up': return 'bg-green-100 text-green-800';
      case 'en_route_delivery': return 'bg-purple-100 text-purple-800';
      case 'delivered': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getNextAction = (status: PharmacyDelivery['status']) => {
    switch (status) {
      case 'assigned': return { text: 'Head to Pharmacy', nextStatus: 'en_route_pickup' as const };
      case 'en_route_pickup': return { text: 'Arrived at Pharmacy', nextStatus: 'picked_up' as const };
      case 'picked_up': return { text: 'Start Delivery', nextStatus: 'en_route_delivery' as const };
      case 'en_route_delivery': return { text: 'Mark Delivered', nextStatus: 'delivered' as const };
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Pill className="w-5 h-5 text-blue-600" />
            Pharmacy Deliveries
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {deliveries.map((delivery) => {
              const nextAction = getNextAction(delivery.status);
              
              return (
                <div key={delivery.id} className="border rounded-lg p-4 bg-blue-50">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-semibold flex items-center gap-2">
                        <QrCode className="w-4 h-4" />
                        Pickup Code: {delivery.pickupCode}
                      </h3>
                      <p className="text-sm text-gray-600">Patient: {delivery.patientName}</p>
                    </div>
                    <Badge className={getStatusColor(delivery.status)}>
                      {delivery.status.replace('_', ' ').toUpperCase()}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <div className="text-sm text-gray-600">Medication</div>
                      <div className="font-medium">{delivery.medicationName}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600">Distance</div>
                      <div className="font-medium">{delivery.distance} miles</div>
                    </div>
                  </div>

                  <div className="bg-green-50 p-3 rounded-lg mb-4">
                    <div className="text-sm font-semibold text-green-800 mb-2">Driver Pay Breakdown (Updated):</div>
                    <div className="text-sm space-y-1">
                      <div className="flex justify-between">
                        <span>Pickup Fee:</span>
                        <span>${delivery.pickupFee.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Drop-off Fee:</span>
                        <span>${delivery.dropoffFee.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Mileage ({delivery.distance} mi × ${delivery.mileageRate}):</span>
                        <span>${(delivery.distance * delivery.mileageRate).toFixed(2)}</span>
                      </div>
                      <div className="border-t pt-1 flex justify-between font-semibold text-green-700">
                        <span>Total Driver Pay:</span>
                        <span>${delivery.totalDriverPay.toFixed(2)}</span>
                      </div>
                      <div className="text-xs text-gray-600 mt-2">
                        Delivery Rate: ${delivery.deliveryRate.toFixed(2)} | Platform Fee: ${delivery.platformFee.toFixed(2)}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="w-3 h-3 text-red-500" />
                      <span><strong>Pickup:</strong> {delivery.pharmacyName}, {delivery.pharmacyAddress}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="w-3 h-3 text-green-500" />
                      <span><strong>Delivery:</strong> {delivery.customerAddress}</span>
                    </div>
                  </div>

                  {delivery.status === 'picked_up' && (
                    <Alert className="mb-4 border-green-200 bg-green-50">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-800">
                        ✅ Prescription picked up! Customer has been notified.
                      </AlertDescription>
                    </Alert>
                  )}

                  <div className="flex gap-2">
                    {nextAction && (
                      <Button 
                        onClick={() => updateDeliveryStatus(delivery.id, nextAction.nextStatus)}
                        className="flex items-center gap-2"
                      >
                        <Navigation className="w-4 h-4" />
                        {nextAction.text}
                      </Button>
                    )}
                    
                    {delivery.status !== 'delivered' && (
                      <Button variant="outline" size="sm">
                        Open Maps
                      </Button>
                    )}
                  </div>

                  {delivery.status === 'delivered' && (
                    <div className="mt-3 p-3 bg-green-100 rounded-lg">
                      <div className="text-sm text-green-800">
                        ✅ <strong>Delivery Complete!</strong> Payment of ${delivery.totalDriverPay.toFixed(2)} processed.
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DriverPharmacyDashboard;