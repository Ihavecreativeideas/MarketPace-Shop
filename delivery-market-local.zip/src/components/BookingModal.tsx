import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Calendar, MessageCircle, DollarSign } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  musician: {
    name: string;
    id: number;
  };
  selectedDate: string;
  selectedTime: string;
  price: number;
  onSubmitBooking: (bookingData: any) => void;
}

const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  musician,
  selectedDate,
  selectedTime,
  price,
  onSubmitBooking
}) => {
  const [formData, setFormData] = useState({
    eventType: '',
    venue: '',
    duration: '',
    specialRequests: '',
    contactInfo: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitBooking({
      ...formData,
      musicianId: musician.id,
      date: selectedDate,
      time: selectedTime,
      price
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Book {musician.name}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-gray-50 p-3 rounded-lg">
            <p className="text-sm text-gray-600">Booking Details</p>
            <p className="font-medium">{new Date(selectedDate).toLocaleDateString()} at {selectedTime}</p>
            <p className="text-green-600 font-semibold">${price}</p>
          </div>

          <div className="space-y-3">
            <div>
              <Label htmlFor="eventType">Event Type</Label>
              <Input
                id="eventType"
                placeholder="Wedding, Party, Concert, etc."
                value={formData.eventType}
                onChange={(e) => setFormData({...formData, eventType: e.target.value})}
                required
              />
            </div>

            <div>
              <Label htmlFor="venue">Venue</Label>
              <Input
                id="venue"
                placeholder="Event location"
                value={formData.venue}
                onChange={(e) => setFormData({...formData, venue: e.target.value})}
                required
              />
            </div>

            <div>
              <Label htmlFor="duration">Duration (hours)</Label>
              <Input
                id="duration"
                type="number"
                placeholder="2"
                value={formData.duration}
                onChange={(e) => setFormData({...formData, duration: e.target.value})}
                required
              />
            </div>

            <div>
              <Label htmlFor="contactInfo">Your Contact Info</Label>
              <Input
                id="contactInfo"
                placeholder="Phone or email"
                value={formData.contactInfo}
                onChange={(e) => setFormData({...formData, contactInfo: e.target.value})}
                required
              />
            </div>

            <div>
              <Label htmlFor="message">Message to Musician</Label>
              <Textarea
                id="message"
                placeholder="Tell them about your event..."
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="specialRequests">Special Requests</Label>
              <Textarea
                id="specialRequests"
                placeholder="Equipment needs, song requests, etc."
                value={formData.specialRequests}
                onChange={(e) => setFormData({...formData, specialRequests: e.target.value})}
                rows={2}
              />
            </div>
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1">
              <MessageCircle className="w-4 h-4 mr-2" />
              Send Booking Request
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default BookingModal;