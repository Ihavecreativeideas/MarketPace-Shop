import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Gift, Heart, Users, Truck, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PartnerSignupFlowProps {
  onComplete?: () => void;
}

const PartnerSignupFlow: React.FC<PartnerSignupFlowProps> = ({ onComplete }) => {
  const [formData, setFormData] = useState({
    businessName: '',
    ownerName: '',
    email: '',
    phone: '',
    businessType: '',
    description: '',
    preferredDelivery: '',
    wantsToDonate: false,
    donationAmount: '',
    becomeSponsor: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData({ ...formData, [name]: value });
  };

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData({ ...formData, [name]: checked });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: '🎉 Welcome to MarketPace!',
        description: 'Your FREE access is now active. Start reaching more customers today!'
      });
      
      if (onComplete) onComplete();
    } catch (error) {
      toast({
        title: 'Signup Failed',
        description: 'Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="text-center mb-8">
        <Badge className="mb-4 bg-green-500 text-white text-lg px-4 py-2">
          FREE ACCESS - LIMITED TIME
        </Badge>
        <h1 className="text-3xl font-bold mb-2">Join MarketPace Partners</h1>
        <p className="text-gray-600 mb-4">
          Get FREE platform access to reach more customers during our test campaign
        </p>
        
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="w-5 h-5 text-blue-600" />
            <span className="font-semibold text-blue-800">Test Campaign Benefits</span>
          </div>
          <p className="text-blue-700 text-sm mb-2">
            <strong>No extra delivery service fee</strong> - delivery fees only pay our drivers during the test run
          </p>
          <p className="text-blue-600 text-sm">
            Help us launch successfully and benefit your growing community with "Delivering Opportunities"
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Partner Registration Form</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="businessName">Business Name *</Label>
                <Input
                  id="businessName"
                  name="businessName"
                  value={formData.businessName}
                  onChange={handleInputChange}
                  required
                  placeholder="Your business name"
                />
              </div>
              
              <div>
                <Label htmlFor="ownerName">Owner Name *</Label>
                <Input
                  id="ownerName"
                  name="ownerName"
                  value={formData.ownerName}
                  onChange={handleInputChange}
                  required
                  placeholder="Your full name"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  placeholder="your@email.com"
                />
              </div>
              
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={handleInputChange}
                  required
                  placeholder="(555) 123-4567"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="businessType">Business Type</Label>
              <Input
                id="businessType"
                name="businessType"
                value={formData.businessType}
                onChange={handleInputChange}
                placeholder="Restaurant, Retail, Service, etc."
              />
            </div>

            <div>
              <Label htmlFor="preferredDelivery">Preferred Delivery Method</Label>
              <Select onValueChange={(value) => handleSelectChange('preferredDelivery', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose your delivery preference" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="marketplace">MarketPace Drivers (optional)</SelectItem>
                  <SelectItem value="ups">UPS Shipping</SelectItem>
                  <SelectItem value="fedex">FedEx Shipping</SelectItem>
                  <SelectItem value="usps">USPS Mail</SelectItem>
                  <SelectItem value="doordash">DoorDash Integration</SelectItem>
                  <SelectItem value="self">Self Delivery</SelectItem>
                  <SelectItem value="flexible">Keep Options Open</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="description">Business Description</Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                placeholder="Tell us about your business and what you offer..."
                rows={3}
              />
            </div>

            {/* Support Options */}
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h3 className="font-semibold text-green-800 mb-3 flex items-center gap-2">
                <Heart className="w-5 h-5" />
                Support MarketPace Launch (Optional)
              </h3>
              
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Checkbox
                    id="donate"
                    checked={formData.wantsToDonate}
                    onCheckedChange={(checked) => handleCheckboxChange('wantsToDonate', checked as boolean)}
                  />
                  <div className="flex-1">
                    <Label htmlFor="donate" className="text-sm font-medium">
                      Make a donation to support our launch
                    </Label>
                    <p className="text-xs text-gray-600 mt-1">
                      Help us deliver opportunities to your community
                    </p>
                    {formData.wantsToDonate && (
                      <Input
                        name="donationAmount"
                        value={formData.donationAmount}
                        onChange={handleInputChange}
                        placeholder="$25, $50, $100..."
                        className="mt-2 w-32"
                      />
                    )}
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Checkbox
                    id="sponsor"
                    checked={formData.becomeSponsor}
                    onCheckedChange={(checked) => handleCheckboxChange('becomeSponsor', checked as boolean)}
                  />
                  <div className="flex-1">
                    <Label htmlFor="sponsor" className="text-sm font-medium">
                      Become a Launch Sponsor
                    </Label>
                    <p className="text-xs text-gray-600 mt-1">
                      Get featured promotion and help build our community
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-green-600 hover:bg-green-700 text-white text-lg py-3"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Creating your account...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Gift className="w-5 h-5" />
                  Get FREE Access Now - No Credit Card Required
                </div>
              )}
            </Button>
            
            <p className="text-xs text-center text-gray-500">
              By signing up, you agree to our Terms of Service and Privacy Policy.
              Free access includes full platform features during our test campaign.
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default PartnerSignupFlow;