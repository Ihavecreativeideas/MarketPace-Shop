import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, X, Eye, Heart, MapPin, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Notification {
  id: string;
  type: 'new_item' | 'price_drop' | 'back_in_stock' | 'interest_match';
  title: string;
  message: string;
  item_title?: string;
  item_price?: number;
  item_category?: string;
  match_score?: number;
  created_at: string;
  is_read: boolean;
  action_url?: string;
}

interface NotificationCenterProps {
  userId: string;
  onClose?: () => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({ userId, onClose }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadNotifications();
    // Set up real-time notifications
    const interval = setInterval(loadNotifications, 30000); // Check every 30 seconds
    return () => clearInterval(interval);
  }, [userId]);

  const loadNotifications = async () => {
    try {
      // Mock notifications for now - in real app, this would come from Supabase
      const mockNotifications: Notification[] = [
        {
          id: '1',
          type: 'interest_match',
          title: 'Perfect Match Found!',
          message: 'A guitar that matches your music interests just went on sale',
          item_title: 'Fender Acoustic Guitar',
          item_price: 299.99,
          item_category: 'music',
          match_score: 0.95,
          created_at: new Date().toISOString(),
          is_read: false,
          action_url: '/marketplace/item/123'
        },
        {
          id: '2',
          type: 'new_item',
          title: 'New Baby Items Available',
          message: 'Based on your family status, we found some great baby products',
          item_title: 'Baby Stroller Set',
          item_price: 150.00,
          item_category: 'baby_products',
          match_score: 0.88,
          created_at: new Date(Date.now() - 3600000).toISOString(),
          is_read: false,
          action_url: '/marketplace/item/124'
        },
        {
          id: '3',
          type: 'price_drop',
          title: 'Price Drop Alert!',
          message: 'The outdoor camping gear you viewed is now 20% off',
          item_title: 'Camping Tent - 4 Person',
          item_price: 89.99,
          item_category: 'outdoors',
          created_at: new Date(Date.now() - 7200000).toISOString(),
          is_read: true,
          action_url: '/marketplace/item/125'
        }
      ];
      
      setNotifications(mockNotifications);
    } catch (error) {
      console.error('Failed to load notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationId: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n)
    );
  };

  const dismissNotification = async (notificationId: string) => {
    setNotifications(prev => prev.filter(n => n.id !== notificationId));
    toast({
      title: "Notification dismissed",
      description: "You won't see this notification again"
    });
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'interest_match': return <Heart className="h-5 w-5 text-red-500" />;
      case 'new_item': return <Bell className="h-5 w-5 text-blue-500" />;
      case 'price_drop': return <MapPin className="h-5 w-5 text-green-500" />;
      default: return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  if (loading) {
    return (
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="h-6 bg-gray-200 rounded animate-pulse"></div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-gray-200 rounded animate-pulse"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md max-h-96 overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Notifications
          {unreadCount > 0 && (
            <Badge variant="destructive" className="text-xs">
              {unreadCount}
            </Badge>
          )}
        </CardTitle>
        {onClose && (
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        )}
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="max-h-80 overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground">
              <Bell className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No notifications yet</p>
              <p className="text-sm">We'll notify you about items that match your interests</p>
            </div>
          ) : (
            <div className="space-y-1">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 border-b hover:bg-muted/50 transition-colors ${
                    !notification.is_read ? 'bg-blue-50' : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {getNotificationIcon(notification.type)}
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-medium text-sm">{notification.title}</h4>
                        <div className="flex items-center gap-2">
                          {notification.match_score && (
                            <Badge variant="outline" className="text-xs">
                              {Math.round(notification.match_score * 100)}%
                            </Badge>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => dismissNotification(notification.id)}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-2">
                        {notification.message}
                      </p>
                      
                      {notification.item_title && (
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-sm">{notification.item_title}</span>
                          {notification.item_price && (
                            <span className="text-green-600 font-bold">
                              ${notification.item_price.toFixed(2)}
                            </span>
                          )}
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {formatTimeAgo(notification.created_at)}
                        </div>
                        
                        <div className="flex gap-2">
                          {!notification.is_read && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => markAsRead(notification.id)}
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              Mark read
                            </Button>
                          )}
                          
                          {notification.action_url && (
                            <Button size="sm" onClick={() => markAsRead(notification.id)}>
                              View Item
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};