import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Facebook, Share2, Store } from 'lucide-react';

interface Product {
  id: string;
  title: string;
  price: number;
  description: string;
  shopName: string;
}

interface FacebookPromotionProps {
  userType: 'member' | 'platform';
  product?: Product;
  shopId?: string;
}

export const FacebookPromotion: React.FC<FacebookPromotionProps> = ({
  userType,
  product,
  shopId
}) => {
  const [isPromoting, setIsPromoting] = useState(false);
  const [customMessage, setCustomMessage] = useState('');
  const { toast } = useToast();

  const handlePromotion = async () => {
    setIsPromoting(true);
    try {
      if (userType === 'member' && product) {
        const deliverNowUrl = `${window.location.origin}/deliver-now/${product.id}`;
        const fbText = `🛍️ ${product.title}\n\n${product.description}\n\nPrice: $${product.price}\n\n${customMessage}\n\n✨ Order now with instant delivery!`;
        const fbShareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(deliverNowUrl)}&quote=${encodeURIComponent(fbText)}`;
        window.open(fbShareUrl, '_blank');
        toast({ title: "Product Promoted!", description: "Your product is now being shared on Facebook Marketplace" });
      } else {
        const response = await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/fae604a9-2bc0-4e50-8c28-36aa522f9545', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'promote_partner', shopId, promotionType: 'facebook_platform', customMessage })
        });
        const result = await response.json();
        if (result.success) {
          toast({ title: "Partner Promoted!", description: "Shop promotion posted to MarketPace Facebook page" });
        }
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to promote", variant: "destructive" });
    } finally {
      setIsPromoting(false);
    }
  };

  return (
    <Card className="w-full max-w-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Facebook className="h-5 w-5 text-blue-600" />
          {userType === 'member' ? 'Promote Your Product' : 'Promote Partner Shop'}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {userType === 'member' && product && (
          <div className="space-y-2">
            <p className="font-medium">{product.title} - ${product.price}</p>
            <p className="text-sm text-muted-foreground">{product.shopName}</p>
          </div>
        )}
        
        <div>
          <Textarea
            placeholder="Add your custom message..."
            value={customMessage}
            onChange={(e) => setCustomMessage(e.target.value)}
          />
        </div>
        
        <Button onClick={handlePromotion} disabled={isPromoting} className="w-full bg-blue-600 hover:bg-blue-700">
          <Share2 className="h-4 w-4 mr-2" />
          {isPromoting ? 'Promoting...' : userType === 'member' ? 'Share on Facebook' : 'Promote Partner'}
        </Button>
      </CardContent>
    </Card>
  );
};