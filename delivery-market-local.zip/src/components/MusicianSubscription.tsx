import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, Star, Zap, Bell, Share2, Calendar, Users } from 'lucide-react';
import { useState } from 'react';

const MusicianSubscription = () => {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubscribed(true);
      setLoading(false);
    }, 2000);
  };

  const features = [
    {
      icon: <Share2 className="w-5 h-5" />,
      title: 'Social Media Integration',
      description: 'Connect and auto-post to Facebook, Instagram, Twitter, and TikTok'
    },
    {
      icon: <Bell className="w-5 h-5" />,
      title: 'Fan Notifications',
      description: 'Automatically notify local fans when you release new music'
    },
    {
      icon: <Calendar className="w-5 h-5" />,
      title: 'Event Promotion',
      description: 'Send event notifications to followers in your area'
    },
    {
      icon: <Users className="w-5 h-5" />,
      title: 'Advanced Analytics',
      description: 'Track fan engagement and reach across all platforms'
    },
    {
      icon: <Zap className="w-5 h-5" />,
      title: 'Priority Support',
      description: 'Get priority customer support and feature requests'
    },
    {
      icon: <Star className="w-5 h-5" />,
      title: 'Verified Badge',
      description: 'Get a verified musician badge on your profile'
    }
  ];

  if (isSubscribed) {
    return (
      <Card className="bg-gradient-to-r from-green-50 to-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-700">
            <Check className="w-6 h-6" />
            Pro Musician - Active
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span>Next billing date:</span>
              <span className="font-medium">January 15, 2025</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Monthly cost:</span>
              <span className="font-medium">$10.00</span>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-6">
              <Button variant="outline">
                Manage Subscription
              </Button>
              <Button variant="outline">
                View Analytics
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Star className="w-6 h-6 text-purple-600" />
              Upgrade to Pro Musician
            </CardTitle>
            <Badge className="bg-purple-600 text-white">
              $10/month
            </Badge>
          </div>
          <p className="text-gray-600">
            Supercharge your music career with advanced tools and integrations
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="text-purple-600 mt-1">
                    {feature.icon}
                  </div>
                  <div>
                    <h4 className="font-medium">{feature.title}</h4>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-yellow-50 rounded-lg">
              <h4 className="font-medium text-yellow-800 mb-2">🎵 Special Launch Offer</h4>
              <p className="text-sm text-yellow-700">
                Get your first month free! Cancel anytime. No setup fees.
              </p>
            </div>

            <Button 
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              onClick={handleSubscribe}
              disabled={loading}
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Processing...
                </div>
              ) : (
                <>Start Free Trial - $10/month after</>  
              )}
            </Button>
            
            <p className="text-xs text-gray-500 text-center">
              By subscribing, you agree to our Terms of Service and Privacy Policy.
              Cancel anytime from your account settings.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>What Pro Musicians Say</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="border-l-4 border-purple-500 pl-4">
              <p className="text-sm italic">
                "The social media integration saved me hours every week. My fan engagement has doubled!"
              </p>
              <p className="text-xs text-gray-600 mt-2">- Sarah Chen, Indie Folk Artist</p>
            </div>
            <div className="border-l-4 border-purple-500 pl-4">
              <p className="text-sm italic">
                "Event notifications brought 50% more people to my last show. Worth every penny."
              </p>
              <p className="text-xs text-gray-600 mt-2">- The Midnight Blues, Blues Rock Band</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MusicianSubscription;