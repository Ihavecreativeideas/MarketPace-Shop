import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, DollarSign, Package, Users, Brain, Target } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AnalyticsData {
  revenue: { current: number; previous: number; trend: number };
  orders: { current: number; previous: number; trend: number };
  customers: { current: number; previous: number; trend: number };
  avgOrderValue: { current: number; previous: number; trend: number };
}

interface AIInsight {
  id: string;
  type: 'recommendation' | 'alert' | 'opportunity';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  action?: string;
}

export default function BusinessAnalytics({ businessId }: { businessId: string }) {
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    revenue: { current: 0, previous: 0, trend: 0 },
    orders: { current: 0, previous: 0, trend: 0 },
    customers: { current: 0, previous: 0, trend: 0 },
    avgOrderValue: { current: 0, previous: 0, trend: 0 }
  });
  const [aiInsights, setAIInsights] = useState<AIInsight[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
    fetchAIInsights();
  }, [businessId]);

  const fetchAnalytics = async () => {
    try {
      // Mock data for demo
      setAnalytics({
        revenue: { current: 15420, previous: 12850, trend: 20 },
        orders: { current: 156, previous: 142, trend: 9.9 },
        customers: { current: 89, previous: 76, trend: 17.1 },
        avgOrderValue: { current: 98.85, previous: 90.49, trend: 9.2 }
      });
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAIInsights = async () => {
    try {
      // Mock AI insights
      setAIInsights([
        {
          id: '1',
          type: 'opportunity',
          title: 'Peak Hour Optimization',
          description: 'Your busiest hours are 12-2 PM and 6-8 PM. Consider offering lunch specials and dinner combos.',
          impact: 'high',
          action: 'Create targeted promotions'
        },
        {
          id: '2',
          type: 'recommendation',
          title: 'Inventory Alert',
          description: 'Popular items are running low. Restock recommended: Chicken Sandwich, Fries, Soda.',
          impact: 'medium',
          action: 'Update inventory'
        },
        {
          id: '3',
          type: 'alert',
          title: 'Customer Retention',
          description: 'Customer repeat rate decreased by 5%. Consider loyalty program or follow-up campaigns.',
          impact: 'high',
          action: 'Launch retention campaign'
        }
      ]);
    } catch (error) {
      console.error('Error fetching AI insights:', error);
    }
  };

  const MetricCard = ({ title, icon: Icon, data }: { title: string; icon: any; data: any }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">
          {title.includes('Revenue') || title.includes('Value') ? '$' : ''}
          {data.current.toLocaleString()}
        </div>
        <div className="flex items-center text-xs text-muted-foreground">
          <TrendingUp className={`mr-1 h-3 w-3 ${
            data.trend > 0 ? 'text-green-500' : 'text-red-500'
          }`} />
          <span className={data.trend > 0 ? 'text-green-500' : 'text-red-500'}>
            {data.trend > 0 ? '+' : ''}{data.trend.toFixed(1)}%
          </span>
          <span className="ml-1">from last period</span>
        </div>
      </CardContent>
    </Card>
  );

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'opportunity': return <Target className="h-4 w-4" />;
      case 'recommendation': return <Brain className="h-4 w-4" />;
      case 'alert': return <TrendingUp className="h-4 w-4" />;
      default: return <Brain className="h-4 w-4" />;
    }
  };

  if (loading) {
    return <div className="p-6">Loading analytics...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Analytics & AI Insights</h1>
        <Button variant="outline">
          <Brain className="mr-2 h-4 w-4" />
          Generate Report
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard title="Total Revenue" icon={DollarSign} data={analytics.revenue} />
        <MetricCard title="Total Orders" icon={Package} data={analytics.orders} />
        <MetricCard title="New Customers" icon={Users} data={analytics.customers} />
        <MetricCard title="Avg Order Value" icon={TrendingUp} data={analytics.avgOrderValue} />
      </div>

      <Tabs defaultValue="insights" className="space-y-4">
        <TabsList>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="predictions">Predictions</TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                AI-Powered Insights
              </CardTitle>
              <CardDescription>
                Personalized recommendations to grow your business
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {aiInsights.map((insight) => (
                <div key={insight.id} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {getTypeIcon(insight.type)}
                      <h3 className="font-semibold">{insight.title}</h3>
                    </div>
                    <Badge className={getImpactColor(insight.impact)}>
                      {insight.impact} impact
                    </Badge>
                  </div>
                  <p className="text-gray-600 mb-3">{insight.description}</p>
                  {insight.action && (
                    <Button size="sm" variant="outline">
                      {insight.action}
                    </Button>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance">
          <Card>
            <CardHeader>
              <CardTitle>Performance Metrics</CardTitle>
              <CardDescription>Detailed performance analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Performance charts and detailed metrics coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="predictions">
          <Card>
            <CardHeader>
              <CardTitle>AI Predictions</CardTitle>
              <CardDescription>Forecast and trend analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <p>AI-powered predictions and forecasting coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}