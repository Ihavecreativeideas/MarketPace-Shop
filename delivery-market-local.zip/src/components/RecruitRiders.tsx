import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Bike, Share2, Users, MapPin, Clock, DollarSign } from 'lucide-react';
import ShareableFlyerComponent from './ShareableFlyerComponent';

const RecruitRiders: React.FC = () => {
  const handleFacebookShare = () => {
    const jobUrl = encodeURIComponent(`${window.location.origin}/driver-job`);
    const shareText = encodeURIComponent(
      "🚗 MarketPace: Delivering Opportunities to a town near you! Apply to become a driver today! Flexible hours, competitive pay, and the chance to support your local community. #DeliveryJobs #FlexibleWork #MarketPace"
    );
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${jobUrl}&quote=${shareText}`;
    window.open(facebookUrl, '_blank', 'width=600,height=400');
  };

  const handleApplyNow = () => {
    window.location.href = '/driver-job';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-green-100 rounded-full px-6 py-2 mb-6">
            <Bike className="h-5 w-5 text-green-600" />
            <span className="font-semibold text-green-800">Driver Recruitment</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Help Us Find Amazing Drivers!
          </h1>
          <p className="text-xl text-gray-600">
            Share this opportunity with people in your community who would make great delivery drivers
          </p>
        </div>

        {/* Shareable Flyer */}
        <Card className="mb-8 shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-blue-600 mb-4">
              Share Driver Opportunities
            </CardTitle>
            <p className="text-gray-600">
              Know someone who would be perfect for flexible delivery work? Share this bright flyer!
            </p>
          </CardHeader>
          <CardContent className="text-center">
            <div className="mb-6">
              <ShareableFlyerComponent 
                onApplyNow={handleApplyNow}
                onShare={handleFacebookShare}
              />
            </div>
          </CardContent>
        </Card>

        {/* What We're Looking For */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-xl text-gray-900">
              What We're Looking For in Drivers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3 text-gray-900">Requirements:</h4>
                <ul className="space-y-2 text-gray-600">
                  <li>• Valid driver's license and insurance</li>
                  <li>• Clean background check</li>
                  <li>• Reliable vehicle</li>
                  <li>• Smartphone for app usage</li>
                  <li>• 18+ years old</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-3 text-gray-900">Ideal Candidates:</h4>
                <ul className="space-y-2 text-gray-600">
                  <li>• Friendly and professional</li>
                  <li>• Reliable and punctual</li>
                  <li>• Enjoys helping their community</li>
                  <li>• Wants flexible work schedule</li>
                  <li>• Values local businesses</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Call to Action */}
        <div className="text-center">
          <Card className="bg-gradient-to-r from-green-500 to-blue-500 text-white">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-4">
                Know Someone Perfect for This?
              </h2>
              <p className="text-lg mb-6 opacity-90">
                Help them discover a flexible opportunity that makes a real difference in your community!
              </p>
              <Button 
                onClick={() => window.location.href = '/driver-job'}
                size="lg"
                className="bg-white text-green-600 hover:bg-gray-100 mr-4"
              >
                View Full Job Description
              </Button>
              <Button 
                onClick={handleFacebookShare}
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-green-600"
              >
                <Share2 className="h-5 w-5 mr-2" />
                Share Now
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default RecruitRiders;