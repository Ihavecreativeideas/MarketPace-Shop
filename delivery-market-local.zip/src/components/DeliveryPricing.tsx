import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calculator, Truck, Store, CreditCard, Crown, Gift } from 'lucide-react';

const DeliveryPricing: React.FC = () => {
  const calculateDeliveryPrice = (miles: number, partnerTier: 'none' | 'silver' | 'gold' | 'platinum' = 'none') => {
    // New simplified pricing structure for beta testing
    const driverPay = miles * 1.50; // Driver gets $1.50 per mile
    const processingFee = 1.50; // Fixed $1.50 processing fee
    const buyerShare = processingFee / 2; // $0.75
    const sellerShare = processingFee / 2; // $0.75
    
    return {
      driverPay,
      processingFee,
      buyerShare,
      sellerShare,
      total: driverPay + processingFee,
      partnerTier,
      savings: 0 // No delivery fees during beta
    };
  };

  const examples = [
    { 
      miles: 2, 
      pricing: calculateDeliveryPrice(2)
    },
    { 
      miles: 5, 
      pricing: calculateDeliveryPrice(5)
    },
    { 
      miles: 10, 
      pricing: calculateDeliveryPrice(10)
    }
  ];

  return (
    <div className="space-y-6">
      <Card className="border-2 border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <Gift className="w-5 h-5" />
            🚀 Beta Testing Pricing - FREE Delivery Fees!
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-white p-4 rounded-lg border border-green-200 mb-4">
            <h3 className="font-bold text-lg mb-2 text-green-800">Temporary App Testing Pricing</h3>
            <div className="space-y-2 text-sm">
              <p className="text-green-700">✅ <strong>NO delivery fees</strong> during beta testing</p>
              <p className="text-green-700">✅ Customers only pay driver + small processing fee</p>
              <p className="text-green-700">✅ Early supporters get lifetime benefits!</p>
              <p className="text-orange-600 font-medium">⚡ Take advantage of early sign up pricing!</p>
            </div>
          </div>
          
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <h4 className="font-semibold mb-3 text-blue-800">Simple Beta Pricing Structure:</h4>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center p-3 bg-white rounded-lg">
                <Truck className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                <h5 className="font-medium">Driver Pay</h5>
                <p className="text-sm text-gray-600">$1.50 per mile</p>
              </div>
              <div className="text-center p-3 bg-white rounded-lg">
                <CreditCard className="w-8 h-8 mx-auto mb-2 text-green-600" />
                <h5 className="font-medium">Processing Fee</h5>
                <p className="text-sm text-gray-600">$1.50 total</p>
              </div>
              <div className="text-center p-3 bg-white rounded-lg">
                <Store className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                <h5 className="font-medium">Split Fee</h5>
                <p className="text-sm text-gray-600">$0.75 buyer + $0.75 seller</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Beta Testing Delivery Examples
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {examples.map((example, index) => (
              <div key={index} className="border rounded-lg p-4 bg-gradient-to-r from-green-50 to-blue-50">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-medium text-lg">{example.miles} miles delivery</span>
                  <Badge className="bg-green-600 text-white">
                    Total: ${example.pricing.total.toFixed(2)}
                  </Badge>
                </div>
                <div className="grid md:grid-cols-3 gap-3">
                  <div className="bg-white p-3 rounded-lg text-center">
                    <div className="text-lg font-bold text-blue-600">
                      ${example.pricing.driverPay.toFixed(2)}
                    </div>
                    <div className="text-sm text-gray-600">Driver Pay</div>
                  </div>
                  
                  <div className="bg-white p-3 rounded-lg text-center">
                    <div className="text-lg font-bold text-orange-600">
                      ${example.pricing.buyerShare.toFixed(2)}
                    </div>
                    <div className="text-sm text-gray-600">Buyer Pays</div>
                    <div className="text-xs text-gray-500">(processing fee)</div>
                  </div>
                  
                  <div className="bg-white p-3 rounded-lg text-center">
                    <div className="text-lg font-bold text-purple-600">
                      ${example.pricing.sellerShare.toFixed(2)}
                    </div>
                    <div className="text-sm text-gray-600">Seller Pays</div>
                    <div className="text-xs text-gray-500">(processing fee)</div>
                  </div>
                </div>
                
                <div className="mt-3 p-2 bg-yellow-100 rounded text-center">
                  <span className="text-sm font-medium text-yellow-800">
                    🎉 NO delivery fees during beta! Regular pricing would be ${(example.miles * 2.5 + 8).toFixed(2)}
                  </span>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg border border-yellow-200">
            <h4 className="font-bold text-yellow-800 mb-2">⚡ Limited Time Beta Benefits:</h4>
            <ul className="text-sm text-yellow-700 space-y-1">
              <li>• Zero delivery fees (normally $8-15 base fee)</li>
              <li>• Zero mileage fees (normally $1.25+ per mile)</li>
              <li>• Zero sustainability fees (normally $4)</li>
              <li>• Early supporters get lifetime discounts when we launch!</li>
              <li>• Help us perfect the app and get rewarded for it!</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DeliveryPricing;