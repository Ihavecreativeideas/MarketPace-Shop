import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Share2 } from 'lucide-react';

interface WhatNotItem {
  id: string;
  title: string;
  price: number;
  image: string;
  seller: string;
}

export const WhatNotIntegration: React.FC = () => {
  const [connected, setConnected] = useState(false);
  const [items, setItems] = useState<WhatNotItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  const connectToWhatNot = async () => {
    // Simulate API connection
    setConnected(true);
    // Mock data for demonstration
    setItems([
      {
        id: '1',
        title: 'Vintage Guitar Pedal',
        price: 150,
        image: '/placeholder.svg',
        seller: 'MusicGear_Pro'
      },
      {
        id: '2',
        title: 'Rare Vinyl Collection',
        price: 300,
        image: '/placeholder.svg',
        seller: 'VinylCollector'
      }
    ]);
  };

  const shareToMarketPace = (item: WhatNotItem) => {
    // Integration logic to share WhatNot items to MarketPace
    console.log('Sharing to MarketPace:', item);
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <span className="text-purple-600">WhatNot</span>
          <Badge variant="secondary">Integration</Badge>
        </CardTitle>
        <CardDescription>
          Connect your WhatNot account to cross-list items on MarketPace
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!connected ? (
          <div className="text-center py-8">
            <p className="mb-4 text-gray-600">
              Connect your WhatNot account to sync your listings
            </p>
            <Button onClick={connectToWhatNot} className="bg-purple-600 hover:bg-purple-700">
              <ExternalLink className="w-4 h-4 mr-2" />
              Connect WhatNot Account
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Search your WhatNot items..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Button variant="outline">Search</Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {items.map((item) => (
                <div key={item.id} className="border rounded-lg p-4">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-32 object-cover rounded mb-2"
                  />
                  <h3 className="font-semibold">{item.title}</h3>
                  <p className="text-green-600 font-bold">${item.price}</p>
                  <p className="text-sm text-gray-500">by {item.seller}</p>
                  <Button
                    onClick={() => shareToMarketPace(item)}
                    className="mt-2 w-full"
                    size="sm"
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Share to MarketPace
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};