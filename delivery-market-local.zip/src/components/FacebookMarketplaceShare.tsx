import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Facebook, Truck, MapPin, Clock, CheckCircle } from 'lucide-react';
import DeliverNowButton from './DeliverNowButton';

interface FacebookMarketplaceShareProps {
  product: {
    id: number;
    name: string;
    price: string;
    image: string;
    description?: string;
  };
}

const FacebookMarketplaceShare: React.FC<FacebookMarketplaceShareProps> = ({ product }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [shareData, setShareData] = useState({
    title: product.name,
    description: product.description || `${product.name} - Available for delivery`,
    price: product.price,
    location: '',
    category: 'Other'
  });
  const [isSharing, setIsSharing] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);

  const handleShare = async () => {
    setIsSharing(true);
    
    try {
      const marketplaceData = {
        title: shareData.title,
        description: shareData.description + '\n\n🚚 DELIVER NOW AVAILABLE - Fast delivery to your door!',
        price: shareData.price,
        location: shareData.location,
        category: shareData.category,
        images: [product.image],
        delivery_available: true,
        delivery_note: 'Fast delivery service available through MarketPace'
      };

      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/2b8690f4-56b4-45f5-93c4-7d3f7860ae05',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            action: 'create_marketplace_listing',
            data: marketplaceData
          })
        }
      );

      if (response.ok) {
        const result = await response.json();
        
        // Create Facebook Marketplace URL with Deliver Now integration
        const deliverNowText = encodeURIComponent('🚚 DELIVER NOW AVAILABLE - Contact seller for fast delivery!');
        const fbDescription = encodeURIComponent(shareData.description + '\n\n' + deliverNowText);
        
        const fbUrl = `https://www.facebook.com/marketplace/create/item?title=${encodeURIComponent(shareData.title)}&description=${fbDescription}&price=${encodeURIComponent(shareData.price)}&location=${encodeURIComponent(shareData.location)}`;
        
        // Try Facebook app first, then web
        const fbAppUrl = `fb://marketplace/create?title=${encodeURIComponent(shareData.title)}&description=${fbDescription}`;
        
        try {
          window.location.href = fbAppUrl;
          setTimeout(() => {
            window.open(fbUrl, '_blank');
          }, 1000);
        } catch {
          window.open(fbUrl, '_blank');
        }
        
        setShareSuccess(true);
        setTimeout(() => {
          setIsOpen(false);
          setShareSuccess(false);
        }, 2000);
      } else {
        throw new Error('Failed to create listing');
      }
    } catch (error) {
      console.error('Error sharing to Facebook Marketplace:', error);
      // Fallback to direct Facebook sharing
      const deliverNowText = encodeURIComponent('🚚 DELIVER NOW AVAILABLE - Contact seller for fast delivery!');
      const fbDescription = encodeURIComponent(shareData.description + '\n\n' + deliverNowText);
      const fbUrl = `https://www.facebook.com/marketplace/create/item?title=${encodeURIComponent(shareData.title)}&description=${fbDescription}&price=${encodeURIComponent(shareData.price)}`;
      window.open(fbUrl, '_blank');
      setIsOpen(false);
    } finally {
      setIsSharing(false);
    }
  };

  const handleDeliveryRequest = (productId: number) => {
    console.log('Delivery requested for product:', productId);
  };

  if (shareSuccess) {
    return (
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            <Facebook className="w-4 h-4 mr-2" />
            Share to Facebook Marketplace
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-md">
          <div className="text-center py-8">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-green-700 mb-2">Successfully Shared!</h3>
            <p className="text-sm text-gray-600">Your item has been shared to Facebook Marketplace with Deliver Now integration.</p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
          <Facebook className="w-4 h-4 mr-2" />
          Share to Facebook Marketplace
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Facebook className="w-5 h-5 text-blue-600" />
            Share to Facebook Marketplace
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Product Preview */}
          <Card>
            <CardContent className="p-3">
              <div className="flex gap-3">
                <img src={product.image} alt={product.name} className="w-16 h-16 object-cover rounded" />
                <div className="flex-1">
                  <h4 className="font-medium text-sm">{product.name}</h4>
                  <p className="text-green-600 font-semibold">{product.price}</p>
                  <div className="flex gap-2 mt-1">
                    <Badge className="bg-blue-100 text-blue-700 text-xs">
                      <Truck className="w-3 h-3 mr-1" />
                      Deliver Now
                    </Badge>
                    <DeliverNowButton 
                      productId={product.id}
                      productName={product.name}
                      price={product.price}
                      onDeliveryRequest={handleDeliveryRequest}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Share Form */}
          <div className="space-y-3">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={shareData.title}
                onChange={(e) => setShareData({...shareData, title: e.target.value})}
              />
            </div>
            
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={shareData.description}
                onChange={(e) => setShareData({...shareData, description: e.target.value})}
                rows={3}
              />
            </div>
            
            <div>
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                placeholder="Enter your location"
                value={shareData.location}
                onChange={(e) => setShareData({...shareData, location: e.target.value})}
              />
            </div>
          </div>

          {/* Delivery Info */}
          <div className="bg-green-50 p-3 rounded-lg border border-green-200">
            <div className="flex items-center gap-2 text-green-700 mb-2">
              <Truck className="w-4 h-4" />
              <span className="font-medium text-sm">Deliver Now Integration</span>
            </div>
            <div className="text-xs text-green-600 space-y-1">
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>Fast delivery available to buyers</span>
              </div>
              <div className="flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                <span>Door-to-door service included</span>
              </div>
              <p className="mt-2 text-xs">Buyers will see a "Deliver Now" button on your Facebook listing!</p>
            </div>
          </div>

          <Button 
            onClick={handleShare} 
            disabled={isSharing || !shareData.location}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {isSharing ? 'Sharing...' : 'Share with Deliver Now Button'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default FacebookMarketplaceShare;