import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calculator } from 'lucide-react';

interface Product {
  id: number;
  name: string;
  price: string;
  shop: string;
  platform: 'etsy' | 'tiktok' | 'local' | 'other';
  rating: number;
  image: string;
  images?: string[];
  deliveryType: 'local' | 'extended';
  isPartnerShop: boolean;
  partnerBenefits?: string[];
  description?: string;
  createdAt?: string;
}

interface CounterOfferModalProps {
  product: Product;
  onClose: () => void;
}

const CounterOfferModal: React.FC<CounterOfferModalProps> = ({
  product,
  onClose
}) => {
  const [selectedDiscount, setSelectedDiscount] = useState<number | null>(null);
  
  const originalPrice = parseFloat(product.price.replace('$', ''));
  const discountOptions = [10, 20, 30, 40, 50];
  
  const calculateDiscountedPrice = (discount: number) => {
    return originalPrice * (1 - discount / 100);
  };
  
  const handleSubmit = () => {
    if (selectedDiscount) {
      const newPrice = calculateDiscountedPrice(selectedDiscount);
      console.log(`Counter offer submitted: ${selectedDiscount}% off, new price: $${newPrice.toFixed(2)}`);
      onClose();
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Counter Offer
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <h4 className="font-medium mb-1">{product.name}</h4>
            <p className="text-sm text-gray-600">Original Price: {product.price}</p>
            <p className="text-sm text-gray-500">Shop: {product.shop}</p>
          </div>
          
          <div className="space-y-3">
            <p className="text-sm font-medium">Select your offer (fixed discount options):</p>
            {discountOptions.map((discount) => {
              const discountedPrice = calculateDiscountedPrice(discount);
              return (
                <div
                  key={discount}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedDiscount === discount
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedDiscount(discount)}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <Badge variant="outline" className="text-orange-600 border-orange-300">
                        {discount}% cheaper
                      </Badge>
                      <p className="text-sm text-gray-600 mt-1">
                        Save ${(originalPrice - discountedPrice).toFixed(2)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-600">
                        ${discountedPrice.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={handleSubmit} 
              disabled={!selectedDiscount}
              className="flex-1 bg-orange-600 hover:bg-orange-700"
            >
              Submit Counter Offer
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CounterOfferModal;