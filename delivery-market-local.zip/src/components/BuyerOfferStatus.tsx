import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CounterOffer {
  id: string;
  product_id: string;
  product_title: string;
  original_price: number;
  buyer_offer_price: number;
  buyer_discount_percent: number;
  seller_counter_price?: number;
  seller_counter_percent?: number;
  status: string;
  seller_id: string;
  created_at: string;
  expires_at?: string;
}

interface BuyerOfferStatusProps {
  buyerId: string;
}

const BuyerOfferStatus: React.FC<BuyerOfferStatusProps> = ({ buyerId }) => {
  const [offers, setOffers] = useState<CounterOffer[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchOffers = async () => {
    try {
      const response = await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/8c8c05c5-276b-4a02-9305-2c694df852cf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'get_buyer_offers', buyerId })
      });
      const data = await response.json();
      setOffers(data || []);
    } catch (error) {
      console.error('Error fetching offers:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOffers();
    const interval = setInterval(fetchOffers, 30000);
    return () => clearInterval(interval);
  }, [buyerId]);

  const handleAcceptCounterOffer = async (offerId: string, price: number) => {
    try {
      await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/8c8c05c5-276b-4a02-9305-2c694df852cf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'buyer_accept_counter',
          offerId,
          finalPrice: price
        })
      });
      
      toast({ title: 'Purchase completed!', description: `Item purchased for $${price}` });
      fetchOffers();
    } catch (error) {
      toast({ title: 'Error processing purchase', variant: 'destructive' });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'accepted':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'denied':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'seller_countered':
        return <AlertCircle className="w-4 h-4 text-blue-500" />;
      case 'purchased':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Waiting for seller response';
      case 'accepted': return 'Offer accepted - Payment processed';
      case 'denied': return 'Offer denied by seller';
      case 'seller_countered': return 'Seller made counter offer';
      case 'purchased': return 'Item purchased';
      default: return status;
    }
  };

  const isExpired = (expiresAt?: string) => {
    if (!expiresAt) return false;
    return new Date(expiresAt) < new Date();
  };

  if (loading) return <div className="p-4">Loading your offers...</div>;

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Your Offers</h2>
      
      {offers.length === 0 ? (
        <Card>
          <CardContent className="p-6 text-center text-gray-500">
            No offers made yet
          </CardContent>
        </Card>
      ) : (
        offers.map((offer) => {
          const expired = isExpired(offer.expires_at);
          return (
            <Card key={offer.id} className={`${offer.status === 'seller_countered' && !expired ? 'border-l-4 border-l-blue-500' : ''}`}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{offer.product_title}</span>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(offer.status)}
                    <Badge variant={offer.status === 'accepted' || offer.status === 'purchased' ? 'default' : 'secondary'}>
                      {getStatusText(offer.status)}
                    </Badge>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Original Price:</p>
                    <p className="font-semibold">${offer.original_price}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Your Offer:</p>
                    <p className="font-semibold">${offer.buyer_offer_price}</p>
                  </div>
                  {offer.seller_counter_price && (
                    <div>
                      <p className="text-gray-600">Seller's Counter:</p>
                      <p className="font-semibold text-blue-600">${offer.seller_counter_price}</p>
                    </div>
                  )}
                </div>
                
                {offer.status === 'seller_countered' && !expired && (
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm text-blue-800 mb-3">
                      Seller countered with ${offer.seller_counter_price}. This offer expires in 24 hours.
                    </p>
                    <Button
                      onClick={() => handleAcceptCounterOffer(offer.id, offer.seller_counter_price!)}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      Accept & Purchase for ${offer.seller_counter_price}
                    </Button>
                  </div>
                )}
                
                {offer.status === 'seller_countered' && expired && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-600">This counter offer has expired.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })
      )}
    </div>
  );
};

export default BuyerOfferStatus;