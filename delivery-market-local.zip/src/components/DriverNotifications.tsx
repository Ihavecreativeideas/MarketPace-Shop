import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, Truck, MapPin, CheckCircle, Package } from 'lucide-react';

interface Notification {
  id: string;
  orderId: string;
  type: 'pickup_ready' | 'delivery_complete' | 'large_item_delivery';
  message: string;
  itemSize: 'small' | 'medium' | 'large';
  requiresTruck: boolean;
  deliveryFee: number;
  timestamp: Date;
  read: boolean;
}

interface DriverNotificationsProps {
  driverId: string;
  hasTruckTrailer?: boolean;
}

const DriverNotifications: React.FC<DriverNotificationsProps> = ({ driverId, hasTruckTrailer = false }) => {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      orderId: 'MP-001',
      type: 'pickup_ready',
      message: 'iPhone 13 Pro ready for pickup at 123 Main St',
      itemSize: 'small',
      requiresTruck: false,
      deliveryFee: 40,
      timestamp: new Date(),
      read: false
    },
    {
      id: '2',
      orderId: 'MP-002',
      type: 'large_item_delivery',
      message: 'Large furniture delivery - Truck Required at 456 Oak Ave',
      itemSize: 'large',
      requiresTruck: true,
      deliveryFee: 40, // Driver gets $40 flat for large items
      timestamp: new Date(Date.now() - 300000),
      read: false
    }
  ]);

  // Filter notifications based on driver capabilities
  const filteredNotifications = notifications.filter(notification => {
    if (notification.requiresTruck && !hasTruckTrailer) {
      return false; // Don't show large item deliveries to drivers without trucks
    }
    return true;
  });

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const acceptDelivery = async (orderId: string, deliveryFee: number) => {
    try {
      await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/5b1eb5b8-56ac-4df6-94b9-bf46d78d9046', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'accept_delivery',
          order_id: orderId,
          driver_id: driverId,
          driver_fee: deliveryFee
        })
      });
    } catch (error) {
      console.error('Failed to accept delivery:', error);
    }
  };

  const sendInRouteNotification = async (orderId: string) => {
    try {
      await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/5b1eb5b8-56ac-4df6-94b9-bf46d78d9046', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update_status',
          order_id: orderId,
          status: 'in_route',
          driver_id: driverId
        })
      });
    } catch (error) {
      console.error('Failed to update status:', error);
    }
  };

  const sendDeliveredNotification = async (orderId: string) => {
    try {
      await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/5b1eb5b8-56ac-4df6-94b9-bf46d78d9046', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update_status',
          order_id: orderId,
          status: 'delivered',
          driver_id: driverId
        })
      });
    } catch (error) {
      console.error('Failed to update status:', error);
    }
  };

  const getSizeColor = (size: string) => {
    switch (size) {
      case 'small': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'large': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Driver Notifications
            {hasTruckTrailer && (
              <Badge variant="outline" className="ml-2">
                <Truck className="w-3 h-3 mr-1" />
                Truck Capable
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredNotifications.length === 0 ? (
            <p className="text-gray-500 text-center py-4">
              {hasTruckTrailer ? 'No delivery notifications' : 'No notifications (Large item deliveries require truck capability)'}
            </p>
          ) : (
            <div className="space-y-3">
              {filteredNotifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 rounded-lg border ${
                    notification.read ? 'bg-gray-50' : notification.requiresTruck ? 'bg-orange-50 border-orange-200' : 'bg-blue-50 border-blue-200'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex gap-2">
                      <Badge variant="outline">Order #{notification.orderId}</Badge>
                      <Badge className={getSizeColor(notification.itemSize)}>
                        {notification.itemSize.toUpperCase()}
                      </Badge>
                      {notification.requiresTruck && (
                        <Badge variant="destructive" className="flex items-center gap-1">
                          <Truck className="w-3 h-3" />
                          Truck Required
                        </Badge>
                      )}
                    </div>
                    {!notification.read && (
                      <Badge variant="default" className="bg-blue-500">New</Badge>
                    )}
                  </div>
                  
                  <p className="text-sm mb-2">{notification.message}</p>
                  
                  <div className="bg-green-50 p-2 rounded mb-3">
                    <p className="text-sm font-medium text-green-800">
                      💰 Your Earnings: $40 flat rate
                    </p>
                    <p className="text-xs text-green-600">+ Customer tips (100% to you)</p>
                    {notification.requiresTruck && (
                      <p className="text-xs text-orange-600 mt-1">
                        ⚠️ Must have truck/trailer and be prepared to load items
                      </p>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => {
                        acceptDelivery(notification.orderId, 40);
                        markAsRead(notification.id);
                      }}
                      className="flex items-center gap-1 bg-green-600 hover:bg-green-700"
                    >
                      <Package className="w-3 h-3" />
                      Accept Delivery
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => {
                        sendInRouteNotification(notification.orderId);
                        markAsRead(notification.id);
                      }}
                      className="flex items-center gap-1"
                    >
                      <Truck className="w-3 h-3" />
                      Mark In Route
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        sendDeliveredNotification(notification.orderId);
                        markAsRead(notification.id);
                      }}
                      className="flex items-center gap-1"
                    >
                      <CheckCircle className="w-3 h-3" />
                      Mark Delivered
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default DriverNotifications;