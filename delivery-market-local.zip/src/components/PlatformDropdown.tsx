import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { ChevronDown, Home, Store, Package, Pill, Music, Truck, Users, Smartphone, UserPlus, Facebook, BarChart3 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PlatformDropdown = () => {
  const navigate = useNavigate();

  const handleNavigation = (path: string) => {
    navigate(path);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2 text-blue-600 hover:text-blue-700">
          Navigate Platform
          <ChevronDown className="w-4 h-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56">
        <DropdownMenuItem onClick={() => handleNavigation('/')}>
          <Home className="w-4 h-4 mr-2" />
          Home
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleNavigation('/marketplace')}>
          <Store className="w-4 h-4 mr-2" />
          Marketplace
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleNavigation('/musicians')}>
          <Music className="w-4 h-4 mr-2" />
          Musicians
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => handleNavigation('/postpace')}>
          <Package className="w-4 h-4 mr-2" />
          PostPace
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleNavigation('/medpace')}>
          <Pill className="w-4 h-4 mr-2" />
          MedPace
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => handleNavigation('/vendor-partnership')}>
          <Users className="w-4 h-4 mr-2" />
          Partner Tiers
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleNavigation('/vendor-dashboard')}>
          <BarChart3 className="w-4 h-4 mr-2" />
          Vendor Dashboard
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleNavigation('/promotions')}>
          <Facebook className="w-4 h-4 mr-2" />
          Promotions
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => handleNavigation('/driver-job')}>
          <Truck className="w-4 h-4 mr-2" />
          Driver Jobs
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleNavigation('/recruit-shops')}>
          <Store className="w-4 h-4 mr-2" />
          Recruit Shops
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleNavigation('/recruit-riders')}>
          <Package className="w-4 h-4 mr-2" />
          Recruit Riders
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => handleNavigation('/ios')}>
          <Smartphone className="w-4 h-4 mr-2" />
          iOS App
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleNavigation('/invite')}>
          <UserPlus className="w-4 h-4 mr-2" />
          Invite Friends
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default PlatformDropdown;