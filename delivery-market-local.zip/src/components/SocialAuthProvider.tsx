import React from 'react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';

interface SocialAuthProviderProps {
  onSuccess?: () => void;
}

export const SocialAuthProvider: React.FC<SocialAuthProviderProps> = ({ onSuccess }) => {
  const signInWithProvider = async (provider: 'google' | 'facebook' | 'apple') => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: window.location.origin
        }
      });
      if (error) throw error;
      onSuccess?.();
    } catch (error) {
      console.error(`Error signing in with ${provider}:`, error);
    }
  };

  return (
    <div className="space-y-3">
      <Button
        onClick={() => signInWithProvider('google')}
        variant="outline"
        className="w-full flex items-center gap-2"
      >
        <svg className="w-5 h-5" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
        Continue with Google
      </Button>
      
      <Button
        onClick={() => signInWithProvider('facebook')}
        variant="outline"
        className="w-full flex items-center gap-2 bg-blue-600 text-white hover:bg-blue-700"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
        Continue with Facebook
      </Button>
      
      <Button
        onClick={() => signInWithProvider('apple')}
        variant="outline"
        className="w-full flex items-center gap-2 bg-black text-white hover:bg-gray-800"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12.017 0C8.396 0 8.025.044 6.77.207 5.518.37 4.672.64 3.97 1.007c-.72.375-1.33.875-1.94 1.486C1.42 3.103.92 3.713.545 4.433.178 5.135-.092 5.981-.255 7.233-.418 8.488-.462 8.859-.462 12.48s.044 3.992.207 5.247c.163 1.252.433 2.098.8 2.8.375.72.875 1.33 1.486 1.94.61.61 1.22 1.11 1.94 1.486.702.367 1.548.637 2.8.8 1.255.163 1.626.207 5.247.207s3.992-.044 5.247-.207c1.252-.163 2.098-.433 2.8-.8.72-.375 1.33-.875 1.94-1.486.61-.61 1.11-1.22 1.486-1.94.367-.702.637-1.548.8-2.8.163-1.255.207-1.626.207-5.247s-.044-3.992-.207-5.247c-.163-1.252-.433-2.098-.8-2.8-.375-.72-.875-1.33-1.486-1.94C20.897 1.42 20.287.92 19.567.545 18.865.178 18.019-.092 16.767-.255 15.512-.418 15.141-.462 11.52-.462H12.017zm-.017 2.179c3.563 0 3.988.016 5.392.078 1.3.06 2.006.278 2.476.463.622.242 1.066.532 1.532.998.466.466.756.91.998 1.532.185.47.403 1.176.463 2.476.062 1.404.078 1.829.078 5.392s-.016 3.988-.078 5.392c-.06 1.3-.278 2.006-.463 2.476-.242.622-.532 1.066-.998 1.532-.466.466-.91.756-1.532.998-.47.185-1.176.403-2.476.463-1.404.062-1.829.078-5.392.078s-3.988-.016-5.392-.078c-1.3-.06-2.006-.278-2.476-.463-.622-.242-1.066-.532-1.532-.998-.466-.466-.756-.91-.998-1.532-.185-.47-.403-1.176-.463-2.476C2.195 15.988 2.179 15.563 2.179 12s.016-3.988.078-5.392c.06-1.3.278-2.006.463-2.476.242-.622.532-1.066.998-1.532.466-.466.91-.756 1.532-.998.47-.185 1.176-.403 2.476-.463C8.032 2.195 8.457 2.179 12.02 2.179h-.003z"/>
        </svg>
        Continue with Apple
      </Button>
    </div>
  );
};