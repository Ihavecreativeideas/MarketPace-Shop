import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, DollarSign } from 'lucide-react';
import { useLaunch } from '@/contexts/LaunchContext';

interface SustainabilityFeeInfoProps {
  userId?: string;
  showFeeAmount?: boolean;
}

export const SustainabilityFeeInfo: React.FC<SustainabilityFeeInfoProps> = ({ 
  userId, 
  showFeeAmount = true 
}) => {
  const { isLaunched, launchDate } = useLaunch();
  const [isExempt, setIsExempt] = React.useState(false);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    if (userId && launchDate) {
      checkExemption();
    } else {
      setLoading(false);
    }
  }, [userId, launchDate]);

  const checkExemption = async () => {
    if (!userId) return;
    
    try {
      // Check if user signed up before launch
      const exempt = !isLaunched; // If not launched yet, they're pre-launch
      setIsExempt(exempt);
    } catch (error) {
      console.error('Error checking exemption:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="w-full">
        <CardContent className="p-4">
          <div className="animate-pulse h-4 bg-gray-200 rounded"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full border-l-4 border-l-green-500">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <DollarSign className="h-5 w-5" />
          Sustainability Fee
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isExempt ? (
          <div className="flex items-center gap-2 text-green-600">
            <CheckCircle className="h-5 w-5" />
            <span className="font-medium">3 Months FREE!</span>
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              Pre-Launch Member
            </Badge>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <span className="text-gray-600">
              Sustainability Fee: <span className="font-bold text-lg">$4/month</span>
            </span>
          </div>
        )}
        
        <p className="text-sm text-gray-500 mt-2">
          {isExempt 
            ? "As a pre-launch member, you get 3 months without the sustainability fee!"
            : "This fee helps us maintain our eco-friendly delivery network."
          }
        </p>
      </CardContent>
    </Card>
  );
};