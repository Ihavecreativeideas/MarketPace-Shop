import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DollarSign, Calendar, Users, Music, AlertCircle } from 'lucide-react';
import ImageUpload from './ImageUpload';

interface PostingModalProps {
  isOpen: boolean;
  onClose: () => void;
  postType: string;
}

const PostingModal: React.FC<PostingModalProps> = ({ isOpen, onClose, postType }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    location: '',
    contact: '',
    category: '',
    tags: [] as string[]
  });
  const [images, setImages] = useState<File[]>([]);

  const getPostTypeConfig = () => {
    switch (postType) {
      case 'rent':
        return {
          title: 'Rent Equipment',
          icon: <DollarSign className="w-5 h-5" />,
          categories: ['Instruments', 'Audio Equipment', 'Lighting', 'Stage Equipment'],
          placeholder: 'What equipment are you renting out?',
          showImages: true
        };
      case 'sell':
        return {
          title: 'Sell Item',
          icon: <DollarSign className="w-5 h-5" />,
          categories: ['Instruments', 'Audio Equipment', 'Music Gear', 'Accessories'],
          placeholder: 'What are you selling?',
          showImages: true
        };
      case 'music-alert':
        return {
          title: 'New Music Alert',
          icon: <Music className="w-5 h-5" />,
          categories: ['Single Release', 'Album Release', 'EP Release', 'Live Recording'],
          placeholder: 'Share your new music release',
          showImages: false
        };
      case 'band-recruit':
        return {
          title: 'Band Member Recruitment',
          icon: <Users className="w-5 h-5" />,
          categories: ['Vocalist', 'Guitarist', 'Bassist', 'Drummer', 'Keyboardist', 'Other'],
          placeholder: 'What band member are you looking for?',
          showImages: false
        };
      case 'gig-opportunity':
        return {
          title: 'Gig Opportunity',
          icon: <Calendar className="w-5 h-5" />,
          categories: ['Wedding', 'Corporate Event', 'Concert', 'Private Party', 'Festival'],
          placeholder: 'Describe the gig opportunity',
          showImages: false
        };
      default:
        return {
          title: 'Create Post',
          icon: <AlertCircle className="w-5 h-5" />,
          categories: [],
          placeholder: 'Enter details',
          showImages: false
        };
    }
  };

  const config = getPostTypeConfig();

  const handleSubmit = async () => {
    console.log('Posting:', { ...formData, type: postType, images });
    alert('Post created successfully!');
    onClose();
    setFormData({ title: '', description: '', price: '', location: '', contact: '', category: '', tags: [] });
    setImages([]);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {config.icon}
            {config.title}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label>Title</Label>
            <Input
              placeholder={config.placeholder}
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            />
          </div>

          {config.categories.length > 0 && (
            <div>
              <Label>Category</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {config.categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <Label>Description</Label>
            <Textarea
              placeholder="Provide detailed information..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          {config.showImages && (
            <ImageUpload
              images={images}
              onImagesChange={setImages}
              maxImages={5}
            />
          )}

          {(postType === 'rent' || postType === 'sell') && (
            <div>
              <Label>Price</Label>
              <Input
                placeholder="Enter price (e.g., $50/day or $200)"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
              />
            </div>
          )}

          <div>
            <Label>Location</Label>
            <Input
              placeholder="City, State"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            />
          </div>

          <div>
            <Label>Contact</Label>
            <Input
              placeholder="Email or phone number"
              value={formData.contact}
              onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button onClick={handleSubmit} className="flex-1 bg-blue-600 hover:bg-blue-700">
              Post Now
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PostingModal;