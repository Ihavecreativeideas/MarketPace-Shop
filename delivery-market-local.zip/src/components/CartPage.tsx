import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/components/CartContext';
import { Clock, Zap, Truck, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import GrowRouteDiscountCalculator from '@/components/GrowRouteDiscountCalculator';

type DeliveryOption = 'urgent' | 'grow-route';

const CartPage: React.FC = () => {
  const { cartItems, removeFromCart, getCartTotal, clearCart } = useCart();
  const [selectedDelivery, setSelectedDelivery] = useState<DeliveryOption>('urgent');
  const [joinedBuyers, setJoinedBuyers] = useState(3); // Simulated joined buyers
  const navigate = useNavigate();

  const baseGrowRoutePrice = 2.99;
  
  const deliveryOptions = {
    urgent: {
      title: 'Urgent Delivery',
      description: 'Deliver at earliest possible time for drivers',
      icon: Zap,
      price: 5.99,
      time: '15-30 min',
      color: 'bg-red-500'
    },
    'grow-route': {
      title: 'Grow Routes',
      description: 'Join others for discounted delivery',
      icon: Truck,
      price: baseGrowRoutePrice,
      time: '45-90 min',
      color: 'bg-green-500'
    }
  };

  const calculateGrowRoutePrice = () => {
    if (joinedBuyers < 2) return baseGrowRoutePrice / 2;
    const discountPercent = Math.min(joinedBuyers * 5, 25);
    const buyerHalfFee = baseGrowRoutePrice / 2;
    const discountAmount = (buyerHalfFee * discountPercent) / 100;
    return buyerHalfFee - discountAmount;
  };

  const getDeliveryFee = () => {
    if (selectedDelivery === 'grow-route') {
      return calculateGrowRoutePrice();
    }
    return deliveryOptions[selectedDelivery].price;
  };

  const handleCheckout = () => {
    const deliveryFee = getDeliveryFee();
    const total = getCartTotal() + deliveryFee;
    console.log('Proceeding to checkout:', {
      items: cartItems,
      deliveryOption: selectedDelivery,
      deliveryFee,
      total
    });
    navigate('/checkout');
  };

  if (cartItems.length === 0) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <Card>
          <CardContent className="text-center py-12">
            <h2 className="text-2xl font-bold mb-4">Your Cart is Empty</h2>
            <p className="text-gray-600 mb-6">Add some items to get started!</p>
            <Button onClick={() => navigate('/marketplace')}>Continue Shopping</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Your Cart</h1>
      
      {/* Cart Items */}
      <Card>
        <CardHeader>
          <CardTitle>Items ({cartItems.length})</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {cartItems.map((item) => (
            <div key={item.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center space-x-4">
                <img src={item.image} alt={item.title} className="w-16 h-16 object-cover rounded" />
                <div>
                  <h3 className="font-semibold">{item.title}</h3>
                  <p className="text-sm text-gray-600">{item.category}</p>
                  <p className="text-sm text-gray-500">{item.location}</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <span className="font-bold">${item.price.toFixed(2)}</span>
                <Button variant="ghost" size="sm" onClick={() => removeFromCart(item.id)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Delivery Options */}
      <Card>
        <CardHeader>
          <CardTitle>Choose Delivery Option</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {Object.entries(deliveryOptions).map(([key, option]) => {
            const IconComponent = option.icon;
            const isSelected = selectedDelivery === key;
            
            return (
              <div key={key} className="space-y-3">
                <div
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    isSelected ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedDelivery(key as DeliveryOption)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-full text-white ${option.color}`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{option.title}</h3>
                        <p className="text-sm text-gray-600">{option.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">
                        ${key === 'grow-route' ? calculateGrowRoutePrice().toFixed(2) : option.price.toFixed(2)}
                      </p>
                      <p className="text-sm text-gray-500 flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {option.time}
                      </p>
                    </div>
                  </div>
                </div>
                
                {/* Show discount calculator for Grow Routes */}
                {isSelected && key === 'grow-route' && (
                  <GrowRouteDiscountCalculator 
                    joinedBuyers={joinedBuyers}
                    baseDeliveryFee={baseGrowRoutePrice}
                  />
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Order Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Order Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>${getCartTotal().toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Delivery Fee</span>
              <span>${getDeliveryFee().toFixed(2)}</span>
            </div>
            <Separator />
            <div className="flex justify-between font-bold text-lg">
              <span>Total</span>
              <span>${(getCartTotal() + getDeliveryFee()).toFixed(2)}</span>
            </div>
          </div>
          
          <div className="mt-6 space-y-3">
            <Button className="w-full" size="lg" onClick={handleCheckout}>
              Proceed to Checkout
            </Button>
            <Button variant="outline" className="w-full" onClick={() => navigate('/marketplace')}>
              Continue Shopping
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CartPage;