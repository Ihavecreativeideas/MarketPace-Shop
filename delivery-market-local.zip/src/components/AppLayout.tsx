import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { useIsMobile } from '@/hooks/use-mobile';
import Navigation from './Navigation';
import LandingPage from './LandingPage';
import MarketplaceWithOffers from './MarketplaceWithOffers';
import PostPace from './PostPace';
import MedPaceEnhanced from './MedPaceEnhanced';
import LocalShops from './LocalShops';
import EnhancedMusicians from './EnhancedMusicians';
import DriverPortal from './DriverPortal';
import DriverJobDescription from './DriverJobDescription';
import { LegalPages } from './LegalPages';
import Footer from './Footer';
import { CartProvider } from './CartContext';
import { TrafficLight } from './TrafficLight';
import CartModal from './CartModal';
import { useCart } from './CartContext';
import { Toaster } from '@/components/ui/toaster';
import PlatformDropdown from './PlatformDropdown';
import VendorPartnershipTiers from './VendorPartnershipTiers';

const AppLayoutContent: React.FC = () => {
  const { sidebarOpen, toggleSidebar } = useAppContext();
  const isMobile = useIsMobile();
  const [activeTab, setActiveTab] = useState('home');
  const { isCartOpen, setIsCartOpen } = useCart();

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <LandingPage />;
      case 'marketplace':
        return <MarketplaceWithOffers />;
      case 'postpace':
        return <PostPace />;
      case 'medpace':
        return <MedPaceEnhanced />;
      case 'localshops':
        return <LocalShops />;
      case 'musicians':
        return <EnhancedMusicians />;
      case 'driver':
        return <DriverPortal />;
      case 'driver-job':
        return <DriverJobDescription />;
      case 'legal':
        return <LegalPages onBack={() => setActiveTab('home')} />;
      case 'vendor-partnership':
        return <VendorPartnershipTiers />;
      default:
        return <LandingPage />;
    }
  };

  const handleLegalClick = () => {
    setActiveTab('legal');
  };

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <div className="container mx-auto px-4 py-6">
          <div className="mb-4 flex justify-end">
            <PlatformDropdown />
          </div>
          
          {activeTab === 'home' ? (
            <main className="max-w-7xl mx-auto">
              {renderContent()}
            </main>
          ) : (
            <>
              <header className="mb-8">
                <div className="text-center space-y-2">
                  <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                    MarketPace
                  </h1>
                  <p className="text-gray-600">Your Local Delivery & Marketplace Hub</p>
                </div>
              </header>
              
              {activeTab !== 'legal' && activeTab !== 'driver-job' && (
                <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
              )}
              
              <main className="max-w-7xl mx-auto">
                {renderContent()}
              </main>
            </>
          )}
        </div>
        
        {activeTab !== 'legal' && (
          <Footer onLegalClick={handleLegalClick} />
        )}
        
        <TrafficLight />
      </div>
      
      <CartModal 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
      />
      
      <Toaster />
    </>
  );
};

const AppLayout: React.FC = () => {
  return (
    <CartProvider>
      <AppLayoutContent />
    </CartProvider>
  );
};

export default AppLayout;
export { AppLayout };