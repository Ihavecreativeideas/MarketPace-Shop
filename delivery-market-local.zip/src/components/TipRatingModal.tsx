import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Star, DollarSign } from 'lucide-react';

interface TipRatingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (tip: number, rating: number, review: string) => void;
  driverName?: string;
  deliveryFee?: number;
  wasLargeItem?: boolean;
}

const TipRatingModal: React.FC<TipRatingModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  driverName = 'Driver',
  deliveryFee = 40,
  wasLargeItem = false
}) => {
  const [tip, setTip] = useState('');
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [hoveredRating, setHoveredRating] = useState(0);

  const handleSubmit = () => {
    onSubmit(parseFloat(tip) || 0, rating, review);
    onClose();
  };

  const tipOptions = [3, 5, 8, 10];
  const driverEarnings = 40; // Driver gets $40 flat rate

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Tip & Rate {driverName}</DialogTitle>
        </DialogHeader>
        <div className="space-y-6">
          <div className="bg-blue-50 p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-4 h-4 text-blue-600" />
              <span className="font-medium text-blue-900">Driver Earnings</span>
            </div>
            <div className="text-sm text-blue-800">
              <div>Delivery fee: $40 flat rate</div>
              <div className="font-medium mt-1">Tips go 100% to your driver!</div>
            </div>
          </div>
          
          <div>
            <Label className="text-sm font-medium">Tip Amount</Label>
            <div className="flex gap-2 mt-2">
              {tipOptions.map((amount) => (
                <Button
                  key={amount}
                  variant={tip === amount.toString() ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setTip(amount.toString())}
                >
                  ${amount}
                </Button>
              ))}
            </div>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-sm">$</span>
              <Input
                type="number"
                placeholder="Custom amount"
                value={tip}
                onChange={(e) => setTip(e.target.value)}
                className="flex-1"
              />
            </div>
            <p className="text-xs text-gray-600 mt-1">
              Suggested: 10-15% of delivery fee ($4-$6)
            </p>
          </div>
          
          <div>
            <Label className="text-sm font-medium">Rating</Label>
            <div className="flex gap-1 mt-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="p-1"
                >
                  <Star
                    className={`w-6 h-6 ${
                      star <= (hoveredRating || rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <Label htmlFor="review" className="text-sm font-medium">
              Review (Optional)
            </Label>
            <Textarea
              id="review"
              placeholder="Share your experience..."
              value={review}
              onChange={(e) => setReview(e.target.value)}
              className="mt-2"
            />
          </div>
          
          {wasLargeItem && (
            <div className="bg-green-50 p-3 rounded-lg text-sm">
              <div className="font-medium text-green-900 mb-1">Large Item Delivery</div>
              <div className="text-green-800">
                Your driver used their truck/trailer and handled loading for this delivery.
                Consider showing extra appreciation!
              </div>
            </div>
          )}
          
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Skip
            </Button>
            <Button onClick={handleSubmit} className="flex-1">
              Submit
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TipRatingModal;