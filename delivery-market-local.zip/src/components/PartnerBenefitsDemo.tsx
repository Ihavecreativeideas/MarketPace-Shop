import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Star, Crown, Diamond, Calculator, Package2, RotateCcw } from 'lucide-react';
import DeliveryPricing from './DeliveryPricing';
import ReturnCalculator from './ReturnCalculator';
import VendorPartnershipTiers from './VendorPartnershipTiers';

const PartnerBenefitsDemo = () => {
  const [selectedTier, setSelectedTier] = useState<'none' | 'silver' | 'gold' | 'platinum'>('none');
  const [demoType, setDemoType] = useState<'delivery' | 'return' | 'tiers'>('delivery');
  const [distance, setDistance] = useState(5);

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case 'silver': return <Star className="w-4 h-4" />;
      case 'gold': return <Crown className="w-4 h-4" />;
      case 'platinum': return <Diamond className="w-4 h-4" />;
      default: return null;
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'silver': return 'bg-gray-100 text-gray-800';
      case 'gold': return 'bg-yellow-100 text-yellow-800';
      case 'platinum': return 'bg-purple-100 text-purple-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  return (
    <div className="space-y-6 p-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-center text-2xl">Partner Benefits Demo</CardTitle>
          <p className="text-center text-gray-600">
            See how partner tiers affect delivery and return costs
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium mb-2">Demo Type</label>
              <Select value={demoType} onValueChange={(value: 'delivery' | 'return' | 'tiers') => setDemoType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="delivery">
                    <div className="flex items-center gap-2">
                      <Package2 className="w-4 h-4" />
                      Delivery Pricing
                    </div>
                  </SelectItem>
                  <SelectItem value="return">
                    <div className="flex items-center gap-2">
                      <RotateCcw className="w-4 h-4" />
                      Return Calculator
                    </div>
                  </SelectItem>
                  <SelectItem value="tiers">
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4" />
                      Partnership Tiers
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Partner Tier</label>
              <Select value={selectedTier} onValueChange={(value: 'none' | 'silver' | 'gold' | 'platinum') => setSelectedTier(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Standard (No Partnership)</SelectItem>
                  <SelectItem value="silver">
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4" />
                      Silver Partner
                    </div>
                  </SelectItem>
                  <SelectItem value="gold">
                    <div className="flex items-center gap-2">
                      <Crown className="w-4 h-4" />
                      Gold Partner
                    </div>
                  </SelectItem>
                  <SelectItem value="platinum">
                    <div className="flex items-center gap-2">
                      <Diamond className="w-4 h-4" />
                      Platinum Partner
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">Distance (miles)</label>
              <Select value={distance.toString()} onValueChange={(value) => setDistance(parseInt(value))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[1, 2, 3, 5, 8, 10, 15, 20].map(miles => (
                    <SelectItem key={miles} value={miles.toString()}>{miles} miles</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {selectedTier !== 'none' && (
            <div className="mb-6">
              <Badge className={`${getTierColor(selectedTier)} flex items-center gap-1 w-fit`}>
                {getTierIcon(selectedTier)}
                {selectedTier.charAt(0).toUpperCase() + selectedTier.slice(1)} Partner Benefits Active
              </Badge>
            </div>
          )}
        </CardContent>
      </Card>
      
      {demoType === 'delivery' && (
        <DeliveryPricing />
      )}
      
      {demoType === 'return' && (
        <ReturnCalculator 
          distance={distance}
          isPartnerReturn={selectedTier !== 'none'}
          partnerTier={selectedTier !== 'none' ? selectedTier : undefined}
        />
      )}
      
      {demoType === 'tiers' && (
        <VendorPartnershipTiers showSubscribeButtons={false} />
      )}
      
      <Card className="bg-gradient-to-r from-green-50 to-blue-50">
        <CardHeader>
          <CardTitle className="text-center">Key Partner Benefits Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4 text-center">
            <div className="p-4 bg-white rounded-lg">
              <Star className="w-8 h-8 mx-auto mb-2 text-gray-600" />
              <h3 className="font-semibold mb-2">Silver Partners</h3>
              <ul className="text-sm space-y-1">
                <li>• 50% off delivery fees</li>
                <li>• $0.75/mile (vs $1.25)</li>
                <li>• 50% off sustainability fee</li>
                <li>• 50% off return fees</li>
              </ul>
            </div>
            
            <div className="p-4 bg-white rounded-lg">
              <Crown className="w-8 h-8 mx-auto mb-2 text-yellow-600" />
              <h3 className="font-semibold mb-2">Gold Partners</h3>
              <ul className="text-sm space-y-1">
                <li>• 50% off delivery fees</li>
                <li>• $0.75/mile (vs $1.25)</li>
                <li>• NO sustainability fee</li>
                <li>• FREE returns</li>
              </ul>
            </div>
            
            <div className="p-4 bg-white rounded-lg">
              <Diamond className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <h3 className="font-semibold mb-2">Platinum Partners</h3>
              <ul className="text-sm space-y-1">
                <li>• 50% off delivery fees</li>
                <li>• $0.75/mile (vs $1.25)</li>
                <li>• NO sustainability fee</li>
                <li>• FREE returns</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PartnerBenefitsDemo;