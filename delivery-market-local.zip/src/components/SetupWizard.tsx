import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Circle, AlertCircle, ExternalLink } from 'lucide-react';
import { supabase, isDemoMode } from '@/lib/supabase';

interface SetupStep {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  action?: () => void;
  link?: string;
}

export default function SetupWizard() {
  const [steps, setSteps] = useState<SetupStep[]>([]);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    checkSetupStatus();
  }, []);

  const checkSetupStatus = async () => {
    const setupSteps: SetupStep[] = [
      {
        id: 'supabase',
        title: 'Configure Supabase',
        description: isDemoMode() ? 'Replace demo credentials with your own' : 'Supabase configured',
        completed: !isDemoMode()
      },
      {
        id: 'database',
        title: 'Set up Database',
        description: 'Create required tables in Supabase',
        completed: false
      },
      {
        id: 'env',
        title: 'Environment Variables',
        description: 'Create .env.local with your credentials',
        completed: !isDemoMode()
      }
    ];

    // Check database connection
    try {
      const { data, error } = await supabase.from('users').select('count').limit(1);
      if (!error) {
        setupSteps[1].completed = true;
      }
    } catch (err) {
      console.log('Database check failed:', err);
    }

    setSteps(setupSteps);
  };

  const allCompleted = steps.every(step => step.completed);
  const hasIncomplete = steps.some(step => !step.completed);

  if (!isVisible || allCompleted) return null;

  return (
    <Card className="mb-6 border-orange-200 bg-orange-50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-orange-600" />
              Setup Required
            </CardTitle>
            <CardDescription>
              Complete these steps to fully configure MarketPace
            </CardDescription>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setIsVisible(false)}>
            ×
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {steps.map((step) => (
            <div key={step.id} className="flex items-center gap-3">
              {step.completed ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <Circle className="h-5 w-5 text-gray-400" />
              )}
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{step.title}</span>
                  <Badge variant={step.completed ? 'default' : 'secondary'}>
                    {step.completed ? 'Complete' : 'Pending'}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
        
        {hasIncomplete && (
          <div className="mt-6 pt-4 border-t">
            <div className="flex gap-2">
              <Button asChild size="sm">
                <a href="/SETUP.md" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View Setup Guide
                </a>
              </Button>
              <Button variant="outline" size="sm" onClick={checkSetupStatus}>
                Recheck Status
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
