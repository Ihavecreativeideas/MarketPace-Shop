import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { User, Store } from 'lucide-react';
import SellerOfferNotifications from './SellerOfferNotifications';
import BuyerOfferStatus from './BuyerOfferStatus';
import CounterOfferModal from './CounterOfferModal';
import { useToast } from '@/hooks/use-toast';

const OfferDemo: React.FC = () => {
  const [showCounterModal, setShowCounterModal] = useState(false);
  const { toast } = useToast();

  const sampleProduct = {
    id: 'demo-product-1',
    title: 'Vintage Leather Jacket',
    price: 150,
    image: '/placeholder.svg'
  };

  const handleSubmitOffer = async (discountPercent: number, newPrice: number) => {
    try {
      await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/8c8c05c5-276b-4a02-9305-2c694df852cf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create_offer',
          productId: sampleProduct.id,
          productTitle: sampleProduct.title,
          originalPrice: sampleProduct.price,
          buyerOfferPrice: newPrice,
          buyerDiscountPercent: discountPercent,
          buyerId: 'demo-buyer-1',
          sellerId: 'demo-seller-1'
        })
      });
      
      toast({
        title: 'Counter offer submitted!',
        description: `Offered $${newPrice.toFixed(2)} (${discountPercent}% off)`
      });
    } catch (error) {
      toast({
        title: 'Error submitting offer',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Counter Offer System Demo</h1>
        <p className="text-gray-600 mb-6">
          Experience the full counter offer workflow: buyers make offers, sellers respond with accept/deny/counter, 
          and payments process instantly when accepted.
        </p>
        
        {/* Sample Product */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Sample Marketplace Product</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <img src={sampleProduct.image} alt={sampleProduct.title} className="w-20 h-20 object-cover rounded" />
              <div className="flex-1">
                <h3 className="font-semibold text-lg">{sampleProduct.title}</h3>
                <p className="text-2xl font-bold text-green-600">${sampleProduct.price}</p>
              </div>
              <Button onClick={() => setShowCounterModal(true)} variant="outline">
                Make Counter Offer
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="buyer" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="buyer" className="flex items-center gap-2">
            <User className="w-4 h-4" />
            Buyer View
          </TabsTrigger>
          <TabsTrigger value="seller" className="flex items-center gap-2">
            <Store className="w-4 h-4" />
            Seller View
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="buyer" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Buyer Dashboard
                <Badge variant="outline">demo-buyer-1</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <BuyerOfferStatus buyerId="demo-buyer-1" />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="seller" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Store className="w-5 h-5" />
                Seller Dashboard
                <Badge variant="outline">demo-seller-1</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <SellerOfferNotifications sellerId="demo-seller-1" />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <CounterOfferModal
        isOpen={showCounterModal}
        onClose={() => setShowCounterModal(false)}
        originalPrice={sampleProduct.price}
        itemTitle={sampleProduct.title}
        onSubmitOffer={handleSubmitOffer}
      />
    </div>
  );
};

export default OfferDemo;