import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Search, ShoppingCart, Star, Crown, Plus, ExternalLink, AlertTriangle } from 'lucide-react';
import AddItemModal from './AddItemModal';
import CounterOfferModal from './CounterOfferModal';
import FreeAccessPromotion from './FreeAccessPromotion';
import { useCart } from './CartContext';
import { useInterestTracker } from './InterestTracker';

interface Product {
  id: number;
  name: string;
  price: string;
  shop: string;
  platform: 'etsy' | 'tiktok' | 'local' | 'other';
  rating: number;
  image: string;
  images?: string[];
  deliveryType: 'local' | 'extended' | 'external';
  isPartnerShop: boolean;
  partnerBenefits?: string[];
  description?: string;
  createdAt?: string;
  category?: string;
  isFoodItem?: boolean;
}

interface MarketplaceProps {
  userId?: string;
  isPartner?: boolean;
}

const Marketplace: React.FC<MarketplaceProps> = ({ userId, isPartner = false }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isAddItemOpen, setIsAddItemOpen] = useState(false);
  const [counterOfferProduct, setCounterOfferProduct] = useState<Product | null>(null);
  const [products, setProducts] = useState<Product[]>([
    {
      id: 1,
      name: 'Handcrafted Ceramic Mug',
      price: '$24.99',
      shop: 'Clay Creations',
      platform: 'etsy',
      rating: 4.8,
      image: '/placeholder.svg',
      deliveryType: 'local',
      isPartnerShop: false,
      description: 'Beautiful handcrafted ceramic mug perfect for your morning coffee',
      category: 'home'
    },
    {
      id: 2,
      name: 'Vintage Band T-Shirt',
      price: '$35.00',
      shop: 'Retro Threads',
      platform: 'tiktok',
      rating: 4.6,
      image: '/placeholder.svg',
      deliveryType: 'local',
      isPartnerShop: true,
      partnerBenefits: ['Priority Support', 'Extended Warranty', 'Free Returns'],
      description: 'Authentic vintage band t-shirt in excellent condition',
      category: 'clothing'
    },
    {
      id: 3,
      name: 'Fresh Pizza Margherita',
      price: '$18.99',
      shop: 'Tony\'s Pizzeria',
      platform: 'local',
      rating: 4.9,
      image: '/placeholder.svg',
      deliveryType: 'external',
      isPartnerShop: true,
      partnerBenefits: ['Fresh Ingredients', 'Hot Delivery'],
      description: 'Authentic wood-fired pizza with fresh mozzarella and basil',
      category: 'food',
      isFoodItem: true
    },
    {
      id: 4,
      name: 'Acoustic Guitar',
      price: '$299.99',
      shop: 'Music Corner',
      platform: 'local',
      rating: 4.9,
      image: '/placeholder.svg',
      deliveryType: 'local',
      isPartnerShop: true,
      partnerBenefits: ['Free Setup', 'Local Support'],
      description: 'Professional acoustic guitar in excellent condition',
      category: 'sports'
    }
  ]);
  
  const { addToCart } = useCart();
  const { trackPurchase } = useInterestTracker('demo-user-123');

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'electronics', label: 'Electronics' },
    { value: 'clothing', label: 'Clothing' },
    { value: 'home', label: 'Home & Garden' },
    { value: 'sports', label: 'Sports & Outdoors' },
    { value: 'food', label: 'Food & Beverages' },
    { value: 'other', label: 'Other' }
  ];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.shop.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleAddToCart = (product: Product) => {
    if (product.isFoodItem) {
      return;
    }
    
    addToCart({
      id: product.id.toString(),
      name: product.name,
      price: parseFloat(product.price.replace('$', '')),
      image: product.image,
      quantity: 1
    });
  };

  const handleBuyNow = async (product: Product) => {
    if (product.isFoodItem) {
      window.open('https://www.ubereats.com/search?q=' + encodeURIComponent(product.shop), '_blank');
      return;
    }
    
    handleAddToCart(product);
    await trackPurchase(product.category || 'general', product.name, parseFloat(product.price.replace('$', '')));
  };

  const handleItemAdded = (newItem: Product) => {
    setProducts(prev => [...prev, newItem]);
  };

  return (
    <div className="space-y-6">
      {/* Show promotion to marketplace members who aren't partners */}
      {userId && !isPartner && (
        <FreeAccessPromotion isMarketplaceMember={true} isPartner={false} />
      )}
      
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Marketplace</h1>
        <Button onClick={() => setIsAddItemOpen(true)} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />Add New Item
        </Button>
      </div>

      <Alert className="border-orange-200 bg-orange-50">
        <AlertTriangle className="h-4 w-4 text-orange-600" />
        <AlertDescription className="text-orange-800">
          <strong>Food Delivery Notice:</strong> MarketPlace drivers cannot deliver food products. 
          Food items are promoted here but delivered through Uber Eats, DoorDash, or pickup only.
        </AlertDescription>
      </Alert>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search local products and shops..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <select 
          value={selectedCategory} 
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="px-3 py-2 border rounded-md"
        >
          {categories.map(cat => (
            <option key={cat.value} value={cat.value}>{cat.label}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredProducts.map((product) => (
          <Card key={product.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="p-0 relative">
              <img src={product.image} alt={product.name} className="w-full h-48 object-cover rounded-t-lg" />
              <div className="absolute top-2 left-2 flex flex-col gap-1">
                <Badge className="bg-green-600">{product.platform}</Badge>
                {product.isPartnerShop && (
                  <Badge className="bg-purple-600"><Crown className="w-3 h-3 mr-1" />Partner</Badge>
                )}
                {product.isFoodItem && (
                  <Badge className="bg-orange-600">Food Item</Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-2">
                <CardTitle className="text-lg line-clamp-1">{product.name}</CardTitle>
                <p className="text-sm text-gray-600">{product.shop}</p>
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold text-green-600">{product.price}</span>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm">{product.rating}</span>
                  </div>
                </div>
                
                {product.isFoodItem ? (
                  <div className="space-y-2">
                    <Alert className="p-2">
                      <AlertDescription className="text-xs">
                        Food delivery via Uber Eats/DoorDash
                      </AlertDescription>
                    </Alert>
                    <Button className="w-full bg-orange-600 hover:bg-orange-700" onClick={() => handleBuyNow(product)}>
                      <ExternalLink className="w-4 h-4 mr-2" />Order for Delivery
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full" onClick={() => handleAddToCart(product)}>
                      <ShoppingCart className="w-4 h-4 mr-2" />Add to Cart
                    </Button>
                    <Button className="w-full bg-green-600 hover:bg-green-700" onClick={() => handleBuyNow(product)}>
                      Buy Now
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No products found matching your criteria.</p>
        </div>
      )}

      <AddItemModal 
        isOpen={isAddItemOpen} 
        onClose={() => setIsAddItemOpen(false)} 
        onItemAdded={handleItemAdded} 
      />
      {counterOfferProduct && (
        <CounterOfferModal 
          product={counterOfferProduct} 
          onClose={() => setCounterOfferProduct(null)} 
        />
      )}
    </div>
  );
};

export default Marketplace;