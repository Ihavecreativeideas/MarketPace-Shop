import React from 'react';
import RecruitTownFlyer from './RecruitTownFlyer';
import { Button } from './ui/button';
import { ArrowLeft } from 'lucide-react';

const ShareableFlyerPage: React.FC = () => {
  const handleJoinCampaign = () => {
    // Redirect to main page with signup modal
    window.location.href = '/?join=true';
  };

  const handleShare = () => {
    const shareUrl = window.location.href;
    const shareText = "🏪🚗 Recruit Your Town Launch Campaign! We're preparing to launch a delivery business focused on shopping local and delivering opportunities to communities. Join us in creating local jobs and boosting our local economy! #RecruitYourTown #ShopLocal #MarketPace";
    
    if (navigator.share) {
      navigator.share({
        title: 'Recruit Your Town - MarketPace',
        text: shareText,
        url: shareUrl,
      });
    } else {
      // Fallback to Facebook share
      const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
      window.open(facebookUrl, '_blank', 'width=600,height=400');
    }
  };

  const handleBackToMain = () => {
    window.location.href = '/';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 py-8 px-4">
      {/* Meta tags for Facebook Open Graph */}
      <div className="hidden">
        <meta property="og:title" content="Recruit Your Town - MarketPace Launch Campaign" />
        <meta property="og:description" content="Join our campaign to bring local delivery opportunities to your community. Support local businesses and create jobs!" />
        <meta property="og:image" content={`${window.location.origin}/flyer-preview.png`} />
        <meta property="og:url" content={window.location.href} />
        <meta property="og:type" content="website" />
      </div>
      
      <div className="max-w-2xl mx-auto">
        {/* Back Button */}
        <Button 
          onClick={handleBackToMain}
          variant="outline"
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to MarketPace
        </Button>

        {/* Full Flyer */}
        <div className="mb-8">
          <RecruitTownFlyer 
            onJoinCampaign={handleJoinCampaign}
            onShare={handleShare}
          />
        </div>

        {/* Additional Info for Shareable Page */}
        <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            Help Bring MarketPace to Your Community!
          </h2>
          <p className="text-gray-600 mb-6">
            Share this flyer with friends, family, and local businesses. 
            The more people who join our campaign, the sooner we can launch 
            and start supporting your local economy!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={handleJoinCampaign}
              className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-white font-bold text-lg px-8 py-3"
            >
              Join the Campaign
            </Button>
            <Button 
              onClick={handleShare}
              variant="outline"
              className="border-orange-300 text-orange-600 hover:bg-orange-50"
            >
              Share This Flyer
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShareableFlyerPage;