import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import DeliveryStatus from './DeliveryStatus';
import { Package, DollarSign, Shield } from 'lucide-react';

interface MarketplaceOrderProps {
  orderId: string;
  itemTitle: string;
  itemPrice: number;
  deliveryFee: number;
  buyerShare: number;
  sellerShare: number;
  status: 'pending' | 'in_route' | 'delivered' | 'accepted' | 'returned';
  userType: 'buyer' | 'seller';
}

const MarketplaceOrder: React.FC<MarketplaceOrderProps> = ({
  orderId,
  itemTitle,
  itemPrice,
  deliveryFee,
  buyerShare,
  sellerShare,
  status,
  userType
}) => {
  const [orderStatus, setOrderStatus] = useState(status);

  const handleStatusChange = (newStatus: 'accepted' | 'returned') => {
    setOrderStatus(newStatus);
    console.log(`Order ${orderId} status changed to:`, newStatus);
    // Here you would update the backend
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            {itemTitle}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Item Price:</span>
              <p className="font-semibold">${itemPrice}</p>
            </div>
            <div>
              <span className="text-gray-600">Total Delivery Fee:</span>
              <p className="font-semibold">${deliveryFee}</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-2">
            <h4 className="font-medium flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Delivery Cost Split
            </h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className={`p-2 rounded ${userType === 'buyer' ? 'bg-blue-50' : 'bg-gray-50'}`}>
                <span className="text-gray-600">Buyer Pays:</span>
                <p className="font-semibold">${buyerShare}</p>
              </div>
              <div className={`p-2 rounded ${userType === 'seller' ? 'bg-green-50' : 'bg-gray-50'}`}>
                <span className="text-gray-600">Seller Pays:</span>
                <p className="font-semibold">${sellerShare}</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-blue-600 bg-blue-50 p-2 rounded">
            <Shield className="w-4 h-4" />
            <span>MarketPace covers all return costs</span>
          </div>

          {orderStatus === 'delivered' && (
            <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-lg">
              <p className="text-sm text-yellow-800 font-medium">
                {userType === 'buyer' 
                  ? '🎉 Your item has been delivered! Please review and choose to accept or return.'
                  : '✅ Your item has been delivered to the buyer. You can tip the driver now!'}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <DeliveryStatus
        orderId={orderId}
        itemName={itemTitle}
        status={orderStatus}
        userType={userType}
        onStatusChange={handleStatusChange}
      />
    </div>
  );
};

export default MarketplaceOrder;