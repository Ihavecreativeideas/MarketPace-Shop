import React from 'react';
import { Button } from '@/components/ui/button';
import { Truck, Clock, MapPin } from 'lucide-react';

interface DeliverNowButtonProps {
  productId: number;
  productName: string;
  price: string;
  location?: string;
  onDeliveryRequest?: (productId: number) => void;
}

const DeliverNowButton: React.FC<DeliverNowButtonProps> = ({
  productId,
  productName,
  price,
  location,
  onDeliveryRequest
}) => {
  const handleDeliverNow = () => {
    // Track delivery request
    console.log('Deliver Now requested for:', productName);
    
    // Call parent handler if provided
    if (onDeliveryRequest) {
      onDeliveryRequest(productId);
    }
    
    // In a real app, this would:
    // 1. Calculate delivery cost and time
    // 2. Show delivery options modal
    // 3. Connect buyer with available drivers
    // 4. Process payment and create delivery order
    
    alert(`Deliver Now requested for ${productName}!\n\nA driver will be assigned shortly to deliver this item to your location.`);
  };

  return (
    <Button 
      onClick={handleDeliverNow}
      className="bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded-lg shadow-md transition-all duration-200 hover:shadow-lg"
    >
      <Truck className="w-4 h-4 mr-2" />
      <span className="hidden sm:inline">Deliver Now</span>
      <span className="sm:hidden">Deliver</span>
    </Button>
  );
};

export default DeliverNowButton;