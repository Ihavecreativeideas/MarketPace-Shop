import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/components/AuthProvider';
import { Smartphone, Download, Apple, Globe, Zap } from 'lucide-react';

export const IOSApp: React.FC = () => {
  const { user } = useAuth();

  const downloadApp = () => {
    // In real implementation, this would redirect to App Store
    window.open('https://apps.apple.com/app/your-app-id', '_blank');
  };

  const openPWA = () => {
    // Check if app is already installed as PWA
    if (window.matchMedia('(display-mode: standalone)').matches) {
      return;
    }
    
    // Show PWA install prompt
    const installPrompt = localStorage.getItem('pwa-install-prompt');
    if (!installPrompt) {
      alert('To install: Tap Share button in Safari, then "Add to Home Screen"');
      localStorage.setItem('pwa-install-prompt', 'shown');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-md mx-auto space-y-6">
        {/* App Header */}
        <Card className="text-center">
          <CardHeader>
            <div className="mx-auto w-20 h-20 bg-blue-600 rounded-2xl flex items-center justify-center mb-4">
              <Smartphone className="h-10 w-10 text-white" />
            </div>
            <CardTitle className="text-2xl">DeliverNow iOS</CardTitle>
            <p className="text-muted-foreground">
              Facebook Marketplace delivery made simple
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-center gap-2">
              <Badge variant="secondary">v1.0.0</Badge>
              <Badge variant="outline">iOS Ready</Badge>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <Globe className="h-4 w-4 text-blue-600" />
                <span>Web App</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-green-600" />
                <span>Fast & Secure</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Download Options */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Get the App</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              onClick={downloadApp}
              className="w-full bg-black hover:bg-gray-800"
              size="lg"
            >
              <Apple className="h-5 w-5 mr-2" />
              Download from App Store
            </Button>
            
            <Button 
              onClick={openPWA}
              variant="outline"
              className="w-full"
              size="lg"
            >
              <Download className="h-5 w-5 mr-2" />
              Add to Home Screen
            </Button>
            
            <p className="text-xs text-muted-foreground text-center">
              Install as a Progressive Web App for the best experience
            </p>
          </CardContent>
        </Card>

        {/* Features */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Key Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-medium">Facebook Integration</h4>
                  <p className="text-sm text-muted-foreground">
                    Share products with "Deliver Now" button
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-medium">Social Login</h4>
                  <p className="text-sm text-muted-foreground">
                    Sign in with Facebook or Google
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-purple-600 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-medium">Invite & Recruit</h4>
                  <p className="text-sm text-muted-foreground">
                    Grow network by inviting friends, drivers, shops
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-orange-600 rounded-full mt-2"></div>
                <div>
                  <h4 className="font-medium">Real-time Delivery</h4>
                  <p className="text-sm text-muted-foreground">
                    Track orders and manage deliveries
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {user && (
          <Card className="bg-green-50 border-green-200">
            <CardContent className="pt-6">
              <div className="text-center">
                <h3 className="font-semibold text-green-800 mb-2">
                  Welcome back, {user.name}!
                </h3>
                <p className="text-sm text-green-700">
                  You're signed in and ready to use all features
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};