import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, Store, Truck, Globe, BarChart3, Gift, Zap } from 'lucide-react';

const SubscriptionPlans: React.FC = () => {
  const handleSignup = () => {
    console.log('MarketPlace Partner signup initiated');
    // Navigate to signup or open modal
  };

  const benefits = [
    'Website integration included',
    'Platform to promote your business',
    'No added delivery fees (customers pay driver only)',
    'Social media integration tools',
    'Analytics and performance insights',
    'Customer messaging system',
    'Inventory management tools',
    'Marketing promotion features',
    'Priority customer support',
    'Mobile app access for business management'
  ];

  return (
    <Card>
      <CardHeader>
        <div className="text-center">
          <div className="bg-gradient-to-r from-green-400 to-blue-500 text-white p-6 rounded-lg mb-6">
            <h2 className="text-3xl font-bold mb-2">🚀 MarketPlace Partner Program</h2>
            <p className="text-xl mb-2">
              Join our FREE trial run - No payment required!
            </p>
            <div className="flex items-center justify-center gap-2 text-lg font-semibold">
              <Gift className="w-6 h-6" />
              <span>Get promotional discounts & lifetime benefits!</span>
            </div>
          </div>
          <CardTitle className="flex items-center gap-2 justify-center">
            <Store className="w-5 h-5" />
            Become a MarketPlace Partner
          </CardTitle>
          <p className="text-sm text-gray-600 mt-2">
            Help us test our platform and gain incredible value for your business!
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <div className="max-w-2xl mx-auto">
          <div className="border-2 border-green-300 bg-gradient-to-br from-green-50 to-blue-50 rounded-lg p-8 relative">
            <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-600 text-white px-4 py-1">
              <Zap className="w-4 h-4 mr-1" />
              FREE Trial Run
            </Badge>
            
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold mb-3">MarketPlace Partner</h3>
              <div className="text-5xl font-bold text-green-600 mb-2">
                FREE
              </div>
              <p className="text-lg text-green-700 font-semibold mb-2">
                Complete access during our startup campaign
              </p>
              <Badge className="bg-yellow-100 text-yellow-800 px-3 py-1">
                <Gift className="w-4 h-4 mr-1" />
                Early Supporter Benefits
              </Badge>
            </div>

            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  <Check className="w-5 h-5 text-green-600" />
                  What You Get (All FREE):
                </h4>
                <div className="space-y-3">
                  {benefits.slice(0, 5).map((benefit, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  <Gift className="w-5 h-5 text-blue-600" />
                  Plus More Benefits:
                </h4>
                <div className="space-y-3">
                  {benefits.slice(5).map((benefit, index) => (
                    <div key={index} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-white p-4 rounded-lg border text-center">
                <Globe className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                <div className="text-sm font-medium">Website Integration</div>
              </div>
              <div className="bg-white p-4 rounded-lg border text-center">
                <Store className="w-6 h-6 mx-auto mb-2 text-green-600" />
                <div className="text-sm font-medium">Promotion Platform</div>
              </div>
              <div className="bg-white p-4 rounded-lg border text-center">
                <Truck className="w-6 h-6 mx-auto mb-2 text-purple-600" />
                <div className="text-sm font-medium">No Delivery Fees</div>
              </div>
              <div className="bg-white p-4 rounded-lg border text-center">
                <BarChart3 className="w-6 h-6 mx-auto mb-2 text-orange-600" />
                <div className="text-sm font-medium">Analytics</div>
              </div>
            </div>

            <Button 
              onClick={handleSignup}
              className="w-full bg-green-600 hover:bg-green-700 text-white text-lg py-6"
            >
              <Gift className="w-5 h-5 mr-2" />
              🚀 Join FREE Trial Now!
            </Button>
            
            <p className="text-xs text-center text-gray-500 mt-3">
              No credit card required • No contracts • Cancel anytime
            </p>
          </div>
        </div>
        
        <div className="mt-8 space-y-4">
          <div className="p-6 bg-yellow-50 rounded-lg border border-yellow-200">
            <h4 className="font-bold mb-3 text-yellow-800 flex items-center gap-2">
              <Zap className="w-5 h-5" />
              ⚡ Limited Time Beta Offer
            </h4>
            <div className="text-yellow-700 space-y-2">
              <p className="font-medium">
                This is temporary app testing pricing - take advantage of the early sign up!
              </p>
              <p className="text-sm">
                • Complete MarketPlace Partner access absolutely FREE during our startup campaign
              </p>
              <p className="text-sm">
                • Customers only pay driver directly + $1.50 processing fee (split between buyer/seller)
              </p>
              <p className="text-sm font-semibold">
                • Early sign up members get lifetime discounts for supporting and helping our app be successful!
              </p>
            </div>
          </div>
          
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="font-semibold mb-2 text-blue-900">Why Join Our Beta Program?</h4>
            <div className="text-sm text-blue-800 space-y-1">
              <p>• Help shape the future of local marketplace delivery</p>
              <p>• Get all premium features for free during testing</p>
              <p>• Provide feedback and influence product development</p>
              <p>• Lock in lifetime discounts as an early supporter</p>
              <p>• Build your customer base with our growing platform</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SubscriptionPlans;