import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { WhatNotIntegration } from './WhatNotIntegration';
import { CraigslistIntegration } from './CraigslistIntegration';
import { BusinessIntegrationGuide } from './BusinessIntegrationGuide';
import { ContactShareModal } from './ContactShareModal';
import { Button } from '@/components/ui/button';
import { Share2, Zap, Building, Users } from 'lucide-react';

export const IntegrationsPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold">MarketPace Integrations</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Connect your existing platforms and expand your reach across multiple marketplaces
        </p>
        <ContactShareModal>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Share2 className="w-4 h-4 mr-2" />
            Share MarketPace with Contacts
          </Button>
        </ContactShareModal>
      </div>

      <Tabs defaultValue="platforms" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="platforms" className="flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Platform Integrations
          </TabsTrigger>
          <TabsTrigger value="business" className="flex items-center gap-2">
            <Building className="w-4 h-4" />
            Business Setup
          </TabsTrigger>
          <TabsTrigger value="social" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Social Features
          </TabsTrigger>
        </TabsList>

        <TabsContent value="platforms" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <WhatNotIntegration />
            <CraigslistIntegration />
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Coming Soon</CardTitle>
              <CardDescription>
                More platform integrations are on the way
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 border rounded-lg opacity-50">
                  <div className="w-12 h-12 bg-red-100 rounded-lg mx-auto mb-2 flex items-center justify-center">
                    <span className="text-red-600 font-bold">YT</span>
                  </div>
                  <p className="text-sm font-medium">YouTube Shop</p>
                </div>
                <div className="text-center p-4 border rounded-lg opacity-50">
                  <div className="w-12 h-12 bg-pink-100 rounded-lg mx-auto mb-2 flex items-center justify-center">
                    <span className="text-pink-600 font-bold">IG</span>
                  </div>
                  <p className="text-sm font-medium">Instagram Shop</p>
                </div>
                <div className="text-center p-4 border rounded-lg opacity-50">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg mx-auto mb-2 flex items-center justify-center">
                    <span className="text-orange-600 font-bold">AZ</span>
                  </div>
                  <p className="text-sm font-medium">Amazon</p>
                </div>
                <div className="text-center p-4 border rounded-lg opacity-50">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg mx-auto mb-2 flex items-center justify-center">
                    <span className="text-blue-600 font-bold">EB</span>
                  </div>
                  <p className="text-sm font-medium">eBay</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="business">
          <BusinessIntegrationGuide />
        </TabsContent>

        <TabsContent value="social" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Social Features</CardTitle>
              <CardDescription>
                Connect with your community and grow your network
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ContactShareModal>
                <Button className="w-full" size="lg">
                  <Share2 className="w-5 h-5 mr-2" />
                  Share MarketPace with Your Contacts
                </Button>
              </ContactShareModal>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <h3 className="font-semibold mb-2">Referral Program</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    Earn rewards when your friends join MarketPace
                  </p>
                  <Button variant="outline" size="sm" disabled>
                    Coming Soon
                  </Button>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h3 className="font-semibold mb-2">Community Groups</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    Join local groups and connect with nearby members
                  </p>
                  <Button variant="outline" size="sm" disabled>
                    Coming Soon
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};