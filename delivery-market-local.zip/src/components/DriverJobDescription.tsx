import React from 'react';
import { BackButton } from './BackButton';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { DollarSign, Clock, Car, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const DriverJobDescription: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <BackButton to="/" />
        
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Drive with PostPace</h1>
          <p className="text-xl text-gray-600">Flexible delivery driving opportunities</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Earnings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Small/Medium Items:</h4>
                <ul className="text-sm space-y-1">
                  <li>• $4 pickup + $2 drop + $0.75/mile</li>
                  <li>• 100% of tips</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Large Items:</h4>
                <ul className="text-sm space-y-1">
                  <li>• $40 base pay (20 miles)</li>
                  <li>• $1/mile after 20 miles</li>
                  <li>• 100% of tips</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Requirements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li>• Must be 18+ years old</li>
                <li>• Valid driver's license</li>
                <li>• Vehicle insurance</li>
                <li>• Smartphone</li>
                <li>• Background check</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <Button 
            size="lg" 
            className="bg-blue-600 hover:bg-blue-700"
            onClick={() => navigate('/driver-application')}
          >
            <Car className="w-5 h-5 mr-2" />
            Apply Now
          </Button>
        </div>
      </div>
    </div>
  );
};

export default DriverJobDescription;