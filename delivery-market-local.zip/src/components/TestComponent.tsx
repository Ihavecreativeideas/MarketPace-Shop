import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { RefreshCw, CheckCircle, AlertCircle } from 'lucide-react';

const TestComponent: React.FC = () => {
  const [count, setCount] = useState(0);
  const [lastUpdate, setLastUpdate] = useState(new Date().toLocaleTimeString());
  const [isWorking, setIsWorking] = useState(false);

  useEffect(() => {
    setLastUpdate(new Date().toLocaleTimeString());
  }, [count]);

  const handleTest = () => {
    setIsWorking(true);
    setTimeout(() => {
      setCount(prev => prev + 1);
      setIsWorking(false);
    }, 500);
  };

  return (
    <Card className="w-full max-w-md mx-auto border-2 border-green-200 bg-green-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-green-800">
          <CheckCircle className="h-5 w-5" />
          Live Update Test
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          <div className="text-3xl font-bold text-green-600 mb-2">
            {count}
          </div>
          <div className="text-sm text-gray-600">
            Last updated: {lastUpdate}
          </div>
        </div>
        
        <Button 
          onClick={handleTest}
          disabled={isWorking}
          className="w-full bg-green-600 hover:bg-green-700"
        >
          {isWorking ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Testing...
            </>
          ) : (
            'Test Update'
          )}
        </Button>
        
        <div className="text-xs text-center text-green-600 font-medium">
          ✅ Hot Module Replacement Active
        </div>
      </CardContent>
    </Card>
  );
};

export default TestComponent;