import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Truck, Clock, Phone, MessageCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface TrackingData {
  id: string;
  status: 'pending' | 'picked_up' | 'in_transit' | 'delivered';
  driver_name: string;
  driver_phone: string;
  pickup_address: string;
  delivery_address: string;
  estimated_delivery: string;
  current_location?: { lat: number; lng: number };
}

interface RealTimeTrackingProps {
  orderId: string;
}

export const RealTimeTracking: React.FC<RealTimeTrackingProps> = ({ orderId }) => {
  const [tracking, setTracking] = useState<TrackingData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTrackingData();
    
    // Subscribe to real-time updates
    const subscription = supabase
      .channel(`tracking-${orderId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'deliveries',
        filter: `id=eq.${orderId}`
      }, (payload) => {
        setTracking(payload.new as TrackingData);
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [orderId]);

  const fetchTrackingData = async () => {
    try {
      const { data, error } = await supabase
        .from('deliveries')
        .select('*')
        .eq('id', orderId)
        .single();
      
      if (error) throw error;
      setTracking(data);
    } catch (error) {
      console.error('Error fetching tracking data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500';
      case 'picked_up': return 'bg-blue-500';
      case 'in_transit': return 'bg-orange-500';
      case 'delivered': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Order Confirmed';
      case 'picked_up': return 'Picked Up';
      case 'in_transit': return 'On the Way';
      case 'delivered': return 'Delivered';
      default: return 'Unknown';
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading tracking info...</div>;
  }

  if (!tracking) {
    return <div className="text-center p-8">No tracking information available</div>;
  }

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Order Tracking</span>
            <Badge className={getStatusColor(tracking.status)}>
              {getStatusText(tracking.status)}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Progress Timeline */}
          <div className="flex items-center justify-between">
            {['pending', 'picked_up', 'in_transit', 'delivered'].map((status, index) => {
              const isActive = ['pending', 'picked_up', 'in_transit', 'delivered'].indexOf(tracking.status) >= index;
              return (
                <div key={status} className="flex flex-col items-center">
                  <div className={`w-4 h-4 rounded-full ${isActive ? 'bg-blue-500' : 'bg-gray-300'}`} />
                  <span className="text-xs mt-1 capitalize">{status.replace('_', ' ')}</span>
                </div>
              );
            })}
          </div>

          {/* Driver Info */}
          {tracking.driver_name && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Your Driver</h3>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{tracking.driver_name}</p>
                  <p className="text-sm text-gray-600">{tracking.driver_phone}</p>
                </div>
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline">
                    <Phone className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline">
                    <MessageCircle className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Addresses */}
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <MapPin className="h-5 w-5 text-green-500 mt-0.5" />
              <div>
                <p className="font-medium">Pickup</p>
                <p className="text-sm text-gray-600">{tracking.pickup_address}</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <MapPin className="h-5 w-5 text-red-500 mt-0.5" />
              <div>
                <p className="font-medium">Delivery</p>
                <p className="text-sm text-gray-600">{tracking.delivery_address}</p>
              </div>
            </div>
          </div>

          {/* Estimated Delivery */}
          <div className="flex items-center space-x-2 text-sm">
            <Clock className="h-4 w-4" />
            <span>Estimated delivery: {new Date(tracking.estimated_delivery).toLocaleString()}</span>
          </div>

          {/* Map Placeholder */}
          <div className="bg-gray-100 h-48 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <Truck className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              <p className="text-gray-500">Live map tracking coming soon</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};