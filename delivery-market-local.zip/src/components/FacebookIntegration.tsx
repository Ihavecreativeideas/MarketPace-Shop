import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Copy, ExternalLink, Share2 } from 'lucide-react';

interface FacebookIntegrationProps {
  productId: string;
  productTitle: string;
  productPrice: number;
  productImage: string;
  productDescription: string;
}

export const FacebookIntegration: React.FC<FacebookIntegrationProps> = ({
  productId,
  productTitle,
  productPrice,
  productImage,
  productDescription
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [fbPostLink, setFbPostLink] = useState('');
  const { toast } = useToast();

  const generateFacebookLink = async () => {
    setIsGenerating(true);
    try {
      // Generate shareable link with "Deliver Now" button
      const deliverNowUrl = `${window.location.origin}/deliver-now/${productId}`;
      const encodedUrl = encodeURIComponent(deliverNowUrl);
      const encodedTitle = encodeURIComponent(productTitle);
      const encodedDescription = encodeURIComponent(`${productDescription} - Price: $${productPrice}`);
      
      // Facebook share URL with custom parameters
      const facebookShareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedTitle}%20-%20${encodedDescription}`;
      
      setFbPostLink(facebookShareUrl);
      
      toast({
        title: "Facebook Link Generated!",
        description: "Your product link with 'Deliver Now' button is ready to share."
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate Facebook link",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(fbPostLink);
    toast({
      title: "Copied!",
      description: "Facebook link copied to clipboard"
    });
  };

  const openFacebookPost = () => {
    window.open(fbPostLink, '_blank');
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Share2 className="h-5 w-5" />
          Facebook Marketplace Integration
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Product: {productTitle}</Label>
          <p className="text-sm text-muted-foreground">${productPrice}</p>
        </div>
        
        <Button 
          onClick={generateFacebookLink}
          disabled={isGenerating}
          className="w-full"
        >
          {isGenerating ? 'Generating...' : 'Generate Facebook Post Link'}
        </Button>
        
        {fbPostLink && (
          <div className="space-y-2">
            <Label>Facebook Share Link:</Label>
            <div className="flex gap-2">
              <Input 
                value={fbPostLink}
                readOnly
                className="text-xs"
              />
              <Button size="sm" variant="outline" onClick={copyToClipboard}>
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <Button 
              onClick={openFacebookPost}
              variant="outline"
              className="w-full"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              Post to Facebook
            </Button>
          </div>
        )}
        
        <div className="text-xs text-muted-foreground">
          <p>• Link includes "Deliver Now" button</p>
          <p>• Customers can order directly from Facebook</p>
          <p>• Automatic delivery integration</p>
        </div>
      </CardContent>
    </Card>
  );
};