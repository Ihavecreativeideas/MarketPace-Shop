import React, { useState, useEffect } from 'react';
import { useAuth } from './AuthProvider';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Package, Truck, Star, Eye, RotateCcw } from 'lucide-react';

interface Order {
  id: string;
  type: 'marketplace' | 'delivery' | 'pharmacy';
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  total: number;
  created_at: string;
  items?: any[];
  pickup_address?: string;
  delivery_address?: string;
  rating?: number;
}

export const OrderHistory: React.FC = () => {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'marketplace' | 'delivery' | 'pharmacy'>('all');

  useEffect(() => {
    if (user) {
      fetchOrders();
    }
  }, [user]);

  const fetchOrders = async () => {
    try {
      // Fetch from multiple tables
      const [marketplaceOrders, deliveries, pharmacyOrders] = await Promise.all([
        supabase.from('marketplace_orders').select('*').eq('buyer_id', user?.id),
        supabase.from('deliveries').select('*').eq('user_id', user?.id),
        supabase.from('pharmacy_orders').select('*').eq('user_id', user?.id)
      ]);

      const allOrders: Order[] = [
        ...(marketplaceOrders.data || []).map(order => ({
          ...order,
          type: 'marketplace' as const
        })),
        ...(deliveries.data || []).map(delivery => ({
          ...delivery,
          type: 'delivery' as const
        })),
        ...(pharmacyOrders.data || []).map(order => ({
          ...order,
          type: 'pharmacy' as const
        }))
      ];

      setOrders(allOrders.sort((a, b) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      ));
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500';
      case 'confirmed': return 'bg-blue-500';
      case 'in_progress': return 'bg-orange-500';
      case 'completed': return 'bg-green-500';
      case 'cancelled': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'marketplace': return <Package className="h-4 w-4" />;
      case 'delivery': return <Truck className="h-4 w-4" />;
      case 'pharmacy': return <Package className="h-4 w-4" />;
      default: return <Package className="h-4 w-4" />;
    }
  };

  const filteredOrders = filter === 'all' ? orders : orders.filter(order => order.type === filter);

  const reorderItem = async (orderId: string) => {
    // Implement reorder logic
    console.log('Reordering:', orderId);
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading order history...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto p-4">
      <Card>
        <CardHeader>
          <CardTitle>Order History</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={filter} onValueChange={(value) => setFilter(value as any)}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All Orders</TabsTrigger>
              <TabsTrigger value="marketplace">Marketplace</TabsTrigger>
              <TabsTrigger value="delivery">Delivery</TabsTrigger>
              <TabsTrigger value="pharmacy">Pharmacy</TabsTrigger>
            </TabsList>
            
            <TabsContent value={filter} className="mt-6">
              {filteredOrders.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No orders found
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredOrders.map((order) => (
                    <Card key={order.id} className="border">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            {getTypeIcon(order.type)}
                            <span className="font-medium">Order #{order.id.slice(-8)}</span>
                            <Badge className={getStatusColor(order.status)}>
                              {order.status}
                            </Badge>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold">${order.total?.toFixed(2)}</p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(order.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        
                        {order.pickup_address && (
                          <div className="text-sm text-muted-foreground mb-2">
                            <p>From: {order.pickup_address}</p>
                            {order.delivery_address && (
                              <p>To: {order.delivery_address}</p>
                            )}
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            {order.rating && (
                              <div className="flex items-center">
                                <Star className="h-4 w-4 text-yellow-500 mr-1" />
                                <span className="text-sm">{order.rating}</span>
                              </div>
                            )}
                          </div>
                          
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4 mr-1" />
                              View Details
                            </Button>
                            {order.status === 'completed' && (
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => reorderItem(order.id)}
                              >
                                <RotateCcw className="h-4 w-4 mr-1" />
                                Reorder
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};