import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Truck, DollarSign, MapPin, Clock, Calculator } from 'lucide-react';
import LargeItemDeliveryCalculator from './LargeItemDeliveryCalculator';

const LargeItemDeliveryPay: React.FC = () => {
  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <Truck className="w-6 h-6" />
            Large Item Deliveries
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4 mb-6">
            <div className="bg-white p-4 rounded-lg border-2 border-green-200 text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">$40</div>
              <div className="text-sm font-semibold text-gray-700">Fixed Rate for Large Items</div>
              <div className="text-xs text-gray-600">Up to 20 miles</div>
            </div>
            
            <div className="bg-white p-4 rounded-lg border-2 border-orange-200 text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">$1</div>
              <div className="text-sm font-semibold text-gray-700">Per Mile Over 20</div>
              <div className="text-xs text-gray-600">Additional payment</div>
            </div>
          </div>
          
          <div className="bg-green-50 p-4 rounded-lg border border-green-200 mb-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="font-semibold text-green-800">100% Tips from Buyers & Sellers</span>
            </div>
            <p className="text-sm text-green-700">Drivers keep 100% of all tips received from both buyers and sellers</p>
          </div>
          
          <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
            <div className="flex items-center gap-2 mb-2">
              <MapPin className="w-5 h-5 text-yellow-600" />
              <span className="font-semibold text-yellow-800">Large Items Include:</span>
            </div>
            <ul className="text-yellow-700 text-sm space-y-1">
              <li>• Furniture</li>
              <li>• Appliances</li>
              <li>• Exercise equipment</li>
              <li>• Other bulky items requiring special handling</li>
            </ul>
          </div>
          
          <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800">
              <strong>Note:</strong> Large item deliveries are paid at a flat rate of $40 up to 20 miles, 
              plus $1 per mile over 20 miles. Both buyers and sellers are encouraged to tip.
            </p>
          </div>
        </CardContent>
      </Card>

      <LargeItemDeliveryCalculator />

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            Driver Earnings Examples
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-gray-800 mb-1">$40</div>
              <div className="text-sm text-gray-600 mb-2">15 mile delivery</div>
              <Badge variant="outline">Flat rate</Badge>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-green-600 mb-1">$45</div>
              <div className="text-sm text-gray-600 mb-2">25 mile delivery</div>
              <Badge className="bg-green-600">$40 + $5 overage</Badge>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-blue-600 mb-1">$50</div>
              <div className="text-sm text-gray-600 mb-2">30 mile delivery</div>
              <Badge className="bg-blue-600">$40 + $10 overage</Badge>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
            <p className="text-sm text-green-800">
              <strong>100% Tips:</strong> Drivers keep 100% of all tips from both buyers and sellers. 
              Tips are encouraged for all deliveries, especially challenging ones.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LargeItemDeliveryPay;