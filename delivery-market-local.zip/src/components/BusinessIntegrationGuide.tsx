import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ExternalLink, CheckCircle, FileText, Building } from 'lucide-react';

interface IntegrationStep {
  title: string;
  description: string;
  url: string;
  required: string[];
  completed: boolean;
}

export const BusinessIntegrationGuide: React.FC = () => {
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);

  const integrationSteps: IntegrationStep[] = [
    {
      title: 'IRS EIN Registration',
      description: 'Apply for your Employer Identification Number (EIN) with the IRS',
      url: 'https://www.irs.gov/businesses/small-businesses-self-employed/apply-for-an-employer-identification-number-ein-online',
      required: ['Business name', 'Business address', 'Responsible party info'],
      completed: completedSteps.includes('ein')
    },
    {
      title: 'State Business Registration',
      description: 'Register your LLC with your state government',
      url: 'https://www.sba.gov/business-guide/launch-your-business/register-your-business',
      required: ['Articles of Organization', 'Registered agent', 'Filing fee'],
      completed: completedSteps.includes('state')
    },
    {
      title: 'Business Bank Account',
      description: 'Open a dedicated business banking account',
      url: 'https://www.chase.com/business/banking/business-checking',
      required: ['EIN', 'Articles of Organization', 'Operating Agreement'],
      completed: completedSteps.includes('banking')
    },
    {
      title: 'Stripe Business Account',
      description: 'Set up payment processing for your MarketPace integration',
      url: 'https://dashboard.stripe.com/register',
      required: ['EIN', 'Business bank account', 'Business address'],
      completed: completedSteps.includes('stripe')
    },
    {
      title: 'PayPal Business Account',
      description: 'Create PayPal business account for additional payment options',
      url: 'https://www.paypal.com/us/webapps/mpp/account-selection',
      required: ['EIN', 'Business bank account', 'Business information'],
      completed: completedSteps.includes('paypal')
    },
    {
      title: 'Square Business Account',
      description: 'Register for Square POS and payment processing',
      url: 'https://squareup.com/signup',
      required: ['EIN', 'Business details', 'Bank account info'],
      completed: completedSteps.includes('square')
    },
    {
      title: 'Google My Business',
      description: 'Create your Google Business Profile for local visibility',
      url: 'https://www.google.com/business/',
      required: ['Business name', 'Address', 'Phone number', 'Category'],
      completed: completedSteps.includes('google')
    },
    {
      title: 'Facebook Business Manager',
      description: 'Set up Facebook Business Manager for social commerce',
      url: 'https://business.facebook.com/overview',
      required: ['Facebook account', 'Business information', 'EIN'],
      completed: completedSteps.includes('facebook')
    },
    {
      title: 'Apple Business Register',
      description: 'Register for Apple Business services and App Store Connect',
      url: 'https://developer.apple.com/programs/enroll/',
      required: ['Apple ID', 'Business verification', 'EIN', 'D-U-N-S Number'],
      completed: completedSteps.includes('apple')
    },
    {
      title: 'Business Insurance',
      description: 'Obtain general liability and business insurance',
      url: 'https://www.next-insurance.com/',
      required: ['Business details', 'EIN', 'Industry classification'],
      completed: completedSteps.includes('insurance')
    }
  ];

  const toggleStep = (stepKey: string) => {
    setCompletedSteps(prev => 
      prev.includes(stepKey) 
        ? prev.filter(s => s !== stepKey)
        : [...prev, stepKey]
    );
  };

  const completionPercentage = Math.round((completedSteps.length / integrationSteps.length) * 100);

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building className="w-6 h-6" />
          Business Integration Setup Guide
        </CardTitle>
        <CardDescription>
          Complete these steps to properly integrate your business with MarketPace and payment processors
        </CardDescription>
        <div className="flex items-center gap-2">
          <div className="flex-1 bg-gray-200 rounded-full h-2">
            <div 
              className="bg-green-500 h-2 rounded-full transition-all duration-300" 
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
          <span className="text-sm font-medium">{completionPercentage}% Complete</span>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="setup" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="setup">Setup Steps</TabsTrigger>
            <TabsTrigger value="requirements">Requirements</TabsTrigger>
          </TabsList>
          
          <TabsContent value="setup" className="space-y-4">
            {integrationSteps.map((step, index) => {
              const stepKey = step.title.toLowerCase().split(' ')[0];
              return (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold">{step.title}</h3>
                        {step.completed && (
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{step.description}</p>
                      <div className="flex flex-wrap gap-1 mb-3">
                        {step.required.map((req, reqIndex) => (
                          <Badge key={reqIndex} variant="outline" className="text-xs">
                            {req}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex flex-col gap-2 ml-4">
                      <Button
                        size="sm"
                        onClick={() => window.open(step.url, '_blank')}
                        className="whitespace-nowrap"
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Start Setup
                      </Button>
                      <Button
                        size="sm"
                        variant={step.completed ? "default" : "outline"}
                        onClick={() => toggleStep(stepKey)}
                      >
                        {step.completed ? 'Completed' : 'Mark Complete'}
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </TabsContent>
          
          <TabsContent value="requirements" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Essential Documents
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="text-sm space-y-1">
                    <p>• EIN (Employer Identification Number)</p>
                    <p>• Articles of Organization</p>
                    <p>• Operating Agreement</p>
                    <p>• Business License</p>
                    <p>• Registered Agent Information</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Building className="w-5 h-5" />
                    Business Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="text-sm space-y-1">
                    <p>• Legal Business Name</p>
                    <p>• Business Address</p>
                    <p>• Business Phone Number</p>
                    <p>• Business Email</p>
                    <p>• Industry Classification</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};