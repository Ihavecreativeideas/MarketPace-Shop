declare global {
  interface Window {
    FB: {
      init: (params: {
        appId: string;
        cookie: boolean;
        xfbml: boolean;
        version: string;
      }) => void;
      login: (
        callback: (response: {
          authResponse?: {
            accessToken: string;
            userID: string;
            expiresIn: number;
          };
          status: string;
        }) => void,
        options?: { scope: string }
      ) => void;
      api: (
        path: string,
        params: { fields: string },
        callback: (response: {
          name: string;
          email: string;
          id: string;
        }) => void
      ) => void;
    };
    fbAsyncInit: () => void;
  }
}

export {};