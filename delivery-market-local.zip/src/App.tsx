import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import { LaunchProvider } from '@/contexts/LaunchContext';
import { CartProvider } from '@/components/CartContext';
import { EnhancedAuthProvider } from '@/components/EnhancedAuthProvider';
import { PWAInstaller, NotificationManager, OfflineIndicator } from '@/components/PWAFeatures';
import Navigation from '@/components/Navigation';
import PreLaunchMeter from '@/components/PreLaunchMeter';
import Index from '@/pages/Index';
import SetupPage from '@/pages/SetupPage';
import MarketplacePage from '@/pages/MarketplacePage';
import MusiciansPage from '@/pages/MusiciansPage';
import PaceMakersPage from '@/pages/PaceMakersPage';
import SubscriptionsPage from '@/pages/SubscriptionsPage';
import PartnerSignupFlyerPage from '@/pages/PartnerSignupFlyerPage';
import BusinessSetupPage from '@/pages/BusinessSetupPage';
import MedPaceEnhanced from '@/components/MedPaceEnhanced';
import DriverPortalEnhanced from '@/components/DriverPortalEnhanced';
import PharmacyPickupNotification from '@/components/PharmacyPickupNotification';
import DriverApplication from '@/components/DriverApplication';
import CampaignSignup from '@/components/CampaignSignup';
import DriverJobDescription from '@/components/DriverJobDescription';
import PostPace from '@/components/PostPace';
import MarketplacePartnerSignup from '@/components/MarketplacePartnerSignup';
import PartnerSignupFlow from '@/components/PartnerSignupFlow';
import PartnerAIDashboard from '@/components/PartnerAIDashboard';
import BusinessDashboard from '@/components/BusinessDashboard';
import { UserProfile } from '@/components/UserProfile';
import { RealTimeTracking } from '@/components/RealTimeTracking';
import { OrderHistory } from '@/components/OrderHistory';
import { AnalyticsDashboard } from '@/components/AnalyticsDashboard';
import { IntegrationsPage } from '@/components/IntegrationsPage';
import './App.css';

function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="vite-ui-theme">
      <EnhancedAuthProvider>
        <LaunchProvider>
          <CartProvider>
            <Router>
              <div className="min-h-screen bg-background">
                <OfflineIndicator />
                <Navigation />
                <div className="container mx-auto px-2 sm:px-4 pt-2 sm:pt-4">
                  <PWAInstaller />
                  <PreLaunchMeter />
                </div>
                <main className="pb-4">
                  <Routes>
                    <Route path="/" element={<Index />} />
                    <Route path="/setup" element={<SetupPage />} />
                    <Route path="/marketplace" element={<MarketplacePage />} />
                    <Route path="/pacemakers" element={<PaceMakersPage />} />
                    <Route path="/musicians" element={<MusiciansPage />} />
                    <Route path="/subscriptions" element={<SubscriptionsPage />} />
                    <Route path="/subscriptions/:userId" element={<SubscriptionsPage />} />
                    <Route path="/partner-signup" element={<PartnerSignupFlyerPage />} />
                    <Route path="/partner-signup-form" element={<PartnerSignupFlow />} />
                    <Route path="/marketplace-partner" element={<MarketplacePartnerSignup />} />
                    <Route path="/business-dashboard" element={<BusinessDashboard />} />
                    <Route path="/business-setup" element={<BusinessSetupPage />} />
                    <Route path="/integrations" element={<IntegrationsPage />} />
                    <Route path="/medpace" element={<MedPaceEnhanced />} />
                    <Route path="/postpace" element={<PostPace />} />
                    <Route path="/driver-portal" element={<DriverPortalEnhanced />} />
                    <Route path="/pharmacy-tracking" element={<PharmacyPickupNotification />} />
                    <Route path="/driver-application" element={<DriverApplication />} />
                    <Route path="/driver-job" element={<DriverJobDescription />} />
                    <Route path="/campaign-signup" element={<CampaignSignup />} />
                    <Route path="/profile" element={<UserProfile />} />
                    <Route path="/orders" element={<OrderHistory />} />
                    <Route path="/tracking/:orderId" element={
                      <RealTimeTracking orderId={window.location.pathname.split('/')[2]} />
                    } />
                    <Route path="/analytics" element={<AnalyticsDashboard isAdmin={true} />} />
                    <Route path="/vendor-analytics/:vendorId" element={
                      <AnalyticsDashboard vendorId={window.location.pathname.split('/')[2]} />
                    } />
                    <Route path="/notifications" element={<NotificationManager />} />
                    <Route path="/ai-assistant" element={
                      <PartnerAIDashboard 
                        partnerTier="marketplace"
                        userId="user-123"
                      />
                    } />
                    <Route path="*" element={<Index />} />
                  </Routes>
                </main>
                <Toaster />
              </div>
            </Router>
          </CartProvider>
        </LaunchProvider>
      </EnhancedAuthProvider>
    </ThemeProvider>
  );
}

export default App;