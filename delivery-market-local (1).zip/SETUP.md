# MarketPace Setup Guide

## 🚀 Quick Start (Choose Your Method)

### Method 1: GitHub Codespaces (Fastest - No Install)
1. Go to your GitHub repository
2. Click green **"Code"** button
3. Select **"Codespaces"** tab
4. Click **"Create codespace on main"**
5. Wait 2-3 minutes for automatic setup
6. Terminal will open automatically - run:
   ```bash
   npm install && npm run dev
   ```
7. Click the **forwarded port link** (port 5173)
8. ✅ App is running! Guest mode works immediately

### Method 2: StackBlitz (Browser-Based)
1. Go to [stackblitz.com](https://stackblitz.com)
2. Click **"Import from GitHub"**
3. Paste your repository URL
4. Wait for automatic setup (30 seconds)
5. ✅ App starts automatically in browser

### Method 3: Local Development
**Prerequisites:** Node.js v18+ installed

1. **Clone the repository:**
   ```bash
   git clone <your-repo-url>
   cd marketpace
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Start development server:**
   ```bash
   npm run dev
   ```

4. **Open in browser:**
   ```
   http://localhost:5173
   ```

## ✅ What You'll See

### Welcome Screen Features:
- **"Continue as Guest"** button (purple) - No signup required
- Browse all marketplace items, musicians, services
- Security badges: HIPAA Compliant, SSL Encrypted, PCI DSS
- Purchase restrictions for guests (modal appears)

### Immediate Access:
- ✅ Browse marketplace
- ✅ View musician profiles  
- ✅ Check delivery services
- ✅ See all products and pricing
- ❌ Purchase (requires signup)
- ❌ Sell items (requires signup)

## 🔧 Optional: Supabase Backend Setup

**Only needed for:** User accounts, purchases, data persistence

### Step 1: Create Supabase Project
1. Go to [supabase.com](https://supabase.com)
2. Sign up/login
3. Click **"New Project"**
4. Fill project details, wait 2-3 minutes

### Step 2: Get Credentials
1. In Supabase dashboard: **Settings > API**
2. Copy:
   - **Project URL**
   - **anon public key**

### Step 3: Configure Environment
1. **Create environment file:**
   ```bash
   cp .env.example .env.local
   ```

2. **Edit .env.local with your credentials:**
   ```env
   VITE_SUPABASE_URL=https://your-project-id.supabase.co
   VITE_SUPABASE_ANON_KEY=your-actual-anon-key
   ```

3. **Restart development server:**
   ```bash
   npm run dev
   ```

### Step 4: Database Tables (Auto-Created)
The app will automatically create these tables when users interact:
- `users` - User profiles
- `products` - Marketplace items
- `orders` - Purchase history
- `reviews` - Ratings and feedback

## 🛠️ Making Simple Changes

### Key Files to Edit:
- **Welcome message:** `src/components/WelcomeScreen.tsx` (line 41)
- **Guest button text:** `src/components/WelcomeScreen.tsx` (line 67)
- **Marketplace items:** `src/components/Marketplace.tsx`
- **Security messages:** `src/components/SecurePaymentWrapper.tsx`

### Common Customizations:
```javascript
// Change welcome text
"Welcome to MarketPace" → "Welcome to YourApp"

// Modify guest button
"Continue as Guest" → "Browse Without Account"

// Update security badges
"HIPAA Compliant" → "Your Security Standard"
```

## 🚨 Troubleshooting

### Build Errors:
1. Check browser console (F12)
2. Verify Node.js version: `node --version` (needs v18+)
3. Clear cache: `npm run build:dev`

### Guest Mode Issues:
1. Check `WelcomeScreen.tsx` is imported in `App.tsx`
2. Verify `SecureAuthProvider` wraps the app
3. Look for console errors

### Supabase Connection:
1. Verify credentials in `.env.local`
2. Check network connection
3. Confirm project is active in Supabase dashboard

## 📱 Testing Checklist

- [ ] App loads at localhost:5173
- [ ] "Continue as Guest" button appears
- [ ] Can browse marketplace without signup
- [ ] Purchase attempt shows restriction modal
- [ ] Responsive on mobile devices
- [ ] No console errors

## 🚀 Production Deployment

### Build for Production:
```bash
npm run build
npm run preview  # Test production build
```

### Deploy Options:
- **Vercel:** Connect GitHub repo, auto-deploy
- **Netlify:** Drag & drop `dist` folder
- **GitHub Pages:** Enable in repo settings

## 🔒 Security Notes

- ✅ Guest mode collects no personal data
- ✅ All sensitive data encrypted
- ✅ HIPAA compliant architecture
- ❌ Never commit `.env.local` to git
- ❌ Replace demo data before production

---

**🎉 You're Ready!** The app now runs with secure guest access. Users can explore everything without providing personal information, and are prompted to sign up only when making purchases or selling items.