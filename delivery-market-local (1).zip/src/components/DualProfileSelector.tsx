import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { User, Briefcase, Switch } from 'lucide-react';

interface DualProfileSelectorProps {
  currentProfile: 'personal' | 'professional';
  onProfileChange: (profile: 'personal' | 'professional') => void;
  showFullSelector?: boolean;
}

const DualProfileSelector: React.FC<DualProfileSelectorProps> = ({
  currentProfile,
  onProfileChange,
  showFullSelector = false
}) => {
  if (!showFullSelector) {
    return (
      <div className="flex items-center space-x-2 mb-4">
        <Button
          variant={currentProfile === 'personal' ? 'default' : 'outline'}
          size="sm"
          onClick={() => onProfileChange('personal')}
          className="flex items-center"
        >
          <User size={16} className="mr-1" />
          Personal
        </Button>
        <Button
          variant={currentProfile === 'professional' ? 'default' : 'outline'}
          size="sm"
          onClick={() => onProfileChange('professional')}
          className="flex items-center"
        >
          <Briefcase size={16} className="mr-1" />
          Professional
        </Button>
      </div>
    );
  }

  return (
    <div className="grid md:grid-cols-2 gap-6 mb-8">
      <Card 
        className={`cursor-pointer transition-all ${
          currentProfile === 'personal' 
            ? 'ring-2 ring-blue-500 bg-blue-50/50' 
            : 'hover:bg-gray-50'
        }`}
        onClick={() => onProfileChange('personal')}
      >
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <User className="text-blue-500 mr-2" size={24} />
              <CardTitle>Personal Profile</CardTitle>
            </div>
            {currentProfile === 'personal' && (
              <Badge className="bg-blue-500">Active</Badge>
            )}
          </div>
          <CardDescription>
            Share personal items, connect with friends, and engage in community discussions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• Post personal items for sale/rent</li>
            <li>• Community feed participation</li>
            <li>• Friend connections</li>
            <li>• Personal messaging</li>
          </ul>
        </CardContent>
      </Card>

      <Card 
        className={`cursor-pointer transition-all ${
          currentProfile === 'professional' 
            ? 'ring-2 ring-green-500 bg-green-50/50' 
            : 'hover:bg-gray-50'
        }`}
        onClick={() => onProfileChange('professional')}
      >
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Briefcase className="text-green-500 mr-2" size={24} />
              <CardTitle>Professional Profile</CardTitle>
            </div>
            {currentProfile === 'professional' && (
              <Badge className="bg-green-500">Active</Badge>
            )}
          </div>
          <CardDescription>
            Showcase your business, services, or entertainment offerings professionally
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• Business listings and services</li>
            <li>• Professional networking</li>
            <li>• Analytics and insights</li>
            <li>• Customer management</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};

export default DualProfileSelector;