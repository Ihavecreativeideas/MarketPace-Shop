import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Truck, 
  Store, 
  Music, 
  Crown, 
  Calendar, 
  MessageSquare, 
  BarChart3, 
  Shield,
  Zap,
  Globe
} from 'lucide-react';

interface ProfileFeaturesProps {
  membershipType: string;
  onFeatureClick: (feature: string) => void;
}

export const ProfileFeatures: React.FC<ProfileFeaturesProps> = ({ membershipType, onFeatureClick }) => {
  const getFeaturesByMembership = () => {
    switch (membershipType.toLowerCase()) {
      case 'driver':
        return [
          { 
            title: 'Delivery Dashboard', 
            description: 'Track routes, earnings, and delivery stats',
            icon: Truck,
            color: 'text-green-400',
            bgColor: 'bg-green-400/10',
            action: 'delivery-dashboard'
          },
          { 
            title: 'Route Optimizer', 
            description: 'AI-powered route planning for efficiency',
            icon: Zap,
            color: 'text-blue-400',
            bgColor: 'bg-blue-400/10',
            action: 'route-optimizer'
          },
          { 
            title: 'Earnings Analytics', 
            description: 'Detailed breakdown of your income',
            icon: BarChart3,
            color: 'text-yellow-400',
            bgColor: 'bg-yellow-400/10',
            action: 'earnings-analytics'
          },
          { 
            title: 'Customer Messages', 
            description: 'Communicate with customers',
            icon: MessageSquare,
            color: 'text-purple-400',
            bgColor: 'bg-purple-400/10',
            action: 'messages'
          }
        ];
      
      case 'business':
        return [
          { 
            title: 'Store Management', 
            description: 'Manage inventory, orders, and listings',
            icon: Store,
            color: 'text-blue-400',
            bgColor: 'bg-blue-400/10',
            action: 'store-management'
          },
          { 
            title: 'Analytics Dashboard', 
            description: 'Sales metrics and customer insights',
            icon: BarChart3,
            color: 'text-green-400',
            bgColor: 'bg-green-400/10',
            action: 'analytics-dashboard'
          },
          { 
            title: 'Marketing Tools', 
            description: 'Promote your business and products',
            icon: Globe,
            color: 'text-purple-400',
            bgColor: 'bg-purple-400/10',
            action: 'marketing-tools'
          },
          { 
            title: 'Customer Support', 
            description: 'Handle customer inquiries and reviews',
            icon: MessageSquare,
            color: 'text-yellow-400',
            bgColor: 'bg-yellow-400/10',
            action: 'customer-support'
          }
        ];
      
      case 'musician':
        return [
          { 
            title: 'Gig Calendar', 
            description: 'Schedule and manage your performances',
            icon: Calendar,
            color: 'text-purple-400',
            bgColor: 'bg-purple-400/10',
            action: 'gig-calendar'
          },
          { 
            title: 'Music Portfolio', 
            description: 'Showcase your music and get discovered',
            icon: Music,
            color: 'text-blue-400',
            bgColor: 'bg-blue-400/10',
            action: 'music-portfolio'
          },
          { 
            title: 'Booking Management', 
            description: 'Handle gig requests and contracts',
            icon: Shield,
            color: 'text-green-400',
            bgColor: 'bg-green-400/10',
            action: 'booking-management'
          },
          { 
            title: 'Fan Engagement', 
            description: 'Connect with fans and build following',
            icon: MessageSquare,
            color: 'text-yellow-400',
            bgColor: 'bg-yellow-400/10',
            action: 'fan-engagement'
          }
        ];
      
      case 'pro':
        return [
          { 
            title: 'Premium Analytics', 
            description: 'Advanced insights and reporting',
            icon: BarChart3,
            color: 'text-yellow-400',
            bgColor: 'bg-yellow-400/10',
            action: 'premium-analytics'
          },
          { 
            title: 'Priority Support', 
            description: '24/7 dedicated customer support',
            icon: Crown,
            color: 'text-purple-400',
            bgColor: 'bg-purple-400/10',
            action: 'priority-support'
          },
          { 
            title: 'Advanced Tools', 
            description: 'Access to premium features and tools',
            icon: Zap,
            color: 'text-blue-400',
            bgColor: 'bg-blue-400/10',
            action: 'advanced-tools'
          },
          { 
            title: 'Multi-Platform', 
            description: 'Manage across all platforms',
            icon: Globe,
            color: 'text-green-400',
            bgColor: 'bg-green-400/10',
            action: 'multi-platform'
          }
        ];
      
      default:
        return [
          { 
            title: 'Basic Dashboard', 
            description: 'View your activity and orders',
            icon: BarChart3,
            color: 'text-blue-400',
            bgColor: 'bg-blue-400/10',
            action: 'basic-dashboard'
          },
          { 
            title: 'Messages', 
            description: 'Communicate with other users',
            icon: MessageSquare,
            color: 'text-green-400',
            bgColor: 'bg-green-400/10',
            action: 'messages'
          }
        ];
    }
  };

  const features = getFeaturesByMembership();

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Crown className="w-5 h-5 text-yellow-400" />
          {membershipType.toUpperCase()} Features
          <Badge variant="secondary" className="ml-2">
            {features.length} Available
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <div
                key={index}
                className="p-4 rounded-lg border border-slate-700 hover:border-slate-600 transition-colors cursor-pointer"
                onClick={() => onFeatureClick(feature.action)}
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg ${feature.bgColor}`}>
                    <IconComponent className={`w-5 h-5 ${feature.color}`} />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-white mb-1">{feature.title}</h3>
                    <p className="text-sm text-slate-400">{feature.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};