import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { SelfDeliveryOptions } from './SelfDeliveryOptions';
import { ArrowLeft, CreditCard, MapPin } from 'lucide-react';

interface CheckoutItem {
  id: string;
  title: string;
  price: number;
  image?: string;
  seller_name: string;
  location: string;
  self_pickup_available?: boolean;
  marketplace_delivery_available?: boolean;
  shop_delivery_available?: boolean;
  shop_delivery_fee?: number;
}

interface EnhancedCheckoutPageProps {
  items: CheckoutItem[];
  onBack: () => void;
  onComplete: () => void;
}

const EnhancedCheckoutPage: React.FC<EnhancedCheckoutPageProps> = ({
  items,
  onBack,
  onComplete
}) => {
  const [deliveryOptions, setDeliveryOptions] = useState<{[key: string]: string}>({});
  const [shippingAddress, setShippingAddress] = useState({
    street: '',
    city: '',
    state: '',
    zip: ''
  });
  const [paymentMethod, setPaymentMethod] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    name: ''
  });
  const [tipAmount, setTipAmount] = useState(0);

  const getDeliveryOptionsForItem = (item: CheckoutItem) => {
    const options = [];
    
    if (item.self_pickup_available) {
      options.push({
        type: 'self_pickup' as const,
        available: true,
        fee: 0,
        description: 'Pick up the item yourself from the seller\'s location'
      });
    }
    
    if (item.marketplace_delivery_available) {
      options.push({
        type: 'marketplace_delivery' as const,
        available: true,
        fee: 15,
        estimatedTime: '2-4 hours',
        description: 'Fast delivery by MarketPace drivers'
      });
    }
    
    if (item.shop_delivery_available) {
      options.push({
        type: 'shop_delivery' as const,
        available: true,
        fee: item.shop_delivery_fee || 5,
        estimatedTime: '1-2 business days',
        description: 'Delivery by the shop\'s own delivery service'
      });
    }
    
    return options;
  };

  const calculateSubtotal = () => {
    return items.reduce((sum, item) => sum + item.price, 0);
  };

  const calculateDeliveryFees = () => {
    return items.reduce((sum, item) => {
      const selectedOption = deliveryOptions[item.id];
      if (!selectedOption || selectedOption === 'self_pickup') return sum;
      
      const options = getDeliveryOptionsForItem(item);
      const option = options.find(opt => opt.type === selectedOption);
      return sum + (option?.fee || 0);
    }, 0);
  };

  const calculateTotal = () => {
    return calculateSubtotal() + calculateDeliveryFees() + tipAmount;
  };

  const handleCheckout = () => {
    const hasDeliveryItems = items.some(item => 
      deliveryOptions[item.id] && deliveryOptions[item.id] !== 'self_pickup'
    );
    
    if (hasDeliveryItems && (!shippingAddress.street || !shippingAddress.city)) {
      alert('Please provide a delivery address');
      return;
    }
    
    if (!paymentMethod.cardNumber || !paymentMethod.name) {
      alert('Please provide payment information');
      return;
    }
    
    onComplete();
  };

  const needsShippingAddress = items.some(item => 
    deliveryOptions[item.id] && deliveryOptions[item.id] !== 'self_pickup'
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={onBack}
            className="text-white hover:bg-white/10 mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <h1 className="text-3xl font-bold text-white">Checkout</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center gap-4 p-4 bg-white/5 rounded-lg">
                    <div className="w-16 h-16 bg-white/10 rounded-lg flex items-center justify-center">
                      {item.image ? (
                        <img src={item.image} alt={item.title} className="w-full h-full object-cover rounded-lg" />
                      ) : (
                        <div className="text-2xl">📦</div>
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-white font-semibold">{item.title}</h3>
                      <p className="text-gray-400 text-sm">by {item.seller_name}</p>
                      <div className="flex items-center gap-1 text-gray-400 text-sm">
                        <MapPin className="w-3 h-3" />
                        <span>{item.location}</span>
                      </div>
                    </div>
                    <div className="text-green-400 font-semibold">
                      ${item.price.toFixed(2)}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {items.map((item) => (
              <Card key={`delivery-${item.id}`} className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white text-lg">
                    Delivery for: {item.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <SelfDeliveryOptions
                    options={getDeliveryOptionsForItem(item)}
                    selectedOption={deliveryOptions[item.id] || ''}
                    onOptionSelect={(option) => setDeliveryOptions(prev => ({ ...prev, [item.id]: option }))}
                    itemLocation={item.location}
                  />
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="space-y-6">
            {needsShippingAddress && (
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Delivery Address</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="street" className="text-white">Street Address</Label>
                    <Input
                      id="street"
                      value={shippingAddress.street}
                      onChange={(e) => setShippingAddress(prev => ({ ...prev, street: e.target.value }))}
                      className="bg-white/10 border-white/20 text-white"
                      placeholder="123 Main St"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="city" className="text-white">City</Label>
                      <Input
                        id="city"
                        value={shippingAddress.city}
                        onChange={(e) => setShippingAddress(prev => ({ ...prev, city: e.target.value }))}
                        className="bg-white/10 border-white/20 text-white"
                      />
                    </div>
                    <div>
                      <Label htmlFor="state" className="text-white">State</Label>
                      <Input
                        id="state"
                        value={shippingAddress.state}
                        onChange={(e) => setShippingAddress(prev => ({ ...prev, state: e.target.value }))}
                        className="bg-white/10 border-white/20 text-white"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <CreditCard className="w-5 h-5" />
                  Payment Method
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="cardName" className="text-white">Cardholder Name</Label>
                  <Input
                    id="cardName"
                    value={paymentMethod.name}
                    onChange={(e) => setPaymentMethod(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-white/10 border-white/20 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="cardNumber" className="text-white">Card Number</Label>
                  <Input
                    id="cardNumber"
                    value={paymentMethod.cardNumber}
                    onChange={(e) => setPaymentMethod(prev => ({ ...prev, cardNumber: e.target.value }))}
                    className="bg-white/10 border-white/20 text-white"
                    placeholder="1234 5678 9012 3456"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Add Tip (Optional)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2 mb-4">
                  {[5, 10, 15, 20].map(amount => (
                    <Button
                      key={amount}
                      variant={tipAmount === amount ? "default" : "outline"}
                      size="sm"
                      onClick={() => setTipAmount(amount)}
                      className="flex-1"
                    >
                      ${amount}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Order Total</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between text-gray-300">
                  <span>Subtotal:</span>
                  <span>${calculateSubtotal().toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>Delivery Fees:</span>
                  <span>${calculateDeliveryFees().toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>Tip:</span>
                  <span>${tipAmount.toFixed(2)}</span>
                </div>
                <Separator className="bg-white/20" />
                <div className="flex justify-between text-white font-semibold text-lg">
                  <span>Total:</span>
                  <span>${calculateTotal().toFixed(2)}</span>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleCheckout}
              className="w-full bg-green-600 hover:bg-green-700 text-white py-3 text-lg font-semibold"
            >
              Complete Purchase
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnhancedCheckoutPage;
export { EnhancedCheckoutPage };