import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { DollarSign, Clock, Shield, Users } from 'lucide-react';

const DriverJobDescription: React.FC = () => {
  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          Independent Contractor Position
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <h3 className="font-semibold text-blue-900 mb-2">Job Overview</h3>
          <p className="text-blue-800 text-sm">
            Join MarketPace as an Independent Contractor driver! Deliver packages, food, and items 
            within your local community while setting your own schedule and earning competitive pay.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-green-600" />
              <span className="font-medium">Payment Structure</span>
            </div>
            <ul className="text-sm space-y-1 ml-6">
              <li>• Base rate: $3-8 per delivery</li>
              <li>• Distance bonus: $0.50/mile</li>
              <li>• Large item bonus: +$5-15</li>
              <li>• Peak time multipliers</li>
            </ul>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-600" />
              <span className="font-medium">Instant Payment</span>
            </div>
            <div className="bg-green-50 p-3 rounded border border-green-200">
              <p className="text-sm text-green-800 font-medium">
                💰 Get paid immediately after completing each route!
              </p>
              <p className="text-xs text-green-700 mt-1">
                No waiting for weekly payouts - earnings are available instantly.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-purple-600" />
            <span className="font-medium">Requirements (Same as Uber Standards)</span>
          </div>
          <div className="grid md:grid-cols-2 gap-2">
            <Badge variant="outline">Valid Driver's License</Badge>
            <Badge variant="outline">Clean Background Check</Badge>
            <Badge variant="outline">Vehicle Insurance</Badge>
            <Badge variant="outline">18+ Years Old</Badge>
            <Badge variant="outline">Reliable Vehicle</Badge>
            <Badge variant="outline">Smartphone</Badge>
          </div>
        </div>

        <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
          <p className="text-sm text-yellow-800">
            <strong>Independent Contractor Status:</strong> You will work as an independent contractor, 
            not an employee. You're responsible for your own taxes, insurance, and vehicle maintenance. 
            You have the flexibility to choose your own hours and work areas.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default DriverJobDescription;