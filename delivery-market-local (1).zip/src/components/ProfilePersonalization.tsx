import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Slider } from './ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { User, MapPin, Target, Store, Wrench, Music, Save, Plus, X } from 'lucide-react';

const ProfilePersonalization: React.FC = () => {
  const [profileData, setProfileData] = useState({
    name: 'John Doe',
    bio: 'Local entrepreneur passionate about connecting communities through commerce.',
    address: '123 Main St, Springfield, IL',
    city: 'Springfield',
    state: 'IL',
    zipCode: '62701',
    radius: 15,
    interests: ['Electronics', 'Music', 'Home & Garden'],
    accountType: 'dual' as 'personal' | 'dual',
    businessType: 'shops' as 'shops' | 'services' | 'entertainment' | '',
    notifications: {
      email: true,
      sms: false,
      push: true,
      marketing: false
    },
    privacy: {
      showAddress: false,
      showPhone: false,
      publicProfile: true
    }
  });

  const [customInterest, setCustomInterest] = useState('');

  const availableInterests = [
    'Electronics', 'Fashion', 'Home & Garden', 'Sports', 'Books', 'Music',
    'Food & Dining', 'Health & Beauty', 'Automotive', 'Toys & Games',
    'Art & Crafts', 'Travel', 'Fitness', 'Technology', 'Photography'
  ];

  const handleInputChange = (field: string, value: any) => {
    setProfileData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleNestedChange = (parent: string, field: string, value: any) => {
    setProfileData(prev => ({
      ...prev,
      [parent]: {
        ...prev[parent as keyof typeof prev] as any,
        [field]: value
      }
    }));
  };

  const handleInterestToggle = (interest: string) => {
    setProfileData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const addCustomInterest = () => {
    if (customInterest.trim() && !profileData.interests.includes(customInterest.trim())) {
      setProfileData(prev => ({
        ...prev,
        interests: [...prev.interests, customInterest.trim()]
      }));
      setCustomInterest('');
    }
  };

  const removeInterest = (interest: string) => {
    setProfileData(prev => ({
      ...prev,
      interests: prev.interests.filter(i => i !== interest)
    }));
  };

  const handleSave = () => {
    console.log('Saving profile data:', profileData);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Personalize Your Profile</h1>
          <p className="text-gray-600">Customize your MarketPace experience</p>
        </div>

        {/* Basic Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Basic Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  value={profileData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Enter your full name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Street Address</Label>
                <Input
                  id="address"
                  value={profileData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  placeholder="123 Main St"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                value={profileData.bio}
                onChange={(e) => handleInputChange('bio', e.target.value)}
                placeholder="Tell us about yourself..."
                className="min-h-[100px]"
              />
            </div>
          </CardContent>
        </Card>

        {/* Location & Delivery */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Location & Delivery
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Delivery Radius: {profileData.radius} miles</Label>
              <Slider
                value={[profileData.radius]}
                onValueChange={(value) => handleInputChange('radius', value[0])}
                max={50}
                min={1}
                step={1}
                className="w-full"
              />
              <p className="text-sm text-gray-600">
                This determines how far you're willing to travel for pickups/deliveries
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Interests */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5" />
              Your Interests
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              Select topics you're interested in to personalize your feed and recommendations
            </p>
            <div className="flex flex-wrap gap-2">
              {availableInterests.map((interest) => (
                <Badge
                  key={interest}
                  variant={profileData.interests.includes(interest) ? 'default' : 'outline'}
                  className="cursor-pointer transition-colors"
                  onClick={() => handleInterestToggle(interest)}
                >
                  {interest}
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                value={customInterest}
                onChange={(e) => setCustomInterest(e.target.value)}
                placeholder="Add custom interest"
                onKeyPress={(e) => e.key === 'Enter' && addCustomInterest()}
              />
              <Button onClick={addCustomInterest} size="sm">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            {profileData.interests.length > 0 && (
              <div className="space-y-2">
                <Label>Selected Interests:</Label>
                <div className="flex flex-wrap gap-2">
                  {profileData.interests.map((interest) => (
                    <Badge key={interest} variant="secondary" className="flex items-center gap-1">
                      {interest}
                      <X
                        className="w-3 h-3 cursor-pointer hover:text-red-500"
                        onClick={() => removeInterest(interest)}
                      />
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Account Type */}
        <Card>
          <CardHeader>
            <CardTitle>Account Type</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-base font-medium">Dual Account (Personal + Business)</Label>
                <p className="text-sm text-gray-600">Enable business features alongside personal account</p>
              </div>
              <Switch
                checked={profileData.accountType === 'dual'}
                onCheckedChange={(checked) => 
                  handleInputChange('accountType', checked ? 'dual' : 'personal')
                }
              />
            </div>
            {profileData.accountType === 'dual' && (
              <div className="space-y-4 pt-4 border-t">
                <Label>Business Type</Label>
                <div className="grid grid-cols-1 gap-2">
                  {[
                    { value: 'shops', label: 'Shops - Sell physical products', icon: Store },
                    { value: 'services', label: 'Services - Offer professional services', icon: Wrench },
                    { value: 'entertainment', label: 'Entertainment - Musicians, DJs, performers', icon: Music }
                  ].map((type) => {
                    const Icon = type.icon;
                    return (
                      <Button
                        key={type.value}
                        variant={profileData.businessType === type.value ? 'default' : 'outline'}
                        onClick={() => handleInputChange('businessType', type.value)}
                        className="flex items-center gap-2 justify-start h-auto p-3"
                      >
                        <Icon className="w-4 h-4" />
                        <span className="text-left">{type.label}</span>
                      </Button>
                    );
                  })}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Notification Preferences */}
        <Card>
          <CardHeader>
            <CardTitle>Notification Preferences</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { key: 'email', label: 'Email Notifications', desc: 'Order updates, messages, and important alerts' },
              { key: 'sms', label: 'SMS Notifications', desc: 'Urgent delivery updates and security alerts' },
              { key: 'push', label: 'Push Notifications', desc: 'Real-time updates in the app' },
              { key: 'marketing', label: 'Marketing Communications', desc: 'Promotions, deals, and newsletter' }
            ].map((notification) => (
              <div key={notification.key} className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">{notification.label}</Label>
                  <p className="text-sm text-gray-600">{notification.desc}</p>
                </div>
                <Switch
                  checked={profileData.notifications[notification.key as keyof typeof profileData.notifications]}
                  onCheckedChange={(checked) => 
                    handleNestedChange('notifications', notification.key, checked)
                  }
                />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Privacy Settings */}
        <Card>
          <CardHeader>
            <CardTitle>Privacy Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { key: 'showAddress', label: 'Show Address Publicly', desc: 'Display your address on your public profile' },
              { key: 'showPhone', label: 'Show Phone Number', desc: 'Allow others to see your phone number' },
              { key: 'publicProfile', label: 'Public Profile', desc: 'Make your profile visible to all users' }
            ].map((privacy) => (
              <div key={privacy.key} className="flex items-center justify-between">
                <div>
                  <Label className="text-base font-medium">{privacy.label}</Label>
                  <p className="text-sm text-gray-600">{privacy.desc}</p>
                </div>
                <Switch
                  checked={profileData.privacy[privacy.key as keyof typeof profileData.privacy]}
                  onCheckedChange={(checked) => 
                    handleNestedChange('privacy', privacy.key, checked)
                  }
                />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex justify-center">
          <Button onClick={handleSave} className="flex items-center gap-2 px-8">
            <Save className="w-4 h-4" />
            Save Profile
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProfilePersonalization;