import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { UniversalBackButton } from './UniversalBackButton';
import { Calendar as CalendarIcon, Clock, DollarSign, User, MapPin } from 'lucide-react';

interface BookingPageProps {
  serviceProvider: {
    id: string;
    name: string;
    service: string;
    location: string;
    rating: number;
    bookingFee: number;
    serviceFee: number;
    image?: string;
    availableTimes: string[];
    cancellationPolicy: string;
  };
  onBack: () => void;
  onBookingComplete: () => void;
}

const BookingPage: React.FC<BookingPageProps> = ({
  serviceProvider,
  onBack,
  onBookingComplete
}) => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState('');
  const [eventDetails, setEventDetails] = useState('');
  const [customRequests, setCustomRequests] = useState('');
  const [paymentMethod, setPaymentMethod] = useState({
    cardNumber: '',
    name: '',
    expiryDate: '',
    cvv: ''
  });

  const totalAmount = serviceProvider.bookingFee + serviceProvider.serviceFee;

  const handleBooking = () => {
    if (!selectedDate || !selectedTime) {
      alert('Please select a date and time');
      return;
    }
    
    if (!eventDetails.trim()) {
      alert('Please describe your event needs');
      return;
    }
    
    if (!paymentMethod.cardNumber || !paymentMethod.name) {
      alert('Please provide payment information');
      return;
    }
    
    // Process booking
    onBookingComplete();
  };

  const isDateAvailable = (date: Date) => {
    const today = new Date();
    return date >= today;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-indigo-900 to-purple-900 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6">
          <UniversalBackButton customAction={onBack} />
          <h1 className="text-3xl font-bold text-white mt-4">Book Service</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Service Provider
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center">
                    {serviceProvider.image ? (
                      <img src={serviceProvider.image} alt={serviceProvider.name} className="w-full h-full object-cover rounded-full" />
                    ) : (
                      <User className="w-8 h-8 text-white" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-lg">{serviceProvider.name}</h3>
                    <p className="text-gray-300">{serviceProvider.service}</p>
                    <div className="flex items-center gap-1 text-gray-400 text-sm">
                      <MapPin className="w-3 h-3" />
                      <span>{serviceProvider.location}</span>
                    </div>
                    <Badge className="mt-1 bg-yellow-500/20 text-yellow-300">
                      ⭐ {serviceProvider.rating}/5
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <CalendarIcon className="w-5 h-5" />
                  Select Date & Time
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-white mb-2 block">Choose Date</Label>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) => !isDateAvailable(date)}
                    className="bg-white/5 rounded-lg border border-white/20"
                  />
                </div>
                
                {selectedDate && (
                  <div>
                    <Label className="text-white mb-2 block">Available Times</Label>
                    <div className="grid grid-cols-3 gap-2">
                      {serviceProvider.availableTimes.map((time) => (
                        <Button
                          key={time}
                          variant={selectedTime === time ? "default" : "outline"}
                          size="sm"
                          onClick={() => setSelectedTime(time)}
                          className="text-sm"
                        >
                          {time}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white">Event Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="eventDetails" className="text-white">Describe Your Event/Service Needs *</Label>
                  <Textarea
                    id="eventDetails"
                    value={eventDetails}
                    onChange={(e) => setEventDetails(e.target.value)}
                    className="bg-white/10 border-white/20 text-white mt-2"
                    placeholder="Please describe what you need for your event..."
                    rows={4}
                  />
                </div>
                
                <div>
                  <Label htmlFor="customRequests" className="text-white">Special Requests (Optional)</Label>
                  <Textarea
                    id="customRequests"
                    value={customRequests}
                    onChange={(e) => setCustomRequests(e.target.value)}
                    className="bg-white/10 border-white/20 text-white mt-2"
                    placeholder="Any special requirements or requests..."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Booking Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-gray-300">
                    <span>Booking Fee:</span>
                    <span>${serviceProvider.bookingFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-gray-300">
                    <span>Service Fee:</span>
                    <span>${serviceProvider.serviceFee.toFixed(2)}</span>
                  </div>
                  <Separator className="bg-white/20" />
                  <div className="flex justify-between text-white font-semibold text-lg">
                    <span>Total:</span>
                    <span>${totalAmount.toFixed(2)}</span>
                  </div>
                </div>
                
                <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-3">
                  <p className="text-blue-300 text-sm">
                    💡 Funds will be held until the day after your booking to ensure service quality.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white">Payment Method</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="cardName" className="text-white">Cardholder Name</Label>
                  <Input
                    id="cardName"
                    value={paymentMethod.name}
                    onChange={(e) => setPaymentMethod(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-white/10 border-white/20 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="cardNumber" className="text-white">Card Number</Label>
                  <Input
                    id="cardNumber"
                    value={paymentMethod.cardNumber}
                    onChange={(e) => setPaymentMethod(prev => ({ ...prev, cardNumber: e.target.value }))}
                    className="bg-white/10 border-white/20 text-white"
                    placeholder="1234 5678 9012 3456"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white">Cancellation Policy</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-sm">
                  {serviceProvider.cancellationPolicy}
                </p>
                <div className="mt-3 p-3 bg-green-500/20 border border-green-500/30 rounded-lg">
                  <p className="text-green-300 text-sm">
                    ✅ If the provider cancels, you receive a full refund.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleBooking}
              className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white py-3 text-lg font-semibold"
            >
              Confirm Booking
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingPage;
export { BookingPage };