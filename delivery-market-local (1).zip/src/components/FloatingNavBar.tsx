import { useEffect, useState } from "react";
import {
  Home,
  ShoppingBag,
  Music,
  Users,
  Hammer,
  MessageSquare,
  Menu,
} from "lucide-react";

export const FloatingNavBar = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      setIsVisible(lastScrollY > currentScrollY || currentScrollY < 10);
      setLastScrollY(currentScrollY);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [lastScrollY]);

  const mainLinks = [
    { icon: <Home />, href: "/", onClick: () => setExpanded(!expanded) },
    { icon: <ShoppingBag />, href: "/marketplace" },
    { icon: <Music />, href: "/entertainment" },
    { icon: <Users />, href: "/services" },
    { icon: <Hammer />, href: "/handcrafted" },
    { icon: <MessageSquare />, href: "/community" },
  ];

  const extraLinks = [
    { name: "Rent Anything", href: "/rent" },
    { name: "Driver Hub", href: "/driver-hub" },
    { name: "Privacy Policies", href: "/privacy" },
    { name: "Professional Dashboard", href: "/dashboard" },
    { name: "Ad Center", href: "/ads" },
    { name: "Favorites", href: "/favorites" },
    { name: "Events", href: "/events" },
    { name: "Upgrade to MarketPlace Pro", href: "/marketplace-pro" },
  ];

  return (
    <>
      <nav
        className={`fixed bottom-0 z-50 w-full bg-white shadow-md transition-transform duration-300 ${
          isVisible ? "translate-y-0" : "translate-y-full"
        }`}
      >
        <div className="flex justify-around items-center h-14">
          {mainLinks.map((link, i) =>
            link.onClick ? (
              <button key={i} onClick={link.onClick} className="p-2 hover:bg-gray-100 rounded">
                {link.icon}
              </button>
            ) : (
              <a key={i} href={link.href} className="p-2 hover:bg-gray-100 rounded">
                {link.icon}
              </a>
            )
          )}
        </div>
      </nav>

      {expanded && (
        <div className="fixed bottom-14 left-0 right-0 bg-white p-4 shadow-lg z-40 border-t">
          <ul className="grid grid-cols-2 gap-3">
            {extraLinks.map((link) => (
              <li key={link.href}>
                <a href={link.href} className="block text-sm text-blue-700 hover:text-blue-900 p-2 rounded hover:bg-blue-50">
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
    </>
  );
};