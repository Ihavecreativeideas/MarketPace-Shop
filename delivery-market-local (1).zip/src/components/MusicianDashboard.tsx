import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Music, ShoppingBag, Users, Calendar, Link, Star } from 'lucide-react';
import EquipmentListing from './EquipmentListing';
import BandRecruitment from './BandRecruitment';
import EventCreator from './EventCreator';
import EventCalendar from './EventCalendar';
import MusicLinks from './MusicLinks';
import MusicianSubscription from './MusicianSubscription';

const MusicianDashboard = () => {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          Musician Hub
        </h1>
        <p className="text-gray-600">
          Your complete platform for music, equipment, events, and fan engagement
        </p>
      </div>

      <Tabs defaultValue="equipment" className="w-full">
        <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
          <TabsTrigger value="equipment" className="flex items-center gap-2">
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden sm:inline">Equipment</span>
          </TabsTrigger>
          <TabsTrigger value="recruitment" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            <span className="hidden sm:inline">Recruit</span>
          </TabsTrigger>
          <TabsTrigger value="events" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span className="hidden sm:inline">Events</span>
          </TabsTrigger>
          <TabsTrigger value="calendar" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span className="hidden sm:inline">Calendar</span>
          </TabsTrigger>
          <TabsTrigger value="music" className="flex items-center gap-2">
            <Link className="w-4 h-4" />
            <span className="hidden sm:inline">Music</span>
          </TabsTrigger>
          <TabsTrigger value="pro" className="flex items-center gap-2">
            <Star className="w-4 h-4" />
            <span className="hidden sm:inline">Pro</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="equipment" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5" />
                Equipment Marketplace
              </CardTitle>
              <p className="text-gray-600">
                Buy, sell, rent, or trade music equipment with other musicians and fans
              </p>
            </CardHeader>
            <CardContent>
              <EquipmentListing />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recruitment" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Find Band Members
              </CardTitle>
              <p className="text-gray-600">
                Connect with local musicians to form or join bands
              </p>
            </CardHeader>
            <CardContent>
              <BandRecruitment />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="events" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Live Events
              </CardTitle>
              <p className="text-gray-600">
                Create and manage your live performances and shows
              </p>
            </CardHeader>
            <CardContent>
              <EventCreator />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar" className="space-y-6">
          <EventCalendar />
        </TabsContent>

        <TabsContent value="music" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Music className="w-5 h-5" />
                Share Your Music
              </CardTitle>
              <p className="text-gray-600">
                Add links to your music across all streaming platforms
              </p>
            </CardHeader>
            <CardContent>
              <MusicLinks />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pro" className="space-y-6">
          <MusicianSubscription />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MusicianDashboard;