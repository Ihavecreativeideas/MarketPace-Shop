import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Truck, MapPin, Clock, DollarSign } from 'lucide-react';

interface DeliveryOption {
  type: 'self_pickup' | 'marketplace_delivery' | 'shop_delivery';
  available: boolean;
  fee?: number;
  estimatedTime?: string;
  description: string;
}

interface SelfDeliveryOptionsProps {
  options: DeliveryOption[];
  selectedOption: string;
  onOptionSelect: (option: string) => void;
  itemLocation?: string;
}

const SelfDeliveryOptions: React.FC<SelfDeliveryOptionsProps> = ({
  options,
  selectedOption,
  onOptionSelect,
  itemLocation
}) => {
  const getOptionIcon = (type: string) => {
    switch (type) {
      case 'self_pickup':
        return <MapPin className="w-5 h-5" />;
      case 'marketplace_delivery':
        return <Truck className="w-5 h-5" />;
      case 'shop_delivery':
        return <Truck className="w-5 h-5" />;
      default:
        return <MapPin className="w-5 h-5" />;
    }
  };

  const getOptionTitle = (type: string) => {
    switch (type) {
      case 'self_pickup':
        return 'Self Pickup';
      case 'marketplace_delivery':
        return 'MarketPace Delivery';
      case 'shop_delivery':
        return 'Shop Delivery';
      default:
        return 'Unknown';
    }
  };

  const availableOptions = options.filter(option => option.available);

  if (availableOptions.length === 0) {
    return (
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardContent className="p-4">
          <p className="text-gray-300 text-center">No delivery options available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white mb-4">Choose Delivery Option</h3>
      
      {availableOptions.map((option) => (
        <Card 
          key={option.type}
          className={`cursor-pointer transition-all ${
            selectedOption === option.type
              ? 'bg-blue-600/20 border-blue-400 ring-2 ring-blue-400'
              : 'bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20'
          }`}
          onClick={() => onOptionSelect(option.type)}
        >
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${
                  selectedOption === option.type ? 'bg-blue-500' : 'bg-white/10'
                }`}>
                  {getOptionIcon(option.type)}
                </div>
                <div>
                  <CardTitle className="text-white text-base">
                    {getOptionTitle(option.type)}
                  </CardTitle>
                  {option.estimatedTime && (
                    <div className="flex items-center gap-1 text-sm text-gray-400">
                      <Clock className="w-3 h-3" />
                      <span>{option.estimatedTime}</span>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="text-right">
                {option.fee !== undefined ? (
                  <div className="flex items-center gap-1 text-green-400 font-semibold">
                    <DollarSign className="w-4 h-4" />
                    <span>${option.fee.toFixed(2)}</span>
                  </div>
                ) : (
                  <Badge variant="outline" className="border-green-400 text-green-400">
                    FREE
                  </Badge>
                )}
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="pt-0">
            <p className="text-gray-300 text-sm">{option.description}</p>
            
            {option.type === 'self_pickup' && itemLocation && (
              <div className="mt-2 p-2 bg-white/5 rounded-lg">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <MapPin className="w-3 h-3" />
                  <span>Pickup Location: {itemLocation}</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default SelfDeliveryOptions;
export { SelfDeliveryOptions };