import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, TrendingDown, Users, MapPin, Store, Music, Wrench, DollarSign } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AnalyticsData {
  totalUsers: number;
  activeUsers: number;
  totalTowns: number;
  totalDrivers: number;
  totalBusinesses: number;
  totalDeliveries: number;
}

interface CampaignStats {
  membersJoined: number;
  townsParticipating: number;
  shopsLive: number;
  servicesLive: number;
  entertainersLive: number;
  growthRate: number;
}

interface AdminAnalyticsProps {
  data: AnalyticsData;
}

export default function AdminAnalytics({ data }: AdminAnalyticsProps) {
  const [campaignStats, setCampaignStats] = useState<CampaignStats>({
    membersJoined: 0,
    townsParticipating: 0,
    shopsLive: 0,
    servicesLive: 0,
    entertainersLive: 0,
    growthRate: 0
  });
  const [weeklyGrowth] = useState({
    users: 12.5,
    businesses: 8.3,
    deliveries: 15.7,
    revenue: 22.1
  });

  useEffect(() => {
    loadCampaignStats();
  }, []);

  const loadCampaignStats = async () => {
    try {
      const { data: businesses, error } = await supabase
        .from('business_profiles')
        .select('business_type, status');

      if (error) throw error;

      const activeBusinesses = (businesses || []).filter(b => b.status === 'active');
      const shops = activeBusinesses.filter(b => b.business_type === 'shop').length;
      const services = activeBusinesses.filter(b => b.business_type === 'service').length;
      const entertainers = activeBusinesses.filter(b => b.business_type === 'entertainment').length;

      setCampaignStats({
        membersJoined: data.totalUsers,
        townsParticipating: data.totalTowns,
        shopsLive: shops,
        servicesLive: services,
        entertainersLive: entertainers,
        growthRate: 15.8
      });
    } catch (error) {
      console.error('Error loading campaign stats:', error);
    }
  };

  const getGrowthIcon = (growth: number) => {
    return growth > 0 ? 
      <TrendingUp className="h-4 w-4 text-green-600" /> : 
      <TrendingDown className="h-4 w-4 text-red-600" />;
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">📊 Business Analytics</h2>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Platform Overview</TabsTrigger>
          <TabsTrigger value="campaign">Campaign Tracker</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Total Users
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{data.totalUsers.toLocaleString()}</div>
                <div className="flex items-center gap-1 text-sm text-green-600">
                  {getGrowthIcon(weeklyGrowth.users)}
                  +{weeklyGrowth.users}% this week
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Store className="h-4 w-4" />
                  Active Businesses
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{data.totalBusinesses.toLocaleString()}</div>
                <div className="flex items-center gap-1 text-sm text-green-600">
                  {getGrowthIcon(weeklyGrowth.businesses)}
                  +{weeklyGrowth.businesses}% this week
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Towns Activated
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{data.totalTowns}</div>
                <div className="text-sm text-muted-foreground">Across 3 states</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Total Deliveries
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{data.totalDeliveries.toLocaleString()}</div>
                <div className="flex items-center gap-1 text-sm text-green-600">
                  {getGrowthIcon(weeklyGrowth.deliveries)}
                  +{weeklyGrowth.deliveries}% this week
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="campaign">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>🚀 Live Campaign Tracker</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-teal-600">{campaignStats.membersJoined.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">Members Joined</div>
                    <Progress value={75} className="mt-2" />
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">{campaignStats.townsParticipating}</div>
                    <div className="text-sm text-muted-foreground">Towns Participating</div>
                    <Progress value={60} className="mt-2" />
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">
                      {campaignStats.shopsLive + campaignStats.servicesLive + campaignStats.entertainersLive}
                    </div>
                    <div className="text-sm text-muted-foreground">Businesses Live</div>
                    <Progress value={45} className="mt-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Store className="h-4 w-4" />
                    Shops Live
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-600">{campaignStats.shopsLive}</div>
                  <div className="text-sm text-muted-foreground">Retail & Products</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Wrench className="h-4 w-4" />
                    Services Live
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-600">{campaignStats.servicesLive}</div>
                  <div className="text-sm text-muted-foreground">Professional Services</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Music className="h-4 w-4" />
                    Entertainers Live
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-pink-600">{campaignStats.entertainersLive}</div>
                  <div className="text-sm text-muted-foreground">Music & Events</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}