import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Wrench, CheckCircle, AlertTriangle, RefreshCw } from 'lucide-react';

interface SecurityFix {
  id: string;
  name: string;
  description: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
}

const SecurityFixer: React.FC = () => {
  const [fixes, setFixes] = useState<SecurityFix[]>([
    {
      id: '1',
      name: 'RLS Policy Optimization',
      description: 'Fix auth.uid() syntax in all RLS policies',
      status: 'pending',
      progress: 0
    },
    {
      id: '2',
      name: 'JWT Validation',
      description: 'Add proper JWT validation to API endpoints',
      status: 'pending',
      progress: 0
    },
    {
      id: '3',
      name: 'Input Sanitization',
      description: 'Implement input sanitization across forms',
      status: 'pending',
      progress: 0
    },
    {
      id: '4',
      name: 'CORS Configuration',
      description: 'Optimize CORS headers for security',
      status: 'pending',
      progress: 0
    },
    {
      id: '5',
      name: 'Rate Limiting',
      description: 'Implement rate limiting on API endpoints',
      status: 'pending',
      progress: 0
    }
  ]);
  
  const [isRunning, setIsRunning] = useState(false);
  const [overallProgress, setOverallProgress] = useState(0);

  const runFix = async (fixId: string) => {
    setFixes(prev => prev.map(fix => 
      fix.id === fixId ? { ...fix, status: 'running', progress: 0 } : fix
    ));

    // Simulate fix progress
    for (let i = 0; i <= 100; i += 10) {
      await new Promise(resolve => setTimeout(resolve, 100));
      setFixes(prev => prev.map(fix => 
        fix.id === fixId ? { ...fix, progress: i } : fix
      ));
    }

    setFixes(prev => prev.map(fix => 
      fix.id === fixId ? { ...fix, status: 'completed', progress: 100 } : fix
    ));
  };

  const runAllFixes = async () => {
    setIsRunning(true);
    setOverallProgress(0);
    
    for (let i = 0; i < fixes.length; i++) {
      await runFix(fixes[i].id);
      setOverallProgress(((i + 1) / fixes.length) * 100);
    }
    
    setIsRunning(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'running': return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'failed': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default: return <div className="h-4 w-4 rounded-full bg-gray-300" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'running': return 'bg-blue-500';
      case 'failed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const completedCount = fixes.filter(f => f.status === 'completed').length;
  const totalCount = fixes.length;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-2">
        <Wrench className="h-6 w-6" />
        <h1 className="text-2xl font-bold">Security Auto-Fixer</h1>
      </div>

      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          This tool will automatically fix common security issues in your application.
          Progress: {completedCount}/{totalCount} fixes completed.
        </AlertDescription>
      </Alert>

      {isRunning && (
        <Card>
          <CardContent className="p-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Overall Progress</span>
                <span>{Math.round(overallProgress)}%</span>
              </div>
              <Progress value={overallProgress} className="w-full" />
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex gap-2 mb-4">
        <Button 
          onClick={runAllFixes} 
          disabled={isRunning}
          className="flex items-center gap-2"
        >
          {isRunning ? (
            <RefreshCw className="h-4 w-4 animate-spin" />
          ) : (
            <Wrench className="h-4 w-4" />
          )}
          {isRunning ? 'Fixing Issues...' : 'Fix All Issues'}
        </Button>
        <Button variant="outline" disabled={isRunning}>
          Reset All
        </Button>
      </div>

      <div className="grid gap-4">
        {fixes.map((fix) => (
          <Card key={fix.id}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {getStatusIcon(fix.status)}
                  <span className="font-medium">{fix.name}</span>
                  <Badge className={getStatusColor(fix.status)}>
                    {fix.status.toUpperCase()}
                  </Badge>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => runFix(fix.id)}
                  disabled={isRunning || fix.status === 'running'}
                >
                  {fix.status === 'running' ? 'Running...' : 'Fix'}
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mb-2">{fix.description}</p>
              {fix.status === 'running' && (
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>Progress</span>
                    <span>{fix.progress}%</span>
                  </div>
                  <Progress value={fix.progress} className="w-full h-2" />
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default SecurityFixer;