import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Megaphone, Target, Calendar, DollarSign } from 'lucide-react';

interface AdCreationProps {
  user: any;
}

export function AdCreation({ user }: AdCreationProps) {
  const [showAdCreator, setShowAdCreator] = useState(false);
  const [adData, setAdData] = useState({
    title: '',
    description: '',
    adType: '',
    targetAudience: '',
    budget: '',
    duration: '',
    boostPost: false,
    promoteEvent: false
  });

  const adTypes = [
    'Product Promotion', 'Service Advertisement', 'Event Promotion',
    'Job Posting', 'Rental Listing', 'General Announcement'
  ];

  const targetAudiences = [
    'Local Community', 'Music Lovers', 'Families', 'Young Adults',
    'Professionals', 'Students', 'Seniors', 'Custom'
  ];

  const durations = ['1 Day', '3 Days', '1 Week', '2 Weeks', '1 Month'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would create the ad in Supabase
    console.log('Ad data:', adData);
    alert('Ad created successfully!');
    setShowAdCreator(false);
    setAdData({
      title: '', description: '', adType: '', targetAudience: '',
      budget: '', duration: '', boostPost: false, promoteEvent: false
    });
  };

  if (!user) return null;

  return (
    <div className="mt-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Megaphone className="w-5 h-5" />
            Promote Your Business
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!showAdCreator ? (
            <div className="text-center space-y-4">
              <p>Create targeted ads to reach your local community during our free trial period!</p>
              <div className="bg-green-50 p-3 rounded-lg">
                <p className="text-sm text-green-700 font-medium">
                  🎉 Launch Special: All advertising features are FREE during our 3-month trial!
                </p>
              </div>
              <Button onClick={() => setShowAdCreator(true)} className="w-full">
                <Target className="w-4 h-4 mr-2" />
                Create Ad
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Ad Title</Label>
                <Input
                  id="title"
                  value={adData.title}
                  onChange={(e) => setAdData(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Catchy headline for your ad"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="description">Ad Description</Label>
                <Textarea
                  id="description"
                  value={adData.description}
                  onChange={(e) => setAdData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe what you're promoting..."
                  rows={3}
                  required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Ad Type</Label>
                  <Select onValueChange={(value) => setAdData(prev => ({ ...prev, adType: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {adTypes.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label>Target Audience</Label>
                  <Select onValueChange={(value) => setAdData(prev => ({ ...prev, targetAudience: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Who to reach" />
                    </SelectTrigger>
                    <SelectContent>
                      {targetAudiences.map(audience => (
                        <SelectItem key={audience} value={audience}>{audience}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="budget">Budget (Currently Free!)</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="budget"
                      type="number"
                      value={adData.budget}
                      onChange={(e) => setAdData(prev => ({ ...prev, budget: e.target.value }))}
                      placeholder="0.00"
                      className="pl-10"
                      disabled
                    />
                  </div>
                  <p className="text-xs text-green-600 mt-1">Free during launch period!</p>
                </div>
                
                <div>
                  <Label>Duration</Label>
                  <Select onValueChange={(value) => setAdData(prev => ({ ...prev, duration: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="How long" />
                    </SelectTrigger>
                    <SelectContent>
                      {durations.map(duration => (
                        <SelectItem key={duration} value={duration}>{duration}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-3 border-t pt-4">
                <Label>Additional Options</Label>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="boostPost"
                    checked={adData.boostPost}
                    onCheckedChange={(checked) => 
                      setAdData(prev => ({ ...prev, boostPost: checked as boolean }))
                    }
                  />
                  <Label htmlFor="boostPost" className="text-sm">
                    Boost this post for maximum visibility
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="promoteEvent"
                    checked={adData.promoteEvent}
                    onCheckedChange={(checked) => 
                      setAdData(prev => ({ ...prev, promoteEvent: checked as boolean }))
                    }
                  />
                  <Label htmlFor="promoteEvent" className="text-sm">
                    Add to community events calendar
                  </Label>
                </div>
              </div>
              
              <div className="bg-blue-50 p-3 rounded-lg">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <p className="text-sm text-blue-700">
                    <strong>Pro Tip:</strong> Schedule your ads to run during peak community hours (6-9 PM) for better engagement!
                  </p>
                </div>
              </div>
              
              <div className="flex gap-2">
                <Button type="submit" className="flex-1">
                  Create Ad (Free!)
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowAdCreator(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}