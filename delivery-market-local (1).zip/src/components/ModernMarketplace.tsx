import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, Music, Store, Wrench, Star, Heart, Share2, Eye } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface MarketItem {
  id: string;
  title: string;
  price: number;
  category: 'product' | 'service' | 'music';
  image: string;
  rating: number;
  views: number;
  likes: number;
  seller: string;
  isNew?: boolean;
  isTrending?: boolean;
}

const ModernMarketplace = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [likedItems, setLikedItems] = useState<Set<string>>(new Set());

  const mockItems: MarketItem[] = [
    {
      id: '1',
      title: 'Handcrafted Acoustic Guitar',
      price: 899,
      category: 'music',
      image: '/placeholder.svg',
      rating: 4.8,
      views: 1234,
      likes: 89,
      seller: 'MusicCraft Pro',
      isNew: true
    },
    {
      id: '2',
      title: 'Professional Photography',
      price: 299,
      category: 'service',
      image: '/placeholder.svg',
      rating: 4.9,
      views: 856,
      likes: 156,
      seller: 'PhotoStudio Elite',
      isTrending: true
    },
    {
      id: '3',
      title: 'Artisan Coffee Beans',
      price: 24,
      category: 'product',
      image: '/placeholder.svg',
      rating: 4.7,
      views: 2341,
      likes: 234,
      seller: 'Local Roasters'
    }
  ];

  const categories = [
    { id: 'all', label: 'All', icon: ShoppingBag },
    { id: 'product', label: 'Products', icon: Store },
    { id: 'service', label: 'Services', icon: Wrench },
    { id: 'music', label: 'Music', icon: Music }
  ];

  const toggleLike = (itemId: string) => {
    const newLiked = new Set(likedItems);
    if (newLiked.has(itemId)) {
      newLiked.delete(itemId);
    } else {
      newLiked.add(itemId);
    }
    setLikedItems(newLiked);
  };

  const filteredItems = selectedCategory === 'all' 
    ? mockItems 
    : mockItems.filter(item => item.category === selectedCategory);

  return (
    <div className="space-y-8">
      {/* Category Filter */}
      <motion.div 
        className="flex flex-wrap gap-4 justify-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <Button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              variant={selectedCategory === category.id ? 'default' : 'outline'}
              className={`flex items-center space-x-2 px-6 py-3 rounded-full transition-all duration-300 ${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white shadow-lg'
                  : 'bg-white/5 border-white/20 text-gray-300 hover:bg-white/10'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{category.label}</span>
            </Button>
          );
        })}
      </motion.div>

      {/* Items Grid */}
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        layout
      >
        {filteredItems.map((item, index) => (
          <motion.div
            key={item.id}
            layout
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
            whileHover={{ y: -8, scale: 1.02 }}
            className="group"
          >
            <Card className="bg-white/5 backdrop-blur-lg border-white/10 overflow-hidden hover:shadow-2xl transition-all duration-300">
              <div className="relative">
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
                />
                
                {/* Badges */}
                <div className="absolute top-3 left-3 flex space-x-2">
                  {item.isNew && (
                    <Badge className="bg-green-500 text-white px-2 py-1 text-xs">
                      NEW
                    </Badge>
                  )}
                  {item.isTrending && (
                    <Badge className="bg-orange-500 text-white px-2 py-1 text-xs">
                      TRENDING
                    </Badge>
                  )}
                </div>
                
                {/* Quick Actions */}
                <div className="absolute top-3 right-3 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => toggleLike(item.id)}
                    className={`p-2 rounded-full bg-white/20 backdrop-blur-sm ${
                      likedItems.has(item.id) ? 'text-red-400' : 'text-white'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${likedItems.has(item.id) ? 'fill-current' : ''}`} />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="p-2 rounded-full bg-white/20 backdrop-blur-sm text-white"
                  >
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <CardContent className="p-4">
                <h3 className="font-semibold text-lg mb-2 text-white group-hover:text-cyan-400 transition-colors">
                  {item.title}
                </h3>
                
                <div className="flex items-center justify-between mb-3">
                  <span className="text-2xl font-bold text-cyan-400">
                    ${item.price}
                  </span>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="text-sm text-gray-300">{item.rating}</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                  <span>{item.seller}</span>
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-1">
                      <Eye className="w-3 h-3" />
                      <span>{item.views}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Heart className="w-3 h-3" />
                      <span>{item.likes}</span>
                    </div>
                  </div>
                </div>
                
                <Button className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white">
                  View Details
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
};

export default ModernMarketplace;