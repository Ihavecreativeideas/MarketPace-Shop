import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Crown, Star, Gift, Zap } from 'lucide-react';
import EquipmentCard from './EquipmentCard';
import ArtistBookingCard from './ArtistBookingCard';
import MusicDiscovery from './MusicDiscovery';
import ForHireSearchBar from './ForHireSearchBar';
import MarketPaceProPromotion from './MarketPaceProPromotion';
import TrialEraSubscriptionModal from './TrialEraSubscriptionModal';
import { toast } from '@/hooks/use-toast';

const EnhancedMusicianMarket: React.FC = () => {
  const [showProModal, setShowProModal] = useState(false);
  const [isProSubscriber, setIsProSubscriber] = useState(false);
  const [showPromotion, setShowPromotion] = useState(true);

  const handleProSubscription = () => {
    setShowProModal(true);
  };

  const handleSubscriptionComplete = (subscriptionData: any) => {
    setIsProSubscriber(true);
    setShowPromotion(false);
    console.log('Pro subscription activated:', subscriptionData);
  };

  // Mock data
  const mockEquipment = [
    {
      id: 1,
      name: 'Fender Stratocaster',
      price: 1200,
      type: 'sale',
      image: '/placeholder.svg',
      condition: 'Excellent',
      location: 'Downtown',
      seller: 'Mike Johnson'
    },
    {
      id: 2,
      name: 'Marshall Amp Stack',
      price: 150,
      type: 'rent',
      image: '/placeholder.svg',
      condition: 'Good',
      location: 'Midtown',
      seller: 'Sarah\'s Music'
    }
  ];

  const mockArtists = [
    {
      id: 1,
      name: 'DJ Mike',
      type: 'DJ',
      rating: 4.8,
      hourlyRate: 150,
      image: '/placeholder.svg',
      location: 'Downtown',
      verified: true,
      specialties: ['Weddings', 'Corporate Events']
    },
    {
      id: 2,
      name: 'The Blues Brothers',
      type: 'Band',
      rating: 4.9,
      hourlyRate: 300,
      image: '/placeholder.svg',
      location: 'Uptown',
      verified: true,
      specialties: ['Blues', 'Rock']
    }
  ];

  return (
    <div className="space-y-6">
      {/* Pro Subscription Promotion - Show to non-subscribers */}
      {showPromotion && !isProSubscriber && (
        <MarketPaceProPromotion 
          onSubscribe={handleProSubscription}
          isTrialUser={true}
        />
      )}

      {/* Pro Subscriber Welcome */}
      {isProSubscriber && (
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-300">
          <CardContent className="p-4 text-center">
            <div className="flex justify-center mb-2">
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-2 rounded-full">
                <Crown className="w-6 h-6 text-white" />
              </div>
            </div>
            <h3 className="text-lg font-bold text-purple-800 mb-1">
              🎉 Welcome to MarketPace Pro!
            </h3>
            <p className="text-sm text-purple-700">
              You now have lifetime access to all professional features during our trial era.
            </p>
            <Badge className="mt-2 bg-purple-600 text-white">
              <Star className="w-3 h-3 mr-1" />
              Pro Member - Lifetime Benefits
            </Badge>
          </CardContent>
        </Card>
      )}

      {/* Market Header */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">
            🎵 Musician Market
          </CardTitle>
          <p className="text-center text-gray-600">
            Buy, Sell, and Rent Music Equipment • Book Artists • Hire Soundmen/DJs • Discover New Music
          </p>
        </CardHeader>
      </Card>

      {/* For Hire Search Bar */}
      <ForHireSearchBar />

      {/* Main Market Tabs */}
      <Tabs defaultValue="equipment" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="equipment">Equipment</TabsTrigger>
          <TabsTrigger value="artists">Book Artists</TabsTrigger>
          <TabsTrigger value="services">Services</TabsTrigger>
          <TabsTrigger value="discover">Discover Music</TabsTrigger>
        </TabsList>

        <TabsContent value="equipment" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Music Equipment</h3>
            <div className="flex gap-2">
              <Badge variant="outline">Buy</Badge>
              <Badge variant="outline">Sell</Badge>
              <Badge variant="outline">Rent</Badge>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockEquipment.map((item) => (
              <EquipmentCard key={item.id} equipment={item} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="artists" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Book Artists & Performers</h3>
            <Badge variant="outline">Available Now</Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mockArtists.map((artist) => (
              <ArtistBookingCard key={artist.id} artist={artist} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="services" className="space-y-4">
          <div className="text-center py-8">
            <h3 className="text-lg font-semibold mb-2">Professional Services</h3>
            <p className="text-gray-600 mb-4">Find sound engineers, producers, and technical support</p>
            <Button variant="outline">
              <Zap className="w-4 h-4 mr-2" />
              Browse Services
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="discover" className="space-y-4">
          <MusicDiscovery />
        </TabsContent>
      </Tabs>

      {/* Pro Subscription Modal */}
      <TrialEraSubscriptionModal
        isOpen={showProModal}
        onClose={() => setShowProModal(false)}
        onSubscriptionComplete={handleSubscriptionComplete}
      />
    </div>
  );
};

export default EnhancedMusicianMarket;