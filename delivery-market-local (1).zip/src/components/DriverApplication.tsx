import React, { useState } from 'react';
import { BackButton } from './BackButton';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Alert, AlertDescription } from './ui/alert';
import { UserCheck, Shield, Truck, AlertCircle, DollarSign } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import DriverLicenseUpload from './DriverLicenseUpload';
import BackgroundCheckUpload from './BackgroundCheckUpload';
import VehicleTypeSelector from './VehicleTypeSelector';

const DriverApplication: React.FC = () => {
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', phone: '',
    hasInsurance: false, hasDriversLicense: false, hasBackgroundCheck: false,
    vehicleType: '', deliveryTypes: [] as string[]
  });
  const [licenseFile, setLicenseFile] = useState<File | null>(null);
  const [backgroundFile, setBackgroundFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleDeliveryTypeChange = (type: string, checked: boolean) => {
    if (checked) {
      setFormData({...formData, deliveryTypes: [...formData.deliveryTypes, type]});
    } else {
      setFormData({...formData, deliveryTypes: formData.deliveryTypes.filter(t => t !== type)});
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!licenseFile || !backgroundFile) {
      alert('Please upload both your driver\'s license and background check documents.');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const formDataToSend = new FormData();
      formDataToSend.append('firstName', formData.firstName);
      formDataToSend.append('lastName', formData.lastName);
      formDataToSend.append('email', formData.email);
      formDataToSend.append('phone', formData.phone);
      formDataToSend.append('hasInsurance', formData.hasInsurance.toString());
      formDataToSend.append('hasDriversLicense', formData.hasDriversLicense.toString());
      formDataToSend.append('hasBackgroundCheck', formData.hasBackgroundCheck.toString());
      formDataToSend.append('vehicleType', formData.vehicleType);
      formDataToSend.append('deliveryTypes', JSON.stringify(formData.deliveryTypes));
      formDataToSend.append('licenseFile', licenseFile);
      formDataToSend.append('backgroundFile', backgroundFile);
      
      const response = await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/0801246c-b0bf-4774-9d2c-89520ad05718', {
        method: 'POST',
        body: formDataToSend
      });
      
      const result = await response.json();
      if (result.success) {
        alert(`Application received! We'll review your application and notify you within 24 hours. Username: ${result.credentials.username}`);
        navigate('/driver-login');
      } else {
        alert('Application needs review: ' + result.message);
      }
    } catch (error) {
      alert('Error submitting application. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isFormValid = formData.hasInsurance && formData.hasDriversLicense && formData.hasBackgroundCheck && 
                      licenseFile && backgroundFile && formData.vehicleType && formData.deliveryTypes.length > 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <BackButton to="/driver-job" />
        
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Driver Application</h1>
          <p className="text-gray-600">Apply to join PostPace as an Independent Contractor</p>
        </div>

        <Alert className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Important:</strong> You will be hired as an Independent Contractor. You must have valid insurance, 
            driver's license, and provide your own background check. We hold drivers to Uber standards.
          </AlertDescription>
        </Alert>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Job Description & Payment
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <p><strong>Position:</strong> Independent Contractor Delivery Driver</p>
              <p><strong>Payment Structure:</strong></p>
              <ul className="ml-4 space-y-1">
                <li>• $4.00 per pickup</li>
                <li>• $2.00 per drop-off</li>
                <li>• $0.50 per mile distance bonus</li>
                <li>• 100% of customer tips</li>
              </ul>
              <p><strong>Payment:</strong> Paid immediately after completing each route</p>
              <p><strong>Note:</strong> Food/grocery delivery requires business partnership with Shipt/UberEats/DoorDash (free during trial, subscription required after)</p>
            </div>
          </CardContent>
        </Card>

        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCheck className="w-5 h-5" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input 
                    id="firstName" 
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input 
                    id="lastName" 
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input 
                  id="email" 
                  type="email" 
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input 
                  id="phone" 
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="w-5 h-5" />
                Vehicle & Delivery Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <VehicleTypeSelector 
                value={formData.vehicleType}
                onChange={(value) => setFormData({...formData, vehicleType: value})}
              />
              
              <div>
                <Label className="text-base font-medium">Delivery Types You Can Handle *</Label>
                <div className="mt-2 space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="small" 
                      checked={formData.deliveryTypes.includes('small')}
                      onCheckedChange={(checked) => handleDeliveryTypeChange('small', !!checked)}
                    />
                    <Label htmlFor="small">Small Items (documents, packages, small electronics)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="medium" 
                      checked={formData.deliveryTypes.includes('medium')}
                      onCheckedChange={(checked) => handleDeliveryTypeChange('medium', !!checked)}
                    />
                    <Label htmlFor="medium">Medium Items (appliances, boxes, multiple bags)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="large" 
                      checked={formData.deliveryTypes.includes('large')}
                      onCheckedChange={(checked) => handleDeliveryTypeChange('large', !!checked)}
                    />
                    <Label htmlFor="large">Large Items (furniture, mattresses, workout equipment)</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="mt-6 space-y-6">
            <DriverLicenseUpload 
              onFileUpload={setLicenseFile} 
              uploadedFile={licenseFile} 
            />
            
            <BackgroundCheckUpload 
              onFileUpload={setBackgroundFile} 
              uploadedFile={backgroundFile} 
            />
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Requirements
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="insurance" 
                  checked={formData.hasInsurance}
                  onCheckedChange={(checked) => setFormData({...formData, hasInsurance: !!checked})}
                />
                <Label htmlFor="insurance">I have valid vehicle insurance *</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="license" 
                  checked={formData.hasDriversLicense}
                  onCheckedChange={(checked) => setFormData({...formData, hasDriversLicense: !!checked})}
                />
                <Label htmlFor="license">I have a valid driver's license *</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="background" 
                  checked={formData.hasBackgroundCheck}
                  onCheckedChange={(checked) => setFormData({...formData, hasBackgroundCheck: !!checked})}
                />
                <Label htmlFor="background">I have provided my own background check *</Label>
              </div>
            </CardContent>
          </Card>

          <div className="mt-8 text-center">
            <Button 
              type="submit" 
              size="lg" 
              className="bg-blue-600 hover:bg-blue-700"
              disabled={isSubmitting || !isFormValid}
            >
              {isSubmitting ? 'Submitting...' : 'Submit Application'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DriverApplication;