import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { ShoppingCart, MapPin, DollarSign, Info } from 'lucide-react';
import { useState } from 'react';

interface PostPaceNonLocalPurchaseProps {
  onPurchase: (data: any) => void;
}

const PostPaceNonLocalPurchase: React.FC<PostPaceNonLocalPurchaseProps> = ({ onPurchase }) => {
  const [formData, setFormData] = useState({
    sellerAddress: '',
    sellerTown: '',
    itemDescription: '',
    purchasePrice: '',
    dropoffService: '',
    yourAddress: '',
    specialInstructions: ''
  });

  const [estimatedCost, setEstimatedCost] = useState({
    deliveryFee: 15,
    shippingCost: 12,
    total: 27
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onPurchase(formData);
  };

  return (
    <Card className="shadow-lg">
      <CardContent className="p-6">
        <div className="flex items-center mb-6">
          <ShoppingCart className="w-6 h-6 text-green-600 mr-2" />
          <h3 className="text-xl font-bold">Non-Local Item Purchase</h3>
        </div>
        
        <div className="bg-blue-50 p-4 rounded-lg mb-6">
          <div className="flex items-start">
            <Info className="w-5 h-5 text-blue-600 mr-2 mt-0.5" />
            <div>
              <p className="text-blue-800 font-semibold mb-1">How it works:</p>
              <p className="text-blue-700 text-sm">
                Our drivers will pick up your purchased item from the seller's house in another town 
                and drop it off at your chosen shipping service (UPS, FedEx, USPS) for final delivery to you.
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="sellerAddress">Seller's Address</Label>
              <Input
                id="sellerAddress"
                value={formData.sellerAddress}
                onChange={(e) => setFormData({...formData, sellerAddress: e.target.value})}
                placeholder="Seller's full address"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="sellerTown">Seller's Town</Label>
              <Input
                id="sellerTown"
                value={formData.sellerTown}
                onChange={(e) => setFormData({...formData, sellerTown: e.target.value})}
                placeholder="Town/City"
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="itemDescription">Item Description</Label>
            <Textarea
              id="itemDescription"
              value={formData.itemDescription}
              onChange={(e) => setFormData({...formData, itemDescription: e.target.value})}
              placeholder="Describe the item you're purchasing"
              rows={3}
              required
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="purchasePrice">Purchase Price</Label>
              <Input
                id="purchasePrice"
                type="number"
                value={formData.purchasePrice}
                onChange={(e) => setFormData({...formData, purchasePrice: e.target.value})}
                placeholder="Item cost"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="dropoffService">Shipping Service</Label>
              <Select onValueChange={(value) => setFormData({...formData, dropoffService: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select service" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fedex">FedEx</SelectItem>
                  <SelectItem value="ups">UPS</SelectItem>
                  <SelectItem value="usps">USPS</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="yourAddress">Your Address</Label>
            <Input
              id="yourAddress"
              value={formData.yourAddress}
              onChange={(e) => setFormData({...formData, yourAddress: e.target.value})}
              placeholder="Your delivery address"
              required
            />
          </div>

          <div>
            <Label htmlFor="specialInstructions">Special Instructions</Label>
            <Textarea
              id="specialInstructions"
              value={formData.specialInstructions}
              onChange={(e) => setFormData({...formData, specialInstructions: e.target.value})}
              placeholder="Any special pickup or handling instructions"
              rows={2}
            />
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-semibold mb-2 flex items-center">
              <DollarSign className="w-4 h-4 mr-1" />
              Estimated Total Cost
            </h4>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>Delivery Fee:</span>
                <span>${estimatedCost.deliveryFee}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping Cost:</span>
                <span>${estimatedCost.shippingCost}</span>
              </div>
              <div className="flex justify-between font-semibold border-t pt-1">
                <span>Total:</span>
                <span>${estimatedCost.total}</span>
              </div>
            </div>
          </div>

          <Button type="submit" className="w-full">
            Request Pickup Service
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default PostPaceNonLocalPurchase;