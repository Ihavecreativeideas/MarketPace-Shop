import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calculator } from 'lucide-react';

interface CartItem {
  id: string;
  name: string;
  price: number;
  image: string;
  quantity: number;
  sellerId?: string;
  offerStatus?: 'none' | 'pending' | 'accepted' | 'declined';
  counterOfferPrice?: number;
}

interface CartCounterOfferProps {
  item: CartItem;
  onOfferSubmit: (itemId: string, discount: number) => void;
  onOfferAccept: (itemId: string) => void;
}

const CartCounterOffer: React.FC<CartCounterOfferProps> = ({
  item,
  onOfferSubmit,
  onOfferAccept
}) => {
  const [selectedDiscount, setSelectedDiscount] = useState<number | null>(null);
  const [showOfferOptions, setShowOfferOptions] = useState(false);
  
  const discountOptions = [15, 25, 35, 50];
  
  const calculateDiscountedPrice = (discount: number) => {
    return item.price * (1 - discount / 100);
  };
  
  const handleSubmitOffer = () => {
    if (selectedDiscount) {
      onOfferSubmit(item.id, selectedDiscount);
      setShowOfferOptions(false);
      setSelectedDiscount(null);
    }
  };

  if (item.offerStatus === 'accepted') {
    return (
      <div className="bg-green-50 p-3 rounded-lg border border-green-200">
        <p className="text-sm font-medium text-green-800">Offer Accepted!</p>
        <p className="text-sm text-green-600">
          Final Price: ${item.counterOfferPrice?.toFixed(2)}
        </p>
        <Button 
          size="sm" 
          className="mt-2 bg-green-600 hover:bg-green-700"
          onClick={() => onOfferAccept(item.id)}
        >
          Accept & Lock Order
        </Button>
      </div>
    );
  }

  if (item.offerStatus === 'pending') {
    return (
      <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
        <p className="text-sm font-medium text-yellow-800">Offer Pending</p>
        <p className="text-sm text-yellow-600">Waiting for seller response...</p>
      </div>
    );
  }

  if (item.offerStatus === 'declined') {
    return (
      <div className="bg-red-50 p-3 rounded-lg border border-red-200">
        <p className="text-sm font-medium text-red-800">Offer Declined</p>
        <p className="text-sm text-red-600">Seller declined your offer</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {!showOfferOptions ? (
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => setShowOfferOptions(true)}
          className="w-full border-orange-300 text-orange-600 hover:bg-orange-50"
        >
          <Calculator className="w-4 h-4 mr-2" />
          Make Counter Offer
        </Button>
      ) : (
        <div className="space-y-2">
          <p className="text-sm font-medium">Select discount:</p>
          <div className="grid grid-cols-2 gap-2">
            {discountOptions.map((discount) => {
              const discountedPrice = calculateDiscountedPrice(discount);
              return (
                <div
                  key={discount}
                  className={`p-2 border rounded cursor-pointer text-center ${
                    selectedDiscount === discount
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedDiscount(discount)}
                >
                  <Badge variant="outline" className="text-xs">
                    {discount}% off
                  </Badge>
                  <p className="text-sm font-bold mt-1">
                    ${discountedPrice.toFixed(2)}
                  </p>
                </div>
              );
            })}
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => {
                setShowOfferOptions(false);
                setSelectedDiscount(null);
              }}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button 
              size="sm" 
              onClick={handleSubmitOffer}
              disabled={!selectedDiscount}
              className="flex-1 bg-orange-600 hover:bg-orange-700"
            >
              Submit Offer
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartCounterOffer;