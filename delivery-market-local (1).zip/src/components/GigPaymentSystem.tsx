import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { DollarSign, Shield, Bell, CheckCircle, Clock } from 'lucide-react';

interface GigPayment {
  id: number;
  clientName: string;
  amount: number;
  eventDate: string;
  status: 'pending' | 'held' | 'confirmed' | 'released';
  confirmations: {
    clientConfirmed: boolean;
    musicianConfirmed: boolean;
    gigStarted: boolean;
    gigCompleted: boolean;
  };
}

interface GigPaymentSystemProps {
  payments: GigPayment[];
  onConfirmGig: (paymentId: number, type: string) => void;
}

const GigPaymentSystem: React.FC<GigPaymentSystemProps> = ({ payments, onConfirmGig }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'held': return 'bg-blue-100 text-blue-800';
      case 'confirmed': return 'bg-green-100 text-green-800';
      case 'released': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getProgressValue = (confirmations: any) => {
    const total = Object.keys(confirmations).length;
    const confirmed = Object.values(confirmations).filter(Boolean).length;
    return (confirmed / total) * 100;
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-green-500" />
            MarketPace Payment Protection
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-sm text-green-700">
              <strong>How it works:</strong> Client pays upfront → MarketPace holds payment → 
              Both parties confirm gig completion → Payment released to musician
            </p>
          </div>
        </CardContent>
      </Card>

      {payments.map((payment) => (
        <Card key={payment.id}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">
                Gig with {payment.clientName}
              </CardTitle>
              <Badge className={getStatusColor(payment.status)}>
                {payment.status.toUpperCase()}
              </Badge>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <span className="flex items-center gap-1">
                <DollarSign className="w-4 h-4" />
                ${payment.amount}
              </span>
              <span>{payment.eventDate}</span>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Confirmation Progress</span>
                <span className="text-sm text-gray-500">
                  {Object.values(payment.confirmations).filter(Boolean).length}/4
                </span>
              </div>
              <Progress value={getProgressValue(payment.confirmations)} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <span className="text-sm">Client Payment Received</span>
                {payment.confirmations.clientConfirmed ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <Clock className="w-4 h-4 text-gray-400" />
                )}
              </div>
              
              <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <span className="text-sm">Musician Arrival Confirmed</span>
                {payment.confirmations.musicianConfirmed ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <Button 
                    size="sm" 
                    onClick={() => onConfirmGig(payment.id, 'arrival')}
                    disabled={!payment.confirmations.clientConfirmed}
                  >
                    Confirm Arrival
                  </Button>
                )}
              </div>
              
              <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <span className="text-sm">Performance Started</span>
                {payment.confirmations.gigStarted ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <Button 
                    size="sm" 
                    onClick={() => onConfirmGig(payment.id, 'started')}
                    disabled={!payment.confirmations.musicianConfirmed}
                  >
                    Confirm Start
                  </Button>
                )}
              </div>
              
              <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <span className="text-sm">Performance Completed</span>
                {payment.confirmations.gigCompleted ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <Button 
                    size="sm" 
                    onClick={() => onConfirmGig(payment.id, 'completed')}
                    disabled={!payment.confirmations.gigStarted}
                  >
                    Confirm Completion
                  </Button>
                )}
              </div>
            </div>

            {payment.status === 'released' && (
              <div className="bg-green-50 p-3 rounded-lg text-center">
                <CheckCircle className="w-6 h-6 text-green-500 mx-auto mb-2" />
                <p className="text-green-700 font-medium">Payment Released!</p>
                <p className="text-sm text-green-600">$${payment.amount} has been transferred to your account</p>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default GigPaymentSystem;