import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Store, Wrench, Music, User, Building2, ArrowRight } from 'lucide-react';

interface DualAccountSetupProps {
  onComplete: (accountType: 'personal' | 'dual', businessType?: 'shop' | 'service' | 'entertainment') => void;
}

const DualAccountSetup: React.FC<DualAccountSetupProps> = ({ onComplete }) => {
  const [selectedType, setSelectedType] = useState<'personal' | 'dual'>('personal');
  const [businessType, setBusinessType] = useState<'shop' | 'service' | 'entertainment' | null>(null);

  const businessTypes = [
    {
      id: 'shop' as const,
      title: 'Shop',
      icon: Store,
      description: 'Sell physical products, manage inventory, process orders',
      features: ['Product listings', 'Inventory management', 'Order processing', 'Payment integration', 'Shipping tools']
    },
    {
      id: 'service' as const,
      title: 'Service',
      icon: Wrench,
      description: 'Offer services, manage bookings, handle appointments',
      features: ['Service listings', 'Booking calendar', 'Client management', 'Payment processing', 'Review system']
    },
    {
      id: 'entertainment' as const,
      title: 'Entertainment',
      icon: Music,
      description: 'Showcase talent, book gigs, manage events',
      features: ['Portfolio showcase', 'Event booking', 'Equipment rental', 'Collaboration tools', 'Performance calendar']
    }
  ];

  const handleContinue = () => {
    if (selectedType === 'dual' && !businessType) {
      return;
    }
    onComplete(selectedType, businessType || undefined);
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <Card className="bg-gradient-to-br from-slate-900 via-cyan-900 to-purple-900 border-cyan-500/30 text-white">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            Choose Your Account Type
          </CardTitle>
          <p className="text-cyan-300 text-lg">
            Create a personal account or add a business profile
          </p>
        </CardHeader>
        <CardContent className="space-y-8">
          {/* Account Type Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card 
              className={`cursor-pointer transition-all duration-300 border-2 ${
                selectedType === 'personal' 
                  ? 'border-cyan-400 bg-cyan-500/10' 
                  : 'border-slate-600 bg-slate-800/50 hover:border-cyan-500/50'
              }`}
              onClick={() => setSelectedType('personal')}
            >
              <CardContent className="p-6 text-center">
                <User className="h-12 w-12 mx-auto mb-4 text-cyan-400" />
                <h3 className="text-xl font-bold text-white mb-2">Personal Only</h3>
                <p className="text-slate-300">
                  Browse, buy, and connect with the MarketPace community
                </p>
              </CardContent>
            </Card>

            <Card 
              className={`cursor-pointer transition-all duration-300 border-2 ${
                selectedType === 'dual' 
                  ? 'border-purple-400 bg-purple-500/10' 
                  : 'border-slate-600 bg-slate-800/50 hover:border-purple-500/50'
              }`}
              onClick={() => setSelectedType('dual')}
            >
              <CardContent className="p-6 text-center">
                <Building2 className="h-12 w-12 mx-auto mb-4 text-purple-400" />
                <h3 className="text-xl font-bold text-white mb-2">Personal + Business</h3>
                <p className="text-slate-300">
                  Get a personal account plus a business profile to sell or offer services
                </p>
                <Badge className="mt-2 bg-gradient-to-r from-cyan-500 to-purple-500">
                  Recommended
                </Badge>
              </CardContent>
            </Card>
          </div>

          {/* Business Type Selection */}
          {selectedType === 'dual' && (
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-center text-white">
                Choose Your Business Type
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {businessTypes.map((type) => {
                  const Icon = type.icon;
                  return (
                    <Card 
                      key={type.id}
                      className={`cursor-pointer transition-all duration-300 border-2 ${
                        businessType === type.id 
                          ? 'border-cyan-400 bg-cyan-500/10' 
                          : 'border-slate-600 bg-slate-800/50 hover:border-cyan-500/50'
                      }`}
                      onClick={() => setBusinessType(type.id)}
                    >
                      <CardContent className="p-6">
                        <div className="text-center mb-4">
                          <Icon className="h-10 w-10 mx-auto mb-2 text-cyan-400" />
                          <h4 className="text-lg font-bold text-white">{type.title}</h4>
                          <p className="text-sm text-slate-300 mt-1">{type.description}</p>
                        </div>
                        <div className="space-y-2">
                          <p className="text-sm font-medium text-cyan-300">Key Features:</p>
                          <ul className="text-xs text-slate-400 space-y-1">
                            {type.features.map((feature, index) => (
                              <li key={index}>• {feature}</li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          )}

          <div className="text-center">
            <Button
              onClick={handleContinue}
              disabled={selectedType === 'dual' && !businessType}
              className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 px-8 py-3 text-lg"
            >
              Continue Setup
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DualAccountSetup;