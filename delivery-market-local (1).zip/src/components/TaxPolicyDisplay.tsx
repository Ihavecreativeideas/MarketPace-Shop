import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Receipt, Info, Shield, DollarSign } from 'lucide-react';

interface TaxPolicyDisplayProps {
  productSubtotal: number;
  deliveryFee: number;
  serviceFee: number;
  taxRate?: number;
  showExample?: boolean;
}

export const TaxPolicyDisplay: React.FC<TaxPolicyDisplayProps> = ({
  productSubtotal,
  deliveryFee,
  serviceFee,
  taxRate = 0.0925,
  showExample = false
}) => {
  const taxableAmount = deliveryFee + serviceFee;
  const taxCollected = taxableAmount * taxRate;
  const total = productSubtotal + deliveryFee + serviceFee + taxCollected;

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Receipt className="w-5 h-5" />
          MarketPace Tax Policy
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Tax Responsibilities Overview */}
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-blue-50 p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="w-4 h-4 text-blue-600" />
              <span className="font-medium text-blue-900">Product Sales</span>
            </div>
            <div className="text-sm text-blue-800">
              <div>• Vendors collect tax</div>
              <div>• Vendors remit tax</div>
              <div>• MarketPace not responsible</div>
            </div>
          </div>
          
          <div className="bg-green-50 p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Receipt className="w-4 h-4 text-green-600" />
              <span className="font-medium text-green-900">Platform Fees</span>
            </div>
            <div className="text-sm text-green-800">
              <div>• MarketPace collects tax</div>
              <div>• MarketPace remits tax</div>
              <div>• Delivery & service fees</div>
            </div>
          </div>
          
          <div className="bg-purple-50 p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-4 h-4 text-purple-600" />
              <span className="font-medium text-purple-900">Driver Tips</span>
            </div>
            <div className="text-sm text-purple-800">
              <div>• Tax-free gratuities</div>
              <div>• 100% to driver</div>
              <div>• Not subject to sales tax</div>
            </div>
          </div>
        </div>

        {showExample && (
          <>
            <Separator />
            
            {/* Example Calculation */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium mb-3 flex items-center gap-2">
                <Info className="w-4 h-4" />
                Example Tax Calculation
              </h4>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Product Subtotal (Non-taxable by MarketPace)</span>
                  <span>${productSubtotal.toFixed(2)}</span>
                </div>
                
                <div className="bg-white p-2 rounded border-l-4 border-green-500">
                  <div className="font-medium text-green-700 mb-1">MarketPace Taxable Fees:</div>
                  <div className="flex justify-between">
                    <span className="ml-2">Delivery Fee:</span>
                    <span>${deliveryFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="ml-2">Service Fee:</span>
                    <span>${serviceFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between border-t pt-1 mt-1">
                    <span className="ml-2 font-medium">Taxable Amount:</span>
                    <span className="font-medium">${taxableAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-green-700">
                    <span className="ml-2">Sales Tax ({(taxRate * 100).toFixed(2)}%):</span>
                    <span>${taxCollected.toFixed(2)}</span>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex justify-between font-bold text-lg">
                  <span>Total Amount:</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </>
        )}
        
        {/* Policy Details */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">Important Tax Information:</h4>
          <div className="space-y-2 text-sm text-blue-800">
            <div className="flex items-start gap-2">
              <span className="font-medium">1.</span>
              <span>Each vendor is responsible for collecting and remitting applicable sales tax on their products.</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-medium">2.</span>
              <span>MarketPace collects and remits sales tax on delivery fees, service fees, and other platform charges.</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-medium">3.</span>
              <span>Tips for drivers are optional gratuities and are not subject to sales tax.</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-medium">4.</span>
              <span>Driver pay is handled separately as independent contractor payments.</span>
            </div>
          </div>
        </div>
        
        {/* Database Fields Reference */}
        <div className="bg-gray-50 p-3 rounded-lg text-xs">
          <div className="font-medium mb-2">Database/API Fields:</div>
          <div className="grid grid-cols-2 gap-2">
            <Badge variant="outline">product_total</Badge>
            <Badge variant="outline">delivery_fee</Badge>
            <Badge variant="outline">service_fee</Badge>
            <Badge variant="outline">tax_collected</Badge>
            <Badge variant="outline">checkout_total</Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};