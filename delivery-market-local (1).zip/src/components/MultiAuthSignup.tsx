import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Facebook, Mail, Linkedin, User, Building, Music, Wrench } from 'lucide-react';

const MultiAuthSignup: React.FC = () => {
  const [accountType, setAccountType] = useState('personal');
  const [profileTypes, setProfileTypes] = useState<string[]>([]);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    businessName: '',
    location: ''
  });

  const handleProfileTypeChange = (type: string, checked: boolean) => {
    if (checked) {
      setProfileTypes([...profileTypes, type]);
    } else {
      setProfileTypes(profileTypes.filter(t => t !== type));
    }
  };

  const socialButtons = [
    { name: 'Facebook', icon: Facebook, color: 'bg-blue-600 hover:bg-blue-700' },
    { name: 'Google', icon: Mail, color: 'bg-red-600 hover:bg-red-700' },
    { name: 'LinkedIn', icon: Linkedin, color: 'bg-blue-800 hover:bg-blue-900' }
  ];

  return (
    <div className="max-w-md mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-center">Join MarketPace</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Social Login */}
          <div className="space-y-3 mb-6">
            {socialButtons.map((social) => {
              const IconComponent = social.icon;
              return (
                <Button key={social.name} className={`w-full ${social.color}`}>
                  <IconComponent className="w-4 h-4 mr-2" />
                  Continue with {social.name}
                </Button>
              );
            })}
            <Button variant="outline" className="w-full">
              <User className="w-4 h-4 mr-2" />
              Continue as Guest
            </Button>
          </div>

          <div className="text-center text-sm text-gray-500 mb-6">or</div>

          {/* Account Type Selection */}
          <Tabs value={accountType} onValueChange={setAccountType} className="mb-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="personal">Personal</TabsTrigger>
              <TabsTrigger value="business">Business</TabsTrigger>
            </TabsList>
            
            <TabsContent value="personal" className="space-y-4">
              <div>
                <Label>Full Name</Label>
                <Input 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Enter your name"
                />
              </div>
            </TabsContent>
            
            <TabsContent value="business" className="space-y-4">
              <div>
                <Label>Business Name</Label>
                <Input 
                  value={formData.businessName}
                  onChange={(e) => setFormData({...formData, businessName: e.target.value})}
                  placeholder="Enter business name"
                />
              </div>
            </TabsContent>
          </Tabs>

          {/* Profile Types */}
          <div className="mb-6">
            <Label className="text-sm font-medium mb-3 block">Profile Types (Select all that apply)</Label>
            <div className="space-y-3">
              {[
                { id: 'shop', label: 'Shop Owner', icon: Building },
                { id: 'service', label: 'Service Provider', icon: Wrench },
                { id: 'entertainer', label: 'Entertainer/Musician', icon: Music }
              ].map((type) => {
                const IconComponent = type.icon;
                return (
                  <div key={type.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={type.id}
                      checked={profileTypes.includes(type.id)}
                      onCheckedChange={(checked) => handleProfileTypeChange(type.id, !!checked)}
                    />
                    <Label htmlFor={type.id} className="flex items-center gap-2">
                      <IconComponent className="w-4 h-4" />
                      {type.label}
                    </Label>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Basic Info */}
          <div className="space-y-4 mb-6">
            <div>
              <Label>Email</Label>
              <Input 
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                placeholder="Enter your email"
              />
            </div>
            <div>
              <Label>Password</Label>
              <Input 
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                placeholder="Create a password"
              />
            </div>
            <div>
              <Label>Location</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select your location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="downtown">Downtown</SelectItem>
                  <SelectItem value="midtown">Midtown</SelectItem>
                  <SelectItem value="uptown">Uptown</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button className="w-full">Create Account</Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default MultiAuthSignup;