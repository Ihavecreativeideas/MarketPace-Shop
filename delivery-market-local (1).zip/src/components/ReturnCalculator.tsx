import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calculator, DollarSign, Truck, Users, Star, Crown, Diamond } from 'lucide-react';

interface ReturnCalculatorProps {
  distance: number;
  isPartnerReturn?: boolean;
  partnerTier?: 'silver' | 'gold' | 'platinum';
  onCalculate?: (fees: ReturnFees) => void;
}

interface ReturnFees {
  buyerFee: number;
  driverEarnings: number;
  totalCost: number;
  originalFee: number;
  discount: number;
  isPartnerReturn: boolean;
  partnerTier?: string;
}

const ReturnCalculator: React.FC<ReturnCalculatorProps> = ({ 
  distance, 
  isPartnerReturn = false,
  partnerTier,
  onCalculate 
}) => {
  const [fees, setFees] = useState<ReturnFees>({
    buyerFee: 0,
    driverEarnings: 0,
    totalCost: 0,
    originalFee: 0,
    discount: 0,
    isPartnerReturn: false
  });

  useEffect(() => {
    // Original return fee: $3 base + $1 per mile
    const originalFee = 3 + (distance * 1);
    
    // Driver earnings: $2 base + $0.75 per mile (always paid regardless)
    const driverEarnings = 2 + (distance * 0.75);
    
    let buyerFee = originalFee;
    let discount = 0;
    
    if (isPartnerReturn && partnerTier) {
      switch (partnerTier) {
        case 'silver':
          // Silver partners get 50% off return fees
          buyerFee = originalFee * 0.5;
          discount = originalFee * 0.5;
          break;
        case 'gold':
        case 'platinum':
          // Gold and Platinum partners get free returns
          buyerFee = 0;
          discount = originalFee;
          break;
      }
    }
    
    const calculatedFees = {
      buyerFee,
      driverEarnings,
      totalCost: buyerFee,
      originalFee,
      discount,
      isPartnerReturn,
      partnerTier
    };
    
    setFees(calculatedFees);
    
    if (onCalculate) {
      onCalculate(calculatedFees);
    }
  }, [distance, isPartnerReturn, partnerTier, onCalculate]);

  const getPartnerIcon = () => {
    switch (partnerTier) {
      case 'silver': return <Star className="w-3 h-3 mr-1" />;
      case 'gold': return <Crown className="w-3 h-3 mr-1" />;
      case 'platinum': return <Diamond className="w-3 h-3 mr-1" />;
      default: return <Users className="w-3 h-3 mr-1" />;
    }
  };

  const getPartnerColor = () => {
    switch (partnerTier) {
      case 'silver': return 'bg-gray-100 text-gray-800';
      case 'gold': return 'bg-yellow-100 text-yellow-800';
      case 'platinum': return 'bg-purple-100 text-purple-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getDiscountText = () => {
    switch (partnerTier) {
      case 'silver': return '50% off';
      case 'gold':
      case 'platinum': return 'FREE';
      default: return '';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="w-5 h-5" />
          Return Cost Calculator
          {isPartnerReturn && partnerTier && (
            <Badge className={getPartnerColor()}>
              {getPartnerIcon()}
              {partnerTier.charAt(0).toUpperCase() + partnerTier.slice(1)} Partner
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{distance}</div>
            <div className="text-sm text-gray-500">Miles</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">${fees.buyerFee.toFixed(2)}</div>
            <div className="text-sm text-gray-500">Return Fee</div>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
            <span className="text-sm">Base Return Fee</span>
            <span className="font-medium">$3.00</span>
          </div>
          <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
            <span className="text-sm">Distance Fee ({distance} miles × $1.00)</span>
            <span className="font-medium">${(distance * 1).toFixed(2)}</span>
          </div>
          
          {isPartnerReturn && partnerTier && fees.discount > 0 && (
            <div className={`flex justify-between items-center p-2 rounded border ${getPartnerColor().replace('text-', 'border-').replace('bg-', 'bg-').replace('-100', '-200')}`}>
              <span className="text-sm font-medium">
                {partnerTier.charAt(0).toUpperCase() + partnerTier.slice(1)} Partner Discount ({getDiscountText()})
              </span>
              <span className="font-medium text-green-600">-${fees.discount.toFixed(2)}</span>
            </div>
          )}
          
          <div className="flex justify-between items-center p-2 bg-blue-50 rounded border border-blue-200">
            <span className="font-medium text-blue-800">Total Buyer Cost</span>
            <span className="font-bold text-blue-800">${fees.buyerFee.toFixed(2)}</span>
          </div>
        </div>
        
        <div className="border-t pt-4">
          <div className="flex items-center gap-2 mb-2">
            <Truck className="w-4 h-4" />
            <span className="font-medium">Driver Earnings</span>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span>Base Pay</span>
              <span>$2.00</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Mileage ({distance} miles × $0.75)</span>
              <span>${(distance * 0.75).toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-medium pt-1 border-t">
              <span>Total Driver Pay</span>
              <span>${fees.driverEarnings.toFixed(2)}</span>
            </div>
          </div>
          
          {isPartnerReturn && (
            <Badge className="w-full justify-center mt-2 bg-green-100 text-green-800">
              Driver receives full payment regardless of partner discounts
            </Badge>
          )}
        </div>
        
        <Badge className="w-full justify-center bg-orange-100 text-orange-800 hover:bg-orange-200">
          <DollarSign className="w-3 h-3 mr-1" />
          Return will be added to delivery route automatically
        </Badge>
        
        {isPartnerReturn && partnerTier && (
          <div className="mt-4 p-3 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border">
            <div className="text-center">
              <div className="font-semibold text-green-700 mb-1">
                Partner Benefit Applied!
              </div>
              <div className="text-sm text-gray-600">
                {partnerTier === 'silver' && 'Silver partners save 50% on all return fees'}
                {(partnerTier === 'gold' || partnerTier === 'platinum') && 'Gold & Platinum partners get completely free returns'}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ReturnCalculator;