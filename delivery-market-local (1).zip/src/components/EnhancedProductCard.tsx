import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, Star, MapPin, Clock, Truck } from 'lucide-react';

interface ProductCardProps {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  condition: string;
  location: string;
  seller_name: string;
  images: string[];
  created_at: string;
  is_promoted: boolean;
  self_pickup_available?: boolean;
  marketplace_delivery_available?: boolean;
  shop_delivery_available?: boolean;
  onFavorite: (id: string) => void;
  onMakeOffer: (id: string) => void;
  onPromote?: (id: string) => void;
}

const EnhancedProductCard: React.FC<ProductCardProps> = ({
  id,
  title,
  description,
  price,
  category,
  condition,
  location,
  seller_name,
  images,
  created_at,
  is_promoted,
  self_pickup_available,
  marketplace_delivery_available,
  shop_delivery_available,
  onFavorite,
  onMakeOffer,
  onPromote
}) => {
  const getDeliveryOptions = () => {
    const options = [];
    if (self_pickup_available) options.push('Self Pickup');
    if (marketplace_delivery_available) options.push('MarketPace Delivery');
    if (shop_delivery_available) options.push('Shop Delivery');
    return options;
  };

  const deliveryOptions = getDeliveryOptions();

  return (
    <Card className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all">
      {is_promoted && (
        <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs font-bold px-2 py-1 rounded-t-lg">
          ⭐ PROMOTED
        </div>
      )}
      
      <CardHeader className="pb-2">
        <div className="aspect-square bg-white/5 rounded-lg mb-3 flex items-center justify-center relative">
          {images?.length > 0 ? (
            <img 
              src={images[0]} 
              alt={title}
              className="w-full h-full object-cover rounded-lg"
            />
          ) : (
            <div className="text-gray-400 text-4xl">📦</div>
          )}
          <Button
            size="sm"
            variant="ghost"
            onClick={() => onFavorite(id)}
            className="absolute top-2 left-2 bg-white/90 hover:bg-white text-red-500 hover:text-red-600 w-8 h-8 p-0 rounded-full shadow-lg transition-all"
          >
            <Heart className="w-4 h-4" />
          </Button>
        </div>
        
        <CardTitle className="text-white text-lg line-clamp-2">
          {title}
        </CardTitle>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-2xl font-bold text-green-400">
              ${price.toFixed(2)}
            </span>
          </div>
          
          <p className="text-gray-300 text-sm line-clamp-2">
            {description}
          </p>
          
          <div className="flex flex-wrap gap-1">
            <Badge variant="secondary" className="text-xs">
              {category.replace('-', ' ')}
            </Badge>
            <Badge variant="outline" className="text-xs border-purple-400 text-purple-400">
              {condition}
            </Badge>
          </div>
          
          {deliveryOptions.length > 0 && (
            <div className="flex flex-wrap gap-1">
              <div className="flex items-center gap-1 text-xs text-gray-400">
                <Truck className="w-3 h-3" />
                <span>Delivery:</span>
              </div>
              {deliveryOptions.map((option) => (
                <Badge key={option} variant="outline" className="text-xs border-orange-400 text-orange-400">
                  {option}
                </Badge>
              ))}
            </div>
          )}
          
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <MapPin className="w-3 h-3" />
            <span>{location}</span>
            <Clock className="w-3 h-3 ml-2" />
            <span>{new Date(created_at).toLocaleDateString()}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-400">
              by {seller_name}
            </span>
          </div>
          
          <div className="flex gap-2">
            <Button 
              size="sm" 
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              onClick={() => onMakeOffer(id)}
            >
              Make Offer
            </Button>
            
            {!is_promoted && onPromote && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => onPromote(id)}
                className="border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black"
              >
                <Star className="w-3 h-3" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default EnhancedProductCard;
export { EnhancedProductCard };