import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, AlertTriangle, QrCode, Pill, MapPin, Star } from 'lucide-react';

const PharmacyCheckout: React.FC = () => {
  const [step, setStep] = useState<'pharmacy' | 'prescription' | 'payment' | 'confirmation'>('pharmacy');
  const [selectedPharmacy, setSelectedPharmacy] = useState<any>();
  const [formData, setFormData] = useState({
    patientName: '',
    dateOfBirth: '',
    prescriptionNumber: '',
    medicationName: '',
    doctorName: ''
  });
  const [pickupCode, setPickupCode] = useState<string>();
  const [isEligible, setIsEligible] = useState<boolean>();

  const pharmacies = [
    { id: 1, name: 'CVS Pharmacy', address: '123 Main St', distance: '0.5 miles', rating: 4.8, phone: '(555) 123-4567', driveThru: true },
    { id: 2, name: 'Walgreens', address: '456 Oak Ave', distance: '1.2 miles', rating: 4.6, phone: '(555) 234-5678', driveThru: true }
  ];

  const controlledSubstances = ['oxycodone', 'adderall', 'xanax', 'morphine', 'fentanyl'];

  const handlePrescriptionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const medicationLower = formData.medicationName.toLowerCase();
    const isControlled = controlledSubstances.some(substance => medicationLower.includes(substance));
    setIsEligible(!isControlled);
    if (!isControlled) {
      setStep('payment');
    }
  };

  const handlePayment = () => {
    const code = `PU${Date.now().toString().slice(-6)}`;
    setPickupCode(code);
    setStep('confirmation');
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Card className="bg-gradient-to-r from-blue-50 to-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Pill className="w-5 h-5" />
            Pharmacy Pickup Service - $14.00
          </CardTitle>
        </CardHeader>
      </Card>

      {step === 'pharmacy' && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Select Pharmacy</h3>
          {pharmacies.map((pharmacy) => (
            <Card key={pharmacy.id} className={`cursor-pointer transition-all hover:shadow-md ${
              selectedPharmacy?.id === pharmacy.id ? 'ring-2 ring-blue-500' : ''
            }`} onClick={() => setSelectedPharmacy(pharmacy)}>
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold">{pharmacy.name}</h4>
                    <p className="text-sm text-gray-600">{pharmacy.address}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {pharmacy.distance}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary">
                      <Star className="w-3 h-3 mr-1" />
                      {pharmacy.rating}
                    </Badge>
                    {pharmacy.driveThru && (
                      <Badge variant="outline" className="text-xs mt-1">Drive-Thru</Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {selectedPharmacy && (
            <Button onClick={() => setStep('prescription')} className="w-full">
              Continue with {selectedPharmacy.name}
            </Button>
          )}
        </div>
      )}

      {step === 'prescription' && (
        <Card>
          <CardHeader>
            <CardTitle>Prescription Information</CardTitle>
          </CardHeader>
          <CardContent>
            <Alert className="mb-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Controlled substances cannot be picked up by third parties for legal compliance.
              </AlertDescription>
            </Alert>
            <form onSubmit={handlePrescriptionSubmit} className="space-y-4">
              <div>
                <Label>Patient Name</Label>
                <Input value={formData.patientName} onChange={(e) => setFormData({...formData, patientName: e.target.value})} required />
              </div>
              <div>
                <Label>Date of Birth</Label>
                <Input type="date" value={formData.dateOfBirth} onChange={(e) => setFormData({...formData, dateOfBirth: e.target.value})} required />
              </div>
              <div>
                <Label>Prescription Number</Label>
                <Input value={formData.prescriptionNumber} onChange={(e) => setFormData({...formData, prescriptionNumber: e.target.value})} required />
              </div>
              <div>
                <Label>Medication Name</Label>
                <Input value={formData.medicationName} onChange={(e) => setFormData({...formData, medicationName: e.target.value})} required />
              </div>
              <div>
                <Label>Doctor Name</Label>
                <Input value={formData.doctorName} onChange={(e) => setFormData({...formData, doctorName: e.target.value})} required />
              </div>
              <Button type="submit" className="w-full">Continue to Payment</Button>
            </form>
            {isEligible === false && (
              <Alert className="mt-4" variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  This medication requires patient pickup only. Controlled substances cannot be picked up by third parties.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {step === 'payment' && (
        <Card>
          <CardHeader>
            <CardTitle>Payment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm mb-4">
              <div className="flex justify-between">
                <span>Medication:</span>
                <span>{formData.medicationName}</span>
              </div>
              <div className="flex justify-between">
                <span>Pharmacy:</span>
                <span>{selectedPharmacy?.name}</span>
              </div>
              <div className="flex justify-between font-semibold">
                <span>Pickup Fee:</span>
                <span>$14.00</span>
              </div>
            </div>
            <Button onClick={handlePayment} className="w-full">Pay $14.00</Button>
          </CardContent>
        </Card>
      )}

      {step === 'confirmation' && pickupCode && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-600">
              <CheckCircle className="w-5 h-5" />
              Order Confirmed!
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <QrCode className="h-4 w-4" />
              <AlertDescription>
                Pickup Code: <strong>{pickupCode}</strong>
              </AlertDescription>
            </Alert>
            <div className="text-sm space-y-2">
              <p><strong>Pharmacy:</strong> {selectedPharmacy?.name}</p>
              <p><strong>Address:</strong> {selectedPharmacy?.address}</p>
              <p><strong>Phone:</strong> {selectedPharmacy?.phone}</p>
            </div>
            <Alert>
              <AlertDescription>
                Driver will present pickup code {pickupCode} at the pharmacy drive-thru. Estimated pickup: 30-45 minutes.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PharmacyCheckout;