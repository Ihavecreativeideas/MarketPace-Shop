import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Globe, Link, Package, Settings, Check } from 'lucide-react';

const BusinessWebShopIntegration: React.FC = () => {
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [isConnected, setIsConnected] = useState(false);

  const handleConnect = () => {
    if (websiteUrl.trim()) {
      setIsConnected(true);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-4 flex items-center justify-center gap-2">
            <Globe className="h-8 w-8 text-teal-500" />
            Web Shop Integration
          </h1>
          <p className="text-slate-300">
            Connect your existing website to MarketPace and sync your products for local delivery
          </p>
        </div>

        <Card className="bg-slate-800/50 border-slate-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Link className="h-5 w-5" />
              Integration Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!isConnected ? (
              <div className="space-y-4">
                <div className="flex items-center gap-2 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></div>
                  <span className="text-yellow-400">Not Connected</span>
                </div>
                <div>
                  <label className="text-sm text-slate-300 mb-2 block">Website URL</label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="https://yourwebsite.com"
                      value={websiteUrl}
                      onChange={(e) => setWebsiteUrl(e.target.value)}
                      className="bg-slate-700/50 border-slate-600 text-white"
                    />
                    <Button 
                      onClick={handleConnect}
                      className="bg-teal-500 hover:bg-teal-600"
                      disabled={!websiteUrl.trim()}
                    >
                      Connect
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center gap-2 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-green-400">Connected to {websiteUrl}</span>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">24</div>
                    <div className="text-sm text-slate-400">Products Synced</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">12</div>
                    <div className="text-sm text-slate-400">Orders Today</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">$847</div>
                    <div className="text-sm text-slate-400">Revenue</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">98%</div>
                    <div className="text-sm text-slate-400">Sync Rate</div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {isConnected && (
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Package className="h-5 w-5" />
                Synced Products
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: 'Handmade Jewelry Set', price: '$45.99', status: 'Active', orders: 12 },
                  { name: 'Artisan Coffee Blend', price: '$24.99', status: 'Active', orders: 8 },
                  { name: 'Custom T-Shirt Design', price: '$19.99', status: 'Pending', orders: 0 }
                ].map((product, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-slate-700/30 rounded-lg">
                    <div className="flex-1">
                      <h3 className="text-white font-semibold">{product.name}</h3>
                      <p className="text-slate-400 text-sm">{product.price}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge className={product.status === 'Active' ? 'bg-green-500' : 'bg-yellow-500'}>
                        {product.status}
                      </Badge>
                      <span className="text-slate-300 text-sm">{product.orders} orders</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default BusinessWebShopIntegration;
export { BusinessWebShopIntegration };