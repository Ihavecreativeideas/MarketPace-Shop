import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Clock, 
  Package, 
  Star, 
  MessageSquare, 
  TrendingUp,
  Calendar,
  Music,
  Truck
} from 'lucide-react';

interface Activity {
  id: string;
  type: string;
  title: string;
  description: string;
  timestamp: string;
  status?: string;
  amount?: number;
}

interface ProfileActivityProps {
  membershipType: string;
  activities: Activity[];
}

export const ProfileActivity: React.FC<ProfileActivityProps> = ({ membershipType, activities }) => {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'delivery': return Truck;
      case 'order': return Package;
      case 'review': return Star;
      case 'message': return MessageSquare;
      case 'gig': return Music;
      case 'booking': return Calendar;
      case 'earning': return TrendingUp;
      default: return Clock;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'delivery': return 'text-green-400';
      case 'order': return 'text-blue-400';
      case 'review': return 'text-yellow-400';
      case 'message': return 'text-purple-400';
      case 'gig': return 'text-pink-400';
      case 'booking': return 'text-indigo-400';
      case 'earning': return 'text-emerald-400';
      default: return 'text-slate-400';
    }
  };

  const getStatusBadge = (status?: string) => {
    if (!status) return null;
    
    const statusColors = {
      'completed': 'bg-green-600',
      'pending': 'bg-yellow-600',
      'cancelled': 'bg-red-600',
      'in-progress': 'bg-blue-600'
    };
    
    return (
      <Badge className={`${statusColors[status as keyof typeof statusColors] || 'bg-gray-600'} text-white text-xs`}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`;
    return date.toLocaleDateString();
  };

  // Sample activities based on membership type
  const sampleActivities: Activity[] = activities.length > 0 ? activities : [
    ...(membershipType.toLowerCase() === 'driver' ? [
      {
        id: '1',
        type: 'delivery',
        title: 'Delivery Completed',
        description: 'Package delivered to 123 Main St',
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        status: 'completed',
        amount: 25
      },
      {
        id: '2',
        type: 'earning',
        title: 'Payment Received',
        description: 'Weekly earnings deposited',
        timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        amount: 450
      }
    ] : []),
    ...(membershipType.toLowerCase() === 'business' ? [
      {
        id: '3',
        type: 'order',
        title: 'New Order Received',
        description: 'Customer ordered 3 items',
        timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
        status: 'pending'
      },
      {
        id: '4',
        type: 'review',
        title: 'New Review',
        description: '5-star review from satisfied customer',
        timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString()
      }
    ] : []),
    ...(membershipType.toLowerCase() === 'musician' ? [
      {
        id: '5',
        type: 'gig',
        title: 'Gig Confirmed',
        description: 'Wedding performance at Grand Hotel',
        timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
        status: 'confirmed',
        amount: 800
      },
      {
        id: '6',
        type: 'booking',
        title: 'New Booking Request',
        description: 'Corporate event inquiry',
        timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
        status: 'pending'
      }
    ] : []),
    {
      id: '7',
      type: 'message',
      title: 'New Message',
      description: 'You have 2 unread messages',
      timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString()
    }
  ];

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-white flex items-center gap-2">
          <Clock className="w-5 h-5 text-blue-400" />
          Recent Activity
        </CardTitle>
        <Button variant="outline" size="sm" className="border-slate-600">
          View All
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sampleActivities.slice(0, 5).map((activity) => {
            const IconComponent = getActivityIcon(activity.type);
            const iconColor = getActivityColor(activity.type);
            
            return (
              <div key={activity.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-slate-700/50 transition-colors">
                <div className="p-2 rounded-lg bg-slate-700">
                  <IconComponent className={`w-4 h-4 ${iconColor}`} />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-medium text-white truncate">{activity.title}</h4>
                    <div className="flex items-center gap-2">
                      {activity.amount && (
                        <span className="text-green-400 font-medium text-sm">
                          +${activity.amount}
                        </span>
                      )}
                      {getStatusBadge(activity.status)}
                    </div>
                  </div>
                  
                  <p className="text-sm text-slate-400 mb-2">{activity.description}</p>
                  
                  <span className="text-xs text-slate-500">
                    {formatTimestamp(activity.timestamp)}
                  </span>
                </div>
              </div>
            );
          })}
          
          {sampleActivities.length === 0 && (
            <div className="text-center py-8">
              <Clock className="w-12 h-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400">No recent activity</p>
              <p className="text-sm text-slate-500 mt-1">Your activities will appear here</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};