import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { BarChart3, TrendingUp, Users, MapPin, DollarSign, Activity, AlertCircle, CheckCircle } from 'lucide-react';

interface ChartData {
  label: string;
  value: number;
  change: number;
  color: string;
}

export default function StatusChartsPanel() {
  const [userGrowthData, setUserGrowthData] = useState<ChartData[]>([
    { label: 'New Users', value: 245, change: 12, color: 'bg-blue-500' },
    { label: 'Active Users', value: 1834, change: 8, color: 'bg-green-500' },
    { label: 'Returning Users', value: 892, change: -3, color: 'bg-purple-500' },
    { label: 'Premium Users', value: 156, change: 25, color: 'bg-yellow-500' }
  ]);

  const [deliveryStats, setDeliveryStats] = useState<ChartData[]>([
    { label: 'Completed', value: 1247, change: 15, color: 'bg-green-500' },
    { label: 'In Progress', value: 89, change: 5, color: 'bg-blue-500' },
    { label: 'Pending', value: 34, change: -8, color: 'bg-yellow-500' },
    { label: 'Cancelled', value: 12, change: -20, color: 'bg-red-500' }
  ]);

  const [revenueData, setRevenueData] = useState<ChartData[]>([
    { label: 'Daily Revenue', value: 15420, change: 18, color: 'bg-green-500' },
    { label: 'Weekly Revenue', value: 98750, change: 12, color: 'bg-blue-500' },
    { label: 'Monthly Revenue', value: 387500, change: 22, color: 'bg-purple-500' },
    { label: 'Yearly Revenue', value: 2450000, change: 35, color: 'bg-yellow-500' }
  ]);

  const [platformHealth, setPlatformHealth] = useState([
    { name: 'API Response Time', value: 98, status: 'excellent', color: 'text-green-600' },
    { name: 'Database Performance', value: 95, status: 'excellent', color: 'text-green-600' },
    { name: 'Server Uptime', value: 99.9, status: 'excellent', color: 'text-green-600' },
    { name: 'Error Rate', value: 0.1, status: 'excellent', color: 'text-green-600' },
    { name: 'User Satisfaction', value: 94, status: 'excellent', color: 'text-green-600' },
    { name: 'Payment Success', value: 99.5, status: 'excellent', color: 'text-green-600' }
  ]);

  useEffect(() => {
    // Simulate real-time data updates
    const interval = setInterval(() => {
      setUserGrowthData(prev => prev.map(item => ({
        ...item,
        value: item.value + Math.floor(Math.random() * 10) - 5,
        change: Math.floor(Math.random() * 40) - 20
      })));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const renderChart = (data: ChartData[], title: string, icon: React.ReactNode) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {icon}
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {data.map((item, index) => (
          <div key={index} className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">{item.label}</span>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold">
                  {item.label.includes('Revenue') ? '$' : ''}
                  {item.value.toLocaleString()}
                </span>
                <Badge 
                  variant={item.change >= 0 ? 'default' : 'destructive'}
                  className={item.change >= 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                >
                  {item.change >= 0 ? '+' : ''}{item.change}%
                </Badge>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className={`h-2 rounded-full ${item.color}`}
                style={{ width: `${Math.min((item.value / Math.max(...data.map(d => d.value))) * 100, 100)}%` }}
              ></div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );

  return (
    <div className="mb-6">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <BarChart3 className="h-6 w-6 text-purple-500" />
        Status Charts & Analytics
      </h2>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="deliveries">Deliveries</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Platform Health */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-green-500" />
                  Platform Health
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {platformHealth.map((metric, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      {metric.status === 'excellent' ? 
                        <CheckCircle className="h-4 w-4 text-green-500" /> : 
                        <AlertCircle className="h-4 w-4 text-yellow-500" />
                      }
                      <span className="text-sm">{metric.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`font-semibold ${metric.color}`}>
                        {metric.value}%
                      </span>
                      <Progress value={metric.value} className="w-16" />
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-blue-500" />
                  Quick Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">1,247</div>
                    <div className="text-sm text-muted-foreground">Orders Today</div>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">$15,420</div>
                    <div className="text-sm text-muted-foreground">Revenue Today</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">89</div>
                    <div className="text-sm text-muted-foreground">Active Drivers</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">156</div>
                    <div className="text-sm text-muted-foreground">New Signups</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="users">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {renderChart(userGrowthData, 'User Growth Analytics', <Users className="h-5 w-5 text-blue-500" />)}
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-green-500" />
                  User Engagement
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Daily Active Users</span>
                    <span className="font-bold">1,834</span>
                  </div>
                  <Progress value={75} />
                  <div className="flex justify-between items-center">
                    <span>Session Duration</span>
                    <span className="font-bold">12.5 min</span>
                  </div>
                  <Progress value={85} />
                  <div className="flex justify-between items-center">
                    <span>Retention Rate</span>
                    <span className="font-bold">68%</span>
                  </div>
                  <Progress value={68} />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="deliveries">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {renderChart(deliveryStats, 'Delivery Statistics', <MapPin className="h-5 w-5 text-green-500" />)}
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-blue-500" />
                  Delivery Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Average Delivery Time</span>
                    <span className="font-bold">28 min</span>
                  </div>
                  <Progress value={92} />
                  <div className="flex justify-between items-center">
                    <span>Success Rate</span>
                    <span className="font-bold">98.5%</span>
                  </div>
                  <Progress value={98.5} />
                  <div className="flex justify-between items-center">
                    <span>Customer Satisfaction</span>
                    <span className="font-bold">4.8/5</span>
                  </div>
                  <Progress value={96} />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="revenue">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {renderChart(revenueData, 'Revenue Analytics', <DollarSign className="h-5 w-5 text-green-500" />)}
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-purple-500" />
                  Revenue Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Delivery Fees</span>
                    <span className="font-bold">$8,420</span>
                  </div>
                  <Progress value={55} />
                  <div className="flex justify-between items-center">
                    <span>Marketplace Commission</span>
                    <span className="font-bold">$4,200</span>
                  </div>
                  <Progress value={27} />
                  <div className="flex justify-between items-center">
                    <span>Subscription Fees</span>
                    <span className="font-bold">$2,800</span>
                  </div>
                  <Progress value={18} />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}