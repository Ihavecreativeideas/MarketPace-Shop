import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import { Check, Star, Crown, Diamond, Loader2 } from 'lucide-react';

interface PartnershipSubscriptionProps {
  userId?: string;
  onSubscriptionChange?: () => void;
}

const PartnershipSubscription: React.FC<PartnershipSubscriptionProps> = ({ 
  userId, 
  onSubscriptionChange 
}) => {
  const [loading, setLoading] = useState<string | null>(null);
  const { toast } = useToast();

  const tiers = [
    {
      id: 'silver',
      name: 'Silver',
      price: 26.42,
      icon: Star,
      color: 'from-gray-400 to-gray-600',
      features: [
        '20% off delivery fee',
        'Only $0.75 per mile (vs $1.25)',
        '50% off $4 sustainability fee',
        '50% off return fees',
        '1 delivery day a week (4 a month)',
        '8 Deliveries included per day',
        'External web integration',
        'External delivery service integration',
        'Set your own S&H fee',
        'Advanced Analytics',
        'Promotional options',
        'Priority Placement in search'
      ],
      deliveryDiscount: 20,
      sustainabilityDiscount: 50,
      deliveriesIncluded: 8,
      deliveryDaysPerWeek: 1,
      mileDiscount: 0.50,
      searchPriority: 1
    },
    {
      id: 'gold',
      name: 'Gold',
      price: 38.96,
      icon: Crown,
      color: 'from-yellow-400 to-yellow-600',
      popular: true,
      features: [
        '20% off delivery fee',
        'Only $0.75 per mile (vs $1.25)',
        'NO sustainability fee',
        'FREE returns (no return fee)',
        '2 delivery days a week (8 a month)',
        '8 Deliveries included per day',
        'External web integration',
        'External delivery service integration',
        'Set your own S&H fee',
        'Advanced Analytics',
        'Promotional options',
        'Priority Placement in search',
        'Business cards/stickers/merch with QR codes'
      ],
      deliveryDiscount: 20,
      sustainabilityDiscount: 100,
      deliveriesIncluded: 16,
      deliveryDaysPerWeek: 2,
      mileDiscount: 0.50,
      searchPriority: 2
    },
    {
      id: 'platinum',
      name: 'Platinum',
      price: 54.98,
      icon: Diamond,
      color: 'from-purple-400 to-purple-600',
      features: [
        '25% off delivery fee',
        'Only $1.00 per mile (vs $1.25)',
        'NO sustainability fee',
        'FREE returns (no return fee)',
        '3 delivery days a week (12 a month)',
        '8 Deliveries included per day',
        'External web integration',
        'External delivery service integration',
        'Set your own S&H fee',
        'Advanced Analytics & AI tools',
        'Promotional options',
        'Priority Placement in search',
        'Business cards/stickers/merch with QR codes'
      ],
      deliveryDiscount: 25,
      sustainabilityDiscount: 100,
      deliveriesIncluded: 24,
      deliveryDaysPerWeek: 3,
      mileDiscount: 0.25,
      searchPriority: 3
    }
  ];

  const handleSubscribe = async (tier: typeof tiers[0]) => {
    if (!userId) {
      toast({
        title: 'Authentication Required',
        description: 'Please log in to subscribe to a partnership tier.',
        variant: 'destructive'
      });
      return;
    }

    setLoading(tier.id);
    
    try {
      const subscriptionStartDate = new Date();
      const subscriptionEndDate = new Date();
      subscriptionEndDate.setMonth(subscriptionEndDate.getMonth() + 1);

      const { error } = await supabase
        .from('users')
        .update({
          subscription_tier: tier.id,
          delivery_discount: tier.deliveryDiscount,
          sustainability_fee_discount: tier.sustainabilityDiscount,
          search_priority: tier.searchPriority,
          web_integration_enabled: true,
          deliveries_included: tier.deliveriesIncluded,
          delivery_days_per_week: tier.deliveryDaysPerWeek,
          mile_discount: tier.mileDiscount,
          subscription_price: tier.price,
          subscription_start_date: subscriptionStartDate.toISOString(),
          subscription_end_date: subscriptionEndDate.toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('id', userId);

      if (error) throw error;

      toast({
        title: 'Subscription Activated!',
        description: `Welcome to ${tier.name} partnership tier. Your benefits are now active.`
      });

      if (onSubscriptionChange) {
        onSubscriptionChange();
      }
    } catch (error) {
      console.error('Subscription error:', error);
      toast({
        title: 'Subscription Failed',
        description: 'There was an error processing your subscription. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-2xl font-bold mb-2">Regular Partnership Tiers</h3>
        <p className="text-lg text-gray-600 font-medium">
          Choose the plan that fits your business needs
        </p>
      </div>
      <div className="grid md:grid-cols-3 gap-8">
        {tiers.map((tier) => {
          const IconComponent = tier.icon;
          const isLoading = loading === tier.id;
          
          return (
            <Card key={tier.id} className={`relative ${tier.popular ? 'ring-2 ring-blue-500' : ''}`}>
              {tier.popular && (
                <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-blue-500">
                  Most Popular
                </Badge>
              )}
              <CardHeader className="text-center">
                <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-r ${tier.color} flex items-center justify-center mb-4`}>
                  <IconComponent className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-2xl">{tier.name}</CardTitle>
                <div className="text-3xl font-bold text-gray-900">
                  ${tier.price}
                  <span className="text-lg font-normal text-gray-600">/month</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {tier.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  className={`w-full bg-gradient-to-r ${tier.color} hover:opacity-90`}
                  size="lg"
                  onClick={() => handleSubscribe(tier)}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    `Choose ${tier.name}`
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default PartnershipSubscription;