import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, Mail, RefreshCw } from 'lucide-react';

export default function EmailVerification() {
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState<'email' | 'verify' | 'success'>('email');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const sendVerification = async () => {
    setLoading(true);
    setError('');
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setStep('verify');
    } catch (err) {
      setError('Failed to send verification email');
    } finally {
      setLoading(false);
    }
  };

  const verifyCode = async () => {
    setLoading(true);
    setError('');
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      if (code === '123456') {
        setStep('success');
      } else {
        setError('Invalid verification code');
      }
    } catch (err) {
      setError('Verification failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto border-black">
      <CardHeader className="bg-black">
        <CardTitle className="flex items-center gap-2 text-teal-400">
          <Mail className="h-5 w-5" />
          Email Verification
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 pt-6">
        {step === 'email' && (
          <>
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="border-gray-300 focus:border-teal-500"
            />
            <Button 
              onClick={sendVerification} 
              disabled={!email || loading}
              className="w-full bg-black text-teal-400 hover:bg-gray-800"
            >
              {loading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
              Send Verification Code
            </Button>
          </>
        )}
        
        {step === 'verify' && (
          <>
            <p className="text-sm text-black">
              Enter the 6-digit code sent to <span className="text-teal-600 font-medium">{email}</span>
            </p>
            <Input
              placeholder="Enter verification code"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              maxLength={6}
              className="border-gray-300 focus:border-teal-500 text-center text-lg tracking-widest"
            />
            <Button 
              onClick={verifyCode} 
              disabled={code.length !== 6 || loading}
              className="w-full bg-black text-teal-400 hover:bg-gray-800"
            >
              {loading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
              Verify Email
            </Button>
          </>
        )}
        
        {step === 'success' && (
          <Alert className="border-teal-200 bg-teal-50">
            <CheckCircle className="h-4 w-4 text-teal-600" />
            <AlertDescription className="text-black">
              Email verified successfully!
            </AlertDescription>
          </Alert>
        )}
        
        {error && (
          <Alert variant="destructive" className="border-red-200 bg-red-50">
            <AlertDescription className="text-black">{error}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}