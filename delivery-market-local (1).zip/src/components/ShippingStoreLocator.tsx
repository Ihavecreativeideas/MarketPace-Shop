import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { MapPin, Phone, Clock } from 'lucide-react';

interface Store {
  name: string;
  address: string;
  phone: string;
  hours: string;
  distance: string;
  type: 'UPS' | 'USPS' | 'FedEx';
}

const ShippingStoreLocator: React.FC = () => {
  const [zipCode, setZipCode] = useState('');
  const [stores, setStores] = useState<Store[]>([]);
  const [loading, setLoading] = useState(false);

  const mockStores: Store[] = [
    {
      name: 'UPS Store #1234',
      address: '123 Main St, Your City, ST 12345',
      phone: '(555) 123-4567',
      hours: 'Mon-Fri: 8AM-7PM, Sat: 9AM-5PM',
      distance: '0.5 miles',
      type: 'UPS'
    },
    {
      name: 'USPS Post Office',
      address: '456 Oak Ave, Your City, ST 12345',
      phone: '(555) 234-5678',
      hours: 'Mon-Fri: 9AM-5PM, Sat: 9AM-1PM',
      distance: '0.8 miles',
      type: 'USPS'
    },
    {
      name: 'FedEx Office',
      address: '789 Pine St, Your City, ST 12345',
      phone: '(555) 345-6789',
      hours: 'Mon-Fri: 8AM-8PM, Sat: 10AM-6PM',
      distance: '1.2 miles',
      type: 'FedEx'
    }
  ];

  const handleSearch = () => {
    if (!zipCode.trim()) return;
    setLoading(true);
    setTimeout(() => {
      setStores(mockStores);
      setLoading(false);
    }, 1000);
  };

  const getStoreColor = (type: Store['type']) => {
    switch (type) {
      case 'UPS': return 'border-yellow-500 bg-yellow-50';
      case 'USPS': return 'border-blue-500 bg-blue-50';
      case 'FedEx': return 'border-purple-500 bg-purple-50';
      default: return 'border-gray-300';
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5" />
          Find Nearby Shipping Stores
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Enter ZIP code"
            value={zipCode}
            onChange={(e) => setZipCode(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
          />
          <Button onClick={handleSearch} disabled={loading}>
            {loading ? 'Searching...' : 'Search'}
          </Button>
        </div>
        
        {stores.length > 0 && (
          <div className="space-y-3">
            {stores.map((store, index) => (
              <div key={index} className={`p-4 rounded-lg border-2 ${getStoreColor(store.type)}`}>
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-lg">{store.name}</h3>
                  <span className="text-sm text-gray-600">{store.distance}</span>
                </div>
                <p className="text-gray-700 mb-1">{store.address}</p>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span className="flex items-center gap-1">
                    <Phone className="w-4 h-4" />
                    {store.phone}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {store.hours}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ShippingStoreLocator;