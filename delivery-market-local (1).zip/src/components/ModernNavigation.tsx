import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from './ui/button';

const ModernNavigation: React.FC = () => {
  const location = useLocation();

  return (
    <nav className="bg-gray-900/95 backdrop-blur-sm border-b border-gray-700 p-4">
      <div className="flex items-center justify-between">
        <Link to="/">
          <h1 className="text-2xl font-bold text-white">MarketPace</h1>
        </Link>
        <div className="text-gray-300 text-sm">
          Welcome to MarketPace
        </div>
      </div>
    </nav>
  );
};

export default ModernNavigation;