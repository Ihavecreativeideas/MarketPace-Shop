import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Music, Mic, Users, Zap, Theater, Crown, Star, MapPin, MessageCircle, Calendar, Play, ShoppingCart, Verified, Search, Plus } from 'lucide-react';
import { useState } from 'react';
import { ISOPostModal } from './ISOPostModal';

interface EntertainmentIndustryProps {
  onBookEntertainer?: (entertainer: any) => void;
}

const EntertainmentIndustry: React.FC<EntertainmentIndustryProps> = ({ onBookEntertainer }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [activeTab, setActiveTab] = useState('performers');
  const [isISOModalOpen, setIsISOModalOpen] = useState(false);
  const [isoPosts, setIsoPosts] = useState<any[]>([]);

  const entertainmentTypes = [
    { value: 'all', label: 'All Entertainment' },
    { value: 'musician', label: 'Musicians' },
    { value: 'dj', label: 'DJs' },
    { value: 'comedian', label: 'Comedians' },
    { value: 'theater', label: 'Theater' },
    { value: 'tech-crew', label: 'Tech Crew' },
    { value: 'solo-acoustic', label: 'Solo Acoustic' },
    { value: 'duo', label: 'Duo' },
    { value: 'cover-band', label: 'Cover Band' },
    { value: 'songwriter', label: 'Songwriters' }
  ];

  const mockEntertainers = [
    {
      id: 1,
      name: 'The Midnight Blues',
      type: 'Cover Band',
      location: 'Downtown',
      rating: 4.8,
      totalGigs: 156,
      isPro: true,
      isVerified: true,
      image: '/placeholder.svg',
      media: { photos: 12, videos: 5, audio: 8 },
      nextShow: 'Dec 15 - Blue Note Cafe',
      priceRange: '$500-800',
      specialties: ['Blues', 'Rock', 'Classic Rock']
    },
    {
      id: 2,
      name: 'DJ Mike Storm',
      type: 'DJ',
      location: 'Uptown',
      rating: 4.9,
      totalGigs: 89,
      isPro: true,
      isVerified: false,
      image: '/placeholder.svg',
      media: { photos: 8, videos: 15, audio: 25 },
      nextShow: 'Dec 18 - Club Nexus',
      priceRange: '$300-600',
      specialties: ['Electronic', 'House', 'Hip-Hop']
    }
  ];

  const filteredEntertainers = mockEntertainers.filter(entertainer => {
    const matchesSearch = entertainer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entertainer.type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || 
                       entertainer.type.toLowerCase().includes(selectedType.replace('-', ' '));
    return matchesSearch && matchesType;
  });

  const getTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'dj': return <Zap className="w-4 h-4" />;
      case 'comedian': return <Mic className="w-4 h-4" />;
      case 'theater': return <Theater className="w-4 h-4" />;
      case 'tech crew': return <Zap className="w-4 h-4" />;
      case 'cover band':
      case 'duo':
      case 'musician': return <Users className="w-4 h-4" />;
      default: return <Music className="w-4 h-4" />;
    }
  };

  const handleBookNow = (entertainer: any) => {
    if (onBookEntertainer) {
      onBookEntertainer(entertainer);
    }
  };

  const handleISOSubmit = (post: any) => {
    setIsoPosts([post, ...isoPosts]);
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-4 bg-gradient-to-r from-purple-50 to-blue-50 p-6 rounded-lg border">
        <h1 className="text-3xl font-bold text-gray-900">Entertainment Hub</h1>
        <p className="text-lg text-gray-700 max-w-3xl mx-auto">
          Discover performers, post ISO requests, rent equipment, book studios, and attend live events.
        </p>
        <Button 
          onClick={() => setIsISOModalOpen(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Search className="w-4 h-4 mr-2" />
          Post ISO (In Search Of)
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="performers">Performers</TabsTrigger>
          <TabsTrigger value="iso">ISO Posts</TabsTrigger>
          <TabsTrigger value="equipment">Equipment</TabsTrigger>
        </TabsList>

        <TabsContent value="iso" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">ISO Posts</h2>
            <Button onClick={() => setIsISOModalOpen(true)} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Post ISO
            </Button>
          </div>
          
          {isoPosts.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 rounded-lg">
              <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No ISO posts yet</h3>
              <p className="text-gray-600 mb-4">Be the first to post what you're looking for!</p>
              <Button onClick={() => setIsISOModalOpen(true)} className="bg-blue-600 hover:bg-blue-700">
                Post First ISO
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {isoPosts.map((post) => (
                <Card key={post.id} className="hover:shadow-lg transition-all duration-200">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="text-lg font-semibold">{post.title}</h3>
                        <p className="text-sm text-gray-600">by {post.author} • {new Date(post.createdAt).toLocaleDateString()}</p>
                      </div>
                      <Badge className="bg-blue-100 text-blue-800">{post.category}</Badge>
                    </div>
                    
                    <p className="text-gray-700 mb-3">{post.description}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-3">
                      {post.tags.map((tag: string, idx: number) => (
                        <Badge key={idx} variant="outline" className="text-xs">{tag}</Badge>
                      ))}
                    </div>
                    
                    <div className="flex justify-between items-center text-sm text-gray-600">
                      <div className="flex gap-4">
                        {post.location && <span>📍 {post.location}</span>}
                        {post.budget && <span>💰 {post.budget}</span>}
                        {post.deadline && <span>⏰ {post.deadline}</span>}
                      </div>
                      <span>{post.responses} responses</span>
                    </div>
                    
                    <div className="flex gap-2 mt-4">
                      <Button size="sm" variant="outline" className="flex-1">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Respond
                      </Button>
                      <Button size="sm" variant="ghost">
                        Share
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="performers" className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <Input
              placeholder="Search entertainers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Entertainment Type" />
              </SelectTrigger>
              <SelectContent>
                {entertainmentTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEntertainers.map((entertainer) => (
              <Card key={entertainer.id} className="hover:shadow-lg transition-all duration-200">
                <CardHeader className="p-0 relative">
                  <img 
                    src={entertainer.image} 
                    alt={entertainer.name} 
                    className="w-full h-48 object-cover rounded-t-lg" 
                  />
                  <div className="absolute top-2 right-2 flex gap-1">
                    {entertainer.isPro && (
                      <Badge className="bg-purple-600">
                        <Crown className="w-3 h-3 mr-1" />PRO
                      </Badge>
                    )}
                    {entertainer.isVerified && (
                      <Badge className="bg-blue-600">
                        <Verified className="w-3 h-3" />
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent className="p-4 space-y-3">
                  <div>
                    <CardTitle className="text-lg">{entertainer.name}</CardTitle>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-3 h-3" />
                      <span>{entertainer.location}</span>
                      <span>•</span>
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span>{entertainer.rating}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {entertainer.specialties.slice(0, 3).map((specialty, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {specialty}
                      </Badge>
                    ))}
                  </div>

                  <div className="text-sm font-medium text-green-600">
                    {entertainer.priceRange}
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <Play className="w-4 h-4 mr-1" />
                      View
                    </Button>
                    <Button 
                      size="sm" 
                      className="bg-blue-600 hover:bg-blue-700"
                      onClick={() => handleBookNow(entertainer)}
                    >
                      Book
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="equipment">
          <div className="text-center py-12 bg-gray-50 rounded-lg">
            <h3 className="text-lg font-medium mb-2">Equipment Rental</h3>
            <p className="text-gray-600">Coming soon...</p>
          </div>
        </TabsContent>
      </Tabs>

      <ISOPostModal 
        isOpen={isISOModalOpen}
        onClose={() => setIsISOModalOpen(false)}
        onSubmit={handleISOSubmit}
      />
    </div>
  );
};

export default EntertainmentIndustry;
export { EntertainmentIndustry };