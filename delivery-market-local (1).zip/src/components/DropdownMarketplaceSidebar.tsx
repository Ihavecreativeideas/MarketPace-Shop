import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { 
  Menu, 
  Filter, 
  ShoppingBag, 
  Star, 
  MapPin,
  DollarSign,
  Truck,
  Package,
  ChevronDown
} from 'lucide-react';

interface FilterState {
  priceRange: [number, number];
  category: string;
  rating: number;
  deliveryType: string;
  distance: number;
}

interface DropdownMarketplaceSidebarProps {
  filters: FilterState;
  onFiltersChange: (filters: Partial<FilterState>) => void;
  onClearFilters: () => void;
  onSectionChange: (section: string) => void;
  activeSection: string;
  className?: string;
}

const DropdownMarketplaceSidebar: React.FC<DropdownMarketplaceSidebarProps> = ({
  filters,
  onFiltersChange,
  onClearFilters,
  onSectionChange,
  activeSection,
  className
}) => {
  const sections = [
    { id: 'marketplace', label: 'Marketplace', icon: ShoppingBag },
    { id: 'rent-anything', label: 'Rent Anything', icon: Package }
  ];

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'electronics', label: 'Electronics' },
    { value: 'clothing', label: 'Clothing' },
    { value: 'home', label: 'Home & Garden' },
    { value: 'food', label: 'Food & Beverages' },
    { value: 'services', label: 'Services' }
  ];

  const deliveryTypes = [
    { value: 'all', label: 'All Delivery' },
    { value: 'local', label: 'Local Delivery' },
    { value: 'pickup', label: 'Pickup Only' },
    { value: 'shipping', label: 'Shipping' }
  ];

  return (
    <div className="flex gap-2 flex-wrap">
      {/* Sections Dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <Menu className="w-4 h-4 mr-2" />
            Sections
            <ChevronDown className="w-4 h-4 ml-2" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-48">
          {sections.map(section => {
            const Icon = section.icon;
            return (
              <DropdownMenuItem
                key={section.id}
                onClick={() => onSectionChange(section.id)}
                className={activeSection === section.id ? 'bg-primary/10' : ''}
              >
                <Icon className="w-4 h-4 mr-2" />
                {section.label}
              </DropdownMenuItem>
            );
          })}
        </DropdownMenuContent>
      </DropdownMenu>

      {activeSection === 'marketplace' && (
        <>
          {/* Categories Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <ShoppingBag className="w-4 h-4 mr-2" />
                Categories
                <ChevronDown className="w-4 h-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48">
              {categories.map(category => (
                <DropdownMenuItem
                  key={category.value}
                  onClick={() => onFiltersChange({ category: category.value })}
                  className={filters.category === category.value ? 'bg-primary/10' : ''}
                >
                  {category.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Rating Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Star className="w-4 h-4 mr-2" />
                Rating
                <ChevronDown className="w-4 h-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-32">
              {[4, 3, 2, 1].map(rating => (
                <DropdownMenuItem
                  key={rating}
                  onClick={() => onFiltersChange({ rating })}
                  className={filters.rating === rating ? 'bg-primary/10' : ''}
                >
                  <div className="flex items-center gap-1">
                    {rating}+ <Star className="w-3 h-3 fill-current" />
                  </div>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Delivery Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Truck className="w-4 h-4 mr-2" />
                Delivery
                <ChevronDown className="w-4 h-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-40">
              {deliveryTypes.map(type => (
                <DropdownMenuItem
                  key={type.value}
                  onClick={() => onFiltersChange({ deliveryType: type.value })}
                  className={filters.deliveryType === type.value ? 'bg-primary/10' : ''}
                >
                  {type.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Clear Filters */}
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onClearFilters}
            className="text-red-600 hover:text-red-700"
          >
            Clear Filters
          </Button>
        </>
      )}

      {activeSection === 'rent-anything' && (
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Package className="w-4 h-4" />
          <span>Rent items from neighbors or list your own!</span>
        </div>
      )}
    </div>
  );
};

export default DropdownMarketplaceSidebar;