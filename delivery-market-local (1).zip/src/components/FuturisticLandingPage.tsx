import React from 'react';
import FuturisticHeader from './FuturisticHeader';

const FuturisticLandingPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <FuturisticHeader />
      
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-white mb-4">
            Discover Amazing <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">Products & Services</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            From handcrafted items to professional services and live music - find everything you need in one place
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
          <div className="bg-gray-800/50 p-6 rounded-lg border border-gray-700">
            <h3 className="text-xl font-bold text-cyan-400 mb-2">Marketplace</h3>
            <p className="text-gray-300">Buy and sell items with ease</p>
          </div>
          <div className="bg-gray-800/50 p-6 rounded-lg border border-gray-700">
            <h3 className="text-xl font-bold text-purple-400 mb-2">Services</h3>
            <p className="text-gray-300">Find professional services</p>
          </div>
          <div className="bg-gray-800/50 p-6 rounded-lg border border-gray-700">
            <h3 className="text-xl font-bold text-yellow-400 mb-2">Musicians</h3>
            <p className="text-gray-300">Book live entertainment</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FuturisticLandingPage;