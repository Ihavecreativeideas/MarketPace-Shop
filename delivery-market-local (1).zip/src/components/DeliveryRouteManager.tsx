import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Clock, Package, Route, CheckCircle } from 'lucide-react';

const DeliveryRouteManager: React.FC = () => {
  const [routes, setRoutes] = useState([
    {
      id: 'route-1',
      scheduledTime: '12:00 PM',
      status: 'pending',
      totalDistance: 15.2,
      estimatedDuration: 90,
      stops: [
        {
          id: 'stop-1',
          type: 'pickup',
          address: '123 Seller St',
          customerName: 'Tech Store',
          itemDescription: 'Phone case',
          timeWindow: '12:00-12:15 PM',
          status: 'pending'
        },
        {
          id: 'stop-2',
          type: 'delivery',
          address: '456 Buyer Ave',
          customerName: 'John Smith',
          itemDescription: 'Phone case',
          timeWindow: '12:45-1:00 PM',
          status: 'pending'
        }
      ]
    }
  ]);

  const deliveryTimes = ['9:00 AM', '12:00 PM', '3:00 PM', '6:00 PM', '9:00 PM'];

  const acceptRoute = (routeId: string) => {
    setRoutes(prev => prev.map(route => 
      route.id === routeId ? { ...route, status: 'accepted' } : route
    ));
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Delivery Routes</h1>
        <p className="text-muted-foreground">
          AI-optimized delivery routes. Working hours: 9AM-9PM, routes every 3 hours.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
        {deliveryTimes.map((time, index) => (
          <Card key={index} className="p-4 text-center">
            <Clock className="h-6 w-6 mx-auto mb-2 text-blue-600" />
            <div className="font-semibold">{time}</div>
            <div className="text-sm text-muted-foreground">Route {index + 1}</div>
          </Card>
        ))}
      </div>

      <div className="space-y-6">
        {routes.map((route) => (
          <Card key={route.id} className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-semibold mb-2">Route {route.scheduledTime}</h3>
                <div className="flex gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Route className="h-4 w-4" />
                    {route.totalDistance} miles
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {route.estimatedDuration} min
                  </span>
                  <span className="flex items-center gap-1">
                    <Package className="h-4 w-4" />
                    {route.stops.length} stops
                  </span>
                </div>
              </div>
              <div className="flex gap-2">
                <Badge className={route.status === 'accepted' ? 'bg-green-600' : 'bg-gray-600'}>
                  {route.status.toUpperCase()}
                </Badge>
                {route.status === 'pending' && (
                  <Button size="sm" onClick={() => acceptRoute(route.id)}>
                    Accept Route
                  </Button>
                )}
              </div>
            </div>

            <div className="space-y-3">
              {route.stops.map((stop, index) => (
                <div key={stop.id} className="flex items-center gap-4 p-3 bg-muted/50 rounded-lg">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-semibold ${
                    stop.type === 'pickup' ? 'bg-blue-600' : 'bg-green-600'
                  }`}>
                    {index + 1}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant={stop.type === 'pickup' ? 'default' : 'secondary'}>
                        {stop.type.toUpperCase()}
                      </Badge>
                      <span className="font-medium">{stop.customerName}</span>
                    </div>
                    <div className="text-sm text-muted-foreground mb-1">{stop.itemDescription}</div>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {stop.address}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {stop.timeWindow}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex-shrink-0">
                    {stop.status === 'completed' ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <div className="w-5 h-5 border-2 border-gray-300 rounded-full" />
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="text-sm">
                <strong>Route Rules:</strong> All pickup stops must be completed before delivery stops. 
                Up to 6 items per route. AI optimizes path from sellers to buyers.
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default DeliveryRouteManager;