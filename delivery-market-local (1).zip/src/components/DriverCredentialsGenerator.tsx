import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { User, Mail, Key, CheckCircle } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

interface DriverCredentials {
  username: string;
  password: string;
  email: string;
  fullName: string;
}

const DriverCredentialsGenerator: React.FC = () => {
  const [credentials, setCredentials] = useState<DriverCredentials | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const colors = ['Red', 'Blue', 'Green', 'Purple', 'Orange', 'Yellow', 'Pink', 'Cyan', 'Magenta', 'Lime'];
  const adjectives = ['Swift', 'Rapid', 'Quick', 'Fast', 'Speedy', 'Turbo', 'Dash', 'Rush', 'Zoom', 'Bolt'];

  const generateUsername = (fullName: string) => {
    const nameParts = fullName.toLowerCase().split(' ');
    const firstName = nameParts[0];
    const lastInitial = nameParts[nameParts.length - 1]?.[0] || '';
    const adjective = adjectives[Math.floor(Math.random() * adjectives.length)];
    const randomNum = Math.floor(Math.random() * 99) + 1;
    
    return `${adjective}${firstName.charAt(0).toUpperCase()}${firstName.slice(1)}${lastInitial.toUpperCase()}${randomNum}`;
  };

  const generatePassword = () => {
    const color = colors[Math.floor(Math.random() * colors.length)];
    const number = Math.floor(Math.random() * 9999) + 1000;
    return `${color}${number}`;
  };

  const generateCredentials = async () => {
    setIsGenerating(true);
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockFullName = 'John Driver';
    const mockEmail = 'john.driver@example.com';
    
    const newCredentials = {
      username: generateUsername(mockFullName),
      password: generatePassword(),
      email: mockEmail,
      fullName: mockFullName
    };
    
    setCredentials(newCredentials);
    setIsGenerating(false);
  };

  const sendCongratulationsEmail = async () => {
    if (!credentials) return;
    
    setEmailSent(true);
    
    // In a real app, this would call the hiring manager function
    console.log('Sending congratulations email with credentials:', credentials);
    
    // Simulate email sending
    await new Promise(resolve => setTimeout(resolve, 1000));
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <div className="max-w-2xl mx-auto">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-cyan-400 flex items-center justify-center gap-2">
              <User className="w-6 h-6" />
              Driver Credentials Generator
            </CardTitle>
            <p className="text-gray-400">Hiring Manager: Brayden Clay</p>
          </CardHeader>
          <CardContent className="space-y-6">
            {!credentials ? (
              <div className="text-center">
                <p className="text-gray-300 mb-6">
                  Generate unique driver credentials for approved applicants
                </p>
                <Button
                  onClick={generateCredentials}
                  disabled={isGenerating}
                  className="bg-cyan-600 hover:bg-cyan-700 text-white px-8 py-3"
                >
                  {isGenerating ? 'Generating Credentials...' : 'Generate Driver Credentials'}
                </Button>
              </div>
            ) : (
              <div className="space-y-6">
                <Alert className="bg-green-900 border-green-700">
                  <CheckCircle className="w-4 h-4" />
                  <AlertDescription className="text-green-200">
                    Driver credentials successfully generated!
                  </AlertDescription>
                </Alert>
                
                <div className="bg-gray-700 rounded-lg p-6 space-y-4">
                  <h3 className="text-xl font-bold text-cyan-400 mb-4">Generated Credentials</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-gray-400 uppercase tracking-wider">Full Name</label>
                      <p className="text-white font-semibold">{credentials.fullName}</p>
                    </div>
                    
                    <div>
                      <label className="text-sm text-gray-400 uppercase tracking-wider">Email</label>
                      <p className="text-white font-semibold">{credentials.email}</p>
                    </div>
                    
                    <div>
                      <label className="text-sm text-gray-400 uppercase tracking-wider">Username</label>
                      <div className="flex items-center gap-2">
                        <p className="text-cyan-400 font-bold text-lg">{credentials.username}</p>
                        <Badge className="bg-blue-600">Unique</Badge>
                      </div>
                    </div>
                    
                    <div>
                      <label className="text-sm text-gray-400 uppercase tracking-wider">Password</label>
                      <div className="flex items-center gap-2">
                        <p className="text-green-400 font-bold text-lg">{credentials.password}</p>
                        <Badge className="bg-green-600">Auto-Generated</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 p-4 bg-gray-800 rounded-lg">
                    <h4 className="text-cyan-400 font-semibold mb-2">Password Format:</h4>
                    <p className="text-gray-300 text-sm">
                      Random Color + Random Number (e.g., {credentials.password})
                    </p>
                  </div>
                </div>
                
                {!emailSent ? (
                  <div className="text-center">
                    <Button
                      onClick={sendCongratulationsEmail}
                      className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 flex items-center gap-2 mx-auto"
                    >
                      <Mail className="w-4 h-4" />
                      Send Congratulations Email
                    </Button>
                    <p className="text-sm text-gray-400 mt-2">
                      Brayden Clay will send the credentials via email
                    </p>
                  </div>
                ) : (
                  <Alert className="bg-blue-900 border-blue-700">
                    <Mail className="w-4 h-4" />
                    <AlertDescription className="text-blue-200">
                      Congratulations email sent successfully! The driver will receive their credentials shortly.
                    </AlertDescription>
                  </Alert>
                )}
                
                <div className="mt-6 p-4 bg-purple-900/30 border border-purple-700 rounded-lg">
                  <h4 className="text-purple-400 font-semibold mb-2 flex items-center gap-2">
                    <Key className="w-4 h-4" />
                    Hiring Manager Note:
                  </h4>
                  <p className="text-purple-200 text-sm italic">
                    "Congratulations on joining our elite driver network! Your unique credentials have been 
                    carefully generated to ensure maximum security and easy memorability. Welcome to the future 
                    of delivery services!" - Brayden Clay, Hiring Manager
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DriverCredentialsGenerator;