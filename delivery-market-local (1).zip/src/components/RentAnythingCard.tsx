import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, MapPin, MessageCircle, Truck } from 'lucide-react';

interface RentalItem {
  id: string;
  title: string;
  description: string;
  pricePerHour: number;
  pricePerDay: number;
  category: string;
  location: string;
  availability: string;
  rating: number;
  imageUrl?: string;
  owner: {
    name: string;
    rating: number;
  };
}

interface RentAnythingCardProps {
  item: RentalItem;
  onRent: (itemId: string) => void;
  onMessage: (itemId: string) => void;
}

const RentAnythingCard: React.FC<RentAnythingCardProps> = ({
  item,
  onRent,
  onMessage
}) => {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle className="text-lg">{item.title}</CardTitle>
            <p className="text-sm text-gray-600 mt-1">{item.description}</p>
          </div>
          <Badge variant="secondary">{item.category}</Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <MapPin className="w-4 h-4 text-gray-500" />
            <span>{item.location}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4 text-gray-500" />
            <span>{item.availability}</span>
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <div>
            <div className="text-lg font-semibold text-green-600">
              ${item.pricePerHour}/hr
            </div>
            <div className="text-sm text-gray-600">
              ${item.pricePerDay}/day
            </div>
          </div>
          
          <div className="text-right">
            <div className="text-sm font-medium">{item.owner.name}</div>
            <div className="text-xs text-gray-600">
              ⭐ {item.owner.rating}/5
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button 
            onClick={() => onRent(item.id)}
            className="flex-1"
            size="sm"
          >
            <Truck className="w-4 h-4 mr-1" />
            Rent Now
          </Button>
          <Button 
            onClick={() => onMessage(item.id)}
            variant="outline"
            size="sm"
          >
            <MessageCircle className="w-4 h-4" />
          </Button>
        </div>
        
        <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded">
          📦 Delivery available via MarketPace drivers
        </div>
      </CardContent>
    </Card>
  );
};

export default RentAnythingCard;