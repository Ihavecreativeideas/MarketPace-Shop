import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { VisuallyHidden } from '@/components/ui/visually-hidden';
import { Calendar, MapPin, Clock, DollarSign, MessageCircle, ShoppingCart } from 'lucide-react';
import { useState } from 'react';
import { toast } from '@/hooks/use-toast';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  entertainer: any;
  onBookingComplete: (booking: any) => void;
}

const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, entertainer, onBookingComplete }) => {
  const [bookingType, setBookingType] = useState('booking');
  const [eventType, setEventType] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [eventTime, setEventTime] = useState('');
  const [venue, setVenue] = useState('');
  const [budget, setBudget] = useState('');
  const [message, setMessage] = useState('');
  const [contactInfo, setContactInfo] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const eventTypes = [
    'Wedding', 'Corporate Event', 'Birthday Party', 'Concert', 'Festival',
    'Private Party', 'Club Night', 'Restaurant Gig', 'Theater Show', 'Comedy Night'
  ];

  const handleSubmit = async () => {
    if (!eventType || !eventDate || !venue || !contactInfo) {
      toast({ title: 'Error', description: 'Please fill in all required fields.' });
      return;
    }

    setSubmitting(true);
    
    // Simulate booking process
    setTimeout(() => {
      const bookingData = {
        id: Date.now(),
        entertainerId: entertainer.id,
        entertainerName: entertainer.name,
        type: bookingType,
        eventType,
        eventDate,
        eventTime,
        venue,
        budget,
        message,
        contactInfo,
        status: 'pending',
        createdAt: new Date().toISOString()
      };
      
      onBookingComplete(bookingData);
      toast({ 
        title: 'Success', 
        description: bookingType === 'booking' 
          ? 'Booking request sent successfully!' 
          : 'Purchase request sent successfully!' 
      });
      
      // Reset form
      setEventType('');
      setEventDate('');
      setEventTime('');
      setVenue('');
      setBudget('');
      setMessage('');
      setContactInfo('');
      setSubmitting(false);
      onClose();
    }, 1500);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {bookingType === 'booking' ? (
              <Calendar className="w-5 h-5" />
            ) : (
              <ShoppingCart className="w-5 h-5" />
            )}
            {bookingType === 'booking' ? 'Book' : 'Buy from'} {entertainer?.name}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Booking Type */}
          <div>
            <Label>Request Type</Label>
            <div className="flex gap-2 mt-2">
              <Button
                variant={bookingType === 'booking' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setBookingType('booking')}
                className="flex items-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                Book Performance
              </Button>
              <Button
                variant={bookingType === 'purchase' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setBookingType('purchase')}
                className="flex items-center gap-2"
              >
                <ShoppingCart className="w-4 h-4" />
                Buy Tickets/Merch
              </Button>
            </div>
          </div>

          {/* Event Type */}
          <div>
            <Label>Event Type *</Label>
            <Select value={eventType} onValueChange={setEventType}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Select event type" />
              </SelectTrigger>
              <SelectContent>
                {eventTypes.map(type => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Date and Time */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Event Date *</Label>
              <Input
                type="date"
                value={eventDate}
                onChange={(e) => setEventDate(e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Event Time</Label>
              <Input
                type="time"
                value={eventTime}
                onChange={(e) => setEventTime(e.target.value)}
                className="mt-1"
              />
            </div>
          </div>

          {/* Venue */}
          <div>
            <Label>Venue/Location *</Label>
            <div className="relative mt-1">
              <MapPin className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <Input
                value={venue}
                onChange={(e) => setVenue(e.target.value)}
                placeholder="Enter venue or event location"
                className="pl-10"
              />
            </div>
          </div>

          {/* Budget */}
          <div>
            <Label>Budget Range</Label>
            <div className="relative mt-1">
              <DollarSign className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <Input
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                placeholder="e.g., $500-800"
                className="pl-10"
              />
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <Label>Contact Information *</Label>
            <Input
              value={contactInfo}
              onChange={(e) => setContactInfo(e.target.value)}
              placeholder="Your phone number or email"
              className="mt-1"
            />
          </div>

          {/* Message */}
          <div>
            <Label>Additional Message</Label>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell them more about your event or requirements..."
              className="mt-1"
              rows={4}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={handleSubmit} 
              disabled={submitting}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              {submitting ? (
                'Sending...'
              ) : (
                <>
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Send Request
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BookingModal;