import { Card, CardContent } from './ui/card';
import { Heart, Clock } from 'lucide-react';

const MedPace: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 py-12">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-100 rounded-full mb-6">
            <Heart className="w-10 h-10 text-blue-600" />
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">MedPace</h1>
          <div className="mt-4 p-6 bg-yellow-50 border border-yellow-200 rounded-lg">
            <Clock className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
            <p className="text-yellow-800 font-semibold text-xl">Coming Soon</p>
            <p className="text-yellow-700 mt-2">Prescription delivery service launching soon!</p>
          </div>
        </div>

        <Card className="shadow-lg">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Safe & Secure Prescription Delivery
            </h3>
            <p className="text-gray-600 mb-6">
              MedPace will provide reliable prescription delivery services to your community.
              Stay tuned for updates on our launch!
            </p>
            <div className="inline-flex items-center space-x-2 text-blue-600">
              <Heart className="w-5 h-5" />
              <span className="font-medium">Caring for your community, one delivery at a time</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MedPace;