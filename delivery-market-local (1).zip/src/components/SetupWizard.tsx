import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Circle, AlertCircle, ExternalLink, BookOpen } from 'lucide-react';
import { supabase, isDemoMode } from '@/lib/supabase';

interface SetupStep {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  action?: () => void;
  link?: string;
}

export default function SetupWizard() {
  const [steps, setSteps] = useState<SetupStep[]>([]);
  const [isVisible, setIsVisible] = useState(true);
  const [showGuide, setShowGuide] = useState(false);

  useEffect(() => {
    checkSetupStatus();
  }, []);

  const checkSetupStatus = async () => {
    const setupSteps: SetupStep[] = [
      {
        id: 'supabase',
        title: 'Configure Supabase',
        description: isDemoMode() ? 'Replace demo credentials with your own' : 'Supabase configured',
        completed: !isDemoMode()
      },
      {
        id: 'database',
        title: 'Set up Database',
        description: 'Create required tables in Supabase',
        completed: false
      },
      {
        id: 'env',
        title: 'Environment Variables',
        description: 'Create .env.local with your credentials',
        completed: !isDemoMode()
      }
    ];

    // Check database connection
    try {
      const { data, error } = await supabase.from('users').select('count').limit(1);
      if (!error) {
        setupSteps[1].completed = true;
      }
    } catch (err) {
      console.log('Database check failed:', err);
    }

    setSteps(setupSteps);
  };

  const allCompleted = steps.every(step => step.completed);
  const hasIncomplete = steps.some(step => !step.completed);

  if (!isVisible || allCompleted) return null;

  return (
    <Card className="mb-6 border-orange-200 bg-orange-50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-orange-600" />
              Setup Required
            </CardTitle>
            <CardDescription>
              Complete these steps to fully configure MarketPace
            </CardDescription>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setIsVisible(false)}>
            ×
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {steps.map((step) => (
            <div key={step.id} className="flex items-center gap-3">
              {step.completed ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <Circle className="h-5 w-5 text-gray-400" />
              )}
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{step.title}</span>
                  <Badge variant={step.completed ? 'default' : 'secondary'}>
                    {step.completed ? 'Complete' : 'Pending'}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
        
        {hasIncomplete && (
          <div className="mt-6 pt-4 border-t">
            <div className="flex gap-2">
              <Button size="sm" onClick={() => setShowGuide(true)}>
                <BookOpen className="h-4 w-4 mr-2" />
                View Setup Guide
              </Button>
              <Button variant="outline" size="sm" onClick={checkSetupStatus}>
                Recheck Status
              </Button>
            </div>
          </div>
        )}
      </CardContent>
      
      {showGuide && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">MarketPace Setup Guide</h2>
                <Button variant="ghost" onClick={() => setShowGuide(false)}>×</Button>
              </div>
              <SetupGuideContent />
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}

function SetupGuideContent() {
  return (
    <div className="prose max-w-none">
      <h3>🚀 Quick Start (Choose Your Method)</h3>
      
      <div className="grid md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Method 1: GitHub Codespaces</CardTitle>
            <CardDescription>Fastest - No Install</CardDescription>
          </CardHeader>
          <CardContent className="text-sm space-y-2">
            <p>1. Go to your GitHub repository</p>
            <p>2. Click green "Code" button</p>
            <p>3. Select "Codespaces" tab</p>
            <p>4. Click "Create codespace on main"</p>
            <p>5. Run: <code>npm install && npm run dev</code></p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Method 2: StackBlitz</CardTitle>
            <CardDescription>Browser-Based</CardDescription>
          </CardHeader>
          <CardContent className="text-sm space-y-2">
            <p>1. Go to stackblitz.com</p>
            <p>2. Click "Import from GitHub"</p>
            <p>3. Paste your repository URL</p>
            <p>4. Wait for automatic setup</p>
            <p>✅ App starts automatically</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Method 3: Local Dev</CardTitle>
            <CardDescription>Node.js v18+ required</CardDescription>
          </CardHeader>
          <CardContent className="text-sm space-y-2">
            <p>1. <code>git clone &lt;repo-url&gt;</code></p>
            <p>2. <code>npm install</code></p>
            <p>3. <code>npm run dev</code></p>
            <p>4. Open localhost:5173</p>
          </CardContent>
        </Card>
      </div>
      
      <h3>🔧 Optional: Supabase Backend Setup</h3>
      <p><strong>Only needed for:</strong> User accounts, purchases, data persistence</p>
      
      <div className="bg-blue-50 p-4 rounded-lg mb-4">
        <h4 className="font-semibold mb-2">Step 1: Create Supabase Project</h4>
        <p>1. Go to supabase.com → Sign up/login</p>
        <p>2. Click "New Project" → Fill details → Wait 2-3 minutes</p>
      </div>
      
      <div className="bg-green-50 p-4 rounded-lg mb-4">
        <h4 className="font-semibold mb-2">Step 2: Get Credentials</h4>
        <p>1. In Supabase dashboard: Settings → API</p>
        <p>2. Copy Project URL and anon public key</p>
      </div>
      
      <div className="bg-yellow-50 p-4 rounded-lg mb-4">
        <h4 className="font-semibold mb-2">Step 3: Configure Environment</h4>
        <p>1. Create .env.local file</p>
        <p>2. Add your Supabase credentials</p>
        <p>3. Restart: <code>npm run dev</code></p>
      </div>
      
      <h3>🚨 Troubleshooting</h3>
      <ul className="list-disc pl-6 space-y-1">
        <li><strong>Build Errors:</strong> Check browser console (F12), verify Node.js v18+</li>
        <li><strong>Guest Mode:</strong> Verify WelcomeScreen.tsx is imported</li>
        <li><strong>Supabase:</strong> Check credentials in .env.local</li>
      </ul>
    </div>
  );
}