import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X, Bell } from 'lucide-react';

interface NotificationCenterProps {
  userId: string;
  onClose: () => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({ userId, onClose }) => {
  const notifications = [
    { id: '1', message: 'Welcome to MarketPace!', time: '2 min ago' },
    { id: '2', message: 'New items in your area', time: '1 hour ago' }
  ];

  return (
    <Card className="w-80 bg-white/10 backdrop-blur-lg border-white/20 shadow-xl">
      <div className="flex items-center justify-between p-4 border-b border-white/10">
        <div className="flex items-center space-x-2">
          <Bell className="w-5 h-5 text-cyan-400" />
          <h3 className="font-semibold text-white">Notifications</h3>
        </div>
        <Button variant="ghost" size="sm" onClick={onClose} className="text-gray-400 hover:text-white">
          <X className="w-4 h-4" />
        </Button>
      </div>
      
      <CardContent className="p-0 max-h-64 overflow-y-auto">
        {notifications.map((notification) => (
          <div key={notification.id} className="p-4 border-b border-white/5 hover:bg-white/5 transition-colors">
            <p className="text-sm text-white mb-1">{notification.message}</p>
            <p className="text-xs text-gray-400">{notification.time}</p>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};