import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Upload, Music, Video, Image, FileText } from 'lucide-react';
import { useState } from 'react';
import { toast } from '@/hooks/use-toast';

interface MediaUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadComplete: (media: any) => void;
}

const MediaUploadModal: React.FC<MediaUploadModalProps> = ({ isOpen, onClose, onUploadComplete }) => {
  const [mediaType, setMediaType] = useState('photo');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const mediaTypes = [
    { value: 'photo', label: 'Photo', icon: Image, accept: 'image/*' },
    { value: 'video', label: 'Video Clip', icon: Video, accept: 'video/*' },
    { value: 'audio', label: 'Music/Audio', icon: Music, accept: 'audio/*' },
    { value: 'flyer', label: 'Flyer/Poster', icon: FileText, accept: 'image/*,application/pdf' }
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
    }
  };

  const handleUpload = async () => {
    if (!file || !title) {
      toast({ title: 'Error', description: 'Please select a file and enter a title.' });
      return;
    }

    setUploading(true);
    
    // Simulate upload process
    setTimeout(() => {
      const mediaData = {
        id: Date.now(),
        type: mediaType,
        title,
        description,
        fileName: file.name,
        fileSize: file.size,
        uploadDate: new Date().toISOString()
      };
      
      onUploadComplete(mediaData);
      toast({ title: 'Success', description: 'Media uploaded successfully!' });
      
      // Reset form
      setTitle('');
      setDescription('');
      setFile(null);
      setUploading(false);
      onClose();
    }, 2000);
  };

  const selectedType = mediaTypes.find(type => type.value === mediaType);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Upload Media</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Media Type Selection */}
          <div>
            <Label>Media Type</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {mediaTypes.map((type) => {
                const Icon = type.icon;
                return (
                  <Button
                    key={type.value}
                    variant={mediaType === type.value ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setMediaType(type.value)}
                    className="flex items-center gap-2"
                  >
                    <Icon className="w-4 h-4" />
                    {type.label}
                  </Button>
                );
              })}
            </div>
          </div>

          {/* File Upload */}
          <div>
            <Label>Select File</Label>
            <div className="mt-2">
              <Input
                type="file"
                accept={selectedType?.accept}
                onChange={handleFileChange}
                className="cursor-pointer"
              />
              {file && (
                <p className="text-sm text-gray-600 mt-1">
                  Selected: {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
                </p>
              )}
            </div>
          </div>

          {/* Title */}
          <div>
            <Label>Title *</Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter media title"
              className="mt-1"
            />
          </div>

          {/* Description */}
          <div>
            <Label>Description</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Optional description"
              className="mt-1"
              rows={3}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={handleUpload} 
              disabled={!file || !title || uploading}
              className="flex-1"
            >
              {uploading ? (
                'Uploading...'
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Upload
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default MediaUploadModal;