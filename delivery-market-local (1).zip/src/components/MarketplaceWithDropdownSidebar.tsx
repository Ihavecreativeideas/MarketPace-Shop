import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Search, 
  ShoppingCart, 
  Star, 
  Heart,
  Share2,
  Eye,
  Crown
} from 'lucide-react';
import DropdownMarketplaceSidebar from './DropdownMarketplaceSidebar';
import RentAnything from './RentAnything';

interface Product {
  id: number;
  name: string;
  price: number;
  shop: string;
  rating: number;
  image: string;
  category: string;
  deliveryType: string;
  distance: number;
  isPartner: boolean;
  views: number;
  likes: number;
}

interface FilterState {
  priceRange: [number, number];
  category: string;
  rating: number;
  deliveryType: string;
  distance: number;
}

const MarketplaceWithDropdownSidebar: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [likedItems, setLikedItems] = useState<Set<number>>(new Set());
  const [activeSection, setActiveSection] = useState('marketplace');
  const [filters, setFilters] = useState<FilterState>({
    priceRange: [0, 500],
    category: 'all',
    rating: 0,
    deliveryType: 'all',
    distance: 20
  });

  const [products] = useState<Product[]>([
    {
      id: 1,
      name: 'Handcrafted Ceramic Mug',
      price: 24.99,
      shop: 'Clay Creations',
      rating: 4.8,
      image: '/placeholder.svg',
      category: 'home',
      deliveryType: 'local',
      distance: 1.2,
      isPartner: false,
      views: 1234,
      likes: 89
    },
    {
      id: 2,
      name: 'Vintage Band T-Shirt',
      price: 35.00,
      shop: 'Retro Threads',
      rating: 4.6,
      image: '/placeholder.svg',
      category: 'clothing',
      deliveryType: 'local',
      distance: 3.5,
      isPartner: true,
      views: 856,
      likes: 156
    },
    {
      id: 3,
      name: 'Fresh Pizza Margherita',
      price: 18.99,
      shop: 'Tony\'s Pizzeria',
      rating: 4.9,
      image: '/placeholder.svg',
      category: 'food',
      deliveryType: 'local',
      distance: 2.8,
      isPartner: true,
      views: 2341,
      likes: 234
    },
    {
      id: 4,
      name: 'Wireless Headphones',
      price: 129.99,
      shop: 'Tech Store',
      rating: 4.5,
      image: '/placeholder.svg',
      category: 'electronics',
      deliveryType: 'shipping',
      distance: 15.2,
      isPartner: false,
      views: 567,
      likes: 78
    }
  ]);

  const handleFiltersChange = (newFilters: Partial<FilterState>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  const handleClearFilters = () => {
    setFilters({
      priceRange: [0, 500],
      category: 'all',
      rating: 0,
      deliveryType: 'all',
      distance: 20
    });
  };

  const toggleLike = (productId: number) => {
    const newLiked = new Set(likedItems);
    if (newLiked.has(productId)) {
      newLiked.delete(productId);
    } else {
      newLiked.add(productId);
    }
    setLikedItems(newLiked);
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.shop.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filters.category === 'all' || product.category === filters.category;
    const matchesPrice = product.price >= filters.priceRange[0] && product.price <= filters.priceRange[1];
    const matchesRating = filters.rating === 0 || product.rating >= filters.rating;
    const matchesDelivery = filters.deliveryType === 'all' || product.deliveryType === filters.deliveryType;
    const matchesDistance = product.distance <= filters.distance;
    
    return matchesSearch && matchesCategory && matchesPrice && matchesRating && matchesDelivery && matchesDistance;
  });

  const renderMarketplace = () => (
    <>
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-4">MarketPace</h1>
        
        {/* Search Bar */}
        <div className="relative max-w-md mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Dropdown Filters */}
        <DropdownMarketplaceSidebar
          filters={filters}
          onFiltersChange={handleFiltersChange}
          onClearFilters={handleClearFilters}
          onSectionChange={setActiveSection}
          activeSection={activeSection}
        />
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <Card key={product.id} className="group hover:shadow-lg transition-all duration-300">
            <div className="relative">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-full h-48 object-cover rounded-t-lg group-hover:scale-105 transition-transform duration-300"
              />
              
              {/* Badges */}
              <div className="absolute top-2 left-2 flex flex-col gap-1">
                {product.isPartner && (
                  <Badge className="bg-purple-600">
                    <Crown className="w-3 h-3 mr-1" />Partner
                  </Badge>
                )}
              </div>
              
              {/* Quick Actions */}
              <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => toggleLike(product.id)}
                  className={`p-2 rounded-full bg-white/80 backdrop-blur-sm ${
                    likedItems.has(product.id) ? 'text-red-500' : 'text-gray-600'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${likedItems.has(product.id) ? 'fill-current' : ''}`} />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="p-2 rounded-full bg-white/80 backdrop-blur-sm text-gray-600"
                >
                  <Share2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            <CardContent className="p-4">
              <h3 className="font-semibold text-lg mb-2 line-clamp-1">{product.name}</h3>
              <p className="text-sm text-gray-600 mb-2">{product.shop}</p>
              
              <div className="flex items-center justify-between mb-3">
                <span className="text-xl font-bold text-green-600">
                  ${product.price}
                </span>
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="text-sm">{product.rating}</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1">
                    <Eye className="w-3 h-3" />
                    <span>{product.views}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Heart className="w-3 h-3" />
                    <span>{product.likes}</span>
                  </div>
                </div>
                <span>{product.distance} mi</span>
              </div>
              
              <div className="space-y-2">
                <Button variant="outline" className="w-full">
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Add to Cart
                </Button>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Buy Now
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No products found</p>
          <p className="text-gray-400 text-sm mt-2">Try adjusting your filters or search terms</p>
        </div>
      )}
    </>
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="p-4 md:p-6">
        {activeSection === 'marketplace' && renderMarketplace()}
        {activeSection === 'rent-anything' && <RentAnything />}
      </div>
    </div>
  );
};

export default MarketplaceWithDropdownSidebar;