import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';

export const PrivacyPolicy = () => {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">
            Privacy Policy
          </CardTitle>
          <p className="text-sm text-gray-600 text-center">
            Last updated: {new Date().toLocaleDateString()}
          </p>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px] pr-4">
            <div className="space-y-6">
              <section>
                <h3 className="text-lg font-semibold mb-3">1. Information We Collect</h3>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-medium text-sm mb-2">Personal Information:</h4>
                    <ul className="list-disc list-inside text-sm text-gray-700 space-y-1 ml-4">
                      <li>Name, email address, phone number</li>
                      <li>Delivery addresses</li>
                      <li>Payment information (processed securely)</li>
                      <li>Profile photos and preferences</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm mb-2">Usage Information:</h4>
                    <ul className="list-disc list-inside text-sm text-gray-700 space-y-1 ml-4">
                      <li>Order history and preferences</li>
                      <li>Location data for delivery services</li>
                      <li>Device information and app usage</li>
                      <li>Communication records</li>
                    </ul>
                  </div>
                </div>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">2. How We Use Your Information</h3>
                <ul className="list-disc list-inside text-sm text-gray-700 space-y-1 ml-4">
                  <li>Process and fulfill your orders</li>
                  <li>Provide customer support</li>
                  <li>Send order updates and notifications</li>
                  <li>Improve our services and user experience</li>
                  <li>Prevent fraud and ensure platform security</li>
                  <li>Comply with legal obligations</li>
                </ul>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">3. Information Sharing</h3>
                <p className="text-sm text-gray-700 leading-relaxed mb-2">
                  We share your information only as necessary to provide our services:
                </p>
                <ul className="list-disc list-inside text-sm text-gray-700 space-y-1 ml-4">
                  <li>With merchants to fulfill your orders</li>
                  <li>With delivery partners for order completion</li>
                  <li>With payment processors for transactions</li>
                  <li>With service providers who assist our operations</li>
                  <li>When required by law or legal process</li>
                </ul>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">4. Location Information</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  We collect location data to provide delivery services, estimate delivery times, 
                  and show nearby restaurants. You can control location sharing through your device settings.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">5. Data Security</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  We implement industry-standard security measures to protect your information, including 
                  encryption, secure servers, and regular security assessments. However, no system is 
                  completely secure.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">6. Your Rights and Choices</h3>
                <ul className="list-disc list-inside text-sm text-gray-700 space-y-1 ml-4">
                  <li>Access and update your personal information</li>
                  <li>Delete your account and associated data</li>
                  <li>Opt out of marketing communications</li>
                  <li>Control location sharing permissions</li>
                  <li>Request data portability</li>
                </ul>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">7. Cookies and Tracking</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  We use cookies and similar technologies to improve your experience, analyze usage patterns, 
                  and provide personalized content. You can manage cookie preferences in your browser settings.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">8. Third-Party Services</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  Our app integrates with third-party services (Facebook, Google, payment processors). 
                  These services have their own privacy policies that govern their use of your information.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">9. Children's Privacy</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  Our service is not intended for children under 13. We do not knowingly collect personal 
                  information from children under 13.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">10. Changes to This Policy</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  We may update this Privacy Policy periodically. We will notify you of significant changes 
                  through the app or email.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3">11. Contact Us</h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  For privacy-related questions or requests, contact us at privacy@deliveryapp.com or 
                  through our in-app support.
                </p>
              </section>
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
};