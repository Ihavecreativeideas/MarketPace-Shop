import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Truck, MapPin, Clock, DollarSign, Package, Navigation } from 'lucide-react';

export default function DriverPreview() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-teal-900 to-green-900 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-green-100 p-3 rounded-full">
              <Truck className="h-8 w-8 text-green-600" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">Driver Portal Preview</h1>
          <p className="text-gray-300">MarketPace Driver Dashboard</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">Today's Earnings</p>
                  <p className="text-2xl font-bold text-white">$127.50</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">Deliveries</p>
                  <p className="text-2xl font-bold text-white">8</p>
                </div>
                <Package className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">Miles Driven</p>
                  <p className="text-2xl font-bold text-white">47.2</p>
                </div>
                <Navigation className="h-8 w-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">Online Time</p>
                  <p className="text-2xl font-bold text-white">6.5h</p>
                </div>
                <Clock className="h-8 w-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Package className="h-5 w-5" />
                Available Jobs
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="text-white font-medium">Pharmacy Delivery</p>
                      <p className="text-gray-300 text-sm">CVS → 123 Main St</p>
                    </div>
                    <Badge className="bg-green-500 text-white">$15.50</Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      2.1 mi
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      15 min
                    </span>
                  </div>
                </div>

                <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="text-white font-medium">Grocery Delivery</p>
                      <p className="text-gray-300 text-sm">Local Market → 456 Oak Ave</p>
                    </div>
                    <Badge className="bg-green-500 text-white">$22.00</Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      3.7 mi
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      25 min
                    </span>
                  </div>
                </div>

                <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="text-white font-medium">Restaurant Order</p>
                      <p className="text-gray-300 text-sm">Tony's Pizza → 789 Pine St</p>
                    </div>
                    <Badge className="bg-yellow-500 text-white">$18.75</Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      1.8 mi
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      12 min
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-white text-sm">Delivery completed</p>
                    <p className="text-gray-400 text-xs">Best Buy → Customer</p>
                  </div>
                  <span className="text-green-400 text-sm">+$19.25</span>
                </div>

                <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-white text-sm">Package picked up</p>
                    <p className="text-gray-400 text-xs">Local Pharmacy</p>
                  </div>
                  <span className="text-gray-400 text-sm">2:15 PM</span>
                </div>

                <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-white text-sm">Delivery completed</p>
                    <p className="text-gray-400 text-xs">Grocery Store → Customer</p>
                  </div>
                  <span className="text-green-400 text-sm">+$16.50</span>
                </div>

                <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-white text-sm">Route optimized</p>
                    <p className="text-gray-400 text-xs">3 stops planned</p>
                  </div>
                  <span className="text-gray-400 text-sm">1:45 PM</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8 text-center">
          <p className="text-gray-400 mb-4">This is a preview of the Driver Portal</p>
          <Button className="bg-green-600 hover:bg-green-700 text-white">
            Login to Access Full Portal
          </Button>
        </div>
      </div>
    </div>
  );
}