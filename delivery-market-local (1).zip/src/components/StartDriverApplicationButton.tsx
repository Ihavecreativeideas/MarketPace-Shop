import React from 'react';
import { Button } from './ui/button';
import { Car, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface StartDriverApplicationButtonProps {
  className?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
}

const StartDriverApplicationButton: React.FC<StartDriverApplicationButtonProps> = ({
  className = '',
  variant = 'default',
  size = 'md'
}) => {
  const navigate = useNavigate();

  const handleStartApplication = () => {
    navigate('/driver-application');
  };

  return (
    <Button
      onClick={handleStartApplication}
      className={`bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white font-semibold ${className}`}
      variant={variant}
      size={size}
    >
      <Car className="w-4 h-4 mr-2" />
      Start Application
    </Button>
  );
};

export default StartDriverApplicationButton;