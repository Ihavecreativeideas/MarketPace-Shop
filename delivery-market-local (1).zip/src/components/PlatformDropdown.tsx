import React from 'react';
import { Card, CardContent } from './ui/card';
import { Smartphone, Globe, Download } from 'lucide-react';

const PlatformDropdown: React.FC = () => {
  return (
    <Card className="bg-slate-800/60 border-slate-600/40 backdrop-blur-sm">
      <CardContent className="p-4">
        <div className="flex items-center gap-3 text-sm text-slate-300">
          <div className="flex items-center gap-2">
            <Smartphone className="h-4 w-4 text-teal-400" />
            <span>Mobile App</span>
          </div>
          <div className="flex items-center gap-2">
            <Globe className="h-4 w-4 text-teal-400" />
            <span>Web Platform</span>
          </div>
          <div className="flex items-center gap-2">
            <Download className="h-4 w-4 text-teal-400" />
            <span>Coming Soon</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PlatformDropdown;