import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ExternalLink, Utensils, AlertTriangle, CheckCircle, Crown } from 'lucide-react';

interface FoodServiceIntegrationProps {
  businessType?: string;
  onIntegrationUpdate?: (platform: string, connected: boolean) => void;
  isTrialPhase?: boolean;
  hasSubscription?: boolean;
}

const FoodServiceIntegration: React.FC<FoodServiceIntegrationProps> = ({
  businessType,
  onIntegrationUpdate,
  isTrialPhase = true,
  hasSubscription = false
}) => {
  const [uberEatsConnected, setUberEatsConnected] = useState(false);
  const [doorDashConnected, setDoorDashConnected] = useState(false);
  const [shiptConnected, setShiptConnected] = useState(false);

  const isFoodService = businessType === 'restaurant' || businessType === 'food' || businessType === 'grocery';
  const canAccessFeature = isTrialPhase || hasSubscription;

  const handleUberEatsConnect = () => {
    if (!canAccessFeature) {
      alert('This feature requires a subscription. Please upgrade to continue.');
      return;
    }
    window.open('https://merchants.ubereats.com/us/en/signup/', '_blank');
    setUberEatsConnected(true);
    onIntegrationUpdate?.('ubereats', true);
  };

  const handleDoorDashConnect = () => {
    if (!canAccessFeature) {
      alert('This feature requires a subscription. Please upgrade to continue.');
      return;
    }
    window.open('https://get.doordash.com/en-us/products/business/restaurants', '_blank');
    setDoorDashConnected(true);
    onIntegrationUpdate?.('doordash', true);
  };

  const handleShiptConnect = () => {
    if (!canAccessFeature) {
      alert('This feature requires a subscription. Please upgrade to continue.');
      return;
    }
    window.open('https://www.shipt.com/business', '_blank');
    setShiptConnected(true);
    onIntegrationUpdate?.('shipt', true);
  };

  if (!isFoodService) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Utensils className="h-5 w-5" />
          Food & Grocery Delivery Integration
          {!canAccessFeature && (
            <Badge variant="secondary" className="bg-amber-100 text-amber-800">
              <Crown className="h-3 w-3 mr-1" />
              Subscription Required
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Important:</strong> PostPace drivers cannot deliver food/grocery products directly. 
            Businesses must integrate with approved delivery partners below.
            {isTrialPhase ? (
              <span className="block mt-1 text-green-700">
                ✓ Free during trial phase - Subscribe to continue after trial ends
              </span>
            ) : !hasSubscription ? (
              <span className="block mt-1 text-red-700">
                ⚠ Subscription required to access this feature
              </span>
            ) : null}
          </AlertDescription>
        </Alert>

        <div className="grid gap-4 md:grid-cols-3">
          <Card className={`border-2 ${!canAccessFeature ? 'opacity-60' : ''}`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold">Uber Eats</h3>
                {uberEatsConnected ? (
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Connected
                  </Badge>
                ) : (
                  <Badge variant="outline">Not Connected</Badge>
                )}
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Connect for restaurant food delivery with professional drivers.
              </p>
              <Button 
                onClick={handleUberEatsConnect}
                className="w-full"
                variant={uberEatsConnected ? "outline" : "default"}
                disabled={!canAccessFeature}
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                {uberEatsConnected ? 'Manage Account' : 'Connect Uber Eats'}
              </Button>
            </CardContent>
          </Card>

          <Card className={`border-2 ${!canAccessFeature ? 'opacity-60' : ''}`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold">DoorDash</h3>
                {doorDashConnected ? (
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Connected
                  </Badge>
                ) : (
                  <Badge variant="outline">Not Connected</Badge>
                )}
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Connect for reliable restaurant food delivery services.
              </p>
              <Button 
                onClick={handleDoorDashConnect}
                className="w-full"
                variant={doorDashConnected ? "outline" : "default"}
                disabled={!canAccessFeature}
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                {doorDashConnected ? 'Manage Account' : 'Connect DoorDash'}
              </Button>
            </CardContent>
          </Card>

          <Card className={`border-2 ${!canAccessFeature ? 'opacity-60' : ''}`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold">Shipt</h3>
                {shiptConnected ? (
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Connected
                  </Badge>
                ) : (
                  <Badge variant="outline">Not Connected</Badge>
                )}
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Connect for grocery delivery and shopping services.
              </p>
              <Button 
                onClick={handleShiptConnect}
                className="w-full"
                variant={shiptConnected ? "outline" : "default"}
                disabled={!canAccessFeature}
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                {shiptConnected ? 'Manage Account' : 'Connect Shipt'}
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-semibold text-blue-900 mb-2">Why Use Approved Delivery Partners?</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Specialized food handling and temperature control</li>
            <li>• Licensed food delivery drivers with proper training</li>
            <li>• Insurance coverage specifically for food products</li>
            <li>• Faster delivery times for perishable items</li>
            <li>• Full compliance with food safety regulations</li>
            <li>• Professional customer service for food orders</li>
          </ul>
        </div>

        {!canAccessFeature && (
          <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
            <h4 className="font-semibold text-amber-900 mb-2">Subscription Required</h4>
            <p className="text-sm text-amber-800 mb-3">
              Food and grocery delivery integration is available free during the trial phase. 
              After the trial ends, a subscription is required to continue using this feature.
            </p>
            <Button className="bg-amber-600 hover:bg-amber-700 text-white">
              Upgrade to Pro
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FoodServiceIntegration;