import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ShoppingCart, Search, Filter, MapPin, Clock, Star, Heart, Plus } from 'lucide-react';
import { FloatingBottomNavigation } from './FloatingBottomNavigation';

const Marketplace: React.FC = () => {
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState<number[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showCounterOffer, setShowCounterOffer] = useState<number | null>(null);

  const products = [
    {
      id: 1,
      name: 'Vintage Guitar',
      price: 450,
      originalPrice: 500,
      seller: 'Mike\'s Music',
      location: '2.3 miles away',
      rating: 4.8,
      image: '/api/placeholder/300/200',
      category: 'Music',
      timeSlots: ['9am', '12pm', '3pm', '6pm', '9pm'],
      description: 'Beautiful vintage acoustic guitar in excellent condition'
    },
    {
      id: 2,
      name: 'iPhone 13',
      price: 650,
      originalPrice: 750,
      seller: 'TechStore Local',
      location: '1.8 miles away',
      rating: 4.9,
      image: '/api/placeholder/300/200',
      category: 'Electronics',
      timeSlots: ['9am', '12pm', '3pm', '6pm', '9pm'],
      description: 'Like new iPhone 13 with original box and accessories'
    },
    {
      id: 3,
      name: 'Handmade Pottery Set',
      price: 85,
      originalPrice: 120,
      seller: 'Local Artisan',
      location: '3.1 miles away',
      rating: 4.7,
      image: '/api/placeholder/300/200',
      category: 'Home & Garden',
      timeSlots: ['12pm', '3pm', '6pm'],
      description: 'Beautiful handcrafted pottery set, perfect for home decoration',
      badge: 'USA Made'
    },
    {
      id: 4,
      name: 'Mountain Bike',
      price: 320,
      originalPrice: 400,
      seller: 'Bike Shop Pro',
      location: '4.2 miles away',
      rating: 4.6,
      image: '/api/placeholder/300/200',
      category: 'Sports',
      timeSlots: ['9am', '12pm', '3pm', '6pm'],
      description: 'Well-maintained mountain bike, perfect for trails'
    }
  ];

  const categories = ['all', 'Electronics', 'Music', 'Home & Garden', 'Sports', 'Fashion', 'Books'];
  const discountOptions = [15, 20, 25, 35, 50];

  const addToCart = (productId: number) => {
    setCartItems(prev => [...prev, productId]);
  };

  const handleCounterOffer = (productId: number, discount: number) => {
    console.log(`Counter offer for product ${productId} with ${discount}% discount`);
    setShowCounterOffer(null);
    // In real app, this would send the offer to the seller
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-20">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-sm border-b border-slate-700 px-4 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold text-white">Marketplace</h1>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/cart')}
              className="relative"
            >
              <ShoppingCart className="h-4 w-4" />
              {cartItems.length > 0 && (
                <Badge className="absolute -top-2 -right-2 bg-teal-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                  {cartItems.length}
                </Badge>
              )}
            </Button>
            <Button
              onClick={() => navigate('/post-item')}
              className="bg-teal-500 hover:bg-teal-600 text-white"
              size="sm"
            >
              <Plus className="h-4 w-4 mr-1" />
              Sell
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Search and Filters */}
        <div className="mb-6 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
            />
          </div>
          
          <div className="flex gap-4 items-center">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-48 bg-slate-800/50 border-slate-600 text-white">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category === 'all' ? 'All Categories' : category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              More Filters
            </Button>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-colors">
              <CardHeader className="p-0">
                <div className="relative">
                  <div className="w-full h-48 bg-slate-700 rounded-t-lg flex items-center justify-center">
                    <span className="text-slate-400 text-sm">Product Image</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute top-2 right-2 text-slate-400 hover:text-red-400"
                  >
                    <Heart className="h-4 w-4" />
                  </Button>
                  {product.badge && (
                    <Badge className="absolute top-2 left-2 bg-blue-600 text-white">
                      {product.badge}
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div>
                    <h3 className="text-white font-semibold text-lg">{product.name}</h3>
                    <p className="text-slate-400 text-sm line-clamp-2">{product.description}</p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-teal-400">${product.price}</span>
                      {product.originalPrice > product.price && (
                        <span className="text-slate-500 line-through text-sm">${product.originalPrice}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-yellow-400">
                      <Star className="h-4 w-4 fill-current" />
                      <span className="text-sm">{product.rating}</span>
                    </div>
                  </div>
                  
                  <div className="text-slate-400 text-sm space-y-1">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      <span>{product.location}</span>
                    </div>
                    <div>Sold by: {product.seller}</div>
                  </div>
                  
                  {/* Delivery Time Slots */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-1 text-slate-400 text-sm">
                      <Clock className="h-3 w-3" />
                      <span>Available delivery times:</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {product.timeSlots.map((slot, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {slot}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      onClick={() => addToCart(product.id)}
                      className="flex-1 bg-teal-500 hover:bg-teal-600 text-white"
                      size="sm"
                    >
                      <ShoppingCart className="h-4 w-4 mr-1" />
                      Add to Cart
                    </Button>
                    <Button
                      onClick={() => setShowCounterOffer(product.id)}
                      variant="outline"
                      size="sm"
                      className="text-orange-400 border-orange-400 hover:bg-orange-400/10"
                    >
                      Offer
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Counter Offer Modal */}
      {showCounterOffer && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <Card className="w-full max-w-md bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Make Counter Offer</CardTitle>
              <p className="text-slate-400 text-sm">
                Select a discount percentage for your offer
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-2">
                {discountOptions.map((discount) => {
                  const product = products.find(p => p.id === showCounterOffer);
                  const newPrice = product ? Math.round(product.price * (1 - discount / 100)) : 0;
                  return (
                    <Button
                      key={discount}
                      onClick={() => handleCounterOffer(showCounterOffer, discount)}
                      className="bg-orange-500 hover:bg-orange-600 text-white flex flex-col p-3 h-auto"
                    >
                      <span className="text-lg font-bold">{discount}%</span>
                      <span className="text-xs">off</span>
                      <span className="text-sm">${newPrice}</span>
                    </Button>
                  );
                })}
              </div>
              <div className="text-center text-slate-400 text-sm">
                Seller has 3 hours to respond
              </div>
              <Button
                variant="outline"
                onClick={() => setShowCounterOffer(null)}
                className="w-full"
              >
                Cancel
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      <FloatingBottomNavigation />
    </div>
  );
};

export default Marketplace;
export { Marketplace };