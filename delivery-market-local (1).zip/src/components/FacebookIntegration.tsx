import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import { Facebook, Link, ExternalLink } from 'lucide-react';

export default function FacebookIntegration() {
  const [user, setUser] = useState(null);
  const [fbListingUrl, setFbListingUrl] = useState('');
  const [linkedListings, setLinkedListings] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Load existing listings on mount
  useEffect(() => {
    if (user) {
      loadLinkedListings();
    }
  }, [user]);

  const loadLinkedListings = async () => {
    try {
      const { data, error } = await supabase
        .from('fb_listings')
        .select('*')
        .eq('user_email', user.email);
      
      if (!error && data) {
        setLinkedListings(data);
      }
    } catch (error) {
      console.error('Error loading listings:', error);
    }
  };

  // Facebook Login Handler
  const handleFacebookLogin = async () => {
    setIsLoading(true);
    try {
      // Simulate Facebook login (replace with actual FB SDK)
      const mockResponse = {
        accessToken: 'mock_token',
        email: 'user@example.com',
        name: 'Facebook User',
        userID: 'fb_123456'
      };
      
      const { email, name, userID } = mockResponse;
      
      // Save or update user info in Supabase
      const { data, error } = await supabase.from('users').upsert({
        email,
        full_name: name,
        facebook_id: userID,
        is_facebook_linked: true
      });
      
      if (!error) {
        setUser({ email, name });
        toast({
          title: "Connected to Facebook!",
          description: "You can now link your Facebook Marketplace listings."
        });
      }
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: "Unable to connect to Facebook. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Save FB Listing link
  const handleSaveListing = async () => {
    if (!fbListingUrl.trim()) return;
    
    setIsLoading(true);
    try {
      const { data, error } = await supabase.from('fb_listings').insert({
        user_email: user.email,
        listing_url: fbListingUrl,
        title: 'Facebook Marketplace Item',
        delivery_enabled: true,
        is_active: true
      });
      
      if (!error) {
        setLinkedListings(prev => [...prev, { listing_url: fbListingUrl, title: 'Facebook Marketplace Item' }]);
        setFbListingUrl('');
        toast({
          title: "Listing Linked!",
          description: "Your Facebook listing now offers MarketPace delivery."
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to link listing. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-center">
          <Facebook className="h-6 w-6 text-blue-600" />
          Connect Your Facebook Listings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!user ? (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground text-center">
              Connect your Facebook account to link Marketplace listings with MarketPace delivery
            </p>
            <Button 
              onClick={handleFacebookLogin}
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              <Facebook className="h-4 w-4 mr-2" />
              {isLoading ? 'Connecting...' : 'Connect with Facebook'}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-sm">Welcome, {user.name}!</p>
            
            <div className="space-y-2">
              <Label htmlFor="listing-url">Facebook Marketplace Listing URL</Label>
              <Input
                id="listing-url"
                type="text"
                placeholder="Paste your Facebook Marketplace listing URL"
                value={fbListingUrl}
                onChange={(e) => setFbListingUrl(e.target.value)}
              />
            </div>
            
            <Button
              onClick={handleSaveListing}
              disabled={isLoading || !fbListingUrl.trim()}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <Link className="h-4 w-4 mr-2" />
              {isLoading ? 'Linking...' : 'Link Listing with MarketPace Delivery'}
            </Button>

            {linkedListings.length > 0 && (
              <div className="pt-4 space-y-2">
                <h3 className="font-semibold text-sm">Your Linked Listings:</h3>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {linkedListings.map((listing, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2 bg-muted rounded">
                      <span className="text-xs truncate flex-1">{listing.title || 'Facebook Listing'}</span>
                      <Button size="sm" variant="ghost" asChild>
                        <a href={listing.listing_url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div className="text-xs text-muted-foreground space-y-1">
              <p>• Buyers can request MarketPace delivery</p>
              <p>• Automatic driver assignment</p>
              <p>• Secure payment processing</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}