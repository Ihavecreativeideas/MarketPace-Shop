import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Shield
} from 'lucide-react';

interface AnalysisItem {
  category: string;
  status: 'working' | 'missing' | 'partial';
  description: string;
  details?: string[];
}

const AppAnalysis: React.FC = () => {
  const analysisData: AnalysisItem[] = [
    {
      category: 'Navigation',
      status: 'working',
      description: 'All navigation buttons work correctly',
      details: [
        '✅ Home, Marketplace, Musicians, PaceMakers routes work',
        '✅ Premium Partners page accessible',
        '✅ Mobile responsive navigation',
        '✅ Guest mode and user authentication'
      ]
    },
    {
      category: 'Member Purchases',
      status: 'working',
      description: 'Purchase system is functional',
      details: [
        '✅ Cart system works with add/remove items',
        '✅ Checkout page with delivery options',
        '✅ Order processing and database storage',
        '✅ Multiple payment methods supported'
      ]
    },
    {
      category: 'Stripe Integration',
      status: 'working',
      description: 'Stripe is connected and functional',
      details: [
        '✅ Stripe secrets configured in Supabase',
        '✅ Payment processor function deployed',
        '✅ StripeCheckout component ready',
        '✅ Subscription payments supported'
      ]
    },
    {
      category: 'Business Registration',
      status: 'partial',
      description: 'EIN collection exists but not required',
      details: [
        '⚠️ Business setup forms available',
        '⚠️ EIN field present but optional',
        '⚠️ Tax compliance features basic',
        '✅ Business profile creation works'
      ]
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'working': return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'partial': return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
      case 'missing': return <XCircle className="w-5 h-5 text-red-600" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'working': return 'bg-green-50 border-green-200';
      case 'partial': return 'bg-yellow-50 border-yellow-200';
      case 'missing': return 'bg-red-50 border-red-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">MarketPace App Analysis</h1>
        <p className="text-gray-600">Comprehensive review of app functionality</p>
      </div>

      <div className="grid gap-6">
        {analysisData.map((item, index) => (
          <Card key={index} className={`${getStatusColor(item.status)} border-2`}>
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                {getStatusIcon(item.status)}
                <span>{item.category}</span>
                <Badge 
                  variant={item.status === 'working' ? 'default' : 
                          item.status === 'partial' ? 'secondary' : 'destructive'}
                >
                  {item.status.toUpperCase()}
                </Badge>
              </CardTitle>
              <p className="text-gray-700">{item.description}</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {item.details?.map((detail, idx) => (
                  <li key={idx} className="text-sm">{detail}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>

      <Alert className="bg-blue-50 border-blue-200">
        <Shield className="w-4 h-4" />
        <AlertDescription>
          <strong>Summary:</strong> Your app is functional with working navigation, purchases, and Stripe integration. 
          EIN collection exists but isn't required.
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default AppAnalysis;