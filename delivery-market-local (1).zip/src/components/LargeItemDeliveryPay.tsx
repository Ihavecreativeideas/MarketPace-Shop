import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Truck, DollarSign, MapPin, Zap, Heart } from 'lucide-react';
import LargeItemDeliveryCalculator from './LargeItemDeliveryCalculator';

const LargeItemDeliveryPay: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Tips Highlight */}
      <Card className="border-2 border-green-300 bg-green-50">
        <CardContent className="pt-6">
          <div className="flex items-center justify-center gap-2 text-green-800">
            <Heart className="w-6 h-6" />
            <h3 className="text-xl font-bold">Drivers Keep 100% of All Tips!</h3>
          </div>
          <p className="text-center text-green-700 mt-2">No platform fees or deductions on customer tips</p>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-800">
            <Truck className="w-6 h-6" />
            Large Item Deliveries - $40+ Base Pay
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4 mb-6">
            <div className="bg-white p-4 rounded-lg border-2 border-orange-200 text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">$40+</div>
              <div className="text-sm font-semibold text-gray-700">Minimum Base Pay</div>
              <div className="text-xs text-gray-600">For large items</div>
            </div>
            
            <div className="bg-white p-4 rounded-lg border-2 border-purple-200 text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">$0.50</div>
              <div className="text-sm font-semibold text-gray-700">Per Mile</div>
              <div className="text-xs text-gray-600">Additional mileage</div>
            </div>
          </div>
          
          <div className="bg-red-50 p-4 rounded-lg border border-red-200 mb-4">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-5 h-5 text-red-600" />
              <span className="font-semibold text-red-800">Urgent Delivery Bonus</span>
            </div>
            <p className="text-sm text-red-700">Rush large item deliveries get bonus pay on top of base rate</p>
          </div>
          
          <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
            <div className="flex items-center gap-2 mb-2">
              <MapPin className="w-5 h-5 text-yellow-600" />
              <span className="font-semibold text-yellow-800">Large Items Requiring Heavy Pickup, Truck, or Trailer:</span>
            </div>
            <ul className="text-yellow-700 text-sm space-y-1">
              <li>• Furniture (couches, beds, dressers)</li>
              <li>• Appliances (refrigerators, washers, dryers)</li>
              <li>• Exercise equipment</li>
              <li>• Construction materials</li>
              <li>• Other bulky items requiring specialized vehicles</li>
            </ul>
          </div>
          
          <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800">
              <strong>Fair Pay Structure:</strong> Large item deliveries requiring heavy pickup, truck, or trailer start at $40 minimum, 
              plus $0.50 per mile. Urgent delivery bonuses available. Drivers keep 100% of tips.
            </p>
          </div>
        </CardContent>
      </Card>

      <LargeItemDeliveryCalculator />

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            Driver Earnings Examples
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-gray-800 mb-1">$45.00</div>
              <div className="text-sm text-gray-600 mb-2">10 mile furniture delivery</div>
              <Badge variant="outline">$40 + $5 mileage</Badge>
            </div>
            
            <div className="bg-orange-50 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-orange-600 mb-1">$52.50</div>
              <div className="text-sm text-gray-600 mb-2">25 mile appliance delivery</div>
              <Badge className="bg-orange-600">$40 + $12.50 mileage</Badge>
            </div>
            
            <div className="bg-red-50 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-red-600 mb-1">$67.88</div>
              <div className="text-sm text-gray-600 mb-2">25 mile urgent delivery</div>
              <Badge className="bg-red-600">$52.50 + urgent bonus</Badge>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
            <p className="text-sm text-green-800">
              <strong>100% Tips:</strong> Drivers keep 100% of all tips from buyers and sellers. 
              Large item deliveries often receive generous tips for the extra effort required.
            </p>
          </div>
          
          <div className="mt-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
            <p className="text-sm text-purple-800">
              <strong>Equipment Requirements:</strong> Large item deliveries require drivers to have 
              appropriate vehicles (trucks, trailers) and may need additional helpers for safe handling.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LargeItemDeliveryPay;