import React from 'react';
import { cn } from '../lib/utils';

interface MobileLayoutProps {
  children: React.ReactNode;
  className?: string;
  hasBottomNav?: boolean;
}

const MobileLayout: React.FC<MobileLayoutProps> = ({ 
  children, 
  className,
  hasBottomNav = false 
}) => {
  return (
    <div className={cn(
      "min-h-screen max-w-md mx-auto bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900",
      "relative overflow-x-hidden",
      hasBottomNav && "pb-20",
      className
    )}>
      <div className="relative z-10 h-full">
        {children}
      </div>
    </div>
  );
};

export default MobileLayout;