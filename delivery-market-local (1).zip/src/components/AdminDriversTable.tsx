import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Star, MapPin, DollarSign, Clock, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Driver {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  status: 'active' | 'inactive' | 'probationary';
  rating: number;
  totalEarnings: number;
  totalDeliveries: number;
  avgMilesPerMission: number;
  urgentAcceptanceRate: number;
  preferredShops: string[];
  joinedDate: string;
}

interface DriverApplication {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  licenseUploaded: boolean;
  insuranceUploaded: boolean;
  backgroundCheckUploaded: boolean;
  status: 'pending' | 'approved' | 'rejected';
  appliedDate: string;
}

export default function AdminDriversTable() {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [applications, setApplications] = useState<DriverApplication[]>([]);
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDrivers();
    loadApplications();
  }, []);

  const loadDrivers = async () => {
    try {
      const { data, error } = await supabase
        .from('driver_profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedDrivers: Driver[] = (data || []).map(driver => ({
        id: driver.id,
        name: driver.full_name || 'Unknown',
        email: driver.email || '',
        phone: driver.phone || '',
        city: driver.city || 'Unknown',
        status: driver.status || 'active',
        rating: driver.rating || 0,
        totalEarnings: driver.total_earnings || 0,
        totalDeliveries: driver.total_deliveries || 0,
        avgMilesPerMission: driver.avg_miles_per_mission || 0,
        urgentAcceptanceRate: driver.urgent_acceptance_rate || 0,
        preferredShops: driver.preferred_shops || [],
        joinedDate: driver.created_at
      }));

      setDrivers(formattedDrivers);
    } catch (error) {
      console.error('Error loading drivers:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadApplications = async () => {
    try {
      const { data, error } = await supabase
        .from('driver_applications')
        .select('*')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedApplications: DriverApplication[] = (data || []).map(app => ({
        id: app.id,
        name: app.full_name || 'Unknown',
        email: app.email || '',
        phone: app.phone || '',
        city: app.city || 'Unknown',
        licenseUploaded: !!app.license_url,
        insuranceUploaded: !!app.insurance_url,
        backgroundCheckUploaded: !!app.background_check_url,
        status: app.status || 'pending',
        appliedDate: app.created_at
      }));

      setApplications(formattedApplications);
    } catch (error) {
      console.error('Error loading applications:', error);
    }
  };

  const updateDriverStatus = async (driverId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('driver_profiles')
        .update({ status: newStatus })
        .eq('id', driverId);

      if (error) throw error;
      loadDrivers();
    } catch (error) {
      console.error('Error updating driver status:', error);
    }
  };

  const approveApplication = async (applicationId: string) => {
    try {
      const { error } = await supabase
        .from('driver_applications')
        .update({ status: 'approved' })
        .eq('id', applicationId);

      if (error) throw error;
      loadApplications();
    } catch (error) {
      console.error('Error approving application:', error);
    }
  };

  const cities = ['all', ...new Set(drivers.map(d => d.city))];
  const filteredDrivers = selectedCity === 'all' ? drivers : drivers.filter(d => d.city === selectedCity);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active': return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'inactive': return <Badge className="bg-gray-100 text-gray-800">Inactive</Badge>;
      case 'probationary': return <Badge className="bg-yellow-100 text-yellow-800">Probationary</Badge>;
      default: return <Badge>{status}</Badge>;
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading drivers...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">🚗 Driver Management</h2>
        <Select value={selectedCity} onValueChange={setSelectedCity}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter by city" />
          </SelectTrigger>
          <SelectContent>
            {cities.map(city => (
              <SelectItem key={city} value={city}>
                {city === 'all' ? 'All Cities' : city}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="active" className="space-y-4">
        <TabsList>
          <TabsTrigger value="active">Active Drivers ({filteredDrivers.length})</TabsTrigger>
          <TabsTrigger value="applications">Applications ({applications.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="active">
          <Card>
            <CardHeader>
              <CardTitle>Driver Overview by City</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Driver</TableHead>
                    <TableHead>City</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Rating</TableHead>
                    <TableHead>Earnings</TableHead>
                    <TableHead>Deliveries</TableHead>
                    <TableHead>Avg Miles</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDrivers.map(driver => (
                    <TableRow key={driver.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{driver.name}</div>
                          <div className="text-sm text-muted-foreground">{driver.email}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {driver.city}
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(driver.status)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          {driver.rating.toFixed(1)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4" />
                          ${driver.totalEarnings.toLocaleString()}
                        </div>
                      </TableCell>
                      <TableCell>{driver.totalDeliveries}</TableCell>
                      <TableCell>{driver.avgMilesPerMission.toFixed(1)} mi</TableCell>
                      <TableCell>
                        <Select onValueChange={(value) => updateDriverStatus(driver.id, value)}>
                          <SelectTrigger className="w-32">
                            <SelectValue placeholder="Actions" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="active">Mark Active</SelectItem>
                            <SelectItem value="probationary">Probationary</SelectItem>
                            <SelectItem value="inactive">Mark Inactive</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="applications">
          <Card>
            <CardHeader>
              <CardTitle>Pending Driver Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Applicant</TableHead>
                    <TableHead>City</TableHead>
                    <TableHead>Documents</TableHead>
                    <TableHead>Applied</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {applications.map(app => (
                    <TableRow key={app.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{app.name}</div>
                          <div className="text-sm text-muted-foreground">{app.email}</div>
                        </div>
                      </TableCell>
                      <TableCell>{app.city}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          {app.licenseUploaded ? 
                            <CheckCircle className="h-4 w-4 text-green-500" /> : 
                            <XCircle className="h-4 w-4 text-red-500" />
                          }
                          {app.insuranceUploaded ? 
                            <CheckCircle className="h-4 w-4 text-green-500" /> : 
                            <XCircle className="h-4 w-4 text-red-500" />
                          }
                          {app.backgroundCheckUploaded ? 
                            <CheckCircle className="h-4 w-4 text-green-500" /> : 
                            <XCircle className="h-4 w-4 text-red-500" />
                          }
                        </div>
                      </TableCell>
                      <TableCell>
                        {new Date(app.appliedDate).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            onClick={() => approveApplication(app.id)}
                            disabled={!app.licenseUploaded || !app.insuranceUploaded || !app.backgroundCheckUploaded}
                          >
                            Approve
                          </Button>
                          <Button size="sm" variant="outline">
                            Review
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}