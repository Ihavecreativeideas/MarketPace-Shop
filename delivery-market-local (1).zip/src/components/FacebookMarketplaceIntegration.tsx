import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Facebook, Truck, CheckCircle, ExternalLink, Zap } from 'lucide-react';

interface FacebookMarketplaceIntegrationProps {
  onClose?: () => void;
}

const FacebookMarketplaceIntegration: React.FC<FacebookMarketplaceIntegrationProps> = ({ onClose }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnectFacebook = async () => {
    setIsConnecting(true);
    
    // Simulate Facebook Business Portfolio connection
    setTimeout(() => {
      setIsConnecting(false);
      setIsConnected(true);
    }, 2000);
  };

  const handleMarketplaceSync = () => {
    // Navigate to Facebook Marketplace with delivery integration
    window.open('https://www.facebook.com/marketplace', '_blank');
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Facebook className="w-6 h-6 text-blue-600" />
          <span>Facebook Business Integration</span>
        </CardTitle>
        <Badge className="bg-blue-500 text-white w-fit">
          Trial Era - Enhanced Features
        </Badge>
      </CardHeader>
      <CardContent className="space-y-6">
        {!isConnected ? (
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold text-blue-900 mb-2">
                Connect Your Facebook Business Portfolio
              </h3>
              <p className="text-sm text-blue-800 mb-3">
                Link your Facebook Business account to enable direct marketplace integration 
                with "Deliver Now" options.
              </p>
              <ul className="text-xs text-blue-700 space-y-1">
                <li>• Sync products directly to Facebook Marketplace</li>
                <li>• Add "Deliver Now" buttons to all listings</li>
                <li>• Manage orders from both platforms</li>
                <li>• Real-time inventory sync</li>
              </ul>
            </div>
            
            <Button
              onClick={handleConnectFacebook}
              disabled={isConnecting}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isConnecting ? (
                <><Zap className="w-4 h-4 mr-2 animate-spin" /> Connecting...</>
              ) : (
                <><Facebook className="w-4 h-4 mr-2" /> Connect Facebook Business</>  
              )}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-green-600">
              <CheckCircle className="w-5 h-5" />
              <span className="font-semibold">Facebook Business Connected!</span>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-semibold text-green-900 mb-2">
                Marketplace Integration Active
              </h3>
              <p className="text-sm text-green-800 mb-3">
                Your products now include "Deliver Now" options on Facebook Marketplace.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={handleMarketplaceSync}
                variant="outline"
                className="border-blue-200 hover:bg-blue-50"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                View Marketplace
              </Button>
              
              <Button
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <Truck className="w-4 h-4 mr-2" />
                Manage Deliveries
              </Button>
            </div>
          </div>
        )}
        
        <div className="bg-yellow-50 p-4 rounded-lg">
          <p className="text-sm text-yellow-800">
            <strong>Trial Era Benefit:</strong> Facebook Marketplace integration with 
            delivery options is FREE during our trial period!
          </p>
        </div>
        
        {onClose && (
          <Button variant="ghost" onClick={onClose} className="w-full">
            Close
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default FacebookMarketplaceIntegration;