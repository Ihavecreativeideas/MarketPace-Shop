import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MapPin, Clock, Truck, Navigation, Search, TrendingUp, Route } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface DeliveryRoute {
  id: string;
  routeName: string;
  driverName: string;
  status: 'active' | 'completed' | 'pending';
  startLocation: string;
  endLocation: string;
  distance: number;
  estimatedTime: number;
  actualTime?: number;
  stops: number;
  priority: 'high' | 'medium' | 'low';
  createdAt: string;
  completedAt?: string;
}

export default function RoutesPanel() {
  const [routes, setRoutes] = useState<DeliveryRoute[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRoutes();
  }, []);

  const loadRoutes = async () => {
    try {
      const { data, error } = await supabase
        .from('delivery_routes')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Mock additional data for demo
      const mockRoutes: DeliveryRoute[] = [
        {
          id: '1',
          routeName: 'Downtown Express',
          driverName: 'John Smith',
          status: 'active',
          startLocation: 'Main Hub',
          endLocation: 'Downtown District',
          distance: 12.5,
          estimatedTime: 45,
          stops: 8,
          priority: 'high',
          createdAt: '2024-01-15T10:30:00Z'
        },
        {
          id: '2',
          routeName: 'Suburban Loop',
          driverName: 'Sarah Johnson',
          status: 'completed',
          startLocation: 'North Hub',
          endLocation: 'Suburban Area',
          distance: 18.2,
          estimatedTime: 60,
          actualTime: 55,
          stops: 12,
          priority: 'medium',
          createdAt: '2024-01-15T09:15:00Z',
          completedAt: '2024-01-15T10:10:00Z'
        },
        {
          id: '3',
          routeName: 'Business District',
          driverName: 'Mike Wilson',
          status: 'pending',
          startLocation: 'Central Hub',
          endLocation: 'Business District',
          distance: 8.7,
          estimatedTime: 30,
          stops: 5,
          priority: 'high',
          createdAt: '2024-01-15T11:00:00Z'
        },
        {
          id: '4',
          routeName: 'University Route',
          driverName: 'Emily Davis',
          status: 'active',
          startLocation: 'South Hub',
          endLocation: 'University Campus',
          distance: 15.3,
          estimatedTime: 50,
          stops: 10,
          priority: 'medium',
          createdAt: '2024-01-15T08:45:00Z'
        }
      ];

      setRoutes(mockRoutes);
    } catch (error) {
      console.error('Error loading routes:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: DeliveryRoute['status']) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: DeliveryRoute['priority']) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredRoutes = routes.filter(route =>
    route.routeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    route.driverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    route.startLocation.toLowerCase().includes(searchTerm.toLowerCase()) ||
    route.endLocation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const activeRoutes = routes.filter(r => r.status === 'active').length;
  const completedRoutes = routes.filter(r => r.status === 'completed').length;
  const totalDistance = routes.reduce((sum, r) => sum + r.distance, 0);
  const avgTime = routes.reduce((sum, r) => sum + r.estimatedTime, 0) / routes.length;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
        <div className="text-center">Loading routes...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Route Management</h1>
          <p className="text-gray-600">Monitor and optimize delivery routes</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-green-600">{activeRoutes}</div>
                  <div className="text-sm text-muted-foreground">Active Routes</div>
                </div>
                <Route className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-blue-600">{completedRoutes}</div>
                  <div className="text-sm text-muted-foreground">Completed Today</div>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-purple-600">{totalDistance.toFixed(1)} mi</div>
                  <div className="text-sm text-muted-foreground">Total Distance</div>
                </div>
                <Navigation className="h-8 w-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-orange-600">{avgTime.toFixed(0)} min</div>
                  <div className="text-sm text-muted-foreground">Avg Time</div>
                </div>
                <Clock className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search routes by name, driver, or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Routes List */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredRoutes.map((route) => (
            <Card key={route.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{route.routeName}</CardTitle>
                  <div className="flex gap-2">
                    <Badge className={getPriorityColor(route.priority)}>
                      {route.priority}
                    </Badge>
                    <Badge className={getStatusColor(route.status)}>
                      {route.status}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Truck className="h-4 w-4" />
                  Driver: {route.driverName}
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-muted-foreground">From</div>
                    <div className="text-sm font-medium">{route.startLocation}</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">To</div>
                    <div className="text-sm font-medium">{route.endLocation}</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4 pt-2">
                  <div className="text-center">
                    <div className="text-lg font-bold text-blue-600">{route.distance} mi</div>
                    <div className="text-xs text-muted-foreground">Distance</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-green-600">{route.stops}</div>
                    <div className="text-xs text-muted-foreground">Stops</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-purple-600">
                      {route.actualTime || route.estimatedTime} min
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {route.actualTime ? 'Actual' : 'Estimated'}
                    </div>
                  </div>
                </div>
                
                <div className="text-xs text-muted-foreground">
                  Created: {new Date(route.createdAt).toLocaleString()}
                  {route.completedAt && (
                    <div>Completed: {new Date(route.completedAt).toLocaleString()}</div>
                  )}
                </div>
                
                <div className="flex gap-2 pt-2">
                  <Button size="sm" variant="outline" className="flex-1">
                    <MapPin className="h-3 w-3 mr-1" />
                    View Map
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1">
                    <Navigation className="h-3 w-3 mr-1" />
                    Optimize
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredRoutes.length === 0 && (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No routes found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
}