import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/context/AuthContext";

interface ProfileQuestionnaireProps {
  onComplete: () => void;
}

export function ProfileQuestionnaire({ onComplete }: ProfileQuestionnaireProps) {
  const { user } = useAuth();
  const [profileType, setProfileType] = useState("personal");
  const [businessCategory, setBusinessCategory] = useState("");
  const [shopLinks, setShopLinks] = useState({
    etsy: "",
    website: "",
    facebook: "",
    instagram: "",
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const profileData = {
        user_id: user.id,
        profile_type: profileType,
        business_category: businessCategory,
        shop_links: shopLinks,
        profile_complete: true,
        created_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('user_profiles_questionnaire')
        .upsert(profileData);

      if (error) throw error;
      
      onComplete();
    } catch (error) {
      console.error('Error saving profile:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Profile Setup</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="profile-type">Choose Profile Type:</Label>
          <Select value={profileType} onValueChange={setProfileType}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="personal">Personal</SelectItem>
              <SelectItem value="dual">Business + Personal (Dual)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {profileType === "dual" && (
          <>
            <div>
              <Label htmlFor="business-category">Business Category:</Label>
              <Select value={businessCategory} onValueChange={setBusinessCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="shop">Shop</SelectItem>
                  <SelectItem value="service">Service</SelectItem>
                  <SelectItem value="entertainment">Entertainment Industry</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Link Your Existing Platforms:</Label>
              <Input
                placeholder="Etsy Store URL"
                value={shopLinks.etsy}
                onChange={(e) => setShopLinks({ ...shopLinks, etsy: e.target.value })}
              />
              <Input
                placeholder="Website URL"
                value={shopLinks.website}
                onChange={(e) => setShopLinks({ ...shopLinks, website: e.target.value })}
              />
              <Input
                placeholder="Facebook Page"
                value={shopLinks.facebook}
                onChange={(e) => setShopLinks({ ...shopLinks, facebook: e.target.value })}
              />
              <Input
                placeholder="Instagram Handle"
                value={shopLinks.instagram}
                onChange={(e) => setShopLinks({ ...shopLinks, instagram: e.target.value })}
              />
            </div>
          </>
        )}

        <Button 
          onClick={handleSubmit} 
          disabled={loading}
          className="w-full"
        >
          {loading ? "Saving..." : "Complete Setup"}
        </Button>
      </CardContent>
    </Card>
  );
}