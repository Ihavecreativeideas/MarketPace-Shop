import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Upload, X, DollarSign } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface EnhancedAddItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onItemAdded?: () => void;
  itemType: 'marketplace' | 'rental' | 'shop';
}

const EnhancedAddItemModal: React.FC<EnhancedAddItemModalProps> = ({
  isOpen,
  onClose,
  onItemAdded,
  itemType
}) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    category: '',
    condition: 'new',
    location: '',
    images: [] as string[],
    self_pickup_available: false,
    marketplace_delivery_available: true,
    shop_delivery_available: false,
    shop_delivery_fee: ''
  });
  const [loading, setLoading] = useState(false);

  const categories = [
    'electronics', 'clothing', 'home-garden', 'sports', 'books',
    'toys-games', 'automotive', 'health-beauty', 'jewelry', 'other'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const itemData = {
        title: formData.title,
        description: formData.description,
        price: parseFloat(formData.price),
        category: formData.category,
        condition: formData.condition,
        location: formData.location,
        images: formData.images,
        seller_id: user.id,
        self_pickup_available: formData.self_pickup_available,
        marketplace_delivery_available: formData.marketplace_delivery_available,
        shop_delivery_available: formData.shop_delivery_available
      };

      const tableName = itemType === 'rental' ? 'rental_items' : 
                       itemType === 'shop' ? 'shop_inventory' : 'marketplace_items';

      const { error } = await supabase
        .from(tableName)
        .insert([itemData]);

      if (error) throw error;

      // Reset form
      setFormData({
        title: '',
        description: '',
        price: '',
        category: '',
        condition: 'new',
        location: '',
        images: [],
        self_pickup_available: false,
        marketplace_delivery_available: true,
        shop_delivery_available: false,
        shop_delivery_fee: ''
      });

      onItemAdded?.();
      onClose();
    } catch (error) {
      console.error('Error adding item:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      // In a real app, you'd upload to storage and get URLs
      const newImages = Array.from(files).map(file => URL.createObjectURL(file));
      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...newImages].slice(0, 5)
      }));
    }
  };

  const removeImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-800 border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-white">
            Add New {itemType === 'rental' ? 'Rental' : itemType === 'shop' ? 'Shop' : 'Marketplace'} Item
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Info */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="title" className="text-white">Title</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-white"
                required
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-white">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-white"
                rows={3}
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="price" className="text-white">Price</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                    className="pl-10 bg-slate-700 border-slate-600 text-white"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="category" className="text-white">Category</Label>
                <Select value={formData.category} onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat} value={cat}>
                        {cat.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="condition" className="text-white">Condition</Label>
                <Select value={formData.condition} onValueChange={(value) => setFormData(prev => ({ ...prev, condition: value }))}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="like-new">Like New</SelectItem>
                    <SelectItem value="good">Good</SelectItem>
                    <SelectItem value="fair">Fair</SelectItem>
                    <SelectItem value="poor">Poor</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="location" className="text-white">Location</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                  className="bg-slate-700 border-slate-600 text-white"
                  placeholder="City, State"
                  required
                />
              </div>
            </div>
          </div>

          {/* Delivery Options */}
          <Card className="bg-slate-700 border-slate-600">
            <CardContent className="p-4">
              <h3 className="text-white font-semibold mb-4">Delivery Options</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="self_pickup"
                    checked={formData.self_pickup_available}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, self_pickup_available: !!checked }))}
                  />
                  <Label htmlFor="self_pickup" className="text-white">Allow Self Pickup</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="marketplace_delivery"
                    checked={formData.marketplace_delivery_available}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, marketplace_delivery_available: !!checked }))}
                  />
                  <Label htmlFor="marketplace_delivery" className="text-white">MarketPace Delivery</Label>
                </div>

                {itemType === 'shop' && (
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="shop_delivery"
                        checked={formData.shop_delivery_available}
                        onCheckedChange={(checked) => setFormData(prev => ({ ...prev, shop_delivery_available: !!checked }))}
                      />
                      <Label htmlFor="shop_delivery" className="text-white">Shop Delivery</Label>
                    </div>
                    {formData.shop_delivery_available && (
                      <div className="ml-6">
                        <Label htmlFor="shop_delivery_fee" className="text-white text-sm">Delivery Fee</Label>
                        <div className="relative">
                          <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <Input
                            id="shop_delivery_fee"
                            type="number"
                            step="0.01"
                            value={formData.shop_delivery_fee}
                            onChange={(e) => setFormData(prev => ({ ...prev, shop_delivery_fee: e.target.value }))}
                            className="pl-10 bg-slate-600 border-slate-500 text-white"
                            placeholder="0.00"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Image Upload */}
          <div>
            <Label className="text-white">Images (up to 5)</Label>
            <div className="mt-2">
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className="flex items-center justify-center w-full h-32 border-2 border-dashed border-slate-600 rounded-lg cursor-pointer hover:border-slate-500 transition-colors"
              >
                <div className="text-center">
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-400">Click to upload images</p>
                </div>
              </label>
            </div>

            {formData.images.length > 0 && (
              <div className="grid grid-cols-5 gap-2 mt-4">
                {formData.images.map((image, index) => (
                  <div key={index} className="relative">
                    <img
                      src={image}
                      alt={`Upload ${index + 1}`}
                      className="w-full h-20 object-cover rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs hover:bg-red-600"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Submit Buttons */}
          <div className="flex gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1 border-slate-600 text-white hover:bg-slate-700"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              {loading ? 'Adding...' : 'Add Item'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EnhancedAddItemModal;
export { EnhancedAddItemModal };