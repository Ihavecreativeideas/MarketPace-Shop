import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, ExternalLink, Building, FileText, CreditCard, Globe } from 'lucide-react';

interface SetupItem {
  id: string;
  title: string;
  description: string;
  url: string;
  category: 'legal' | 'financial' | 'business' | 'platform';
  priority: 'high' | 'medium' | 'low';
  requirements: string[];
}

export const BusinessSetupList: React.FC = () => {
  const [completedItems, setCompletedItems] = useState<string[]>([]);

  const setupItems: SetupItem[] = [
    {
      id: 'ein',
      title: 'IRS EIN Registration',
      description: 'Get your Employer Identification Number from the IRS',
      url: 'https://www.irs.gov/businesses/small-businesses-self-employed/apply-for-an-employer-identification-number-ein-online',
      category: 'legal',
      priority: 'high',
      requirements: ['Business name', 'Business address', 'Responsible party SSN']
    },
    {
      id: 'llc',
      title: 'State LLC Registration',
      description: 'Register your LLC with your state government',
      url: 'https://www.sba.gov/business-guide/launch-your-business/register-your-business',
      category: 'legal',
      priority: 'high',
      requirements: ['Articles of Organization', 'Registered agent', 'Filing fee']
    },
    {
      id: 'bank',
      title: 'Business Bank Account',
      description: 'Open dedicated business banking account',
      url: 'https://www.chase.com/business/banking/business-checking',
      category: 'financial',
      priority: 'high',
      requirements: ['EIN', 'Articles of Organization', 'Initial deposit']
    },
    {
      id: 'stripe',
      title: 'Stripe Business Account',
      description: 'Payment processing for MarketPace',
      url: 'https://dashboard.stripe.com/register',
      category: 'financial',
      priority: 'high',
      requirements: ['EIN', 'Business bank account', 'Business verification']
    },
    {
      id: 'paypal',
      title: 'PayPal Business Account',
      description: 'Additional payment processing option',
      url: 'https://www.paypal.com/us/webapps/mpp/account-selection',
      category: 'financial',
      priority: 'medium',
      requirements: ['EIN', 'Business bank account']
    },
    {
      id: 'square',
      title: 'Square Business Account',
      description: 'POS and payment processing',
      url: 'https://squareup.com/signup',
      category: 'financial',
      priority: 'medium',
      requirements: ['EIN', 'Business details', 'Bank account']
    },
    {
      id: 'google',
      title: 'Google My Business',
      description: 'Local business visibility',
      url: 'https://www.google.com/business/',
      category: 'business',
      priority: 'high',
      requirements: ['Business name', 'Address', 'Phone', 'Category']
    },
    {
      id: 'facebook',
      title: 'Facebook Business Manager',
      description: 'Social commerce integration',
      url: 'https://business.facebook.com/overview',
      category: 'platform',
      priority: 'medium',
      requirements: ['Facebook account', 'Business info', 'EIN']
    },
    {
      id: 'apple',
      title: 'Apple Developer Program',
      description: 'iOS app distribution',
      url: 'https://developer.apple.com/programs/enroll/',
      category: 'platform',
      priority: 'low',
      requirements: ['Apple ID', 'EIN', 'D-U-N-S Number', '$99 fee']
    },
    {
      id: 'whatnot',
      title: 'WhatNot Seller Account',
      description: 'Live auction platform integration',
      url: 'https://www.whatnot.com/sell',
      category: 'platform',
      priority: 'medium',
      requirements: ['Valid ID', 'Tax information', 'Bank account']
    },
    {
      id: 'craigslist',
      title: 'Craigslist Business Posting',
      description: 'Local classified advertising',
      url: 'https://www.craigslist.org/about/help/posting_fees',
      category: 'platform',
      priority: 'low',
      requirements: ['Phone verification', 'Payment method for fees']
    },
    {
      id: 'insurance',
      title: 'Business Insurance',
      description: 'General liability coverage',
      url: 'https://www.next-insurance.com/',
      category: 'business',
      priority: 'high',
      requirements: ['Business details', 'EIN', 'Industry info']
    }
  ];

  const toggleComplete = (id: string) => {
    setCompletedItems(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id)
        : [...prev, id]
    );
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'legal': return <FileText className="w-4 h-4" />;
      case 'financial': return <CreditCard className="w-4 h-4" />;
      case 'business': return <Building className="w-4 h-4" />;
      case 'platform': return <Globe className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const completionRate = Math.round((completedItems.length / setupItems.length) * 100);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Business Setup Checklist</CardTitle>
          <CardDescription>
            Complete these steps to integrate your business with MarketPace and payment platforms
          </CardDescription>
          <div className="flex items-center gap-3">
            <div className="flex-1 bg-gray-200 rounded-full h-3">
              <div 
                className="bg-blue-500 h-3 rounded-full transition-all duration-500" 
                style={{ width: `${completionRate}%` }}
              />
            </div>
            <span className="text-sm font-semibold">{completionRate}% Complete</span>
          </div>
        </CardHeader>
      </Card>

      <div className="space-y-4">
        {setupItems.map((item) => {
          const isCompleted = completedItems.includes(item.id);
          return (
            <Card key={item.id} className={`transition-all ${isCompleted ? 'bg-green-50 border-green-200' : ''}`}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      {getCategoryIcon(item.category)}
                      <h3 className="font-semibold">{item.title}</h3>
                      {isCompleted && <CheckCircle className="w-5 h-5 text-green-500" />}
                      <Badge className={getPriorityColor(item.priority)}>
                        {item.priority.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{item.description}</p>
                    <div className="flex flex-wrap gap-1">
                      {item.requirements.map((req, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {req}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 ml-4">
                    <Button
                      size="sm"
                      onClick={() => window.open(item.url, '_blank')}
                      className="whitespace-nowrap"
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Open Link
                    </Button>
                    <Button
                      size="sm"
                      variant={isCompleted ? "default" : "outline"}
                      onClick={() => toggleComplete(item.id)}
                    >
                      {isCompleted ? 'Completed' : 'Mark Done'}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};