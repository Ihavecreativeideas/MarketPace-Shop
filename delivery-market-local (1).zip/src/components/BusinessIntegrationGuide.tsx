import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ExternalLink, CheckCircle, FileText, Building } from 'lucide-react';

interface IntegrationStep {
  title: string;
  description: string;
  url: string;
  required: string[];
  completed: boolean;
}

const BusinessIntegrationGuide: React.FC = () => {
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);

  const integrationSteps: IntegrationStep[] = [
    {
      title: 'IRS EIN Registration',
      description: 'Apply for your Employer Identification Number (EIN) with the IRS',
      url: 'https://www.irs.gov/businesses/small-businesses-self-employed/apply-for-an-employer-identification-number-ein-online',
      required: ['Business name', 'Business address', 'Responsible party info'],
      completed: completedSteps.includes('ein')
    },
    {
      title: 'State Business Registration',
      description: 'Register your LLC with your state government',
      url: 'https://www.sba.gov/business-guide/launch-your-business/register-your-business',
      required: ['Articles of Organization', 'Registered agent', 'Filing fee'],
      completed: completedSteps.includes('state')
    },
    {
      title: 'Business Bank Account',
      description: 'Open a dedicated business banking account',
      url: 'https://www.chase.com/business/banking/business-checking',
      required: ['EIN', 'Articles of Organization', 'Operating Agreement'],
      completed: completedSteps.includes('banking')
    },
    {
      title: 'Stripe Business Account',
      description: 'Set up payment processing for your MarketPace integration',
      url: 'https://dashboard.stripe.com/register',
      required: ['EIN', 'Business bank account', 'Business address'],
      completed: completedSteps.includes('stripe')
    }
  ];

  const toggleStep = (stepKey: string) => {
    setCompletedSteps(prev => 
      prev.includes(stepKey) 
        ? prev.filter(s => s !== stepKey)
        : [...prev, stepKey]
    );
  };

  const completionPercentage = Math.round((completedSteps.length / integrationSteps.length) * 100);

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building className="w-6 h-6" />
          Business Integration Setup Guide
        </CardTitle>
        <CardDescription>
          Complete these steps to properly integrate your business with MarketPace
        </CardDescription>
        <div className="flex items-center gap-2">
          <div className="flex-1 bg-gray-200 rounded-full h-2">
            <div 
              className="bg-green-500 h-2 rounded-full transition-all duration-300" 
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
          <span className="text-sm font-medium">{completionPercentage}% Complete</span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {integrationSteps.map((step, index) => {
            const stepKey = step.title.toLowerCase().split(' ')[0];
            return (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold">{step.title}</h3>
                      {step.completed && (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{step.description}</p>
                    <div className="flex flex-wrap gap-1 mb-3">
                      {step.required.map((req, reqIndex) => (
                        <Badge key={reqIndex} variant="outline" className="text-xs">
                          {req}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 ml-4">
                    <Button
                      size="sm"
                      onClick={() => window.open(step.url, '_blank')}
                      className="whitespace-nowrap"
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Start Setup
                    </Button>
                    <Button
                      size="sm"
                      variant={step.completed ? "default" : "outline"}
                      onClick={() => toggleStep(stepKey)}
                    >
                      {step.completed ? 'Completed' : 'Mark Complete'}
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default BusinessIntegrationGuide;