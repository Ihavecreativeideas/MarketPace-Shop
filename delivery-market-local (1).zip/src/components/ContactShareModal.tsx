import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Share2, Users, Mail, Phone } from 'lucide-react';
import { toast } from 'sonner';

interface Contact {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  selected: boolean;
}

interface ContactShareModalProps {
  children: React.ReactNode;
}

export const ContactShareModal: React.FC<ContactShareModalProps> = ({ children }) => {
  const [contacts, setContacts] = useState<Contact[]>([
    { id: '1', name: 'John Doe', email: 'john@email.com', phone: '555-0123', selected: false },
    { id: '2', name: 'Jane Smith', email: 'jane@email.com', phone: '555-0456', selected: false },
    { id: '3', name: 'Mike Johnson', email: 'mike@email.com', selected: false },
  ]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const filteredContacts = contacts.filter(contact =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const toggleContact = (id: string) => {
    setContacts(prev => prev.map(contact =>
      contact.id === id ? { ...contact, selected: !contact.selected } : contact
    ));
  };

  const selectAll = () => {
    const allSelected = filteredContacts.every(contact => contact.selected);
    setContacts(prev => prev.map(contact => ({
      ...contact,
      selected: filteredContacts.some(fc => fc.id === contact.id) ? !allSelected : contact.selected
    })));
  };

  const shareWithSelected = () => {
    const selectedContacts = contacts.filter(contact => contact.selected);
    if (selectedContacts.length === 0) {
      toast.error('Please select at least one contact');
      return;
    }

    // Simulate sharing MarketPace with selected contacts
    toast.success(`MarketPace invitation sent to ${selectedContacts.length} contacts!`);
    setIsOpen(false);
    
    // Reset selections
    setContacts(prev => prev.map(contact => ({ ...contact, selected: false })));
  };

  const selectedCount = contacts.filter(contact => contact.selected).length;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            Share MarketPace
          </DialogTitle>
          <DialogDescription>
            Invite your contacts to join MarketPace and discover local opportunities
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="search">Search Contacts</Label>
            <Input
              id="search"
              placeholder="Search by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              size="sm"
              onClick={selectAll}
              className="text-xs"
            >
              {filteredContacts.every(contact => contact.selected) ? 'Deselect All' : 'Select All'}
            </Button>
            {selectedCount > 0 && (
              <span className="text-sm text-gray-600">
                {selectedCount} selected
              </span>
            )}
          </div>

          <div className="max-h-60 overflow-y-auto space-y-2">
            {filteredContacts.map((contact) => (
              <div
                key={contact.id}
                className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                onClick={() => toggleContact(contact.id)}
              >
                <Checkbox
                  checked={contact.selected}
                  onChange={() => toggleContact(contact.id)}
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-gray-400" />
                    <span className="font-medium">{contact.name}</span>
                  </div>
                  <div className="text-sm text-gray-500 space-y-1">
                    {contact.email && (
                      <div className="flex items-center gap-1">
                        <Mail className="w-3 h-3" />
                        <span>{contact.email}</span>
                      </div>
                    )}
                    {contact.phone && (
                      <div className="flex items-center gap-1">
                        <Phone className="w-3 h-3" />
                        <span>{contact.phone}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => setIsOpen(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={shareWithSelected}
              disabled={selectedCount === 0}
              className="flex-1"
            >
              Send Invites ({selectedCount})
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};