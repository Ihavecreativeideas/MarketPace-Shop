import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, MapPin, Share2 } from 'lucide-react';

interface CraigslistItem {
  id: string;
  title: string;
  price: number;
  location: string;
  category: string;
  description: string;
}

export const CraigslistIntegration: React.FC = () => {
  const [connected, setConnected] = useState(false);
  const [items, setItems] = useState<CraigslistItem[]>([]);
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState('');

  const connectToCraigslist = async () => {
    setConnected(true);
    // Mock data for demonstration
    setItems([
      {
        id: '1',
        title: 'Professional DJ Equipment Set',
        price: 800,
        location: 'Downtown',
        category: 'Electronics',
        description: 'Complete DJ setup with turntables and mixer'
      },
      {
        id: '2',
        title: 'Vintage Furniture Collection',
        price: 450,
        location: 'Suburbs',
        category: 'Furniture',
        description: 'Mid-century modern pieces in excellent condition'
      }
    ]);
  };

  const shareToMarketPace = (item: CraigslistItem) => {
    console.log('Sharing Craigslist item to MarketPace:', item);
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <span className="text-blue-600">Craigslist</span>
          <Badge variant="secondary">Integration</Badge>
        </CardTitle>
        <CardDescription>
          Import and cross-post your Craigslist listings to MarketPace
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!connected ? (
          <div className="text-center py-8">
            <div className="space-y-4">
              <Input
                placeholder="Enter your city/location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="electronics">Electronics</SelectItem>
                  <SelectItem value="furniture">Furniture</SelectItem>
                  <SelectItem value="vehicles">Vehicles</SelectItem>
                  <SelectItem value="services">Services</SelectItem>
                  <SelectItem value="jobs">Jobs</SelectItem>
                </SelectContent>
              </Select>
              <Button 
                onClick={connectToCraigslist} 
                className="bg-blue-600 hover:bg-blue-700"
                disabled={!location}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Connect to Craigslist
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <MapPin className="w-4 h-4" />
              <span>Connected to {location} Craigslist</span>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              {items.map((item) => (
                <div key={item.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="font-semibold">{item.title}</h3>
                      <p className="text-green-600 font-bold">${item.price}</p>
                      <p className="text-sm text-gray-500 flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {item.location}
                      </p>
                      <p className="text-sm mt-2">{item.description}</p>
                      <Badge variant="outline" className="mt-2">
                        {item.category}
                      </Badge>
                    </div>
                    <Button
                      onClick={() => shareToMarketPace(item)}
                      size="sm"
                      className="ml-4"
                    >
                      <Share2 className="w-4 h-4 mr-2" />
                      Import to MarketPace
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};