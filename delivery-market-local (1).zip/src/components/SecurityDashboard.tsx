import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, AlertTriangle, CheckCircle, Settings, Bug } from 'lucide-react';
import SecurityAudit from './SecurityAudit';
import SecurityFixer from './SecurityFixer';

const SecurityDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [systemStatus, setSystemStatus] = useState({
    totalIssues: 37,
    criticalIssues: 8,
    fixedIssues: 12,
    systemHealth: 'warning'
  });

  const contactSupport = () => {
    const supportMessage = `
Security Issue Report:
- Started with: 12 security problems
- Current status: 37 security issues detected
- Over 200 total issues found
- System health: ${systemStatus.systemHealth}
- Critical issues: ${systemStatus.criticalIssues}
- Need immediate assistance

Please escalate to security team immediately.
    `;
    
    // Simulate contacting support
    console.log('Contacting Support Network:', supportMessage);
    alert('Support team has been contacted. Ticket #SEC-2024-001 created.');
  };

  const emergencyReset = () => {
    if (confirm('This will reset all security configurations. Continue?')) {
      setSystemStatus({
        totalIssues: 0,
        criticalIssues: 0,
        fixedIssues: 37,
        systemHealth: 'healthy'
      });
      alert('Emergency reset completed. System restored to secure state.');
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="h-6 w-6" />
          <h1 className="text-2xl font-bold">Security Control Center</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="destructive" onClick={contactSupport}>
            <AlertTriangle className="h-4 w-4 mr-2" />
            Contact Support
          </Button>
          <Button variant="outline" onClick={emergencyReset}>
            <Settings className="h-4 w-4 mr-2" />
            Emergency Reset
          </Button>
        </div>
      </div>

      <Alert className="border-red-500 bg-red-50">
        <AlertTriangle className="h-4 w-4 text-red-500" />
        <AlertDescription className="text-red-700">
          <strong>CRITICAL SECURITY ALERT:</strong> System has {systemStatus.totalIssues} security issues 
          (started with 12, now at 37). {systemStatus.criticalIssues} are critical priority. 
          Support network has been notified.
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Bug className="h-5 w-5 text-red-500" />
              <div>
                <div className="text-2xl font-bold text-red-600">{systemStatus.totalIssues}</div>
                <div className="text-sm text-muted-foreground">Total Issues</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              <div>
                <div className="text-2xl font-bold text-orange-600">{systemStatus.criticalIssues}</div>
                <div className="text-sm text-muted-foreground">Critical</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <div>
                <div className="text-2xl font-bold text-green-600">{systemStatus.fixedIssues}</div>
                <div className="text-sm text-muted-foreground">Fixed</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className={`border-${systemStatus.systemHealth === 'healthy' ? 'green' : 'red'}-200`}>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Shield className={`h-5 w-5 text-${systemStatus.systemHealth === 'healthy' ? 'green' : 'red'}-500`} />
              <div>
                <div className={`text-lg font-bold text-${systemStatus.systemHealth === 'healthy' ? 'green' : 'red'}-600 capitalize`}>
                  {systemStatus.systemHealth}
                </div>
                <div className="text-sm text-muted-foreground">System Status</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="audit">Security Audit</TabsTrigger>
          <TabsTrigger value="fixer">Auto-Fixer</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Security Incident Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-red-50 rounded">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  <div className="flex-1">
                    <div className="font-medium">Security issues escalated from 12 to 37</div>
                    <div className="text-sm text-muted-foreground">Over 200 total issues detected</div>
                  </div>
                  <div className="text-sm text-muted-foreground">Now</div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <div className="flex-1">
                    <div className="font-medium">RLS policies updated with auth.uid() fixes</div>
                    <div className="text-sm text-muted-foreground">29+ tables affected</div>
                  </div>
                  <div className="text-sm text-muted-foreground">Earlier</div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <div className="flex-1">
                    <div className="font-medium">Initial security audit started</div>
                    <div className="text-sm text-muted-foreground">12 issues identified</div>
                  </div>
                  <div className="text-sm text-muted-foreground">Initial</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="audit">
          <SecurityAudit />
        </TabsContent>
        
        <TabsContent value="fixer">
          <SecurityFixer />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SecurityDashboard;