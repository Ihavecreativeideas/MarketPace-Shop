import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { ShoppingCart, Lock, Gift } from 'lucide-react';
import { useLaunch } from '@/contexts/LaunchContext';
import { CheckoutWithFees } from './CheckoutWithFees';

interface PreLaunchCartProps {
  itemCount: number;
  onViewCart: () => void;
}

const PreLaunchCart: React.FC<PreLaunchCartProps> = ({ itemCount, onViewCart }) => {
  const { isLaunched } = useLaunch();

  if (isLaunched) {
    return (
      <Button onClick={onViewCart} className="bg-green-600 hover:bg-green-700">
        <ShoppingCart className="w-4 h-4 mr-2" />
        Cart ({itemCount})
      </Button>
    );
  }

  return (
    <div className="relative">
      <Button 
        onClick={onViewCart} 
        variant="outline" 
        className="border-orange-300 text-orange-600 hover:bg-orange-50"
      >
        <ShoppingCart className="w-4 h-4 mr-2" />
        Cart ({itemCount})
      </Button>
      {itemCount > 0 && (
        <Card className="absolute top-12 right-0 w-80 z-50 border-orange-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center space-x-2">
              <Lock className="w-4 h-4 text-orange-500" />
              <span>Pre-Launch Mode</span>
              <Gift className="w-4 h-4 text-green-500" />
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-3">
            <div className="bg-green-50 p-2 rounded border border-green-200">
              <p className="text-xs text-green-700 font-medium">
                🎉 Pre-Launch Benefit: 3 months FREE sustainability fee ($4/month saved!)
              </p>
            </div>
            <p className="text-xs text-gray-600">
              You can add items to cart, but checkout is disabled until launch!
            </p>
            <Button 
              onClick={onViewCart}
              size="sm" 
              variant="outline" 
              className="w-full"
            >
              View Cart
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PreLaunchCart;