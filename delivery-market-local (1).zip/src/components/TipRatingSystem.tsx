import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Star, DollarSign, User, Truck } from 'lucide-react';

interface TipRatingSystemProps {
  isOpen: boolean;
  onClose: () => void;
  driverName: string;
  deliveryId: string;
  userType: 'buyer' | 'seller';
  onSubmit: (rating: number, tip: number, comment: string) => void;
}

const TipRatingSystem = ({
  isOpen,
  onClose,
  driverName,
  deliveryId,
  userType,
  onSubmit
}: TipRatingSystemProps) => {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [tipAmount, setTipAmount] = useState('');
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const quickTipAmounts = [2, 5, 10, 15, 20];

  const handleSubmit = async () => {
    if (rating === 0) {
      alert('Please provide a rating');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit(rating, parseFloat(tipAmount) || 0, comment);
      onClose();
    } catch (error) {
      console.error('Failed to submit rating:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getRatingText = (stars: number) => {
    switch (stars) {
      case 1: return 'Poor';
      case 2: return 'Fair';
      case 3: return 'Good';
      case 4: return 'Very Good';
      case 5: return 'Excellent';
      default: return 'Rate your experience';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Truck className="h-5 w-5" />
            Rate & Tip Driver
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Driver Info */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <User className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium">{driverName}</p>
                  <p className="text-sm text-gray-600">Delivery ID: {deliveryId}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Rating Section */}
          <div className="space-y-3">
            <h3 className="font-medium">How was your delivery experience?</h3>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="p-1 transition-colors"
                >
                  <Star
                    className={`h-8 w-8 ${
                      star <= (hoveredRating || rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>
            <p className="text-sm text-gray-600">
              {getRatingText(hoveredRating || rating)}
            </p>
          </div>

          {/* Tip Section */}
          <div className="space-y-3">
            <h3 className="font-medium flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Add a tip (optional)
            </h3>
            
            {/* Quick Tip Buttons */}
            <div className="flex gap-2 flex-wrap">
              {quickTipAmounts.map((amount) => (
                <Button
                  key={amount}
                  variant={tipAmount === amount.toString() ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setTipAmount(amount.toString())}
                >
                  ${amount}
                </Button>
              ))}
            </div>
            
            {/* Custom Tip Input */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">$</span>
              <Input
                type="number"
                placeholder="Custom amount"
                value={tipAmount}
                onChange={(e) => setTipAmount(e.target.value)}
                min="0"
                step="0.01"
                className="flex-1"
              />
            </div>
          </div>

          {/* Comment Section */}
          <div className="space-y-2">
            <h3 className="font-medium">Leave a comment (optional)</h3>
            <Textarea
              placeholder="Share your feedback about the delivery..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={isSubmitting}
            >
              Skip
            </Button>
            <Button
              onClick={handleSubmit}
              className="flex-1"
              disabled={isSubmitting || rating === 0}
            >
              {isSubmitting ? 'Submitting...' : 'Submit'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TipRatingSystem;