import React from 'react';
import { Button } from './ui/button';
import { Users, Rocket } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface JoinLaunchButtonProps {
  className?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
}

const JoinLaunchButton: React.FC<JoinLaunchButtonProps> = ({
  className = '',
  variant = 'default',
  size = 'md'
}) => {
  const navigate = useNavigate();

  const handleJoinLaunch = () => {
    // Navigate to auth page for signup or driver application
    navigate('/auth');
  };

  return (
    <Button
      onClick={handleJoinLaunch}
      className={`bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white font-semibold ${className}`}
      variant={variant}
      size={size}
    >
      <Rocket className="w-4 h-4 mr-2" />
      Join Launch Campaign
    </Button>
  );
};

export default JoinLaunchButton;