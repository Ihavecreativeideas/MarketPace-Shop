import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calculator, Truck, Store, CreditCard, Crown, Gift, Heart } from 'lucide-react';

const DeliveryPricing: React.FC = () => {
  const calculateDeliveryPrice = (miles: number, pickups: number = 1, dropoffs: number = 1, isLarge: boolean = false, isUrgent: boolean = false) => {
    let driverPay = 0;
    
    if (isLarge) {
      // Large items requiring heavy pickup, truck, or trailer
      driverPay = 40 + (miles * 0.50);
    } else {
      // Standard items
      driverPay = (pickups * 4) + (dropoffs * 2) + (miles * 0.50);
    }
    
    // Urgent delivery bonus
    if (isUrgent) {
      driverPay = driverPay * 1.35; // 35% bonus
    }
    
    const processingFee = 1.50; // Fixed processing fee
    const buyerShare = processingFee / 2; // $0.75
    const sellerShare = processingFee / 2; // $0.75
    
    return {
      driverPay,
      processingFee,
      buyerShare,
      sellerShare,
      total: driverPay + processingFee,
      isLarge,
      isUrgent
    };
  };

  const examples = [
    { 
      description: "Standard delivery",
      miles: 5, 
      pickups: 1,
      dropoffs: 1,
      pricing: calculateDeliveryPrice(5, 1, 1, false, false)
    },
    { 
      description: "Large item (truck required)",
      miles: 8, 
      pickups: 1,
      dropoffs: 1,
      pricing: calculateDeliveryPrice(8, 1, 1, true, false)
    },
    { 
      description: "Urgent large item",
      miles: 8, 
      pickups: 1,
      dropoffs: 1,
      pricing: calculateDeliveryPrice(8, 1, 1, true, true)
    }
  ];

  return (
    <div className="space-y-6">
      {/* Tips Highlight */}
      <Card className="border-2 border-green-300 bg-green-50">
        <CardContent className="pt-6">
          <div className="flex items-center justify-center gap-2 text-green-800">
            <Heart className="w-6 h-6" />
            <h3 className="text-xl font-bold">Drivers Keep 100% of All Tips!</h3>
          </div>
          <p className="text-center text-green-700 mt-2">No platform fees or deductions on customer tips</p>
        </CardContent>
      </Card>

      <Card className="border-2 border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-800">
            <Calculator className="w-5 h-5" />
            Driver Pay Structure
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-white p-4 rounded-lg border border-blue-200 mb-4">
            <h3 className="font-bold text-lg mb-3 text-blue-800">Fair & Transparent Pricing</h3>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="text-center p-3 bg-green-50 rounded-lg">
                <div className="text-xl font-bold text-green-600">$4</div>
                <div className="text-sm text-gray-600">Per Pickup</div>
              </div>
              <div className="text-center p-3 bg-blue-50 rounded-lg">
                <div className="text-xl font-bold text-blue-600">$2</div>
                <div className="text-sm text-gray-600">Per Drop-off</div>
              </div>
              <div className="text-center p-3 bg-purple-50 rounded-lg">
                <div className="text-xl font-bold text-purple-600">$0.50</div>
                <div className="text-sm text-gray-600">Per Mile</div>
              </div>
              <div className="text-center p-3 bg-orange-50 rounded-lg">
                <div className="text-xl font-bold text-orange-600">$40+</div>
                <div className="text-sm text-gray-600">Large Items</div>
              </div>
            </div>
          </div>
          
          <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
            <h4 className="font-semibold mb-2 text-yellow-800">Large Items Requiring Heavy Pickup, Truck, or Trailer:</h4>
            <p className="text-sm text-yellow-700 mb-2">
              $40+ base pay for items requiring specialized vehicles or heavy lifting equipment
            </p>
            <div className="text-sm text-yellow-700">
              • Furniture, appliances, construction materials<br/>
              • Plus $0.50 per mile<br/>
              • Urgent delivery bonus available
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck className="w-5 h-5" />
            Driver Earnings Examples
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {examples.map((example, index) => (
              <div key={index} className="border rounded-lg p-4 bg-gradient-to-r from-green-50 to-blue-50">
                <div className="flex justify-between items-center mb-3">
                  <div>
                    <span className="font-medium text-lg">{example.description}</span>
                    <div className="text-sm text-gray-600">{example.miles} miles</div>
                  </div>
                  <div className="text-right">
                    <Badge className={`${example.pricing.isLarge ? 'bg-orange-600' : 'bg-green-600'} text-white`}>
                      Driver Earns: ${example.pricing.driverPay.toFixed(2)}
                    </Badge>
                    {example.pricing.isUrgent && (
                      <div className="text-xs text-red-600 mt-1">+ Urgent bonus</div>
                    )}
                  </div>
                </div>
                
                <div className="grid md:grid-cols-3 gap-3">
                  <div className="bg-white p-3 rounded-lg text-center">
                    <div className="text-lg font-bold text-blue-600">
                      ${example.pricing.driverPay.toFixed(2)}
                    </div>
                    <div className="text-sm text-gray-600">Driver Pay</div>
                    {example.pricing.isLarge && (
                      <div className="text-xs text-orange-600">Large item rate</div>
                    )}
                  </div>
                  
                  <div className="bg-white p-3 rounded-lg text-center">
                    <div className="text-lg font-bold text-orange-600">
                      ${example.pricing.buyerShare.toFixed(2)}
                    </div>
                    <div className="text-sm text-gray-600">Buyer Fee</div>
                    <div className="text-xs text-gray-500">(processing)</div>
                  </div>
                  
                  <div className="bg-white p-3 rounded-lg text-center">
                    <div className="text-lg font-bold text-purple-600">
                      ${example.pricing.sellerShare.toFixed(2)}
                    </div>
                    <div className="text-sm text-gray-600">Seller Fee</div>
                    <div className="text-xs text-gray-500">(processing)</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
            <h4 className="font-bold text-green-800 mb-2">💡 Why This Structure Works:</h4>
            <ul className="text-sm text-green-700 space-y-1">
              <li>• Drivers keep 100% of tips - no platform deductions</li>
              <li>• $40+ for large items requiring heavy pickup, truck, or trailer</li>
              <li>• Urgent delivery bonuses reward fast service</li>
              <li>• No confusing peak time multipliers</li>
              <li>• Fair pay for pickup + drop-off + mileage</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DeliveryPricing;