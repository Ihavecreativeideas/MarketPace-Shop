import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Home, Store, Hammer, ShoppingBag, Music, Menu, Users, Truck, Shield, MapPin, User, BarChart3, MessageSquare, Heart, Building, Settings, Activity, CreditCard, Lock, Flag, Cookie, Globe, Wrench } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import WebIntegrationModal from '@/components/WebIntegrationModal';

const FacebookBottomNavigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isWebIntegrationOpen, setIsWebIntegrationOpen] = useState(false);
  const navigate = useNavigate();

  const mainNavItems = [
    { icon: Store, label: 'Marketplace', path: '/marketplace' },
    { icon: Hammer, label: 'Handcrafted', path: '/handcrafted' },
    { icon: ShoppingBag, label: 'Shops', path: '/shops' },
    { icon: Wrench, label: 'Services', path: '/services' },
    { icon: Music, label: 'Entertainment', path: '/musicians' }
  ];

  const menuItems = [
    { icon: Users, label: 'Invite Friends', path: '/invite-friends' },
    { icon: Truck, label: 'Driver Portal', path: '/driver-signin' },
    { icon: Shield, label: 'Admin', path: '/admin' },
    { icon: MapPin, label: 'Delivery', path: '/delivery' },
    { icon: Home, label: 'Home', path: '/' },
    { icon: User, label: 'Profile', path: '/profile' }
  ];

  const memberFeatures = [
    { icon: Globe, label: 'Website Integration', action: 'web-integration' },
    { icon: BarChart3, label: 'Analytics', path: '/analytics' },
    { icon: MessageSquare, label: 'Messages', path: '/messages' },
    { icon: Heart, label: 'Favorites', path: '/favorites' },
    { icon: Building, label: 'Business Integration', path: '/business-integration' },
    { icon: Settings, label: 'Device Permissions', path: '/device-permissions' },
    { icon: Activity, label: 'Activity Log', path: '/activity-log' },
    { icon: CreditCard, label: 'Payments/Payouts', path: '/payments' },
    { icon: Lock, label: 'Privacy Center', path: '/privacy-center' },
    { icon: Flag, label: 'Block/Report Members', path: '/block-report' },
    { icon: Cookie, label: 'Cookies Policy', path: '/cookies-policy' }
  ];

  const handleNavigation = (path: string) => {
    navigate(path);
    setIsMenuOpen(false);
  };

  const handleFeatureClick = (item: any) => {
    if (item.action === 'web-integration') {
      setIsWebIntegrationOpen(true);
      setIsMenuOpen(false);
    } else if (item.path) {
      handleNavigation(item.path);
    }
  };

  return (
    <>
      {/* Bottom Navigation Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-slate-800 border-t border-slate-600 z-50 shadow-lg">
        <div className="flex items-center justify-around py-2">
          {mainNavItems.slice(0, 4).map((item) => (
            <Button
              key={item.path}
              variant="ghost"
              size="sm"
              className="flex flex-col items-center gap-1 h-auto py-2 px-2 text-slate-200 hover:text-white hover:bg-slate-700"
              onClick={() => handleNavigation(item.path)}
            >
              <item.icon className="w-4 h-4" />
              <span className="text-xs">{item.label}</span>
            </Button>
          ))}
          
          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="flex flex-col items-center gap-1 h-auto py-2 px-2 text-slate-200 hover:text-white hover:bg-slate-700"
              >
                <Menu className="w-4 h-4" />
                <span className="text-xs">Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="h-[80vh] overflow-y-auto bg-slate-800 text-slate-200 border-slate-600">
              <div className="space-y-6 py-4">
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-white">Navigation</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {[...menuItems, mainNavItems[4]].map((item) => (
                      <Button
                        key={item.path}
                        variant="ghost"
                        className="flex items-center gap-3 justify-start h-12 text-slate-200 hover:text-white hover:bg-slate-700"
                        onClick={() => handleNavigation(item.path)}
                      >
                        <item.icon className="w-5 h-5" />
                        {item.label}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3 text-white">Member Features</h3>
                  <div className="grid grid-cols-1 gap-2">
                    {memberFeatures.map((item) => (
                      <Button
                        key={item.label}
                        variant="ghost"
                        className="flex items-center gap-3 justify-start h-12 text-slate-200 hover:text-white hover:bg-slate-700"
                        onClick={() => handleFeatureClick(item)}
                      >
                        <item.icon className="w-5 h-5" />
                        {item.label}
                        {item.action === 'web-integration' && (
                          <span className="ml-auto text-xs bg-green-600 text-white px-2 py-1 rounded">NEW</span>
                        )}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
      
      {/* Spacer to prevent content from being hidden behind bottom nav */}
      <div className="h-16" />
      
      <WebIntegrationModal 
        isOpen={isWebIntegrationOpen} 
        onClose={() => setIsWebIntegrationOpen(false)} 
      />
    </>
  );
};

export default FacebookBottomNavigation;