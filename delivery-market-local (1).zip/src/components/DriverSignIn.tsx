import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Truck, User, Lock, Phone } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';

const DriverSignIn: React.FC = () => {
  const [credentials, setCredentials] = useState({ 
    email: '', 
    password: '',
    phone: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      if (isSignUp) {
        // Sign up new driver
        const { data, error } = await supabase.auth.signUp({
          email: credentials.email,
          password: credentials.password,
          options: {
            data: {
              user_type: 'driver',
              phone: credentials.phone
            }
          }
        });
        
        if (error) throw error;
        
        if (data.user) {
          // Create driver profile
          const { error: profileError } = await supabase
            .from('driver_profiles')
            .insert({
              user_id: data.user.id,
              phone: credentials.phone,
              status: 'pending_approval',
              notifications_enabled: true,
              sms_alerts_enabled: true
            });
            
          if (profileError) throw profileError;
          
          alert('Account created! Please check your email to verify your account.');
        }
      } else {
        // Sign in existing driver
        const { data, error } = await supabase.auth.signInWithPassword({
          email: credentials.email,
          password: credentials.password
        });
        
        if (error) throw error;
        
        if (data.user) {
          // Check if user is a driver
          const { data: profile } = await supabase
            .from('driver_profiles')
            .select('*')
            .eq('user_id', data.user.id)
            .single();
            
          if (profile) {
            navigate('/driver-dashboard');
          } else {
            setError('This account is not registered as a driver.');
            await supabase.auth.signOut();
          }
        }
      }
    } catch (error: any) {
      setError(error.message || 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2 text-2xl text-white">
              <Truck className="w-6 h-6 text-blue-400" />
              Driver {isSignUp ? 'Sign Up' : 'Sign In'}
            </CardTitle>
            <p className="text-gray-400">
              {isSignUp ? 'Create your driver account' : 'Access your driver dashboard'}
            </p>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert className="mb-4 bg-red-900 border-red-700">
                <AlertDescription className="text-red-200">{error}</AlertDescription>
              </Alert>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="email" className="flex items-center gap-2 text-white">
                  <User className="w-4 h-4" />
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={credentials.email}
                  onChange={(e) => setCredentials({...credentials, email: e.target.value})}
                  placeholder="Enter your email"
                  className="bg-gray-700 border-gray-600 text-white"
                  required
                />
              </div>
              
              {isSignUp && (
                <div>
                  <Label htmlFor="phone" className="flex items-center gap-2 text-white">
                    <Phone className="w-4 h-4" />
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={credentials.phone}
                    onChange={(e) => setCredentials({...credentials, phone: e.target.value})}
                    placeholder="Enter your phone number"
                    className="bg-gray-700 border-gray-600 text-white"
                    required
                  />
                </div>
              )}
              
              <div>
                <Label htmlFor="password" className="flex items-center gap-2 text-white">
                  <Lock className="w-4 h-4" />
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={credentials.password}
                  onChange={(e) => setCredentials({...credentials, password: e.target.value})}
                  placeholder="Enter your password"
                  className="bg-gray-700 border-gray-600 text-white"
                  required
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={isLoading}
              >
                {isLoading ? 'Processing...' : (isSignUp ? 'Create Account' : 'Sign In')}
              </Button>
            </form>
            
            <div className="mt-4 text-center">
              <Button 
                variant="link" 
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-blue-400 hover:text-blue-300"
              >
                {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
              </Button>
            </div>
            
            <div className="mt-4 text-center text-sm text-gray-400">
              <p>Need to apply as a driver?</p>
              <Button 
                variant="link" 
                onClick={() => navigate('/driver-application')}
                className="p-0 h-auto font-normal text-blue-400 hover:text-blue-300"
              >
                Submit Driver Application
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DriverSignIn;