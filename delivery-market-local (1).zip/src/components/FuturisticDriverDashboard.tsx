import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { MapPin, Clock, DollarSign, Star, Zap, Target, Route } from 'lucide-react';
import { Switch } from './ui/switch';

interface DeliveryJob {
  id: string;
  pickup: { address: string; lat: number; lng: number };
  dropoff: { address: string; lat: number; lng: number };
  distance: number;
  estimatedTime: number;
  basePayment: number;
  tips: number;
  priority: 'urgent' | 'standard' | 'scheduled';
  loadTime: number;
  unloadTime: number;
  trafficDelay: number;
}

const FuturisticDriverDashboard: React.FC = () => {
  const [isOnline, setIsOnline] = useState(false);
  const [selectedJob, setSelectedJob] = useState<DeliveryJob | null>(null);
  const [availableJobs] = useState<DeliveryJob[]>([
    {
      id: '1',
      pickup: { address: '123 Tech Plaza', lat: 40.7128, lng: -74.0060 },
      dropoff: { address: '456 Innovation Ave', lat: 40.7589, lng: -73.9851 },
      distance: 3.2,
      estimatedTime: 18,
      basePayment: 15.50,
      tips: 3.25,
      priority: 'urgent',
      loadTime: 3,
      unloadTime: 2,
      trafficDelay: 5
    }
  ]);

  const stats = {
    todayEarnings: 287.50,
    completedJobs: 12,
    rating: 4.94,
    efficiency: 96,
    streak: 8
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 text-white p-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              DRIVER COMMAND CENTER
            </h1>
            <p className="text-cyan-300 mt-2">Neural Network Status: {isOnline ? 'CONNECTED' : 'OFFLINE'}</p>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <span className="text-cyan-300">SYSTEM STATUS</span>
              <Switch
                checked={isOnline}
                onCheckedChange={setIsOnline}
                className="data-[state=checked]:bg-cyan-500"
              />
            </div>
            <div className={`px-4 py-2 rounded-full border-2 ${isOnline ? 'border-cyan-400 bg-cyan-400/20 text-cyan-300' : 'border-gray-500 bg-gray-500/20 text-gray-400'}`}>
              {isOnline ? 'ACTIVE' : 'STANDBY'}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-green-900/50 to-emerald-900/50 border-green-500/30 shadow-lg shadow-green-500/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <DollarSign className="w-8 h-8 text-green-400" />
                <div>
                  <p className="text-xs text-green-300 uppercase tracking-wider">Credits Earned</p>
                  <p className="text-2xl font-bold text-green-400">${stats.todayEarnings}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-blue-900/50 to-cyan-900/50 border-blue-500/30 shadow-lg shadow-blue-500/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Target className="w-8 h-8 text-blue-400" />
                <div>
                  <p className="text-xs text-blue-300 uppercase tracking-wider">Missions</p>
                  <p className="text-2xl font-bold text-blue-400">{stats.completedJobs}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-yellow-900/50 to-orange-900/50 border-yellow-500/30 shadow-lg shadow-yellow-500/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Star className="w-8 h-8 text-yellow-400" />
                <div>
                  <p className="text-xs text-yellow-300 uppercase tracking-wider">Rating</p>
                  <p className="text-2xl font-bold text-yellow-400">{stats.rating}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-900/50 to-pink-900/50 border-purple-500/30 shadow-lg shadow-purple-500/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Zap className="w-8 h-8 text-purple-400" />
                <div>
                  <p className="text-xs text-purple-300 uppercase tracking-wider">Efficiency</p>
                  <p className="text-2xl font-bold text-purple-400">{stats.efficiency}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-red-900/50 to-orange-900/50 border-red-500/30 shadow-lg shadow-red-500/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Route className="w-8 h-8 text-red-400" />
                <div>
                  <p className="text-xs text-red-300 uppercase tracking-wider">Streak</p>
                  <p className="text-2xl font-bold text-red-400">{stats.streak}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="bg-gray-900/50 border-cyan-500/30 shadow-xl shadow-cyan-500/10">
            <CardHeader>
              <CardTitle className="text-cyan-300 flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                AVAILABLE MISSIONS
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!isOnline ? (
                <div className="text-center py-8 text-gray-400">
                  <p>Connect to Neural Network to receive missions</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {availableJobs.map((job) => (
                    <div 
                      key={job.id} 
                      className="border-2 rounded-lg p-4 cursor-pointer transition-all duration-300 hover:scale-105 bg-gray-800/50 shadow-red-500/50 border-red-500/50"
                      onClick={() => setSelectedJob(job)}
                    >
                      <div className="flex justify-between items-start mb-3">
                        <Badge className="bg-red-500 text-white">
                          {job.priority.toUpperCase()}
                        </Badge>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-green-400">${(job.basePayment + job.tips).toFixed(2)}</p>
                          <p className="text-xs text-gray-400">Base: ${job.basePayment} + Tips: ${job.tips}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-cyan-400" />
                          <span className="text-cyan-300">PICKUP:</span>
                          <span>{job.pickup.address}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-purple-400" />
                          <span className="text-purple-300">DROPOFF:</span>
                          <span>{job.dropoff.address}</span>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 mt-3 pt-3 border-t border-gray-700">
                          <div className="text-center">
                            <p className="text-xs text-gray-400">DISTANCE</p>
                            <p className="font-bold text-blue-400">{job.distance} mi</p>
                          </div>
                          <div className="text-center">
                            <p className="text-xs text-gray-400">TOTAL TIME</p>
                            <p className="font-bold text-yellow-400">{job.estimatedTime + job.loadTime + job.unloadTime + job.trafficDelay} min</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-purple-500/30 shadow-xl shadow-purple-500/10">
            <CardHeader>
              <CardTitle className="text-purple-300 flex items-center gap-2">
                <Route className="w-5 h-5" />
                MISSION BRIEFING
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!selectedJob ? (
                <div className="text-center py-12 text-gray-400">
                  <Route className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>Select a mission to view details</p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="bg-gray-800 rounded-lg h-48 flex items-center justify-center border border-gray-700">
                    <div className="text-center">
                      <MapPin className="w-12 h-12 mx-auto mb-2 text-cyan-400" />
                      <p className="text-cyan-300">ROUTE CALCULATED</p>
                      <p className="text-sm text-gray-400">Neural GPS Active</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-800/50 rounded-lg p-3 text-center">
                      <Clock className="w-6 h-6 mx-auto mb-1 text-blue-400" />
                      <p className="text-xs text-gray-400">DRIVE TIME</p>
                      <p className="font-bold text-blue-400">{selectedJob.estimatedTime}m</p>
                    </div>
                    <div className="bg-gray-800/50 rounded-lg p-3 text-center">
                      <Zap className="w-6 h-6 mx-auto mb-1 text-yellow-400" />
                      <p className="text-xs text-gray-400">LOAD/UNLOAD</p>
                      <p className="font-bold text-yellow-400">{selectedJob.loadTime + selectedJob.unloadTime}m</p>
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-bold py-3 text-lg"
                    disabled={!isOnline}
                  >
                    ACCEPT MISSION
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default FuturisticDriverDashboard;