import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Crown, Calendar, MessageCircle, FileText, DollarSign } from 'lucide-react';
import MusicianBiography from './MusicianBiography';
import AvailabilityCalendar from './AvailabilityCalendar';
import BookingModal from './BookingModal';
import BookingMessaging from './BookingMessaging';
import AIContractGenerator from './AIContractGenerator';
import GigPaymentSystem from './GigPaymentSystem';

interface ProMusicianProfileProps {
  musician: {
    id: number;
    name: string;
    genre: string;
    image: string;
    isPro: boolean;
    bio: string;
    genres: string[];
    venues: any[];
    rating: number;
    totalGigs: number;
  };
}

const ProMusicianProfile: React.FC<ProMusicianProfileProps> = ({ musician }) => {
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState({ date: '', time: '', price: 0 });
  const [activeBookings] = useState([
    {
      id: 1,
      clientName: 'Sarah Johnson',
      amount: 350,
      eventDate: '2024-01-15',
      status: 'held' as const,
      confirmations: {
        clientConfirmed: true,
        musicianConfirmed: false,
        gigStarted: false,
        gigCompleted: false
      }
    }
  ]);

  const handleBookSlot = (date: string, time: string) => {
    setSelectedSlot({ date, time, price: 250 });
    setShowBookingModal(true);
  };

  const handleBookingSubmit = (bookingData: any) => {
    console.log('Booking submitted:', bookingData);
    // Handle booking submission
  };

  const handleConfirmGig = (paymentId: number, type: string) => {
    console.log('Confirming gig:', paymentId, type);
    // Handle gig confirmation
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-start gap-6">
            <img 
              src={musician.image} 
              alt={musician.name} 
              className="w-24 h-24 rounded-full object-cover"
            />
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-2xl font-bold">{musician.name}</h1>
                {musician.isPro && (
                  <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
                    <Crown className="w-3 h-3 mr-1" />
                    PRO
                  </Badge>
                )}
              </div>
              <p className="text-gray-600 mb-4">{musician.genre}</p>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Calendar className="w-4 h-4 mr-2" />
                Book Now
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pro Features Tabs */}
      <Tabs defaultValue="biography" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="biography">Biography</TabsTrigger>
          <TabsTrigger value="calendar">Availability</TabsTrigger>
          <TabsTrigger value="messages">Messages</TabsTrigger>
          <TabsTrigger value="contracts">Contracts</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
        </TabsList>

        <TabsContent value="biography">
          <MusicianBiography musician={musician} />
        </TabsContent>

        <TabsContent value="calendar">
          <AvailabilityCalendar 
            musicianId={musician.id}
            onBookSlot={handleBookSlot}
          />
        </TabsContent>

        <TabsContent value="messages">
          <BookingMessaging
            bookingId={1}
            clientName="Sarah Johnson"
            musicianName={musician.name}
            onSendMessage={(msg) => console.log('Message:', msg)}
            onAcceptBooking={() => console.log('Booking accepted')}
            onDeclineBooking={() => console.log('Booking declined')}
          />
        </TabsContent>

        <TabsContent value="contracts">
          <AIContractGenerator
            contractData={{
              musicianName: musician.name,
              clientName: 'Sarah Johnson',
              eventDate: '2024-01-15',
              eventTime: '7:00 PM',
              venue: 'Grand Ballroom',
              duration: '3',
              price: 350,
              eventType: 'Wedding Reception'
            }}
            onContractGenerated={(contract) => console.log('Contract:', contract)}
          />
        </TabsContent>

        <TabsContent value="payments">
          <GigPaymentSystem
            payments={activeBookings}
            onConfirmGig={handleConfirmGig}
          />
        </TabsContent>
      </Tabs>

      {/* Booking Modal */}
      <BookingModal
        isOpen={showBookingModal}
        onClose={() => setShowBookingModal(false)}
        musician={{ name: musician.name, id: musician.id }}
        selectedDate={selectedSlot.date}
        selectedTime={selectedSlot.time}
        price={selectedSlot.price}
        onSubmitBooking={handleBookingSubmit}
      />
    </div>
  );
};

export default ProMusicianProfile;