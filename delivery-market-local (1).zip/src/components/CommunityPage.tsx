import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Plus, Heart, MessageCircle, Share2, Search, MapPin, Video, Camera, BarChart3, Eye, X } from 'lucide-react';
import { FloatingBottomNavigation } from './FloatingBottomNavigation';

const CommunityPage: React.FC = () => {
  const [showPostModal, setShowPostModal] = useState(false);
  const [postType, setPostType] = useState('thought');
  const [content, setContent] = useState('');
  const [posts, setPosts] = useState([
    {
      id: 1,
      user: 'Local Music Venue',
      time: '2h ago',
      type: 'event',
      content: 'Live jazz night this Friday! Come support local musicians.',
      likes: 24,
      comments: 8,
      location: 'Downtown'
    },
    {
      id: 2,
      user: 'Sarah M.',
      time: '4h ago',
      type: 'iso',
      content: 'ISO: Looking for a reliable house cleaner in the area. Any recommendations?',
      likes: 12,
      comments: 15,
      location: 'Westside'
    },
    {
      id: 3,
      user: 'Mike\'s Guitar Shop',
      time: '6h ago',
      type: 'livestream',
      content: 'Live guitar lesson stream - Learn basic chords!',
      isLive: true,
      viewers: 23,
      likes: 18,
      comments: 5,
      location: 'Music District'
    },
    {
      id: 4,
      user: 'Community Poll',
      time: '1d ago',
      type: 'poll',
      content: 'What type of local events would you like to see more of?',
      poll: {
        options: [
          { text: 'Music concerts', votes: 45 },
          { text: 'Food festivals', votes: 32 },
          { text: 'Art shows', votes: 28 },
          { text: 'Sports events', votes: 19 }
        ],
        totalVotes: 124
      },
      likes: 8,
      comments: 12,
      location: 'Citywide'
    }
  ]);

  const handleSubmitPost = () => {
    if (content.trim()) {
      const newPost = {
        id: posts.length + 1,
        user: 'You',
        time: 'now',
        type: postType,
        content: content.trim(),
        likes: 0,
        comments: 0,
        location: ''
      };
      setPosts([newPost, ...posts]);
      setContent('');
      setShowPostModal(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-20">
      <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-sm border-b border-slate-700 px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold text-white">Community</h1>
          <Button
            onClick={() => setShowPostModal(true)}
            className="bg-teal-500 hover:bg-teal-600 text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            Post
          </Button>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search community posts..."
                className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
              />
            </div>

            <div className="grid grid-cols-5 gap-2">
              {[
                { icon: MessageCircle, label: 'Thought', type: 'thought' },
                { icon: Camera, label: 'Photo', type: 'picture' },
                { icon: Video, label: 'Live', type: 'livestream' },
                { icon: Search, label: 'ISO', type: 'iso' },
                { icon: BarChart3, label: 'Poll', type: 'poll' }
              ].map(({ icon: Icon, label, type }) => (
                <Button
                  key={type}
                  variant="outline"
                  size="sm"
                  onClick={() => { setPostType(type); setShowPostModal(true); }}
                  className="flex flex-col gap-1 h-auto py-3"
                >
                  <Icon className="h-4 w-4" />
                  <span className="text-xs">{label}</span>
                </Button>
              ))}
            </div>

            <div className="space-y-4">
              {posts.map((post) => (
                <Card key={post.id} className="bg-slate-800/50 border-slate-700">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-teal-500 rounded-full flex items-center justify-center">
                          <span className="text-white font-semibold text-sm">
                            {post.user.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <h3 className="text-white font-semibold">{post.user}</h3>
                          <div className="flex items-center gap-2 text-slate-400 text-sm">
                            <span>{post.time}</span>
                            {post.location && (
                              <>
                                <span>•</span>
                                <MapPin className="h-3 w-3" />
                                <span>{post.location}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {post.isLive && (
                          <Badge className="bg-red-500 text-white animate-pulse">
                            LIVE
                          </Badge>
                        )}
                        <Badge variant="outline" className="text-xs">
                          {post.type}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-300 mb-4">{post.content}</p>
                    
                    {post.type === 'livestream' && (
                      <div className="bg-slate-900 rounded-lg p-4 mb-4">
                        <div className="bg-slate-700 h-48 rounded-lg flex items-center justify-center mb-3">
                          <Video className="h-16 w-16 text-slate-400" />
                        </div>
                        {post.isLive && (
                          <div className="flex items-center gap-4 text-slate-300">
                            <div className="flex items-center gap-1">
                              <Eye className="h-4 w-4" />
                              <span>{post.viewers} watching</span>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                    
                    {post.type === 'poll' && post.poll && (
                      <div className="bg-slate-900 rounded-lg p-4 mb-4">
                        <div className="space-y-3">
                          {post.poll.options.map((option: any, index: number) => {
                            const percentage = post.poll.totalVotes > 0 
                              ? Math.round((option.votes / post.poll.totalVotes) * 100) 
                              : 0;
                            return (
                              <div key={index} className="relative">
                                <div className="flex items-center justify-between p-3 bg-slate-800 rounded-lg hover:bg-slate-700 cursor-pointer">
                                  <span className="text-white">{option.text}</span>
                                  <span className="text-slate-400 text-sm">{percentage}%</span>
                                </div>
                                <div 
                                  className="absolute bottom-0 left-0 h-1 bg-teal-500 rounded-full transition-all"
                                  style={{ width: `${percentage}%` }}
                                />
                              </div>
                            );
                          })}
                        </div>
                        <p className="text-slate-400 text-sm mt-3">
                          {post.poll.totalVotes} votes
                        </p>
                      </div>
                    )}
                    
                    <div className="flex items-center gap-4 text-slate-400">
                      <Button variant="ghost" size="sm" className="text-slate-400 hover:text-red-400">
                        <Heart className="h-4 w-4 mr-1" />
                        {post.likes}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-slate-400 hover:text-blue-400">
                        <MessageCircle className="h-4 w-4 mr-1" />
                        {post.comments}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-slate-400 hover:text-green-400">
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Trending Topics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: 'Local Events', count: 45 },
                  { name: 'House Cleaning', count: 32 },
                  { name: 'Guitar Lessons', count: 28 },
                  { name: 'Food Delivery', count: 24 }
                ].map((topic, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-slate-300 text-sm">{topic.name}</span>
                    <Badge variant="outline" className="text-xs">
                      {topic.count}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {showPostModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <Card className="w-full max-w-md bg-slate-800 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-white">Create {postType === 'iso' ? 'ISO' : postType} Post</CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setShowPostModal(false)}>
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder={`What's ${postType === 'iso' ? 'are you looking for' : 'happening'}?`}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
              />
              <div className="flex gap-2">
                <Button 
                  onClick={handleSubmitPost}
                  className="bg-teal-500 hover:bg-teal-600 flex-1"
                  disabled={!content.trim()}
                >
                  Post
                </Button>
                <Button variant="outline" onClick={() => setShowPostModal(false)}>
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <FloatingBottomNavigation />
    </div>
  );
};

export default CommunityPage;
export { CommunityPage };