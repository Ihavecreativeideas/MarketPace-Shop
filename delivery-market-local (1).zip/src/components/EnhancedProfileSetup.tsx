import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import AccountPersonalization from './AccountPersonalization';
import AutoProfileCreator from './AutoProfileCreator';
import DeliveryServiceSelector from './DeliveryServiceSelector';
import { CheckCircle, User, Globe, Truck, BarChart3 } from 'lucide-react';

interface EnhancedProfileSetupProps {
  onComplete: () => void;
}

const EnhancedProfileSetup: React.FC<EnhancedProfileSetupProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [profileData, setProfileData] = useState<any>({});
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const steps = [
    {
      id: 0,
      title: 'Personal Information',
      description: 'Tell us about yourself and your interests',
      icon: User,
      component: 'personalization'
    },
    {
      id: 1,
      title: 'Auto Profile Creation',
      description: 'Let us create your profile automatically',
      icon: Globe,
      component: 'auto-profile'
    },
    {
      id: 2,
      title: 'Delivery Services',
      description: 'Choose your shipping and delivery options',
      icon: Truck,
      component: 'delivery'
    },
    {
      id: 3,
      title: 'Setup Complete',
      description: 'Your personalized profile is ready',
      icon: CheckCircle,
      component: 'complete'
    }
  ];

  const handleStepComplete = (stepData: any) => {
    setProfileData(prev => ({ ...prev, ...stepData }));
    setCompletedSteps(prev => [...prev, currentStep]);
    
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePersonalizationComplete = () => {
    handleStepComplete({ personalizationComplete: true });
  };

  const handleAutoProfileComplete = () => {
    handleStepComplete({ autoProfileComplete: true });
  };

  const handleDeliveryComplete = (services: string[], rates: Record<string, number>) => {
    handleStepComplete({ deliveryServices: services, customRates: rates });
  };

  const handleFinalComplete = () => {
    onComplete();
  };

  const progress = ((currentStep + 1) / steps.length) * 100;

  return (
    <div className="max-w-4xl mx-auto p-4">
      {/* Progress Header */}
      <Card className="bg-gradient-to-br from-slate-900 via-cyan-900 to-purple-900 border-cyan-500/30 text-white mb-6">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            Enhanced Profile Setup
          </CardTitle>
          <div className="space-y-4">
            <div className="flex justify-between text-sm">
              <span className="text-cyan-300">Step {currentStep + 1} of {steps.length}</span>
              <span className="text-cyan-300">{Math.round(progress)}% Complete</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </CardHeader>
      </Card>

      {/* Step Navigation */}
      <div className="flex justify-center mb-6">
        <div className="flex items-center space-x-4">
          {steps.map((step, index) => {
            const Icon = step.icon;
            const isCompleted = completedSteps.includes(index);
            const isCurrent = currentStep === index;
            
            return (
              <div key={step.id} className="flex items-center">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                  isCompleted ? 'bg-green-600 border-green-600' :
                  isCurrent ? 'bg-cyan-600 border-cyan-600' :
                  'bg-slate-700 border-slate-600'
                }`}>
                  <Icon className="h-5 w-5 text-white" />
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-16 h-0.5 ml-2 ${
                    isCompleted ? 'bg-green-600' : 'bg-slate-600'
                  }`} />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Step Content */}
      <div className="space-y-6">
        {/* Current Step Info */}
        <Card className="bg-slate-800 border-cyan-500/30 text-white">
          <CardContent className="p-4">
            <div className="text-center">
              <h3 className="text-xl font-semibold text-cyan-300">{steps[currentStep].title}</h3>
              <p className="text-cyan-200 mt-1">{steps[currentStep].description}</p>
            </div>
          </CardContent>
        </Card>

        {/* Step Components */}
        {currentStep === 0 && (
          <AccountPersonalization onComplete={handlePersonalizationComplete} />
        )}

        {currentStep === 1 && (
          <AutoProfileCreator 
            userId="user-123" 
            website={profileData.website}
            onComplete={handleAutoProfileComplete} 
          />
        )}

        {currentStep === 2 && (
          <DeliveryServiceSelector onServiceSelect={handleDeliveryComplete} />
        )}

        {currentStep === 3 && (
          <Card className="bg-gradient-to-br from-slate-900 via-cyan-900 to-purple-900 border-cyan-500/30 text-white">
            <CardHeader className="text-center">
              <CheckCircle className="h-16 w-16 text-green-400 mx-auto mb-4" />
              <CardTitle className="text-2xl font-bold text-green-400">
                Profile Setup Complete!
              </CardTitle>
              <p className="text-cyan-200 mt-2">
                Your personalized MarketPace profile is now ready. You can start selling, 
                managing inventory, and connecting with customers.
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-800 p-4 rounded-lg">
                  <h4 className="font-semibold text-cyan-300 mb-2">What's Next?</h4>
                  <ul className="text-sm text-cyan-200 space-y-1">
                    <li>• Explore your personalized dashboard</li>
                    <li>• Add more products to your inventory</li>
                    <li>• Set up events and hiring applications</li>
                    <li>• View your analytics and insights</li>
                  </ul>
                </div>
                <div className="bg-slate-800 p-4 rounded-lg">
                  <h4 className="font-semibold text-cyan-300 mb-2">Profile Features</h4>
                  <ul className="text-sm text-cyan-200 space-y-1">
                    <li>• Automated product integration</li>
                    <li>• Custom delivery options</li>
                    <li>• Real-time analytics</li>
                    <li>• Payment processing</li>
                  </ul>
                </div>
              </div>
              
              <div className="flex justify-center space-x-4 pt-4">
                <Button 
                  onClick={() => setCurrentStep(0)}
                  variant="outline" 
                  className="border-cyan-500 text-cyan-300 hover:bg-cyan-500/10"
                >
                  Go Back and Edit
                </Button>
                <Button 
                  onClick={handleFinalComplete}
                  className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
                >
                  Go to Your Personalized Profile
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default EnhancedProfileSetup;