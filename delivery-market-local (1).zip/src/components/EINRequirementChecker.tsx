import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { FileText, Building, AlertTriangle, CheckCircle } from 'lucide-react';

interface EINRequirementCheckerProps {
  businessType?: string;
  onEINSubmit?: (ein: string) => void;
}

const EINRequirementChecker: React.FC<EINRequirementCheckerProps> = ({
  businessType = 'marketplace',
  onEINSubmit
}) => {
  const [ein, setEin] = useState('');
  const [showEINForm, setShowEINForm] = useState(false);

  const requiresEIN = businessType === 'business' || businessType === 'premium';

  const handleEINSubmit = () => {
    if (ein.length >= 9) {
      onEINSubmit?.(ein);
      alert('EIN submitted successfully!');
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="w-5 h-5" />
          Business Tax Information
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert className={requiresEIN ? 'border-orange-200 bg-orange-50' : 'border-green-200 bg-green-50'}>
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription>
            {requiresEIN ? (
              <div>
                <strong>EIN Required:</strong> Business accounts need an Employer Identification Number for tax compliance.
                <Button 
                  variant="link" 
                  className="p-0 h-auto text-orange-600"
                  onClick={() => setShowEINForm(true)}
                >
                  Submit EIN
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span><strong>No EIN Required:</strong> Personal/member accounts don't need tax ID numbers.</span>
              </div>
            )}
          </AlertDescription>
        </Alert>

        {showEINForm && (
          <div className="space-y-4 p-4 border rounded-lg bg-gray-50">
            <div>
              <Label htmlFor="ein">Employer Identification Number (EIN)</Label>
              <Input
                id="ein"
                value={ein}
                onChange={(e) => setEin(e.target.value)}
                placeholder="XX-XXXXXXX"
                maxLength={10}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleEINSubmit} disabled={ein.length < 9}>
                Submit EIN
              </Button>
              <Button variant="outline" onClick={() => setShowEINForm(false)}>
                Cancel
              </Button>
            </div>
          </div>
        )}

        <div className="text-sm text-gray-600 space-y-2">
          <h4 className="font-semibold">When do you need an EIN?</h4>
          <ul className="list-disc list-inside space-y-1">
            <li>Business accounts selling products/services</li>
            <li>Premium partners with multiple revenue streams</li>
            <li>Musicians earning over $600/year</li>
          </ul>
          <p className="text-xs text-gray-500 mt-2">
            Personal buyers and basic members don't need EIN numbers.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default EINRequirementChecker;