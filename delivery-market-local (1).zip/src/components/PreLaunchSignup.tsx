import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Trophy, Sparkles, Crown, Users, Rocket } from 'lucide-react';
import { useLaunch } from '@/contexts/LaunchContext';
import TownSignupModal from './TownSignupModal';
import TrialEraSignup from './TrialEraSignup';

const PreLaunchSignup: React.FC = () => {
  const [showTownModal, setShowTownModal] = useState(false);
  const [showMembershipSignup, setShowMembershipSignup] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { incrementSignups } = useLaunch();

  const handleTownSignup = async (townName: string, userName: string) => {
    setIsSubmitting(true);
    try {
      await incrementSignups(townName);
      alert(`Welcome to the race, ${userName}! You've joined ${townName}'s team.`);
    } catch (error) {
      console.error('Town signup error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (showMembershipSignup) {
    return (
      <div className="space-y-4">
        <Button 
          onClick={() => setShowMembershipSignup(false)}
          variant="outline"
          className="mb-4"
        >
          ← Back to Quick Join
        </Button>
        <TrialEraSignup />
      </div>
    );
  }

  return (
    <>
      <Card className="bg-white shadow-lg mb-6">
        <CardHeader>
          <div className="text-center space-y-3">
            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-1">
              <Sparkles className="w-4 h-4 mr-1" />
              TRIAL ERA - Join Now!
            </Badge>
            <CardTitle className="text-xl font-bold text-gray-800">
              Be First to Experience MarketPace
            </CardTitle>
            <p className="text-sm text-gray-600">
              Choose your membership level and help us grow!
            </p>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center space-x-2 mb-2">
                <Users className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold text-blue-800">Basic Member</h3>
              </div>
              <p className="text-sm text-blue-700 mb-3">
                Perfect for occasional buyers/sellers
              </p>
              <Badge variant="outline" className="text-blue-600 border-blue-200">
                Trial Era: Full Access
              </Badge>
            </div>

            <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border-2 border-purple-300">
              <div className="flex items-center space-x-2 mb-2">
                <Crown className="w-5 h-5 text-purple-600" />
                <h3 className="font-semibold text-purple-800">Premium Partner</h3>
              </div>
              <p className="text-sm text-purple-700 mb-3">
                For shops, services, frequent users & musicians
              </p>
              <div className="space-y-1">
                <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs">
                  <Sparkles className="w-3 h-3 mr-1" />
                  Lifetime Benefits
                </Badge>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg border border-blue-200">
            <h4 className="font-semibold text-blue-900 mb-2">Trial Era Benefits</h4>
            <div className="text-sm text-blue-800 space-y-1">
              <p>• All early members get full access to ALL features during trial</p>
              <p>• Only Premium Partners (Subscribers) get lifetime benefits</p>
              <p>• Support our startup while we grow and improve together</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Button 
              onClick={() => setShowMembershipSignup(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold"
            >
              <Rocket className="w-4 h-4 mr-2" />
              Choose Membership
            </Button>
            
            <Button 
              variant="outline"
              onClick={() => setShowTownModal(true)}
              className="border-yellow-400 text-yellow-600 hover:bg-yellow-50 font-semibold"
            >
              <Trophy className="w-4 h-4 mr-2" />
              Join Town Race
            </Button>
          </div>
          
          <div className="bg-gradient-to-r from-yellow-50 to-orange-50 p-3 rounded-lg border border-yellow-200">
            <div className="flex items-start space-x-2">
              <Trophy className="w-5 h-5 text-yellow-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-yellow-800">
                  Join the Town Race!
                </p>
                <p className="text-xs text-yellow-700 mt-1">
                  Compete with other towns to see who can get the most members before launch. 
                  The winning town gets exclusive perks!
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <TownSignupModal 
        isOpen={showTownModal}
        onClose={() => setShowTownModal(false)}
        onSignup={handleTownSignup}
      />
    </>
  );
};

export default PreLaunchSignup;