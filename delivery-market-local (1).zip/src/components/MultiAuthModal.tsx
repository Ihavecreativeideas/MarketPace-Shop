import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { LogIn, UserPlus, ArrowLeft, Mail, Lock, User, Car, Shield, Users } from 'lucide-react';

const MultiAuthModal: React.FC = () => {
  const navigate = useNavigate();
  const [authType, setAuthType] = useState<'user' | 'driver' | 'admin' | 'guest'>('user');
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    confirmPassword: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Auth attempt:', { authType, formData });
    
    // Navigate based on auth type
    switch (authType) {
      case 'driver':
        navigate('/driver-dashboard');
        break;
      case 'admin':
        navigate('/admin');
        break;
      case 'guest':
        navigate('/personalized-profile');
        break;
      default:
        navigate('/personalized-profile');
    }
  };

  const handleGuestAccess = () => {
    navigate('/personalized-profile');
  };

  const handleSocialAuth = (provider: string) => {
    console.log(`${provider} auth`);
    navigate('/personalized-profile');
  };

  const handleBack = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-slate-800/90 border-slate-600/30 backdrop-blur-sm">
        <CardHeader className="text-center">
          <div className="flex items-center justify-between mb-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBack}
              className="text-slate-400 hover:text-white"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <CardTitle className="text-2xl font-bold text-white">
              Welcome to MarketPace
            </CardTitle>
            <div className="w-8" />
          </div>
        </CardHeader>
        <CardContent>
          {/* Auth Type Selection */}
          <div className="grid grid-cols-2 gap-2 mb-6">
            <Button
              variant={authType === 'user' ? 'default' : 'outline'}
              onClick={() => setAuthType('user')}
              className="flex items-center gap-2"
            >
              <User className="h-4 w-4" />
              User
            </Button>
            <Button
              variant={authType === 'driver' ? 'default' : 'outline'}
              onClick={() => setAuthType('driver')}
              className="flex items-center gap-2"
            >
              <Car className="h-4 w-4" />
              Driver
            </Button>
            <Button
              variant={authType === 'admin' ? 'default' : 'outline'}
              onClick={() => setAuthType('admin')}
              className="flex items-center gap-2"
            >
              <Shield className="h-4 w-4" />
              Admin
            </Button>
            <Button
              variant={authType === 'guest' ? 'default' : 'outline'}
              onClick={handleGuestAccess}
              className="flex items-center gap-2"
            >
              <Users className="h-4 w-4" />
              Guest
            </Button>
          </div>

          {authType !== 'guest' && (
            <>
              <Tabs value={isLogin ? 'login' : 'signup'} onValueChange={(value) => setIsLogin(value === 'login')}>
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="login" className="flex items-center gap-2">
                    <LogIn className="h-4 w-4" />
                    Login
                  </TabsTrigger>
                  <TabsTrigger value="signup" className="flex items-center gap-2">
                    <UserPlus className="h-4 w-4" />
                    Sign Up
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="login">
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-white">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          placeholder="Enter your email"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-white">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                        <Input
                          id="password"
                          name="password"
                          type="password"
                          placeholder="Enter your password"
                          value={formData.password}
                          onChange={handleInputChange}
                          className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
                          required
                        />
                      </div>
                    </div>
                    <Button type="submit" className="w-full bg-teal-500 hover:bg-teal-600">
                      <LogIn className="mr-2 h-4 w-4" />
                      Login as {authType.charAt(0).toUpperCase() + authType.slice(1)}
                    </Button>
                  </form>
                </TabsContent>

                <TabsContent value="signup">
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-white">Full Name</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                        <Input
                          id="name"
                          name="name"
                          type="text"
                          placeholder="Enter your full name"
                          value={formData.name}
                          onChange={handleInputChange}
                          className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-white">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          placeholder="Enter your email"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-white">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                        <Input
                          id="password"
                          name="password"
                          type="password"
                          placeholder="Create a password"
                          value={formData.password}
                          onChange={handleInputChange}
                          className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
                          required
                        />
                      </div>
                    </div>
                    <Button type="submit" className="w-full bg-teal-500 hover:bg-teal-600">
                      <UserPlus className="mr-2 h-4 w-4" />
                      Sign Up as {authType.charAt(0).toUpperCase() + authType.slice(1)}
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>

              {/* Social Auth Buttons */}
              <div className="mt-6 space-y-3">
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-slate-600" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-slate-800 px-2 text-slate-400">Or continue with</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant="outline"
                    onClick={() => handleSocialAuth('facebook')}
                    className="bg-blue-600 hover:bg-blue-700 text-white border-blue-600"
                  >
                    Facebook
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => handleSocialAuth('google')}
                    className="bg-red-600 hover:bg-red-700 text-white border-red-600"
                  >
                    Google
                  </Button>
                </div>
              </div>
            </>
          )}

          <div className="mt-6 text-center">
            <p className="text-sm text-slate-400">
              By continuing, you agree to our Terms of Service and Privacy Policy
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MultiAuthModal;
export { MultiAuthModal };