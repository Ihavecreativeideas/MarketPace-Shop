import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Briefcase, Wrench } from 'lucide-react';
import ShopsAndServices from './ShopsAndServices';
import HiringService from './HiringService';
import { SellToMarketplaceButton } from './SellToMarketplaceButton';

const ServicesWithHiring: React.FC = () => {
  const [activeTab, setActiveTab] = useState('services');

  return (
    <div className="min-h-screen bg-background">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="border-b">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center py-4">
              <TabsList className="grid w-full max-w-md grid-cols-2">
                <TabsTrigger value="services" className="flex items-center gap-2">
                  <Wrench className="h-4 w-4" />
                  Services
                </TabsTrigger>
                <TabsTrigger value="hiring" className="flex items-center gap-2">
                  <Briefcase className="h-4 w-4" />
                  Hiring
                </TabsTrigger>
              </TabsList>
              <SellToMarketplaceButton fromPage="services" />
            </div>
          </div>
        </div>

        <TabsContent value="services" className="mt-0">
          <ShopsAndServices />
        </TabsContent>

        <TabsContent value="hiring" className="mt-0">
          <HiringService />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ServicesWithHiring;