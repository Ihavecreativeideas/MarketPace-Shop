import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Plus, MapPin, Clock, Star, Package } from 'lucide-react';
import { FloatingBottomNavigation } from './FloatingBottomNavigation';

const RentAnything: React.FC = () => {
  const [showPostModal, setShowPostModal] = useState(false);
  const [postData, setPostData] = useState({
    title: '',
    description: '',
    price: '',
    location: ''
  });

  const rentals = [
    {
      id: 1,
      title: 'Professional Camera Kit',
      price: 45,
      period: 'per day',
      owner: 'PhotoPro Studio',
      location: '2.1 miles away',
      rating: 4.9,
      description: 'Complete DSLR camera kit with lenses and accessories',
      deliveryOptions: ['MarketPace Delivery', 'Self Pickup']
    },
    {
      id: 2,
      title: 'Power Tools Set',
      price: 25,
      period: 'per day',
      owner: 'Tool Rental Co',
      location: '1.5 miles away',
      rating: 4.7,
      description: 'Complete set of power tools for home projects',
      deliveryOptions: ['MarketPace Delivery', 'Self Pickup']
    },
    {
      id: 3,
      title: 'Party Tent 20x20',
      price: 80,
      period: 'per day',
      owner: 'Event Rentals',
      location: '3.2 miles away',
      rating: 4.8,
      description: 'Large party tent perfect for outdoor events',
      deliveryOptions: ['MarketPace Delivery']
    }
  ];

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Posting rental:', postData);
    setShowPostModal(false);
    setPostData({ title: '', description: '', price: '', location: '' });
  };

  const handleRentNow = (rentalId: number) => {
    console.log('Renting item:', rentalId);
    // Navigate to rental checkout
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-20">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-sm border-b border-slate-700 px-4 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold text-white">Rent Anything</h1>
          <Button
            onClick={() => setShowPostModal(true)}
            className="bg-teal-500 hover:bg-teal-600 text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            Post Rental
          </Button>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Search */}
        <div className="mb-6">
          <Input
            placeholder="Search rental items..."
            className="bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
          />
        </div>

        {/* Rental Policy Notice */}
        <Card className="mb-6 bg-orange-500/10 border-orange-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Package className="h-5 w-5 text-orange-400 mt-0.5" />
              <div className="text-sm text-orange-300">
                <p className="font-semibold mb-1">Rental Policy:</p>
                <p>MarketPace is not responsible for lost, stolen, or damaged items. Members are responsible for all communication and creating their own terms. Double delivery fee applies (drop-off and pickup).</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Rentals Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rentals.map((rental) => (
            <Card key={rental.id} className="bg-slate-800/50 border-slate-700">
              <CardHeader className="p-0">
                <div className="w-full h-48 bg-slate-700 rounded-t-lg flex items-center justify-center">
                  <span className="text-slate-400 text-sm">Rental Image</span>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div>
                    <h3 className="text-white font-semibold text-lg">{rental.title}</h3>
                    <p className="text-slate-400 text-sm">{rental.description}</p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-2xl font-bold text-teal-400">${rental.price}</span>
                      <span className="text-slate-400 text-sm ml-1">{rental.period}</span>
                    </div>
                    <div className="flex items-center gap-1 text-yellow-400">
                      <Star className="h-4 w-4 fill-current" />
                      <span className="text-sm">{rental.rating}</span>
                    </div>
                  </div>
                  
                  <div className="text-slate-400 text-sm space-y-1">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      <span>{rental.location}</span>
                    </div>
                    <div>Owner: {rental.owner}</div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-slate-400 text-sm">Delivery Options:</div>
                    <div className="flex flex-wrap gap-1">
                      {rental.deliveryOptions.map((option, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {option}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <Button
                    onClick={() => handleRentNow(rental.id)}
                    className="w-full bg-teal-500 hover:bg-teal-600 text-white"
                  >
                    Rent Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Post Rental Modal */}
      {showPostModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <Card className="w-full max-w-md bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Post Rental Item</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePostSubmit} className="space-y-4">
                <Input
                  placeholder="Item title"
                  value={postData.title}
                  onChange={(e) => setPostData({...postData, title: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
                  required
                />
                <Textarea
                  placeholder="Description"
                  value={postData.description}
                  onChange={(e) => setPostData({...postData, description: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
                  required
                />
                <Input
                  placeholder="Price per day"
                  type="number"
                  value={postData.price}
                  onChange={(e) => setPostData({...postData, price: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
                  required
                />
                <Input
                  placeholder="Location (private)"
                  value={postData.location}
                  onChange={(e) => setPostData({...postData, location: e.target.value})}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
                  required
                />
                <div className="flex gap-2">
                  <Button type="submit" className="bg-teal-500 hover:bg-teal-600">
                    Post Item
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setShowPostModal(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}

      <FloatingBottomNavigation />
    </div>
  );
};

export default RentAnything;
export { RentAnything };