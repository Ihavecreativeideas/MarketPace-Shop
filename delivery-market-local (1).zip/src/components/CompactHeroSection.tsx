import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { MapPin, Clock, Shield, Heart, Rocket } from 'lucide-react';
import { cn } from '../lib/utils';

interface CompactHeroSectionProps {
  onGetStarted: () => void;
  className?: string;
}

const CompactHeroSection: React.FC<CompactHeroSectionProps> = ({ 
  onGetStarted, 
  className 
}) => {
  const features = [
    { icon: MapPin, title: 'Local Focus', desc: 'Supporting neighborhood businesses' },
    { icon: Clock, title: 'Fast Delivery', desc: 'Quick community connections' },
    { icon: Shield, title: 'Safe & Secure', desc: 'Trusted platform for all' },
    { icon: Heart, title: 'Community', desc: 'Building stronger neighborhoods' }
  ];

  return (
    <section className={cn("px-4 py-6 space-y-6", className)}>
      {/* Main Tagline - Centered at Top */}
      <div className="text-center pt-8">
        <h1 className="text-3xl sm:text-4xl font-bold text-white leading-tight mb-8">
          You set the pace, <span className="text-teal-400">we make it happen!</span>
        </h1>
      </div>

      {/* Centered Title and Description */}
      <div className="text-center space-y-4">
        <h2 className="text-xl font-bold text-white">
          MarketPace
        </h2>
        <p className="text-sm text-slate-300 leading-relaxed px-2">
          Buy, sell, rent, and hire locally! MarketPace delivers more opportunities to Local communities.
        </p>
        
        <Button 
          onClick={onGetStarted}
          className="bg-teal-500 hover:bg-teal-600 text-white shadow-lg w-full max-w-xs"
        >
          <Rocket className="mr-2 h-4 w-4" />
          Get Started
        </Button>
      </div>

      {/* Benefits Card */}
      <Card className="bg-slate-800/60 border-slate-600/40 backdrop-blur-sm">
        <CardContent className="p-4">
          <h3 className="font-bold text-teal-400 mb-2 text-sm">Early Member Benefits:</h3>
          <ul className="text-xs text-slate-300 space-y-1">
            <li>• No upcharge, no added fees - just pay the driver</li>
            <li>• Early members get lifetime benefits</li>
            <li>• Test all MarketPace Pro features free</li>
            <li>• Easy web integration for shops & entertainers</li>
          </ul>
        </CardContent>
      </Card>

      {/* Feature Grid - 2x2 Layout - Moved Down */}
      <div className="grid grid-cols-2 gap-4 mt-12">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <Card key={index} className="bg-slate-800/50 border-slate-600/40 hover:bg-slate-700/50 transition-colors shadow-lg">
              <CardContent className="p-4 text-center">
                <Icon className="h-8 w-8 text-teal-400 mx-auto mb-3" />
                <h3 className="font-bold text-sm text-white mb-2">{feature.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed">{feature.desc}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </section>
  );
};

export default CompactHeroSection;