import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Gift, Users, Clock, AlertTriangle, Heart, Truck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface FreeAccessPromotionProps {
  isMarketplaceMember?: boolean;
  isPartner?: boolean;
}

const FreeAccessPromotion: React.FC<FreeAccessPromotionProps> = ({ 
  isMarketplaceMember = false, 
  isPartner = false 
}) => {
  const navigate = useNavigate();

  const handleGetFreeAccess = () => {
    navigate('/partner-signup-form');
  };

  if (isPartner) {
    return null;
  }

  return (
    <Card className="border-2 border-green-500 bg-gradient-to-br from-green-50 to-blue-50 mb-6">
      <CardHeader className="text-center">
        <Badge className="mx-auto mb-2 bg-red-500 text-white animate-pulse">
          <Clock className="w-3 h-3 mr-1" />
          LIMITED TIME ONLY
        </Badge>
        <CardTitle className="text-2xl font-bold text-green-700">
          {isMarketplaceMember ? '🎉 Special Offer for MarketPlace Members!' : '🚀 Join MarketPlace Partners'}
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {isMarketplaceMember && (
          <div className="bg-blue-100 border border-blue-300 rounded-lg p-4 mb-4">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-5 h-5 text-blue-600" />
              <span className="font-semibold text-blue-800">Exclusive Member Benefits</span>
            </div>
            <p className="text-blue-700 text-sm">
              As a MarketPlace member, you can now sign up as a partner for FREE during our test campaign!
            </p>
          </div>
        )}

        <div className="bg-green-100 border border-green-300 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Truck className="w-5 h-5 text-green-600" />
            <span className="font-semibold text-green-800">No Extra Delivery Service Fee</span>
          </div>
          <p className="text-green-700 text-sm mb-2">
            During our test run campaign, delivery fees only go to pay our drivers - no extra charges for you!
          </p>
          <p className="text-green-600 text-xs">
            Help us test our platform while growing your customer base
          </p>
        </div>

        <div className="bg-yellow-50 border border-yellow-300 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-5 h-5 text-yellow-600" />
            <span className="font-semibold text-yellow-800">Why This Matters</span>
          </div>
          <p className="text-yellow-700 text-sm">
            MarketPlace is beneficial to your growing community by "Delivering Opportunities" - 
            connecting local businesses with customers who need their services.
          </p>
        </div>

        <div className="bg-purple-50 border border-purple-300 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Heart className="w-5 h-5 text-purple-600" />
            <span className="font-semibold text-purple-800">Support Our Launch (Optional)</span>
          </div>
          <p className="text-purple-700 text-sm mb-2">
            Want to help ensure MarketPlace's successful launch? You can:
          </p>
          <ul className="text-purple-600 text-xs space-y-1">
            <li>• Make a donation to support development</li>
            <li>• Become a launch sponsor for featured promotion</li>
            <li>• Simply join and help us grow the community</li>
          </ul>
        </div>

        <div className="text-center pt-4">
          <Button 
            size="lg" 
            className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-bold px-8 py-3 text-lg"
            onClick={handleGetFreeAccess}
          >
            <Gift className="w-5 h-5 mr-2" />
            Get FREE Access Now - No Credit Card Required
          </Button>
          
          <p className="text-sm text-gray-600 mt-2">
            {isMarketplaceMember 
              ? 'Exclusive offer for existing members during our test campaign' 
              : 'Limited time offer - Join the community that delivers opportunities'
            }
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default FreeAccessPromotion;