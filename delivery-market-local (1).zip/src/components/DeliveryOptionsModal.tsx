import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, Zap, MapPin, Shield, Calendar, Crown, Lock } from 'lucide-react';

interface DeliveryOptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRush: () => void;
  onSelectScheduled: () => void;
  deliveryFee: number;
  userMembershipType?: 'standard' | 'partner';
}

const DELIVERY_TIMES = [
  { time: '9:00 AM', available: true },
  { time: '12:00 PM', available: true },
  { time: '3:00 PM', available: false },
  { time: '6:00 PM', available: true },
  { time: '9:00 PM', available: true }
];

export const DeliveryOptionsModal: React.FC<DeliveryOptionsModalProps> = ({
  isOpen,
  onClose,
  onSelectRush,
  onSelectScheduled,
  deliveryFee,
  userMembershipType = 'standard'
}) => {
  const rushFee = 5.00;
  const totalWithRush = deliveryFee + rushFee;
  const isStandardMember = userMembershipType === 'standard';

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-green-600" />
            Safe Delivery Options - We Keep You Protected
          </DialogTitle>
          <p className="text-sm text-gray-600 mt-2">
            For your safety and convenience, we only offer delivery services. No pickup required!
          </p>
        </DialogHeader>
        
        {isStandardMember && (
          <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center gap-2 text-blue-700">
              <MapPin className="w-4 h-4" />
              <span className="font-medium">Standard Membership - Local Delivery Only</span>
            </div>
            <p className="text-sm text-blue-600 mt-1">
              Your current plan includes local delivery only (5 mile radius). 
              <Button variant="link" className="p-0 h-auto text-blue-600 underline">
                Become a partner for extended delivery privileges!
              </Button>
            </p>
          </div>
        )}
        
        <div className="grid md:grid-cols-2 gap-4">
          <Card className={`cursor-pointer hover:shadow-lg transition-shadow border-orange-200 ${
            isStandardMember ? 'opacity-50' : ''
          }`} onClick={isStandardMember ? undefined : onSelectRush}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-orange-500" />
                Rush Delivery
                <Badge variant="outline" className="text-orange-600 border-orange-300">
                  +$5.00
                </Badge>
                {isStandardMember && (
                  <Badge variant="outline" className="text-xs">
                    <Crown className="w-3 h-3 mr-1" />
                    Partner Only
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm text-gray-600">
                  {isStandardMember 
                    ? 'Extended range rush delivery - upgrade to partner membership to access'
                    : 'Get your order delivered immediately by the next available driver'
                  }
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">30-60 minutes</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">
                      {isStandardMember ? 'Up to 20 miles' : 'Direct delivery'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Contactless delivery</span>
                  </div>
                </div>
                {!isStandardMember && (
                  <div className="bg-orange-50 p-3 rounded-lg">
                    <div className="text-sm space-y-1">
                      <div className="flex justify-between">
                        <span>Base delivery:</span>
                        <span>${deliveryFee.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Rush fee:</span>
                        <span>+${rushFee.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-bold border-t pt-1">
                        <span>Total:</span>
                        <span>${totalWithRush.toFixed(2)}</span>
                      </div>
                      <div className="text-xs text-gray-500 mt-2">
                        Driver gets $2.50 bonus, $2.50 to platform
                      </div>
                    </div>
                  </div>
                )}
                <Button 
                  className="w-full" 
                  onClick={isStandardMember ? undefined : onSelectRush}
                  disabled={isStandardMember}
                >
                  {isStandardMember ? (
                    <><Lock className="w-4 h-4 mr-2" /> Upgrade to Access</>
                  ) : (
                    'Select Rush Delivery'
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow border-blue-200" onClick={onSelectScheduled}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-500" />
                Scheduled Delivery
                <Badge variant="secondary" className="bg-blue-100 text-blue-700">Standard Rate</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm text-gray-600">
                  Wait for the next scheduled delivery route in your area
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">
                      {isStandardMember ? '5 mile local radius' : '20 mile radius'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">Next available time slot</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Contactless delivery</span>
                  </div>
                </div>
                <div className="bg-blue-50 p-3 rounded-lg">
                  <div className="text-sm font-medium mb-2">Available Time Slots Today:</div>
                  <div className="space-y-1">
                    {DELIVERY_TIMES.map((slot, index) => (
                      <div key={index} className={`flex justify-between items-center ${
                        slot.available ? 'text-green-600' : 'text-gray-400'
                      }`}>
                        <span>{slot.time}</span>
                        <Badge variant={slot.available ? 'default' : 'secondary'} className="text-xs">
                          {slot.available ? 'Available' : 'Full'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                  <div className="text-sm font-bold mt-3 pt-2 border-t">
                    Delivery fee: ${deliveryFee.toFixed(2)}
                  </div>
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={onSelectScheduled}>
                  Select Scheduled Delivery
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex items-center gap-2 text-green-700">
            <Shield className="w-4 h-4" />
            <span className="font-medium">Safe Delivery Guarantee</span>
          </div>
          <p className="text-sm text-green-600 mt-1">
            All deliveries are contactless and brought safely to your door. No pickup required!
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};