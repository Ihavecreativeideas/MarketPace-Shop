import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Clock, Package, Star } from 'lucide-react';

interface Stop {
  id: string;
  type: 'pickup' | 'delivery';
  address: string;
  itemId: string;
  itemName: string;
  distance: number;
  status: 'pending' | 'completed' | 'rejected';
}

const DeliveryExample = () => {
  const [currentStop, setCurrentStop] = useState(0);
  const [showNotification, setShowNotification] = useState(false);
  
  const stops: Stop[] = [
    { id: '1', type: 'pickup', address: '123 Oak St', itemId: 'A1', itemName: 'Vintage Guitar', distance: 2.1, status: 'pending' },
    { id: '2', type: 'pickup', address: '456 Pine Ave', itemId: 'B2', itemName: 'Laptop', distance: 3.8, status: 'pending' },
    { id: '3', type: 'pickup', address: '789 Elm Dr', itemId: 'C3', itemName: 'Bicycle', distance: 5.2, status: 'pending' },
    { id: '4', type: 'delivery', address: '321 Maple Ln', itemId: 'A1', itemName: 'Vintage Guitar', distance: 7.1, status: 'pending' },
    { id: '5', type: 'pickup', address: '654 Cedar Rd', itemId: 'D4', itemName: 'Books', distance: 8.9, status: 'pending' },
    { id: '6', type: 'delivery', address: '987 Birch St', itemId: 'B2', itemName: 'Laptop', distance: 10.3, status: 'pending' },
    { id: '7', type: 'pickup', address: '147 Spruce Way', itemId: 'E5', itemName: 'Camera', distance: 11.7, status: 'pending' },
    { id: '8', type: 'delivery', address: '258 Willow Ave', itemId: 'C3', itemName: 'Bicycle', distance: 12.8, status: 'pending' },
    { id: '9', type: 'pickup', address: '369 Ash Blvd', itemId: 'F6', itemName: 'Desk Chair', distance: 13.5, status: 'pending' },
    { id: '10', type: 'delivery', address: '741 Poplar Dr', itemId: 'D4', itemName: 'Books', distance: 14.2, status: 'pending' },
    { id: '11', type: 'delivery', address: '852 Hickory Ln', itemId: 'E5', itemName: 'Camera', distance: 14.8, status: 'pending' },
    { id: '12', type: 'delivery', address: '963 Walnut St', itemId: 'F6', itemName: 'Desk Chair', distance: 15.0, status: 'pending' }
  ];

  const handleDeliveryComplete = () => {
    setShowNotification(true);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Delivery Route Example: 6 Items = 12 Stops
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold text-blue-800 mb-2">Route Summary</h3>
              <p className="text-sm text-blue-600">• 6 Items to deliver</p>
              <p className="text-sm text-blue-600">• 12 Total stops (6 pickups + 6 deliveries)</p>
              <p className="text-sm text-blue-600">• 15 mile radius coverage</p>
              <p className="text-sm text-blue-600">• Optimized AI routing</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="font-semibold text-green-800 mb-2">Delivery Rules</h3>
              <p className="text-sm text-green-600">• Pickups always before deliveries</p>
              <p className="text-sm text-green-600">• Seller can reject at delivery</p>
              <p className="text-sm text-green-600">• Buyer pays return fees</p>
              <p className="text-sm text-green-600">• Tip & rate after delivery</p>
            </div>
          </div>
          
          <div className="space-y-3">
            {stops.map((stop, index) => (
              <div key={stop.id} className={`flex items-center gap-3 p-3 rounded-lg border ${
                index === currentStop ? 'bg-yellow-50 border-yellow-300' : 
                index < currentStop ? 'bg-green-50 border-green-300' : 'bg-gray-50 border-gray-200'
              }`}>
                <div className="flex-shrink-0">
                  <Badge variant={stop.type === 'pickup' ? 'default' : 'secondary'}>
                    {stop.type === 'pickup' ? 'Pickup' : 'Delivery'}
                  </Badge>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-gray-500" />
                    <span className="font-medium">{stop.address}</span>
                  </div>
                  <p className="text-sm text-gray-600">{stop.itemName} (ID: {stop.itemId})</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{stop.distance} mi</p>
                  <p className="text-xs text-gray-500">Stop {index + 1}</p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 flex gap-3">
            <Button 
              onClick={() => setCurrentStop(Math.min(currentStop + 1, stops.length - 1))}
              disabled={currentStop >= stops.length - 1}
            >
              Next Stop
            </Button>
            <Button 
              variant="outline"
              onClick={handleDeliveryComplete}
              disabled={currentStop < stops.length - 1}
            >
              Complete Delivery
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {showNotification && (
        <Card className="border-green-300 bg-green-50">
          <CardContent className="p-4">
            <h3 className="font-semibold text-green-800 mb-2">Delivery Completed!</h3>
            <p className="text-sm text-green-600 mb-3">
              Driver has notified buyer and seller. Seller has 5 minutes to accept or decline the item.
            </p>
            <div className="flex gap-2">
              <Button size="sm" className="bg-green-600 hover:bg-green-700">
                <Star className="h-4 w-4 mr-1" />
                Rate & Tip Driver
              </Button>
              <Button size="sm" variant="outline">
                Accept Item
              </Button>
              <Button size="sm" variant="destructive">
                Decline & Return
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default DeliveryExample;