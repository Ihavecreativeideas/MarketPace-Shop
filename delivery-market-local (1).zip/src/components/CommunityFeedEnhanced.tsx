import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Heart, MessageCircle, Share2, MapPin, Users, Video, Camera } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface CommunityPost {
  id: string;
  content: string;
  author_name: string;
  author_id: string;
  author_avatar?: string;
  location: string;
  post_type: 'text' | 'image' | 'video' | 'livestream';
  likes_count: number;
  comments_count: number;
  created_at: string;
  is_local: boolean;
  media_url?: string;
}

interface LiveStream {
  id: string;
  title: string;
  streamer_name: string;
  viewer_count: number;
  location: string;
  thumbnail?: string;
}

export const CommunityFeedEnhanced: React.FC = () => {
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [liveStreams, setLiveStreams] = useState<LiveStream[]>([]);
  const [newPost, setNewPost] = useState('');
  const [postType, setPostType] = useState<'text' | 'image' | 'video'>('text');
  const [userLocation, setUserLocation] = useState('Your Town');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCommunityPosts();
    fetchLiveStreams();
  }, []);

  const fetchCommunityPosts = async () => {
    const { data, error } = await supabase
      .from('community_posts')
      .select(`
        *,
        author:user_profiles!author_id(name, avatar_url)
      `)
      .eq('is_local', true)
      .order('created_at', { ascending: false })
      .limit(20);

    if (data) {
      setPosts(data.map(post => ({
        ...post,
        author_name: post.author?.name || 'Anonymous',
        author_avatar: post.author?.avatar_url
      })));
    }
    setLoading(false);
  };

  const fetchLiveStreams = async () => {
    // Mock data for live streams - would integrate with streaming service
    setLiveStreams([
      {
        id: '1',
        title: 'Local Farmer\'s Market Tour',
        streamer_name: 'Sarah M.',
        viewer_count: 23,
        location: userLocation
      },
      {
        id: '2',
        title: 'Downtown Street Performance',
        streamer_name: 'Mike\'s Band',
        viewer_count: 45,
        location: userLocation
      }
    ]);
  };

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPost.trim()) return;

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { error } = await supabase
      .from('community_posts')
      .insert({
        content: newPost,
        author_id: user.id,
        location: userLocation,
        post_type: postType,
        is_local: true
      });

    if (!error) {
      setNewPost('');
      fetchCommunityPosts();
    }
  };

  const handleLike = async (postId: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Toggle like functionality
    console.log('Toggle like for post:', postId);
  };

  const startLiveStream = () => {
    // Integration with streaming service would go here
    alert('Live streaming feature coming soon! This will integrate with your camera and broadcast to your local community.');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Live Streams Section */}
      {liveStreams.length > 0 && (
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Video className="w-5 h-5 text-red-500" />
              Live in {userLocation}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {liveStreams.map((stream) => (
                <div key={stream.id} className="bg-white/5 rounded-lg p-4 cursor-pointer hover:bg-white/10 transition-all">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                    <span className="text-white font-medium">{stream.title}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm text-gray-300">
                    <span>by {stream.streamer_name}</span>
                    <div className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      <span>{stream.viewer_count}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <Button 
              onClick={startLiveStream}
              className="w-full mt-4 bg-red-600 hover:bg-red-700"
            >
              <Video className="w-4 h-4 mr-2" />
              Start Live Stream
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Create Post */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <MessageCircle className="w-5 h-5" />
            Share with Your Community
          </CardTitle>
          <div className="flex items-center gap-2 text-sm text-gray-300">
            <MapPin className="w-4 h-4" />
            <span>Posting to {userLocation} (Local Only)</span>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreatePost} className="space-y-4">
            <div className="flex gap-2 mb-3">
              <Button
                type="button"
                size="sm"
                variant={postType === 'text' ? 'default' : 'outline'}
                onClick={() => setPostType('text')}
                className={postType === 'text' ? 'bg-blue-600' : 'border-white/20 text-white'}
              >
                Text
              </Button>
              <Button
                type="button"
                size="sm"
                variant={postType === 'image' ? 'default' : 'outline'}
                onClick={() => setPostType('image')}
                className={postType === 'image' ? 'bg-blue-600' : 'border-white/20 text-white'}
              >
                <Camera className="w-3 h-3 mr-1" />
                Photo
              </Button>
              <Button
                type="button"
                size="sm"
                variant={postType === 'video' ? 'default' : 'outline'}
                onClick={() => setPostType('video')}
                className={postType === 'video' ? 'bg-blue-600' : 'border-white/20 text-white'}
              >
                <Video className="w-3 h-3 mr-1" />
                Video
              </Button>
            </div>
            
            <Textarea
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              placeholder="What's happening in your community?"
              className="bg-white/10 border-white/20 text-white"
              rows={3}
            />
            
            <Button 
              type="submit" 
              className="w-full bg-blue-600 hover:bg-blue-700"
              disabled={!newPost.trim()}
            >
              Share Post
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Community Posts */}
      <div className="space-y-4">
        {loading ? (
          <div className="text-center text-white py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
            <p>Loading community posts...</p>
          </div>
        ) : posts.length === 0 ? (
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="text-center py-8">
              <p className="text-gray-300">No posts in your community yet. Be the first to share!</p>
            </CardContent>
          </Card>
        ) : (
          posts.map((post) => (
            <Card key={post.id} className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={post.author_avatar} />
                    <AvatarFallback className="bg-blue-600 text-white">
                      {post.author_name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-white font-medium">{post.author_name}</span>
                      <Badge variant="secondary" className="text-xs">
                        <MapPin className="w-2 h-2 mr-1" />
                        {post.location}
                      </Badge>
                      <span className="text-xs text-gray-400">
                        {new Date(post.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    
                    <p className="text-gray-300 mb-3">{post.content}</p>
                    
                    {post.media_url && (
                      <div className="mb-3">
                        {post.post_type === 'image' && (
                          <img 
                            src={post.media_url} 
                            alt="Post media"
                            className="rounded-lg max-w-full h-auto"
                          />
                        )}
                        {post.post_type === 'video' && (
                          <video 
                            src={post.media_url} 
                            controls
                            className="rounded-lg max-w-full h-auto"
                          />
                        )}
                      </div>
                    )}
                    
                    <div className="flex items-center gap-4 text-sm text-gray-400">
                      <button 
                        onClick={() => handleLike(post.id)}
                        className="flex items-center gap-1 hover:text-red-400 transition-colors"
                      >
                        <Heart className="w-4 h-4" />
                        <span>{post.likes_count}</span>
                      </button>
                      
                      <button className="flex items-center gap-1 hover:text-blue-400 transition-colors">
                        <MessageCircle className="w-4 h-4" />
                        <span>{post.comments_count}</span>
                      </button>
                      
                      <button className="flex items-center gap-1 hover:text-green-400 transition-colors">
                        <Share2 className="w-4 h-4" />
                        <span>Share</span>
                      </button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};