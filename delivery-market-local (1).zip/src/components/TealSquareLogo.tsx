import React from 'react';

interface TealSquareLogoProps {
  size?: number;
  className?: string;
}

const TealSquareLogo: React.FC<TealSquareLogoProps> = ({ size = 32, className = '' }) => {
  return (
    <div 
      className={`bg-teal-500 rounded-lg flex items-center justify-center ${className}`}
      style={{ width: size, height: size }}
    >
      <div className="text-white font-bold text-lg">
        M
      </div>
    </div>
  );
};

export default TealSquareLogo;