import React from 'react';
import { Shield, Lock, CreditCard, UserCheck } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface SecurePaymentWrapperProps {
  children: React.ReactNode;
  title?: string;
  showSecurityBadges?: boolean;
}

export const SecurePaymentWrapper: React.FC<SecurePaymentWrapperProps> = ({
  children,
  title = "Secure Payment",
  showSecurityBadges = true
}) => {
  return (
    <div className="max-w-2xl mx-auto">
      {showSecurityBadges && (
        <div className="mb-6">
          <div className="flex flex-wrap gap-2 justify-center mb-4">
            <Badge variant="secondary" className="bg-green-50 text-green-700 border-green-200">
              <Shield className="w-3 h-3 mr-1" />
              HIPAA Compliant
            </Badge>
            <Badge variant="secondary" className="bg-blue-50 text-blue-700 border-blue-200">
              <Lock className="w-3 h-3 mr-1" />
              256-bit SSL Encryption
            </Badge>
            <Badge variant="secondary" className="bg-purple-50 text-purple-700 border-purple-200">
              <CreditCard className="w-3 h-3 mr-1" />
              PCI DSS Certified
            </Badge>
            <Badge variant="secondary" className="bg-orange-50 text-orange-700 border-orange-200">
              <UserCheck className="w-3 h-3 mr-1" />
              Privacy Protected
            </Badge>
          </div>
          
          <div className="text-center text-sm text-gray-600 mb-4">
            <p>Your payment information is encrypted and never stored on our servers.</p>
            <p className="text-xs mt-1">All transactions are processed through secure, certified payment processors.</p>
          </div>
        </div>
      )}
      
      <Card className="border-2 border-green-100 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50">
          <CardTitle className="flex items-center gap-2 text-center justify-center">
            <Shield className="w-5 h-5 text-green-600" />
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          {children}
        </CardContent>
      </Card>
      
      <div className="mt-4 text-center">
        <div className="flex items-center justify-center gap-4 text-xs text-gray-500">
          <span>🔒 End-to-End Encrypted</span>
          <span>🏥 HIPAA Safe</span>
          <span>🛡️ Privacy First</span>
        </div>
      </div>
    </div>
  );
};