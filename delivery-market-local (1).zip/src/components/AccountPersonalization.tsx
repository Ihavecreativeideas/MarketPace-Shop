import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Slider } from './ui/slider';
import { User, MapPin, Phone, Mail, Tag } from 'lucide-react';

interface AccountPersonalizationProps {
  onComplete: () => void;
}

const AccountPersonalization: React.FC<AccountPersonalizationProps> = ({ onComplete }) => {
  const [personalInfo, setPersonalInfo] = useState({
    firstName: '',
    lastName: '',
    bio: '',
    location: '',
    phone: '',
    website: '',
    tags: [] as string[],
    serviceArea: [15] // Default 15 miles
  });

  const [currentTag, setCurrentTag] = useState('');

  const handleAddTag = () => {
    if (currentTag.trim() && !personalInfo.tags.includes(currentTag.trim())) {
      setPersonalInfo(prev => ({
        ...prev,
        tags: [...prev.tags, currentTag.trim()]
      }));
      setCurrentTag('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setPersonalInfo(prev => ({
      ...prev,
      tags: prev.tags.filter(t => t !== tag)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Save personal info to database
    console.log('Personal info:', personalInfo);
    onComplete();
  };

  return (
    <div className="max-w-2xl mx-auto p-4">
      <Card className="bg-gradient-to-br from-slate-900 via-cyan-900 to-purple-900 border-cyan-500/30 text-white">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            Personalize Your Account
          </CardTitle>
          <p className="text-cyan-300">
            Tell us about yourself to get started
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName" className="text-cyan-300 flex items-center gap-2">
                  <User className="h-4 w-4" />
                  First Name
                </Label>
                <Input
                  id="firstName"
                  value={personalInfo.firstName}
                  onChange={(e) => setPersonalInfo(prev => ({ ...prev, firstName: e.target.value }))}
                  className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                  required
                />
              </div>
              <div>
                <Label htmlFor="lastName" className="text-cyan-300">
                  Last Name
                </Label>
                <Input
                  id="lastName"
                  value={personalInfo.lastName}
                  onChange={(e) => setPersonalInfo(prev => ({ ...prev, lastName: e.target.value }))}
                  className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="location" className="text-cyan-300 flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                Location
              </Label>
              <Input
                id="location"
                value={personalInfo.location}
                onChange={(e) => setPersonalInfo(prev => ({ ...prev, location: e.target.value }))}
                className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                placeholder="City, State"
              />
            </div>

            <div>
              <Label htmlFor="serviceArea" className="text-cyan-300">
                Service Area: {personalInfo.serviceArea[0]} miles
              </Label>
              <Slider
                value={personalInfo.serviceArea}
                onValueChange={(value) => setPersonalInfo(prev => ({ ...prev, serviceArea: value }))}
                max={30}
                min={1}
                step={1}
                className="mt-2"
              />
              <div className="flex justify-between text-xs text-cyan-400 mt-1">
                <span>1 mile</span>
                <span>30 miles</span>
              </div>
            </div>

            <div>
              <Label htmlFor="phone" className="text-cyan-300 flex items-center gap-2">
                <Phone className="h-4 w-4" />
                Phone Number
              </Label>
              <Input
                id="phone"
                type="tel"
                value={personalInfo.phone}
                onChange={(e) => setPersonalInfo(prev => ({ ...prev, phone: e.target.value }))}
                className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
              />
            </div>

            <div>
              <Label htmlFor="website" className="text-cyan-300 flex items-center gap-2">
                <Mail className="h-4 w-4" />
                Website (Optional)
              </Label>
              <Input
                id="website"
                type="url"
                value={personalInfo.website}
                onChange={(e) => setPersonalInfo(prev => ({ ...prev, website: e.target.value }))}
                className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                placeholder="https://yourwebsite.com"
              />
              <p className="text-xs text-cyan-400 mt-1">
                We'll automatically import your products to MarketPace
              </p>
            </div>

            <div>
              <Label htmlFor="bio" className="text-cyan-300">
                Bio
              </Label>
              <Textarea
                id="bio"
                value={personalInfo.bio}
                onChange={(e) => setPersonalInfo(prev => ({ ...prev, bio: e.target.value }))}
                className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                placeholder="Tell us about yourself..."
                rows={3}
              />
            </div>

            <div>
              <Label className="text-cyan-300 flex items-center gap-2">
                <Tag className="h-4 w-4" />
                Tags (Your Interests)
              </Label>
              <div className="flex gap-2 mt-1">
                <Input
                  value={currentTag}
                  onChange={(e) => setCurrentTag(e.target.value)}
                  className="bg-slate-800 border-cyan-500/30 text-white"
                  placeholder="Add a tag"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                />
                <Button
                  type="button"
                  onClick={handleAddTag}
                  className="bg-cyan-600 hover:bg-cyan-700"
                >
                  Add
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-2">
                {personalInfo.tags.map((tag) => (
                  <Badge
                    key={tag}
                    variant="secondary"
                    className="bg-purple-600 text-white cursor-pointer"
                    onClick={() => handleRemoveTag(tag)}
                  >
                    #{tag} ×
                  </Badge>
                ))}
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
            >
              Continue to Profile Setup
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default AccountPersonalization;