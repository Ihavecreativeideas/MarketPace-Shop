import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { DollarSign, Truck, Package, Zap, Clock, Heart } from 'lucide-react';

const DriverPayStructure: React.FC = () => {
  return (
    <div className="space-y-6">
      <Card className="border-2 border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-800">
            <DollarSign className="w-5 h-5" />
            Driver Pay Structure
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Tips Section - Highlighted */}
          <div className="mb-6 bg-gradient-to-r from-green-100 to-emerald-100 p-6 rounded-lg border-2 border-green-300">
            <div className="flex items-center gap-2 mb-3">
              <Heart className="w-6 h-6 text-green-600" />
              <h3 className="text-xl font-bold text-green-800">Drivers Keep 100% Tips</h3>
            </div>
            <p className="text-green-700 font-medium">Every tip goes directly to you - no platform fees or deductions!</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Standard Items */}
            <div className="bg-white p-6 rounded-lg border border-blue-200">
              <div className="flex items-center gap-2 mb-4">
                <Package className="w-6 h-6 text-green-600" />
                <h3 className="text-lg font-bold text-gray-800">Standard Items</h3>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <span className="font-medium text-gray-700">Pickup Fee</span>
                  <Badge className="bg-green-600 text-white">$4.00</Badge>
                </div>
                <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                  <span className="font-medium text-gray-700">Drop-off Fee</span>
                  <Badge className="bg-blue-600 text-white">$2.00</Badge>
                </div>
                <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                  <span className="font-medium text-gray-700">Per Mile</span>
                  <Badge className="bg-purple-600 text-white">$0.50</Badge>
                </div>
              </div>
              <div className="mt-4 p-3 bg-gray-100 rounded-lg">
                <p className="text-sm text-gray-600">
                  <strong>Example:</strong> 5-mile delivery = $4 pickup + $2 drop + ($0.50 × 5) = $8.50
                </p>
              </div>
            </div>

            {/* Large Items */}
            <div className="bg-white p-6 rounded-lg border border-orange-200">
              <div className="flex items-center gap-2 mb-4">
                <Truck className="w-6 h-6 text-orange-600" />
                <h3 className="text-lg font-bold text-gray-800">Large Items</h3>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                  <span className="font-medium text-gray-700">Base Pay</span>
                  <Badge className="bg-orange-600 text-white">$40.00+</Badge>
                </div>
                <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                  <span className="font-medium text-gray-700">Additional Miles</span>
                  <Badge className="bg-red-600 text-white">$0.50/mile</Badge>
                </div>
              </div>
              <div className="mt-4 p-3 bg-gray-100 rounded-lg">
                <p className="text-sm text-gray-600">
                  <strong>Requirements:</strong> Heavy pickup, truck, or trailer required. Higher pay for specialized equipment.
                </p>
              </div>
            </div>
          </div>

          {/* Bonus Pay Section */}
          <div className="mt-6 bg-white p-6 rounded-lg border border-yellow-200">
            <div className="flex items-center gap-2 mb-4">
              <Zap className="w-6 h-6 text-yellow-600" />
              <h3 className="text-lg font-bold text-gray-800">Bonus Pay</h3>
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4 text-yellow-600" />
                <span className="font-medium text-gray-700">Urgent Delivery Bonus</span>
              </div>
              <p className="text-sm text-gray-600">Extra pay for rush orders and time-sensitive deliveries</p>
              <Badge className="mt-2 bg-yellow-600 text-white">Bonus Pay Available</Badge>
            </div>
          </div>

          <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
            <h4 className="font-bold text-green-800 mb-2">Why This Structure?</h4>
            <p className="text-sm text-green-700">
              Simple, transparent pay with no confusing multipliers. Drivers keep 100% of tips. 
              Separate pickup/drop-off fees ensure fair compensation for multi-stop deliveries. 
              $40+ for large items requiring heavy pickup, truck, or trailer. Bonus pay rewards urgent service.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DriverPayStructure;