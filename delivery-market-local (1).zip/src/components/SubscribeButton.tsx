import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Crown } from 'lucide-react';

export default function SubscribeButton() {
  const navigate = useNavigate();

  return (
    <Button 
      onClick={() => navigate('/marketpace-pro')}
      className="bg-gradient-to-r from-blue-600 to-lime-500 hover:from-blue-700 hover:to-lime-600 text-white font-semibold px-4 py-2 rounded-lg shadow-lg transition-all duration-200 hover:shadow-xl"
      size="sm"
    >
      <Crown className="h-4 w-4 mr-2" />
      Subscribe
    </Button>
  );
}