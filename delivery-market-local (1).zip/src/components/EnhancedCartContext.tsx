import React, { createContext, useContext, useState, ReactNode } from 'react';

interface CartItem {
  id: string;
  name: string;
  price: number;
  image: string;
  quantity: number;
  sellerId: string;
  sellerName: string;
  pickupAddress?: string;
}

interface DeliveryRoute {
  pickupLocations: Array<{
    sellerId: string;
    sellerName: string;
    address: string;
    items: CartItem[];
  }>;
  dropoffAddress: string;
  estimatedMiles: number;
  estimatedTime: number;
}

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => number;
  getDeliveryRoute: () => DeliveryRoute;
  openCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  deliveryAddress: string;
  setDeliveryAddress: (address: string) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

interface CartProviderProps {
  children: ReactNode;
}

export const CartProvider: React.FC<CartProviderProps> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState('');

  const addToCart = (item: CartItem) => {
    setCartItems(prev => {
      const existingItem = prev.find(cartItem => cartItem.id === item.id);
      if (existingItem) {
        return prev.map(cartItem => 
          cartItem.id === item.id 
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(id);
      return;
    }
    setCartItems(prev => 
      prev.map(item => 
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const getCartTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const getDeliveryRoute = (): DeliveryRoute => {
    // Group items by seller
    const sellerGroups = cartItems.reduce((groups, item) => {
      const sellerId = item.sellerId;
      if (!groups[sellerId]) {
        groups[sellerId] = {
          sellerId: item.sellerId,
          sellerName: item.sellerName,
          address: item.pickupAddress || 'Address not provided',
          items: []
        };
      }
      groups[sellerId].items.push(item);
      return groups;
    }, {} as Record<string, any>);

    const pickupLocations = Object.values(sellerGroups);
    
    // Estimate miles based on pickup locations (simplified)
    const baseMiles = 2; // Base delivery distance
    const milesPerPickup = 1.5; // Additional miles per pickup location
    const estimatedMiles = baseMiles + (pickupLocations.length * milesPerPickup);
    
    return {
      pickupLocations,
      dropoffAddress: deliveryAddress || 'Delivery address not set',
      estimatedMiles: Math.round(estimatedMiles * 10) / 10,
      estimatedTime: Math.ceil(estimatedMiles * 3) // ~3 minutes per mile estimate
    };
  };

  const openCart = () => {
    setIsCartOpen(true);
  };

  return (
    <CartContext.Provider value={{
      cartItems,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      getCartTotal,
      getDeliveryRoute,
      openCart,
      isCartOpen,
      setIsCartOpen,
      deliveryAddress,
      setDeliveryAddress
    }}>
      {children}
    </CartContext.Provider>
  );
};

export default CartProvider;