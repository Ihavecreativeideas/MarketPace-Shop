import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { User, Store, Wrench, Music } from 'lucide-react';

interface ProfileTypeSelectorProps {
  selectedTypes: string[];
  onTypeChange: (types: string[]) => void;
}

const ProfileTypeSelector: React.FC<ProfileTypeSelectorProps> = ({
  selectedTypes,
  onTypeChange
}) => {
  const profileTypes = [
    {
      id: 'regular',
      title: 'Regular Member (Buyer/Seller)',
      description: 'Browse, buy, and post casual listings. Make counter-offers and rate others.',
      icon: User,
      features: ['Browse & Buy', 'Post Listings', 'Counter-offers', 'Rate & Review']
    },
    {
      id: 'shop',
      title: 'Shop / Business',
      description: 'Sell products with inventory management and delivery options.',
      icon: Store,
      features: ['Product Inventory', 'Delivery Options', 'Counter-offers', 'Pro Upgrades']
    },
    {
      id: 'service',
      title: 'Service Provider',
      description: 'Offer services with booking, quotes, and direct messaging.',
      icon: Wrench,
      features: ['Service Booking', 'Quote Requests', 'Direct Messages', 'Portfolio']
    },
    {
      id: 'entertainment',
      title: 'Entertainment Industry',
      description: 'Musicians, DJs, comedians, and performers with media uploads.',
      icon: Music,
      features: ['Media Uploads', 'Event Booking', 'Direct Messages', 'Gig History']
    }
  ];

  const handleTypeToggle = (typeId: string) => {
    if (typeId === 'regular') return; // Regular is always selected
    
    const newTypes = selectedTypes.includes(typeId)
      ? selectedTypes.filter(t => t !== typeId)
      : [...selectedTypes, typeId];
    
    onTypeChange(newTypes);
  };

  return (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-white mb-2">
          What best describes your use for MarketPace?
        </h2>
        <p className="text-gray-300">
          Select one or more profile types. You can always add more later.
        </p>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2">
        {profileTypes.map((type) => {
          const Icon = type.icon;
          const isSelected = selectedTypes.includes(type.id);
          const isRegular = type.id === 'regular';
          
          return (
            <Card 
              key={type.id} 
              className={`cursor-pointer transition-all ${
                isSelected 
                  ? 'border-purple-500 bg-purple-500/10' 
                  : 'border-gray-700 hover:border-gray-600'
              } ${isRegular ? 'opacity-100' : ''}`}
              onClick={() => !isRegular && handleTypeToggle(type.id)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Icon className="h-6 w-6 text-purple-400" />
                    <CardTitle className="text-lg text-white">{type.title}</CardTitle>
                  </div>
                  <Checkbox 
                    checked={isSelected}
                    disabled={isRegular}
                    className="data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
                  />
                </div>
                <CardDescription className="text-gray-300">
                  {type.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {type.features.map((feature) => (
                    <span 
                      key={feature}
                      className="px-2 py-1 bg-gray-700 text-gray-300 text-xs rounded-md"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default ProfileTypeSelector;