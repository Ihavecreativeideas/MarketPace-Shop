import React from 'react';
import { Button } from '@/components/ui/button';
import { Share2, Users } from 'lucide-react';

export const FacebookInvite: React.FC = () => {
  const handleFacebookInvite = () => {
    if (window.FB) {
      window.FB.ui({
        method: 'send',
        link: 'https://marketpace.app/signup',
        quote: '🚀 Join me on MarketPace - the local marketplace that delivers! Buy, sell, rent anything in our community. You set the pace, we make it happen! 📦'
      });
    } else {
      // Fallback for when FB SDK is not loaded
      const shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent('https://marketpace.app/signup')}`;
      window.open(shareUrl, '_blank', 'width=600,height=400');
    }
  };

  const handleFacebookShare = () => {
    if (window.FB) {
      window.FB.ui({
        method: 'share',
        href: 'https://marketpace.app/signup',
        quote: '🚀 Discover MarketPace - Your local marketplace with delivery! Perfect for buying, selling, and renting in our community. #MarketPace #LocalBusiness'
      });
    } else {
      const shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent('https://marketpace.app/signup')}`;
      window.open(shareUrl, '_blank', 'width=600,height=400');
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-center mb-4">
        <h3 className="text-lg font-semibold text-white mb-2">📲 Invite Your Friends!</h3>
        <p className="text-sm text-gray-300">
          Grow your shop, services, or listings by inviting your Facebook friends. 
          MarketPace is built for your community—share the pace!
        </p>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-3">
        <Button
          onClick={handleFacebookInvite}
          className="bg-blue-600 hover:bg-blue-700 text-white flex-1"
        >
          <Users className="w-4 h-4 mr-2" />
          Invite Facebook Friends
        </Button>
        
        <Button
          onClick={handleFacebookShare}
          variant="outline"
          className="border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-white flex-1"
        >
          <Share2 className="w-4 h-4 mr-2" />
          Share on Facebook
        </Button>
      </div>
      
      <div className="text-xs text-gray-400 text-center">
        Help us reach more people in your community!
      </div>
    </div>
  );
};

// Initialize Facebook SDK
if (typeof window !== 'undefined' && !window.FB) {
  (function(d, s, id) {
    var js: any, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js";
    fjs.parentNode?.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));

  window.fbAsyncInit = function() {
    window.FB.init({
      appId: process.env.REACT_APP_FACEBOOK_APP_ID || 'your-app-id',
      cookie: true,
      xfbml: true,
      version: 'v18.0'
    });
  };
}