import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

interface SecurityIssue {
  id: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  category: string;
  description: string;
  recommendation: string;
  status: 'open' | 'resolved' | 'in-progress';
}

const SecurityAudit: React.FC = () => {
  const [issues, setIssues] = useState<SecurityIssue[]>([]);
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState({
    total: 0,
    critical: 0,
    high: 0,
    medium: 0,
    low: 0,
    resolved: 0
  });

  useEffect(() => {
    // Simulate security audit
    const mockIssues: SecurityIssue[] = [
      {
        id: '1',
        severity: 'critical',
        category: 'Authentication',
        description: 'Missing JWT validation in API endpoints',
        recommendation: 'Implement proper JWT validation middleware',
        status: 'open'
      },
      {
        id: '2',
        severity: 'high',
        category: 'Database Security',
        description: 'RLS policies need optimization',
        recommendation: 'Review and update RLS policies with proper syntax',
        status: 'in-progress'
      }
    ];
    
    setIssues(mockIssues);
    setSummary({
      total: mockIssues.length,
      critical: mockIssues.filter(i => i.severity === 'critical').length,
      high: mockIssues.filter(i => i.severity === 'high').length,
      medium: mockIssues.filter(i => i.severity === 'medium').length,
      low: mockIssues.filter(i => i.severity === 'low').length,
      resolved: mockIssues.filter(i => i.status === 'resolved').length
    });
    setLoading(false);
  }, []);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'resolved': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'in-progress': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      default: return <XCircle className="h-4 w-4 text-red-500" />;
    }
  };

  if (loading) {
    return <div className="p-4">Loading security audit...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-2">
        <Shield className="h-6 w-6" />
        <h1 className="text-2xl font-bold">Security Audit Dashboard</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{summary.total}</div>
            <div className="text-sm text-muted-foreground">Total Issues</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-red-500">{summary.critical}</div>
            <div className="text-sm text-muted-foreground">Critical</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-orange-500">{summary.high}</div>
            <div className="text-sm text-muted-foreground">High</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-yellow-500">{summary.medium}</div>
            <div className="text-sm text-muted-foreground">Medium</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-500">{summary.resolved}</div>
            <div className="text-sm text-muted-foreground">Resolved</div>
          </CardContent>
        </Card>
      </div>

      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          Security audit in progress. Please address critical and high severity issues immediately.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>Security Issues</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {issues.map((issue) => (
              <div key={issue.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Badge className={getSeverityColor(issue.severity)}>
                      {issue.severity.toUpperCase()}
                    </Badge>
                    <span className="font-medium">{issue.category}</span>
                    {getStatusIcon(issue.status)}
                  </div>
                </div>
                <p className="text-sm mb-2">{issue.description}</p>
                <p className="text-sm text-muted-foreground">
                  <strong>Recommendation:</strong> {issue.recommendation}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-2">
        <Button onClick={() => window.location.reload()}>
          Refresh Audit
        </Button>
        <Button variant="outline">
          Export Report
        </Button>
      </div>
    </div>
  );
};

export default SecurityAudit;