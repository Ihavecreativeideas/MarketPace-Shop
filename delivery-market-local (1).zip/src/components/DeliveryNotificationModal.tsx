import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, Package, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

interface DeliveryNotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemName: string;
  buyerAddress: string;
  sellerAddress: string;
  userType: 'buyer' | 'seller';
  onAccept?: () => void;
  onDecline?: () => void;
}

export const DeliveryNotificationModal = ({
  isOpen,
  onClose,
  itemName,
  buyerAddress,
  sellerAddress,
  userType,
  onAccept,
  onDecline
}: DeliveryNotificationModalProps) => {
  const [timeLeft, setTimeLeft] = useState(300);
  const [decision, setDecision] = useState<'pending' | 'accepted' | 'declined'>('pending');

  useEffect(() => {
    if (!isOpen || decision !== 'pending') return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setDecision('accepted');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, decision]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAccept = () => {
    setDecision('accepted');
    onAccept?.();
  };

  const handleDecline = () => {
    setDecision('declined');
    onDecline?.();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Item Delivered!
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="space-y-2">
                <p className="font-medium">{itemName}</p>
                <div className="text-sm text-gray-600">
                  <p>From: {sellerAddress}</p>
                  <p>To: {buyerAddress}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {userType === 'seller' && decision === 'pending' && (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-3">
                <Clock className="h-4 w-4 text-orange-600" />
                <span className="font-medium text-orange-800">
                  Time to decide: {formatTime(timeLeft)}
                </span>
              </div>
              <p className="text-sm text-orange-700 mb-4">
                The driver is waiting for your decision. You must accept or decline before the driver leaves.
              </p>
              <div className="flex gap-2">
                <Button 
                  onClick={handleAccept}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Accept Item
                </Button>
                <Button 
                  onClick={handleDecline}
                  variant="destructive"
                  className="flex-1"
                >
                  <XCircle className="h-4 w-4 mr-1" />
                  Decline & Return
                </Button>
              </div>
            </div>
          )}

          {userType === 'buyer' && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-700 mb-3">
                Your item has been delivered! The seller has 5 minutes to accept or decline the delivery.
              </p>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                Waiting for seller confirmation
              </Badge>
            </div>
          )}

          {decision === 'accepted' && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span className="font-medium text-green-800">Item Accepted!</span>
              </div>
              <p className="text-sm text-green-700">
                The delivery has been completed successfully. You can now rate and tip the driver.
              </p>
            </div>
          )}

          {decision === 'declined' && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <span className="font-medium text-red-800">Item Declined</span>
              </div>
              <p className="text-sm text-red-700 mb-2">
                The seller has declined the item. The driver will return it to the seller.
              </p>
              <p className="text-xs text-red-600">
                Note: Return delivery fees will be charged to the seller.
              </p>
            </div>
          )}

          <div className="flex gap-2">
            {decision !== 'pending' && (
              <Button onClick={onClose} className="flex-1">
                Close
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DeliveryNotificationModal;