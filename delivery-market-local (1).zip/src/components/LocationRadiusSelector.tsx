import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Search } from 'lucide-react';

interface LocationRadiusSelectorProps {
  onLocationChange: (location: string, radius: number) => void;
  defaultRadius?: number;
  showMembersFirst?: boolean;
}

const LocationRadiusSelector: React.FC<LocationRadiusSelectorProps> = ({
  onLocationChange,
  defaultRadius = 20,
  showMembersFirst = true
}) => {
  const [location, setLocation] = useState('');
  const [radius, setRadius] = useState(defaultRadius);
  const [isDetecting, setIsDetecting] = useState(false);

  const handleLocationDetection = () => {
    setIsDetecting(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
          onLocationChange(`${latitude}, ${longitude}`, radius);
          setIsDetecting(false);
        },
        () => {
          setIsDetecting(false);
          alert('Unable to detect location. Please enter manually.');
        }
      );
    }
  };

  const handleSearch = () => {
    if (location.trim()) {
      onLocationChange(location, radius);
    }
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5" />
          Location & Radius
        </CardTitle>
        {showMembersFirst && (
          <p className="text-sm text-muted-foreground">
            Showing members/subscribers within 20 miles first
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <div className="flex-1">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              placeholder="Enter city, address, or coordinates"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>
          <Button
            onClick={handleLocationDetection}
            disabled={isDetecting}
            variant="outline"
            className="mt-6"
          >
            {isDetecting ? 'Detecting...' : 'Use Current'}
          </Button>
        </div>
        
        <div className="flex gap-4 items-end">
          <div className="flex-1">
            <Label htmlFor="radius">Search Radius</Label>
            <Select value={radius.toString()} onValueChange={(value) => setRadius(parseInt(value))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5 miles</SelectItem>
                <SelectItem value="10">10 miles</SelectItem>
                <SelectItem value="20">20 miles</SelectItem>
                <SelectItem value="50">50 miles</SelectItem>
                <SelectItem value="100">100 miles</SelectItem>
                <SelectItem value="200">200 miles</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleSearch} className="flex items-center gap-2">
            <Search className="h-4 w-4" />
            Search
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default LocationRadiusSelector;