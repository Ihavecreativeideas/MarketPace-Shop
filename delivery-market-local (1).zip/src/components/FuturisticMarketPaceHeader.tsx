import React from 'react';
import TealSquareLogo from './TealSquareLogo';

const FuturisticMarketPaceHeader = () => {
  return (
    <div className="relative z-50 w-full">
      <div className="flex items-center justify-center py-4 px-6">
        <div className="flex items-center gap-3">
          {/* Floating Teal Square Logo */}
          <div className="relative">
            <div className="absolute inset-0 bg-teal-400 rounded-lg blur-md opacity-50 animate-pulse"></div>
            <TealSquareLogo 
              size={48} 
              className="relative transform hover:scale-110 transition-transform duration-300 animate-float"
            />
          </div>
          
          {/* MarketPace Text */}
          <div className="text-white">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              MarketPace
            </h1>
            <p className="text-xs text-gray-300 -mt-1">Delivery & Marketplace</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FuturisticMarketPaceHeader;