import React from 'react';
import { Card, CardContent } from './ui/card';
import { Users, Store, Music, Truck, Wrench, Target } from 'lucide-react';
import { cn } from '../lib/utils';

interface CompactTownMeterProps {
  townName: string;
  members: number;
  shops: number;
  entertainers: number;
  drivers: number;
  services: number;
  targetMembers: number;
  className?: string;
}

const CompactTownMeter: React.FC<CompactTownMeterProps> = ({
  townName,
  members,
  shops,
  entertainers,
  drivers,
  services,
  targetMembers,
  className
}) => {
  const progress = Math.min((members / targetMembers) * 100, 100);
  
  const stats = [
    { icon: Users, value: members, label: 'Members', color: 'text-blue-400' },
    { icon: Store, value: shops, label: 'Shops', color: 'text-green-400' },
    { icon: Music, value: entertainers, label: 'Artists', color: 'text-purple-400' },
    { icon: Truck, value: drivers, label: 'Drivers', color: 'text-orange-400' },
    { icon: Wrench, value: services, label: 'Services', color: 'text-pink-400' }
  ];

  return (
    <Card className={cn(
      "bg-slate-800/60 border-slate-600/40 backdrop-blur-sm",
      className
    )}>
      <CardContent className="p-4 space-y-4">
        <div className="text-center">
          <h2 className="text-lg font-bold text-white mb-1">{townName} Launch Progress</h2>
          <div className="flex items-center justify-center gap-2 text-sm text-slate-300">
            <Target className="h-4 w-4 text-teal-400" />
            <span>{members} / {targetMembers} members</span>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="bg-slate-700/50 rounded-full h-2 overflow-hidden">
            <div 
              className="bg-gradient-to-r from-teal-500 to-teal-400 h-full transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="text-center text-xs text-slate-400">
            {progress.toFixed(1)}% to launch
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-5 gap-2">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="text-center">
                <Icon className={cn("h-4 w-4 mx-auto mb-1", stat.color)} />
                <div className="text-xs font-semibold text-white">{stat.value}</div>
                <div className="text-xs text-slate-400">{stat.label}</div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default CompactTownMeter;