import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Heart, Plus, Search, Filter, Store, Truck } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { PaceMakersCard, PaceMakerBusiness } from './PaceMakersCard';
import { BusinessProfileModal } from './BusinessProfileModal';
import { CreateBusinessModal } from './CreateBusinessModal';
import BecomeDriverButton from './BecomeDriverButton';
import CommunitySection from './CommunitySection';

const businessCategories = [
  'All Categories',
  'Restaurant & Food',
  'Health & Wellness',
  'Beauty & Personal Care',
  'Home Services',
  'Professional Services',
  'Retail & Shopping',
  'Automotive',
  'Entertainment',
  'Education & Training',
  'Technology',
  'Other'
];

export const PaceMakers: React.FC = () => {
  const { toast } = useToast();
  const [businesses, setBusinesses] = useState<PaceMakerBusiness[]>([]);
  const [filteredBusinesses, setFilteredBusinesses] = useState<PaceMakerBusiness[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [showServiceOnly, setShowServiceOnly] = useState(false);
  const [selectedBusiness, setSelectedBusiness] = useState<PaceMakerBusiness | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);

  useEffect(() => {
    fetchBusinesses();
  }, []);

  useEffect(() => {
    filterBusinesses();
  }, [businesses, searchTerm, selectedCategory, showServiceOnly]);

  const fetchBusinesses = async () => {
    try {
      const { data, error } = await supabase
        .from('pacemakers_businesses')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setBusinesses(data || []);
    } catch (error) {
      console.error('Error fetching businesses:', error);
      toast({
        title: "Error",
        description: "Failed to load businesses. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const filterBusinesses = () => {
    let filtered = businesses;

    if (searchTerm) {
      filtered = filtered.filter(business => 
        business.business_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        business.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        business.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedCategory !== 'All Categories') {
      filtered = filtered.filter(business => business.category === selectedCategory);
    }

    if (showServiceOnly) {
      filtered = filtered.filter(business => business.is_service_business);
    }

    setFilteredBusinesses(filtered);
  };

  const handleViewDetails = (business: PaceMakerBusiness) => {
    setSelectedBusiness(business);
    setShowProfileModal(true);
  };

  const handleShareToFacebook = (business: PaceMakerBusiness) => {
    const shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${encodeURIComponent(`Check out ${business.business_name} - ${business.description}`)}`;
    window.open(shareUrl, '_blank', 'width=600,height=400');
  };

  const handleUpgradeToPartner = (businessId: string) => {
    toast({
      title: "Partner Upgrade",
      description: "Redirecting to partner subscription plans..."
    });
    window.location.href = '/partner-plans';
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading PaceMakers...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Top Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 mb-8 items-center justify-center">
        <Button 
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
          size="lg"
        >
          <Store className="h-5 w-5" />
          Add Your Business
        </Button>
        <Button 
          className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600"
          size="lg"
        >
          <Truck className="h-5 w-5" />
          Become a Driver
        </Button>
      </div>

      {/* Community Values Section - now includes unified header */}
      <CommunitySection />

      {/* Filters */}
      <Card className="mb-8">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search businesses..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {businessCategories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant={showServiceOnly ? "default" : "outline"}
              onClick={() => setShowServiceOnly(!showServiceOnly)}
              className="flex items-center gap-2"
            >
              <Filter className="h-4 w-4" />
              Services Only
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="mb-4">
        <p className="text-sm text-muted-foreground">
          Showing {filteredBusinesses.length} of {businesses.length} businesses
        </p>
      </div>

      {/* Business Grid */}
      {filteredBusinesses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBusinesses.map((business) => (
            <PaceMakersCard
              key={business.id}
              business={business}
              onViewDetails={handleViewDetails}
              onShareToFacebook={handleShareToFacebook}
            />
          ))})
        </div>
      ) : (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground mb-4">
              No businesses found matching your criteria.
            </p>
            <Button onClick={() => setShowCreateModal(true)}>
              Be the first to add your business!
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Modals */}
      <CreateBusinessModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onBusinessCreated={fetchBusinesses}
      />
      
      <BusinessProfileModal
        business={selectedBusiness}
        isOpen={showProfileModal}
        onClose={() => {
          setShowProfileModal(false);
          setSelectedBusiness(null);
        }}
        onUpgradeToPartner={handleUpgradeToPartner}
      />
    </div>
  );
};