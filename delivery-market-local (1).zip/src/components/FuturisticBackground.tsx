import React from 'react';
import { Cpu, Zap, Star } from 'lucide-react';

const FuturisticBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 -z-10">
      {/* Enhanced Futuristic Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-cyan-900 via-indigo-900 to-purple-900" />
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-cyan-500/5 to-purple-500/10" />
      
      {/* Animated Floating Particles */}
      <div className="absolute inset-0 overflow-hidden">
        {Array.from({ length: 50 }).map((_, i) => (
          <div
            key={i}
            className="absolute bg-cyan-400/60 rounded-full animate-float shadow-lg shadow-cyan-400/20"
            style={{
              width: `${3 + Math.random() * 10}px`,
              height: `${3 + Math.random() * 10}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 8}s`,
              animationDuration: `${4 + Math.random() * 6}s`
            }}
          />
        ))}
        {/* Glowing particles */}
        {Array.from({ length: 30 }).map((_, i) => (
          <div
            key={`glow-${i}`}
            className="absolute w-2 h-2 bg-purple-400/70 rounded-full animate-pulse shadow-lg shadow-purple-400/30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 4}s`,
              animationDuration: `${2 + Math.random() * 3}s`
            }}
          />
        ))}
      </div>
      
      {/* Floating Tech Icons */}
      <div className="absolute inset-0">
        <Cpu className="absolute top-20 right-20 w-24 h-24 text-cyan-400/20 animate-spin" style={{ animationDuration: '25s' }} />
        <Zap className="absolute bottom-32 left-16 w-16 h-16 text-purple-400/20 animate-pulse" />
        <Star className="absolute top-1/3 left-1/4 w-12 h-12 text-indigo-400/20 animate-bounce" style={{ animationDuration: '3s' }} />
      </div>
      
      {/* Enhanced Glow Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-500/15 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '3s' }} />
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-indigo-500/10 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '1.5s' }} />
      </div>
    </div>
  );
};

export default FuturisticBackground;