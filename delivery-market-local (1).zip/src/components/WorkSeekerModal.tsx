import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X, MessageCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface WorkSeekerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const WorkSeekerModal: React.FC<WorkSeekerModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    title: '',
    location: '',
    experience: '',
    availability: '',
    description: '',
    skills: [] as string[],
    phone: '',
    email: ''
  });
  const [newSkill, setNewSkill] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Submit work seeker post
      console.log('Submitting work seeker post:', formData);
      
      // Send instant message from MarketPace about driver opportunities
      await sendDriverRecruitmentMessage();
      
      // Reset form
      setFormData({
        name: '',
        title: '',
        location: '',
        experience: '',
        availability: '',
        description: '',
        skills: [],
        phone: '',
        email: ''
      });
      
      toast({
        title: "Work availability posted!",
        description: "You've received a message from MarketPace about driver opportunities.",
      });
      
      onClose();
    } catch (error) {
      console.error('Error posting work availability:', error);
      toast({
        title: "Error",
        description: "Failed to post work availability. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const sendDriverRecruitmentMessage = async () => {
    // Simulate sending instant message from MarketPace
    const message = {
      from: 'MarketPace',
      subject: 'Driver Opportunity Available!',
      content: `Hi ${formData.name}! We noticed you're looking for work. MarketPace is hiring drivers in your area with competitive pay and flexible schedules. Would you like to apply for our driver program? Click here to start your application.`,
      timestamp: new Date().toISOString(),
      hasDriverApplication: true
    };
    
    // In a real app, this would send to your messaging system
    console.log('Sending driver recruitment message:', message);
    
    // Show notification
    setTimeout(() => {
      toast({
        title: "New Message from MarketPace",
        description: "You have a driver opportunity waiting for you!",
        action: (
          <Button size="sm" onClick={() => window.open('/driver-application', '_blank')}>
            View Application
          </Button>
        ),
      });
    }, 2000);
  };

  const addSkill = () => {
    if (newSkill.trim() && !formData.skills.includes(newSkill.trim())) {
      setFormData(prev => ({
        ...prev,
        skills: [...prev.skills, newSkill.trim()]
      }));
      setNewSkill('');
    }
  };

  const removeSkill = (skill: string) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s !== skill)
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5" />
            Post Work Availability
          </DialogTitle>
          <p className="text-sm text-muted-foreground">
            Let employers know you're available for work. You'll receive instant notifications about opportunities!
          </p>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Your full name"
                required
              />
            </div>
            <div>
              <Label htmlFor="title">Professional Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="e.g. Experienced Driver, Handyman"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="location">Location *</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                placeholder="City, State"
                required
              />
            </div>
            <div>
              <Label htmlFor="availability">Availability *</Label>
              <Select value={formData.availability} onValueChange={(value) => setFormData(prev => ({ ...prev, availability: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="When are you available?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="full-time">Full-time (40+ hours/week)</SelectItem>
                  <SelectItem value="part-time">Part-time (20-39 hours/week)</SelectItem>
                  <SelectItem value="evenings">Evenings only</SelectItem>
                  <SelectItem value="weekends">Weekends only</SelectItem>
                  <SelectItem value="flexible">Flexible schedule</SelectItem>
                  <SelectItem value="immediate">Available immediately</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                placeholder="(555) 123-4567"
              />
            </div>
            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                placeholder="your.email@example.com"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="experience">Experience Summary *</Label>
            <Input
              id="experience"
              value={formData.experience}
              onChange={(e) => setFormData(prev => ({ ...prev, experience: e.target.value }))}
              placeholder="e.g. 5 years delivery experience, 3 years construction"
              required
            />
          </div>

          <div>
            <Label htmlFor="description">About You</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Tell employers about your work ethic, strengths, and what type of work you're seeking..."
              rows={3}
            />
          </div>

          <div>
            <Label>Skills & Qualifications</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                placeholder="Add a skill or qualification"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
              />
              <Button type="button" onClick={addSkill} variant="outline">
                Add
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.skills.map((skill, index) => (
                <Badge key={index} variant="secondary" className="flex items-center gap-1">
                  {skill}
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => removeSkill(skill)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <MessageCircle className="h-4 w-4 text-blue-600" />
              <span className="font-medium text-blue-800">Instant Opportunities</span>
            </div>
            <p className="text-sm text-blue-700">
              When you post your work availability, you'll automatically receive a message from MarketPace 
              about driver opportunities in your area with competitive pay and flexible schedules!
            </p>
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="submit" disabled={isSubmitting} className="flex-1">
              {isSubmitting ? 'Posting...' : 'Post Availability'}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default WorkSeekerModal;