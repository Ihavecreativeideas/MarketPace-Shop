import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Badge } from '@/components/ui/badge';
import { UniversalBackButton } from './UniversalBackButton';
import { Calendar as CalendarIcon, MapPin, User, Package } from 'lucide-react';

interface RentalItem {
  id: string;
  title: string;
  price: number;
  image?: string;
  owner_name: string;
  location: string;
  status: 'available' | 'rented' | 'unavailable';
  description: string;
}

interface RentalRequestPageProps {
  item: RentalItem;
  onBack: () => void;
  onRequestSent: () => void;
}

const RentalRequestPage: React.FC<RentalRequestPageProps> = ({
  item,
  onBack,
  onRequestSent
}) => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [deliveryTime, setDeliveryTime] = useState('');
  const [returnDate, setReturnDate] = useState<Date | undefined>(undefined);
  const [returnTime, setReturnTime] = useState('');
  const [rentalPurpose, setRentalPurpose] = useState('');
  const [contactInfo, setContactInfo] = useState({
    name: '',
    phone: '',
    email: ''
  });

  const deliveryTimeSlots = [
    { value: '9am', label: '9:00 AM' },
    { value: '12pm', label: '12:00 PM' },
    { value: '3pm', label: '3:00 PM' },
    { value: '6pm', label: '6:00 PM' },
    { value: '9pm', label: '9:00 PM' }
  ];

  const calculateRentalDays = () => {
    if (!selectedDate || !returnDate) return 0;
    const timeDiff = returnDate.getTime() - selectedDate.getTime();
    return Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;
  };

  const calculateTotalCost = () => {
    const days = calculateRentalDays();
    return days * item.price;
  };

  const handleSendRequest = () => {
    if (!selectedDate || !deliveryTime) {
      alert('Please select delivery date and time');
      return;
    }
    
    if (!returnDate || !returnTime) {
      alert('Please select return date and time');
      return;
    }
    
    if (!rentalPurpose.trim()) {
      alert('Please describe the purpose of rental');
      return;
    }
    
    if (!contactInfo.name || !contactInfo.phone || !contactInfo.email) {
      alert('Please provide complete contact information');
      return;
    }
    
    onRequestSent();
  };

  const isDateAvailable = (date: Date) => {
    const today = new Date();
    return date >= today && item.status === 'available';
  };

  const getStatusBadge = () => {
    switch (item.status) {
      case 'available':
        return <Badge className="bg-green-500/20 text-green-300">Available</Badge>;
      case 'rented':
        return <Badge className="bg-orange-500/20 text-orange-300">Currently Rented</Badge>;
      case 'unavailable':
        return <Badge className="bg-red-500/20 text-red-300">Unavailable</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-indigo-900 to-purple-900 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6">
          <UniversalBackButton customAction={onBack} />
          <h1 className="text-3xl font-bold text-white mt-4">Request Rental</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Package className="w-5 h-5" />
                  Rental Item
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4">
                  <div className="w-20 h-20 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    {item.image ? (
                      <img src={item.image} alt={item.title} className="w-full h-full object-cover rounded-lg" />
                    ) : (
                      <Package className="w-8 h-8 text-white" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-white font-semibold text-lg truncate">{item.title}</h3>
                    <p className="text-gray-300 text-sm truncate">{item.description}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <User className="w-3 h-3 text-gray-400" />
                      <span className="text-gray-300 text-sm truncate">{item.owner_name}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <MapPin className="w-3 h-3 text-gray-400" />
                      <span className="text-gray-300 text-sm truncate">{item.location}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-green-400 font-bold text-xl">${item.price}/day</span>
                      {getStatusBadge()}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <CalendarIcon className="w-5 h-5" />
                  Rental Period
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white mb-2 block">Delivery Date</Label>
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      disabled={(date) => !isDateAvailable(date)}
                      className="bg-white/5 rounded-lg border border-white/20"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-white mb-2 block">Return Date</Label>
                    <Calendar
                      mode="single"
                      selected={returnDate}
                      onSelect={setReturnDate}
                      disabled={(date) => !selectedDate || date <= selectedDate}
                      className="bg-white/5 rounded-lg border border-white/20"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white">Delivery Time</Label>
                    <Select value={deliveryTime} onValueChange={setDeliveryTime}>
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue placeholder="Select time" />
                      </SelectTrigger>
                      <SelectContent>
                        {deliveryTimeSlots.map(slot => (
                          <SelectItem key={slot.value} value={slot.value}>
                            {slot.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label className="text-white">Return Time</Label>
                    <Select value={returnTime} onValueChange={setReturnTime}>
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue placeholder="Select time" />
                      </SelectTrigger>
                      <SelectContent>
                        {deliveryTimeSlots.map(slot => (
                          <SelectItem key={slot.value} value={slot.value}>
                            {slot.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white">Rental Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="purpose" className="text-white">Purpose of Rental *</Label>
                  <Textarea
                    id="purpose"
                    value={rentalPurpose}
                    onChange={(e) => setRentalPurpose(e.target.value)}
                    className="bg-white/10 border-white/20 text-white mt-2"
                    placeholder="Please describe what you need this item for..."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="name" className="text-white">Full Name *</Label>
                  <Input
                    id="name"
                    value={contactInfo.name}
                    onChange={(e) => setContactInfo(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-white/10 border-white/20 text-white"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="phone" className="text-white">Phone Number *</Label>
                    <Input
                      id="phone"
                      value={contactInfo.phone}
                      onChange={(e) => setContactInfo(prev => ({ ...prev, phone: e.target.value }))}
                      className="bg-white/10 border-white/20 text-white"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email" className="text-white">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={contactInfo.email}
                      onChange={(e) => setContactInfo(prev => ({ ...prev, email: e.target.value }))}
                      className="bg-white/10 border-white/20 text-white"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white">Rental Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {calculateRentalDays() > 0 && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-gray-300">
                      <span>Daily Rate:</span>
                      <span>${item.price.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-gray-300">
                      <span>Duration:</span>
                      <span>{calculateRentalDays()} day{calculateRentalDays() > 1 ? 's' : ''}</span>
                    </div>
                    <div className="flex justify-between text-white font-semibold text-lg">
                      <span>Total:</span>
                      <span>${calculateTotalCost().toFixed(2)}</span>
                    </div>
                  </div>
                )}
                
                <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-3">
                  <p className="text-blue-300 text-sm">
                    💡 This is a rental request. The owner will review and respond.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleSendRequest}
              disabled={item.status !== 'available'}
              className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white py-3 text-lg font-semibold disabled:opacity-50"
            >
              Send Rental Request
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RentalRequestPage;
export { RentalRequestPage };