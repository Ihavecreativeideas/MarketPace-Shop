import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Star, Quote } from 'lucide-react';

interface Testimonial {
  name: string;
  business: string;
  tier: string;
  rating: number;
  quote: string;
  avatar?: string;
}

const testimonials: Testimonial[] = [
  {
    name: "Sarah Johnson",
    business: "Johnson's Bakery",
    tier: "Gold Partner",
    rating: 5,
    quote: "MarketPace has transformed our delivery game! The zero fees and direct driver payments have saved us hundreds monthly. Our customers love the convenience!"
  },
  {
    name: "Mike Rodriguez",
    business: "Mike's Auto Parts",
    tier: "Silver Partner",
    rating: 5,
    quote: "Being featured on the Partners Page brought us so many new customers. The QR code stickers work amazingly - people scan them right from our window!"
  },
  {
    name: "Lisa Chen",
    business: "Chen's Flower Shop",
    tier: "Bronze Partner",
    rating: 5,
    quote: "The partnership investment paid for itself in the first month. No delivery fees means we can offer better prices to our customers."
  }
];

export default function SponsorshipTestimonials() {
  return (
    <div className="py-12 bg-gradient-to-r from-purple-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            What Our Partners Say
          </h2>
          <p className="text-lg text-gray-600">
            Real stories from local businesses thriving with MarketPace
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="relative bg-white hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <Quote className="w-8 h-8 text-purple-300 mb-4" />
                
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                  ))}
                </div>
                
                <p className="text-gray-700 mb-6 italic leading-relaxed">
                  "{testimonial.quote}"
                </p>
                
                <div className="flex items-center gap-3">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={testimonial.avatar} />
                    <AvatarFallback className="bg-purple-100 text-purple-600">
                      {testimonial.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.business}</p>
                    <p className="text-xs text-purple-600 font-medium">{testimonial.tier}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}