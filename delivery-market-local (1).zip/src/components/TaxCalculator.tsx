interface TaxCalculation {
  productSubtotal: number;
  deliveryFee: number;
  serviceFee: number;
  taxableAmount: number;
  taxCollected: number;
  checkoutTotal: number;
}

export const calculateTax = (
  productSubtotal: number,
  deliveryFee: number,
  serviceFee: number,
  tipAmount: number = 0,
  taxRate: number = 0.0925
): TaxCalculation => {
  // Only delivery and service fees are taxable by MarketPace
  const taxableAmount = deliveryFee + serviceFee;
  const taxCollected = taxableAmount * taxRate;
  
  // Product subtotal is not taxed by MarketPace (vendor responsibility)
  // Tips are not taxed
  const checkoutTotal = productSubtotal + deliveryFee + serviceFee + taxCollected + tipAmount;
  
  return {
    productSubtotal,
    deliveryFee,
    serviceFee,
    taxableAmount,
    taxCollected,
    checkoutTotal
  };
};

export const formatTaxBredown = (calculation: TaxCalculation) => {
  return {
    'Product Subtotal (Non-taxable)': `$${calculation.productSubtotal.toFixed(2)}`,
    'Delivery Fee (Taxable)': `$${calculation.deliveryFee.toFixed(2)}`,
    'Service Fee (Taxable)': `$${calculation.serviceFee.toFixed(2)}`,
    'Sales Tax (on fees only)': `$${calculation.taxCollected.toFixed(2)}`,
    'Total Amount': `$${calculation.checkoutTotal.toFixed(2)}`
  };
};