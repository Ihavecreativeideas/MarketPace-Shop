import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Check } from 'lucide-react';

interface AddToCartButtonProps {
  itemId: string;
  itemName: string;
  price: number;
  seller: string;
  isGuest?: boolean;
  onAuthRequired?: () => void;
}

const AddToCartButton: React.FC<AddToCartButtonProps> = ({ 
  itemId, 
  itemName, 
  price, 
  seller,
  isGuest = false,
  onAuthRequired
}) => {
  const [isAdded, setIsAdded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleAddToCart = async () => {
    if (isGuest) {
      onAuthRequired?.();
      return;
    }

    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      console.log('Added to cart:', {
        itemId,
        itemName,
        price,
        seller
      });
      setIsAdded(true);
      setIsLoading(false);
      
      // Reset after 2 seconds
      setTimeout(() => setIsAdded(false), 2000);
    }, 500);
  };

  if (isAdded) {
    return (
      <Button 
        disabled
        className="bg-green-500 hover:bg-green-500 text-white"
      >
        <Check className="h-4 w-4 mr-2" />
        Added!
      </Button>
    );
  }

  return (
    <Button 
      onClick={handleAddToCart}
      disabled={isLoading}
      className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
    >
      <ShoppingCart className="h-4 w-4 mr-2" />
      {isLoading ? 'Adding...' : 'Add to Cart'}
    </Button>
  );
};

export { AddToCartButton };
export default AddToCartButton;