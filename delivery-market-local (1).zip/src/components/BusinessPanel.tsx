import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Store, MapPin, Phone, Star, DollarSign, Package, Search, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Business {
  id: string;
  name: string;
  email: string;
  phone: string;
  status: 'active' | 'pending' | 'suspended';
  rating: number;
  totalOrders: number;
  revenue: number;
  category: string;
  location: string;
  joinDate: string;
  subscriptionPlan: string;
}

export default function BusinessPanel() {
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBusinesses();
  }, []);

  const loadBusinesses = async () => {
    try {
      const { data, error } = await supabase
        .from('business_profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Mock additional data for demo
      const mockBusinesses: Business[] = [
        {
          id: '1',
          name: 'Pizza Palace',
          email: 'info@pizzapalace.com',
          phone: '(555) 123-4567',
          status: 'active',
          rating: 4.7,
          totalOrders: 1245,
          revenue: 15420,
          category: 'Restaurant',
          location: 'Downtown',
          joinDate: '2024-01-15',
          subscriptionPlan: 'Pro'
        },
        {
          id: '2',
          name: 'Fresh Grocers',
          email: 'contact@freshgrocers.com',
          phone: '(555) 987-6543',
          status: 'active',
          rating: 4.5,
          totalOrders: 892,
          revenue: 12890,
          category: 'Grocery',
          location: 'Midtown',
          joinDate: '2024-02-20',
          subscriptionPlan: 'Basic'
        },
        {
          id: '3',
          name: 'Tech Repair Shop',
          email: 'hello@techrepair.com',
          phone: '(555) 456-7890',
          status: 'pending',
          rating: 4.9,
          totalOrders: 156,
          revenue: 8340,
          category: 'Electronics',
          location: 'Uptown',
          joinDate: '2024-03-10',
          subscriptionPlan: 'Premium'
        },
        {
          id: '4',
          name: 'Flower Garden',
          email: 'orders@flowergarden.com',
          phone: '(555) 321-0987',
          status: 'suspended',
          rating: 4.2,
          totalOrders: 67,
          revenue: 2340,
          category: 'Retail',
          location: 'Suburbs',
          joinDate: '2024-04-05',
          subscriptionPlan: 'Basic'
        }
      ];

      setBusinesses(mockBusinesses);
    } catch (error) {
      console.error('Error loading businesses:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: Business['status']) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'suspended': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case 'Basic': return 'bg-blue-100 text-blue-800';
      case 'Pro': return 'bg-purple-100 text-purple-800';
      case 'Premium': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredBusinesses = businesses.filter(business =>
    business.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    business.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    business.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    business.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const activeBusinesses = businesses.filter(b => b.status === 'active').length;
  const pendingBusinesses = businesses.filter(b => b.status === 'pending').length;
  const totalRevenue = businesses.reduce((sum, b) => sum + b.revenue, 0);
  const avgRating = businesses.reduce((sum, b) => sum + b.rating, 0) / businesses.length;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
        <div className="text-center">Loading businesses...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Business Management</h1>
          <p className="text-gray-600">Manage and monitor your business partners</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-green-600">{activeBusinesses}</div>
                  <div className="text-sm text-muted-foreground">Active Businesses</div>
                </div>
                <Store className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-yellow-600">{pendingBusinesses}</div>
                  <div className="text-sm text-muted-foreground">Pending Approval</div>
                </div>
                <Package className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-blue-600">${totalRevenue.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Total Revenue</div>
                </div>
                <DollarSign className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-purple-600">{avgRating.toFixed(1)}</div>
                  <div className="text-sm text-muted-foreground">Avg Rating</div>
                </div>
                <Star className="h-8 w-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search businesses by name, email, category, or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Businesses List */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredBusinesses.map((business) => (
            <Card key={business.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{business.name}</CardTitle>
                  <Badge className={getStatusColor(business.status)}>
                    {business.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="h-4 w-4" />
                  {business.phone}
                </div>
                
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  {business.location}
                </div>
                
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Store className="h-4 w-4" />
                  {business.category}
                </div>
                
                <div className="flex items-center justify-between pt-2">
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 text-yellow-500 fill-current" />
                    <span className="text-sm font-medium">{business.rating}</span>
                  </div>
                  <Badge className={getPlanColor(business.subscriptionPlan)}>
                    {business.subscriptionPlan}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between pt-2">
                  <div className="text-sm text-muted-foreground">
                    {business.totalOrders} orders
                  </div>
                  <div className="text-sm font-medium text-green-600">
                    ${business.revenue.toLocaleString()}
                  </div>
                </div>
                
                <div className="text-xs text-muted-foreground">
                  Joined {new Date(business.joinDate).toLocaleDateString()}
                </div>
                
                <div className="flex gap-2 pt-2">
                  <Button size="sm" variant="outline" className="flex-1">
                    View Details
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1">
                    Contact
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredBusinesses.length === 0 && (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No businesses found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
}