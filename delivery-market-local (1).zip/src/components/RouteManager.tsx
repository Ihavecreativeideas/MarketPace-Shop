import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Truck, Package, ArrowRight, AlertCircle } from 'lucide-react';

interface DeliveryStop {
  id: string;
  type: 'pickup' | 'dropoff' | 'return';
  address: string;
  itemName: string;
  orderId: string;
  distance?: number;
}

interface Route {
  id: string;
  stops: DeliveryStop[];
  totalDistance: number;
  earnings: number;
}

interface RouteManagerProps {
  routes: Route[];
  onRouteUpdate: (routes: Route[]) => void;
  maxPickupsPerRoute?: number;
}

const RouteManager: React.FC<RouteManagerProps> = ({ 
  routes, 
  onRouteUpdate, 
  maxPickupsPerRoute = 5 
}) => {
  const [optimizedRoutes, setOptimizedRoutes] = useState<Route[]>(routes);

  useEffect(() => {
    // Auto-optimize routes when they exceed pickup limits
    const optimized = optimizeRoutes(routes, maxPickupsPerRoute);
    setOptimizedRoutes(optimized);
    if (JSON.stringify(optimized) !== JSON.stringify(routes)) {
      onRouteUpdate(optimized);
    }
  }, [routes, maxPickupsPerRoute, onRouteUpdate]);

  const optimizeRoutes = (inputRoutes: Route[], maxPickups: number): Route[] => {
    const result: Route[] = [];
    
    inputRoutes.forEach(route => {
      const pickupStops = route.stops.filter(stop => stop.type === 'pickup');
      
      if (pickupStops.length <= maxPickups) {
        result.push(route);
      } else {
        // Split route into multiple routes
        const chunks = chunkArray(route.stops, maxPickups);
        chunks.forEach((chunk, index) => {
          const newRoute: Route = {
            id: `${route.id}-${index + 1}`,
            stops: chunk,
            totalDistance: calculateRouteDistance(chunk),
            earnings: calculateRouteEarnings(chunk)
          };
          result.push(newRoute);
        });
      }
    });
    
    return result;
  };

  const chunkArray = (array: DeliveryStop[], size: number): DeliveryStop[][] => {
    const chunks: DeliveryStop[][] = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  };

  const calculateRouteDistance = (stops: DeliveryStop[]): number => {
    return stops.reduce((total, stop) => total + (stop.distance || 0), 0);
  };

  const calculateRouteEarnings = (stops: DeliveryStop[]): number => {
    let earnings = 0;
    stops.forEach(stop => {
      if (stop.type === 'return') {
        earnings += 2 + ((stop.distance || 0) * 0.75); // Return earnings
      } else {
        earnings += 3 + ((stop.distance || 0) * 0.5); // Regular delivery
      }
    });
    return earnings;
  };

  const mergeRoutes = (routeIds: string[]) => {
    const routesToMerge = optimizedRoutes.filter(r => routeIds.includes(r.id));
    const otherRoutes = optimizedRoutes.filter(r => !routeIds.includes(r.id));
    
    if (routesToMerge.length < 2) return;
    
    const allStops = routesToMerge.flatMap(r => r.stops);
    const pickupCount = allStops.filter(s => s.type === 'pickup').length;
    
    if (pickupCount > maxPickupsPerRoute) {
      alert(`Cannot merge: Would exceed maximum of ${maxPickupsPerRoute} pickups per route`);
      return;
    }
    
    const mergedRoute: Route = {
      id: `merged-${Date.now()}`,
      stops: allStops,
      totalDistance: calculateRouteDistance(allStops),
      earnings: calculateRouteEarnings(allStops)
    };
    
    const newRoutes = [...otherRoutes, mergedRoute];
    setOptimizedRoutes(newRoutes);
    onRouteUpdate(newRoutes);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Truck className="w-5 h-5" />
          Delivery Routes
        </h3>
        <Badge variant="outline">
          Max {maxPickupsPerRoute} pickups per route
        </Badge>
      </div>
      
      {optimizedRoutes.map((route) => {
        const pickupCount = route.stops.filter(s => s.type === 'pickup').length;
        const returnCount = route.stops.filter(s => s.type === 'return').length;
        
        return (
          <Card key={route.id} className="w-full">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle className="text-base">Route {route.id}</CardTitle>
                <div className="flex gap-2">
                  <Badge className="bg-blue-100 text-blue-800">
                    ${route.earnings.toFixed(2)}
                  </Badge>
                  <Badge variant="outline">
                    {route.totalDistance.toFixed(1)} mi
                  </Badge>
                </div>
              </div>
              <div className="flex gap-2">
                <Badge className="bg-green-100 text-green-800">
                  {pickupCount} pickups
                </Badge>
                {returnCount > 0 && (
                  <Badge className="bg-orange-100 text-orange-800">
                    {returnCount} returns
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {route.stops.map((stop, index) => (
                  <div key={`${stop.id}-${index}`} className="flex items-center gap-3 p-2 bg-gray-50 rounded">
                    {stop.type === 'pickup' && <Package className="w-4 h-4 text-blue-600" />}
                    {stop.type === 'dropoff' && <MapPin className="w-4 h-4 text-green-600" />}
                    {stop.type === 'return' && <ArrowRight className="w-4 h-4 text-orange-600" />}
                    <div className="flex-1">
                      <div className="text-sm font-medium">{stop.itemName}</div>
                      <div className="text-xs text-gray-500">{stop.address}</div>
                    </div>
                    <Badge 
                      className={`text-xs ${
                        stop.type === 'pickup' ? 'bg-blue-100 text-blue-800' :
                        stop.type === 'return' ? 'bg-orange-100 text-orange-800' :
                        'bg-green-100 text-green-800'
                      }`}
                    >
                      {stop.type}
                    </Badge>
                  </div>
                ))}
              </div>
              
              {pickupCount > maxPickupsPerRoute && (
                <div className="mt-3 p-2 bg-red-50 rounded flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-600" />
                  <span className="text-sm text-red-800">
                    Route exceeds maximum pickup limit and will be split automatically
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
      
      {optimizedRoutes.length > 1 && (
        <Card>
          <CardContent className="pt-6">
            <Button 
              onClick={() => mergeRoutes(optimizedRoutes.map(r => r.id))}
              className="w-full"
              variant="outline"
            >
              Merge All Routes (if under pickup limit)
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default RouteManager;