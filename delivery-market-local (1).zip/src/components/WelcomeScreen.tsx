import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Car } from 'lucide-react';
import TownLaunchMeter from './TownLaunchMeter';
import FloatingIcon from './FloatingIcon';
import MultiAuthSignupWithOnboarding from './MultiAuthSignupWithOnboarding';
import DriverApplicationPage from './DriverApplicationPage';

interface WelcomeScreenProps {
  onSignIn: (email: string, password: string) => Promise<void>;
  onSignUp: (email: string, password: string) => Promise<void>;
  onGuestAccess: () => void;
  onComplete?: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onSignIn,
  onSignUp,
  onGuestAccess,
  onComplete
}) => {
  const [showSignup, setShowSignup] = useState(false);
  const [showDriverApp, setShowDriverApp] = useState(false);

  if (showDriverApp) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <DriverApplicationPage onClose={() => setShowDriverApp(false)} />
      </div>
    );
  }

  if (showSignup) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <MultiAuthSignupWithOnboarding 
          onClose={() => setShowSignup(false)}
          onComplete={() => {
            setShowSignup(false);
            onComplete?.();
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden pb-20 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <FloatingIcon />
      
      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 3}s`
            }}
          />
        ))}
      </div>

      {/* Town Launch Meter */}
      <div className="w-full max-w-md mb-6 px-4">
        <TownLaunchMeter 
          townName="Your Town"
          members={247}
          shops={18}
          entertainers={12}
          drivers={31}
          services={9}
          targetMembers={1000}
          totalTowns={12}
        />
      </div>

      <Card className="w-full max-w-md shadow-2xl bg-black/40 backdrop-blur-lg border-purple-500/30">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-white mb-2">
            Welcome to MarketPace
          </CardTitle>
          <CardDescription className="text-gray-300 mb-4">
            Join your town's launch campaign!
          </CardDescription>
          
          <div className="bg-slate-800/50 rounded-lg p-4 border border-cyan-500/30">
            <h3 className="font-bold text-cyan-400 mb-2">Early Member Benefits:</h3>
            <ul className="text-sm text-cyan-200 space-y-1 text-left">
              <li>• No upcharge - just pay the driver</li>
              <li>• Lifetime benefits for early members</li>
              <li>• Test MarketPace Pro features free</li>
              <li>• Web integration for shops & services</li>
            </ul>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-gray-600" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-black/40 px-3 text-gray-400">Get Started</span>
            </div>
          </div>

          <div className="space-y-3">
            <Button 
              onClick={() => setShowSignup(true)}
              className="w-full bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-white text-lg py-3"
            >
              Join Campaign
            </Button>
            
            <Button 
              onClick={() => setShowDriverApp(true)}
              className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white text-lg py-3"
            >
              <Car className="w-5 h-5 mr-2" />
              Driver Application
            </Button>
          </div>

          <div className="text-center">
            <p className="text-xs text-gray-400">
              By joining, you agree to our Terms of Service and Privacy Policy
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};