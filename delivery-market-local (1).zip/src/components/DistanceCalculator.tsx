import React from 'react';
import { MapPin } from 'lucide-react';

interface DistanceCalculatorProps {
  itemLocation?: string;
}

const DistanceCalculator: React.FC<DistanceCalculatorProps> = ({ itemLocation }) => {
  // Mock distance calculation - in real app would use geolocation API
  const calculateDistance = () => {
    return Math.floor(Math.random() * 15) + 1; // Random 1-15 miles
  };

  const distance = calculateDistance();

  return (
    <div className="flex items-center gap-1 text-gray-400 text-sm">
      <MapPin className="h-3 w-3" />
      <span>{distance} miles away</span>
    </div>
  );
};

export { DistanceCalculator };
export default DistanceCalculator;