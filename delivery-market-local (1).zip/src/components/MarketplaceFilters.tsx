import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

interface FilterState {
  priceRange: [number, number];
  sortBy: string;
  deliveryType: string;
  platform: string;
  usaMadeOnly: boolean;
}

interface MarketplaceFiltersProps {
  filters: FilterState;
  onFiltersChange: (filters: Partial<FilterState>) => void;
  onClearFilters: () => void;
}

const MarketplaceFilters: React.FC<MarketplaceFiltersProps> = ({
  filters,
  onFiltersChange,
  onClearFilters
}) => {
  return (
    <Card>
      <CardContent className="p-4 space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="font-medium text-gray-900 dark:text-gray-100">Filters</h3>
          <Button variant="ghost" size="sm" onClick={onClearFilters}>
            <X className="h-4 w-4 mr-1" />
            Clear
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label className="text-sm font-medium mb-2 block text-gray-900 dark:text-gray-100">Price Range</label>
            <Slider
              value={filters.priceRange}
              onValueChange={(value) => onFiltersChange({ priceRange: value as [number, number] })}
              max={500}
              step={10}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400 mt-1">
              <span>${filters.priceRange[0]}</span>
              <span>${filters.priceRange[1]}</span>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block text-gray-900 dark:text-gray-100">Platform</label>
            <Select value={filters.platform} onValueChange={(value) => onFiltersChange({ platform: value })}>
              <SelectTrigger className="bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100">
                <SelectValue placeholder="All platforms" />
              </SelectTrigger>
              <SelectContent className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
                <SelectItem value="all" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">All platforms</SelectItem>
                <SelectItem value="local" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Local</SelectItem>
                <SelectItem value="etsy" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Etsy</SelectItem>
                <SelectItem value="tiktok" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">TikTok</SelectItem>
                <SelectItem value="other" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block text-gray-900 dark:text-gray-100">Delivery</label>
            <Select value={filters.deliveryType} onValueChange={(value) => onFiltersChange({ deliveryType: value })}>
              <SelectTrigger className="bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100">
                <SelectValue placeholder="All delivery" />
              </SelectTrigger>
              <SelectContent className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
                <SelectItem value="all" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">All delivery</SelectItem>
                <SelectItem value="local" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Local delivery</SelectItem>
                <SelectItem value="extended" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Extended delivery</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block text-gray-900 dark:text-gray-100">Sort By</label>
            <Select value={filters.sortBy} onValueChange={(value) => onFiltersChange({ sortBy: value })}>
              <SelectTrigger className="bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700">
                <SelectItem value="relevance" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Relevance</SelectItem>
                <SelectItem value="price-low" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Price: Low to High</SelectItem>
                <SelectItem value="price-high" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Price: High to Low</SelectItem>
                <SelectItem value="rating" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Highest Rated</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block text-gray-900 dark:text-gray-100">USA Made</label>
            <div className="flex items-center space-x-2 mt-3">
              <Checkbox
                id="usa-made"
                checked={filters.usaMadeOnly}
                onCheckedChange={(checked) => onFiltersChange({ usaMadeOnly: !!checked })}
              />
              <label htmlFor="usa-made" className="text-sm text-gray-900 dark:text-gray-100">
                USA Made Only
              </label>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default MarketplaceFilters;