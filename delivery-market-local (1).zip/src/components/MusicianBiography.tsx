import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Calendar, Music, Star } from 'lucide-react';

interface Venue {
  id: number;
  name: string;
  location: string;
  date: string;
  type: string;
}

interface MusicianBiographyProps {
  musician: {
    id: number;
    name: string;
    bio: string;
    genres: string[];
    venues: Venue[];
    rating: number;
    totalGigs: number;
  };
}

const MusicianBiography: React.FC<MusicianBiographyProps> = ({ musician }) => {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Music className="w-5 h-5" />
            Biography
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 leading-relaxed">{musician.bio}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            {musician.genres.map((genre) => (
              <Badge key={genre} variant="secondary">{genre}</Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Performance History
          </CardTitle>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <span className="flex items-center gap-1">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              {musician.rating}/5
            </span>
            <span>{musician.totalGigs} total gigs</span>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {musician.venues.map((venue) => (
              <div key={venue.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <h4 className="font-medium">{venue.name}</h4>
                  <p className="text-sm text-gray-600">{venue.location}</p>
                </div>
                <div className="text-right">
                  <Badge variant="outline" className="mb-1">{venue.type}</Badge>
                  <p className="text-sm text-gray-500">{venue.date}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MusicianBiography;