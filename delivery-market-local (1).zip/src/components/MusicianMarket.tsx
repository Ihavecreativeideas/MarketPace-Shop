import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Music, ShoppingBag, Star, MapPin, DollarSign, Clock, Users, Search, Package, Eye } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LocationRadiusSelector from './LocationRadiusSelector';

const MusicianMarket: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [location, setLocation] = useState('');
  const [radius, setRadius] = useState(20);

  const marketItems = [
    {
      id: 1,
      title: 'Fender Stratocaster Electric Guitar',
      price: 1200,
      category: 'guitars',
      seller: 'Mike Johnson',
      rating: 4.8,
      image: '/placeholder.svg',
      condition: 'Excellent',
      location: 'Downtown',
      description: 'Professional grade Fender Strat, barely used',
      isRental: false,
      distance: 2.3,
      isSubscriber: true
    },
    {
      id: 2,
      title: 'Pearl Drum Kit - 5 Piece',
      price: 800,
      category: 'drums',
      seller: 'Sarah Chen',
      rating: 4.9,
      image: '/placeholder.svg',
      condition: 'Good',
      location: 'Uptown',
      description: 'Complete drum set with cymbals included',
      isRental: false,
      distance: 5.1,
      isSubscriber: true
    },
    {
      id: 3,
      title: 'PA System Rental',
      price: 150,
      category: 'audio',
      seller: 'Sound Solutions',
      rating: 5.0,
      image: '/placeholder.svg',
      condition: 'New',
      location: 'Arts District',
      description: 'Professional PA system for events',
      isRental: true,
      rentalPeriod: 'per day',
      distance: 3.7,
      isSubscriber: false
    },
    {
      id: 4,
      title: 'Yamaha Digital Piano',
      price: 950,
      category: 'keyboards',
      seller: 'The Midnight Blues',
      rating: 4.7,
      image: '/placeholder.svg',
      condition: 'Very Good',
      location: 'Midtown',
      description: '88-key weighted digital piano',
      isRental: false,
      distance: 8.2,
      isSubscriber: true
    }
  ];

  const categories = [
    { id: 'all', name: 'All Items', icon: ShoppingBag },
    { id: 'guitars', name: 'Guitars', icon: Music },
    { id: 'drums', name: 'Drums', icon: Music },
    { id: 'keyboards', name: 'Keyboards', icon: Music },
    { id: 'audio', name: 'Audio Equipment', icon: Music }
  ];

  const handleLocationChange = (newLocation: string, newRadius: number) => {
    setLocation(newLocation);
    setRadius(newRadius);
  };

  // Sort items: subscribers first, then by distance
  const sortedItems = [...marketItems].sort((a, b) => {
    if (a.isSubscriber && !b.isSubscriber) return -1;
    if (!a.isSubscriber && b.isSubscriber) return 1;
    return a.distance - b.distance;
  });

  const filteredItems = sortedItems.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.seller.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const withinRadius = item.distance <= radius;
    return matchesSearch && matchesCategory && withinRadius;
  });

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-lg p-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-purple-800 mb-2">
            🎵 Musician Market
          </h1>
          <p className="text-purple-600 mb-4">
            Buy • Sell • Rent • Discover musical equipment from local musicians
          </p>
          <div className="flex justify-center gap-4 text-sm text-purple-700">
            <div className="flex items-center gap-1">
              <DollarSign className="w-4 h-4" />
              <span>Buy</span>
            </div>
            <div className="flex items-center gap-1">
              <Package className="w-4 h-4" />
              <span>Sell</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>Rent</span>
            </div>
            <div className="flex items-center gap-1">
              <Eye className="w-4 h-4" />
              <span>Discover</span>
            </div>
          </div>
        </div>
      </div>

      <LocationRadiusSelector 
        onLocationChange={handleLocationChange}
        defaultRadius={20}
        showMembersFirst={true}
      />

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search equipment or sellers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button 
          onClick={() => navigate('/musicians')}
          className="bg-purple-600 hover:bg-purple-700"
        >
          <Package className="w-4 h-4 mr-2" />
          Sell Your Equipment
        </Button>
      </div>

      <div className="flex flex-wrap gap-2">
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className={selectedCategory === category.id ? "bg-purple-600" : ""}
            >
              <Icon className="w-4 h-4 mr-1" />
              {category.name}
            </Button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item) => (
          <Card key={item.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="p-0 relative">
              <img 
                src={item.image} 
                alt={item.title} 
                className="w-full h-48 object-cover rounded-t-lg" 
              />
              <div className="absolute top-2 right-2 flex gap-2">
                {item.isRental && (
                  <Badge className="bg-green-500">
                    <Clock className="w-3 h-3 mr-1" />
                    Rental
                  </Badge>
                )}
                <Badge variant="secondary">{item.condition}</Badge>
              </div>
              <div className="absolute top-2 left-2 flex gap-2">
                {item.isSubscriber && (
                  <Badge className="bg-blue-600">
                    Member
                  </Badge>
                )}
                <Badge className="bg-orange-600">
                  {item.distance} mi
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-3">
                <div>
                  <CardTitle className="text-lg line-clamp-2">{item.title}</CardTitle>
                  <p className="text-sm text-gray-600">{item.description}</p>
                </div>

                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold text-green-600">
                    ${item.price}
                    {item.isRental && (
                      <span className="text-sm text-gray-500 ml-1">
                        {item.rentalPeriod}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span>{item.rating}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Users className="w-4 h-4" />
                    <span>Sold by {item.seller}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="w-4 h-4" />
                    <span>{item.location}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    Message Seller
                  </Button>
                  <Button size="sm" className="flex-1 bg-purple-600 hover:bg-purple-700">
                    {item.isRental ? 'Rent Now' : 'Buy Now'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredItems.length === 0 && (
        <div className="text-center py-12">
          <Music className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-500 mb-2">No items found</h3>
          <p className="text-gray-400">Try adjusting your search, category filter, or expanding your radius</p>
        </div>
      )}
    </div>
  );
};

export default MusicianMarket;