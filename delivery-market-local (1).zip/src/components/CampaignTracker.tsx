import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Target, TrendingUp, Users, MapPin, Calendar, Play, Pause, Settings } from 'lucide-react';

interface Campaign {
  id: string;
  name: string;
  type: 'user_acquisition' | 'driver_recruitment' | 'business_onboarding' | 'town_expansion';
  status: 'active' | 'paused' | 'completed';
  progress: number;
  target: number;
  current: number;
  startDate: string;
  endDate: string;
  budget: number;
  spent: number;
}

export default function CampaignTracker() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([
    {
      id: '1',
      name: 'Summer User Growth',
      type: 'user_acquisition',
      status: 'active',
      progress: 75,
      target: 1000,
      current: 750,
      startDate: '2024-06-01',
      endDate: '2024-08-31',
      budget: 5000,
      spent: 3200
    },
    {
      id: '2',
      name: 'Driver Recruitment Drive',
      type: 'driver_recruitment',
      status: 'active',
      progress: 45,
      target: 200,
      current: 90,
      startDate: '2024-07-01',
      endDate: '2024-09-30',
      budget: 3000,
      spent: 1350
    },
    {
      id: '3',
      name: 'Business Partner Expansion',
      type: 'business_onboarding',
      status: 'active',
      progress: 60,
      target: 150,
      current: 90,
      startDate: '2024-06-15',
      endDate: '2024-10-15',
      budget: 4000,
      spent: 2400
    },
    {
      id: '4',
      name: 'New Town Launch',
      type: 'town_expansion',
      status: 'paused',
      progress: 30,
      target: 5,
      current: 1,
      startDate: '2024-08-01',
      endDate: '2024-12-31',
      budget: 10000,
      spent: 2000
    }
  ]);

  const getCampaignIcon = (type: Campaign['type']) => {
    switch (type) {
      case 'user_acquisition': return <Users className="h-4 w-4" />;
      case 'driver_recruitment': return <MapPin className="h-4 w-4" />;
      case 'business_onboarding': return <Target className="h-4 w-4" />;
      case 'town_expansion': return <TrendingUp className="h-4 w-4" />;
      default: return <Target className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: Campaign['status']) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const toggleCampaignStatus = (id: string) => {
    setCampaigns(prev => prev.map(campaign => 
      campaign.id === id 
        ? { ...campaign, status: campaign.status === 'active' ? 'paused' : 'active' }
        : campaign
    ));
  };

  const totalBudget = campaigns.reduce((sum, campaign) => sum + campaign.budget, 0);
  const totalSpent = campaigns.reduce((sum, campaign) => sum + campaign.spent, 0);
  const activeCampaigns = campaigns.filter(c => c.status === 'active').length;

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Target className="h-6 w-6 text-blue-500" />
          Campaign Tracker
        </h2>
        <div className="flex items-center gap-4">
          <div className="text-sm text-muted-foreground">
            Active: <span className="font-semibold text-green-600">{activeCampaigns}</span>
          </div>
          <div className="text-sm text-muted-foreground">
            Budget: <span className="font-semibold">${totalSpent.toLocaleString()} / ${totalBudget.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Campaign Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="border-l-4 border-l-green-500">
          <CardContent className="pt-4">
            <div className="text-2xl font-bold text-green-600">{activeCampaigns}</div>
            <div className="text-sm text-muted-foreground">Active Campaigns</div>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="pt-4">
            <div className="text-2xl font-bold text-blue-600">${totalSpent.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">Total Spent</div>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="pt-4">
            <div className="text-2xl font-bold text-purple-600">{Math.round((totalSpent / totalBudget) * 100)}%</div>
            <div className="text-sm text-muted-foreground">Budget Used</div>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="pt-4">
            <div className="text-2xl font-bold text-orange-600">
              {Math.round(campaigns.reduce((sum, c) => sum + c.progress, 0) / campaigns.length)}%
            </div>
            <div className="text-sm text-muted-foreground">Avg Progress</div>
          </CardContent>
        </Card>
      </div>

      {/* Campaign Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {campaigns.map((campaign) => (
          <Card key={campaign.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-lg">
                  {getCampaignIcon(campaign.type)}
                  {campaign.name}
                </CardTitle>
                <Badge className={getStatusColor(campaign.status)}>
                  {campaign.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span className="font-semibold">{campaign.current} / {campaign.target}</span>
                </div>
                <Progress value={campaign.progress} className="h-2" />
                <div className="text-xs text-muted-foreground">{campaign.progress}% complete</div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Budget</div>
                  <div className="font-semibold">${campaign.budget.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Spent</div>
                  <div className="font-semibold">${campaign.spent.toLocaleString()}</div>
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Calendar className="h-3 w-3" />
                  {new Date(campaign.startDate).toLocaleDateString()} - {new Date(campaign.endDate).toLocaleDateString()}
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => toggleCampaignStatus(campaign.id)}
                  >
                    {campaign.status === 'active' ? 
                      <Pause className="h-3 w-3 mr-1" /> : 
                      <Play className="h-3 w-3 mr-1" />
                    }
                    {campaign.status === 'active' ? 'Pause' : 'Resume'}
                  </Button>
                  <Button size="sm" variant="outline">
                    <Settings className="h-3 w-3 mr-1" />
                    Edit
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}