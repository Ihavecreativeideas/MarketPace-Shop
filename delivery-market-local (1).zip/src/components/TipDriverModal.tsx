import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Star, DollarSign, Heart } from 'lucide-react';

interface TipDriverModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (tip: number, rating: number, review: string) => void;
  userType: 'buyer' | 'seller';
  driverName?: string;
  itemAction?: 'accepted' | 'returned';
}

const TipDriverModal: React.FC<TipDriverModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  userType,
  driverName = 'your driver',
  itemAction
}) => {
  const [tip, setTip] = useState('');
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [hoveredRating, setHoveredRating] = useState(0);

  const handleSubmit = () => {
    onSubmit(parseFloat(tip) || 0, rating, review);
    setTip('');
    setRating(0);
    setReview('');
    onClose();
  };

  const tipOptions = [2, 3, 5, 8];
  const getTitle = () => {
    if (userType === 'buyer') {
      return itemAction === 'returned' 
        ? `Tip ${driverName} (Item Returned)`
        : `Tip ${driverName} (Item Accepted)`;
    }
    return `Tip ${driverName} (Your Item Delivered)`;
  };

  const getMessage = () => {
    if (userType === 'buyer') {
      return itemAction === 'returned'
        ? 'Your driver handled the delivery professionally, even though you returned the item.'
        : 'Your driver successfully delivered your item!';
    }
    return 'Your driver successfully delivered your item to the buyer!';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-500" />
            {getTitle()}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="bg-blue-50 p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-4 h-4 text-blue-600" />
              <span className="font-medium text-blue-900">Show Your Appreciation</span>
            </div>
            <p className="text-sm text-blue-800">{getMessage()}</p>
            <p className="text-xs text-blue-700 mt-1">Tips go 100% to your driver!</p>
          </div>
          
          <div>
            <Label className="text-sm font-medium">Tip Amount (Optional)</Label>
            <div className="flex gap-2 mt-2">
              {tipOptions.map((amount) => (
                <Button
                  key={amount}
                  variant={tip === amount.toString() ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setTip(amount.toString())}
                >
                  ${amount}
                </Button>
              ))}
            </div>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-sm">$</span>
              <Input
                type="number"
                placeholder="Custom amount"
                value={tip}
                onChange={(e) => setTip(e.target.value)}
                className="flex-1"
                min="0"
                step="0.50"
              />
            </div>
          </div>
          
          <div>
            <Label className="text-sm font-medium">Rate Your Driver (Optional)</Label>
            <div className="flex gap-1 mt-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="p-1"
                >
                  <Star
                    className={`w-6 h-6 ${
                      star <= (hoveredRating || rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <Label htmlFor="review" className="text-sm font-medium">
              Review (Optional)
            </Label>
            <Textarea
              id="review"
              placeholder="Share your experience with this driver..."
              value={review}
              onChange={(e) => setReview(e.target.value)}
              className="mt-2"
              rows={3}
            />
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Skip for Now
            </Button>
            <Button onClick={handleSubmit} className="flex-1">
              {tip || rating || review ? 'Submit' : 'No Tip'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TipDriverModal;