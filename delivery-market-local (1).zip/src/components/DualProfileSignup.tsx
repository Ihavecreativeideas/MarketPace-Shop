import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { User, Store, Wrench, Music } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useNavigate } from 'react-router-dom';

type ProfileType = 'member' | 'shop' | 'service' | 'entertainment';

export const DualProfileSignup: React.FC = () => {
  const [selectedType, setSelectedType] = useState<ProfileType>('member');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const profileTypes = [
    { id: 'member', label: 'Regular Member', icon: User, desc: 'Buy, sell, and rent items' },
    { id: 'shop', label: 'Shop', icon: Store, desc: 'Retail business with products' },
    { id: 'service', label: 'Service Provider', icon: Wrench, desc: 'Professional services' },
    { id: 'entertainment', label: 'Entertainment Industry', icon: Music, desc: 'Musicians, DJs, performers' }
  ];

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
            profile_type: selectedType
          }
        }
      });

      if (error) throw error;

      if (data.user) {
        // Create profile record
        const { error: profileError } = await supabase
          .from('user_profiles')
          .insert({
            user_id: data.user.id,
            name,
            profile_type: selectedType,
            email
          });

        if (profileError) console.error('Profile creation error:', profileError);
        
        // Redirect to onboarding
        navigate('/onboarding');
      }
    } catch (error: any) {
      console.error('Signup error:', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto bg-white/10 backdrop-blur-sm border-white/20">
      <CardHeader>
        <CardTitle className="text-center text-white">Join MarketPace</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSignup} className="space-y-4">
          {/* Profile Type Selection */}
          <div className="space-y-3">
            <Label className="text-white">Choose Your Profile Type</Label>
            <div className="grid grid-cols-2 gap-2">
              {profileTypes.map((type) => {
                const Icon = type.icon;
                return (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => setSelectedType(type.id as ProfileType)}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      selectedType === type.id
                        ? 'border-blue-400 bg-blue-400/20'
                        : 'border-white/20 bg-white/5 hover:bg-white/10'
                    }`}
                  >
                    <Icon className="w-6 h-6 mx-auto mb-1 text-white" />
                    <div className="text-xs text-white font-medium">{type.label}</div>
                  </button>
                );
              })}
            </div>
            <p className="text-xs text-gray-300">
              {profileTypes.find(t => t.id === selectedType)?.desc}
            </p>
          </div>

          {/* Form Fields */}
          <div className="space-y-3">
            <div>
              <Label htmlFor="name" className="text-white">Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-white/10 border-white/20 text-white"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="email" className="text-white">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-white/10 border-white/20 text-white"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="password" className="text-white">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-white/10 border-white/20 text-white"
                required
              />
            </div>
          </div>

          <Button 
            type="submit" 
            className="w-full bg-blue-600 hover:bg-blue-700"
            disabled={loading}
          >
            {loading ? 'Creating Account...' : 'Sign Up'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};