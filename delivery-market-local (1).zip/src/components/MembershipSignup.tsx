import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Mail, User, Crown, Users, Sparkles, Gift } from 'lucide-react';
import { useLaunch } from '@/contexts/LaunchContext';

interface MembershipSignupProps {
  onClose?: () => void;
}

const MembershipSignup: React.FC<MembershipSignupProps> = ({ onClose }) => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [membershipType, setMembershipType] = useState('member');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { incrementSignups } = useLaunch();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !name) return;
    
    setIsSubmitting(true);
    try {
      await incrementSignups();
      const message = membershipType === 'subscriber' 
        ? `Welcome to Premium Partners, ${name}! You now have lifetime access to all premium features.`
        : `Welcome to MarketPace, ${name}! You can upgrade to Premium Partners anytime during the trial.`;
      alert(message);
      setEmail('');
      setName('');
      onClose?.();
    } catch (error) {
      console.error('Signup error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-center text-2xl font-bold">
          Join MarketPace - Trial Era
        </CardTitle>
        <div className="text-center space-y-2">
          <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-1">
            <Gift className="w-4 h-4 mr-1" />
            All Early Members Get Full Access!
          </Badge>
          <p className="text-sm text-gray-600">
            Support our startup while we grow and improve together
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="name" className="flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span>Name</span>
              </Label>
              <Input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="email" className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span>Email</span>
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                required
              />
            </div>
          </div>

          <div className="space-y-4">
            <Label className="text-lg font-semibold">Choose Your Membership</Label>
            <RadioGroup value={membershipType} onValueChange={setMembershipType}>
              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value="member" id="member" className="mt-1" />
                  <div className="flex-1">
                    <Label htmlFor="member" className="flex items-center space-x-2 cursor-pointer">
                      <Users className="w-5 h-5 text-blue-600" />
                      <span className="font-semibold">Basic Member</span>
                    </Label>
                    <p className="text-sm text-gray-600 mt-1">
                      Perfect for occasional buyers/sellers. Access to basic marketplace features.
                    </p>
                    <div className="mt-2">
                      <Badge variant="outline" className="text-blue-600 border-blue-200">
                        Trial Era: Full Access
                      </Badge>
                    </div>
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-4 border-2 border-purple-300 rounded-lg bg-gradient-to-br from-purple-50 to-pink-50">
                  <RadioGroupItem value="subscriber" id="subscriber" className="mt-1" />
                  <div className="flex-1">
                    <Label htmlFor="subscriber" className="flex items-center space-x-2 cursor-pointer">
                      <Crown className="w-5 h-5 text-purple-600" />
                      <span className="font-semibold text-purple-800">Premium Partner (Subscriber)</span>
                    </Label>
                    <p className="text-sm text-gray-700 mt-1">
                      For shops, services, frequent buyers/sellers, and musicians. Premium features & benefits.
                    </p>
                    <div className="mt-2 space-y-1">
                      <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white mr-2">
                        <Sparkles className="w-3 h-3 mr-1" />
                        Lifetime Benefits
                      </Badge>
                      <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                        <Gift className="w-3 h-3 mr-1" />
                        Trial Era: FREE
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>
            </RadioGroup>
          </div>

          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg border border-blue-200">
            <h4 className="font-semibold text-blue-900 mb-2">Trial Era Benefits</h4>
            <div className="text-sm text-blue-800 space-y-1">
              <p>• All early members get full access to ALL features during trial</p>
              <p>• Only Premium Partners (Subscribers) get lifetime benefits</p>
              <p>• Help us grow while we improve the platform together</p>
              <p>• Be part of MarketPace's founding community</p>
            </div>
          </div>

          <Button 
            type="submit" 
            disabled={isSubmitting || !email || !name}
            className={`w-full py-3 text-lg font-semibold ${
              membershipType === 'subscriber' 
                ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700'
                : 'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            {isSubmitting ? 'Joining...' : 
             membershipType === 'subscriber' ? '👑 Join as Premium Partner' : '🚀 Join as Member'
            }
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default MembershipSignup;