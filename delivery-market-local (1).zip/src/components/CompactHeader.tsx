import React from 'react';
import { Button } from './ui/button';
import { LogIn, UserPlus, Menu } from 'lucide-react';
import TealSquareLogo from './TealSquareLogo';
import { cn } from '../lib/utils';

interface CompactHeaderProps {
  onAuthClick: () => void;
  onMenuClick?: () => void;
  className?: string;
}

const CompactHeader: React.FC<CompactHeaderProps> = ({ 
  onAuthClick, 
  onMenuClick,
  className 
}) => {
  return (
    <header className={cn(
      "sticky top-0 z-50 bg-slate-900/95 backdrop-blur-lg border-b border-slate-700/50",
      "px-4 py-3 flex items-center justify-between",
      className
    )}>
      <div className="flex items-center space-x-2">
        <TealSquareLogo size={32} />
        <span className="text-lg font-bold text-teal-400">MarketPace</span>
      </div>
      
      <div className="flex items-center gap-2">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onAuthClick}
          className="text-slate-300 hover:text-white hover:bg-slate-800"
        >
          <LogIn className="h-4 w-4" />
        </Button>
        <Button 
          size="sm" 
          onClick={onAuthClick}
          className="bg-teal-500 hover:bg-teal-600 text-white px-3"
        >
          <UserPlus className="h-4 w-4 mr-1" />
          Join
        </Button>
        {onMenuClick && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onMenuClick}
            className="text-slate-300 hover:text-white hover:bg-slate-800"
          >
            <Menu className="h-4 w-4" />
          </Button>
        )}
      </div>
    </header>
  );
};

export default CompactHeader;