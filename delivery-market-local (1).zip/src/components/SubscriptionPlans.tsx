import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Gift, Zap, Crown, Sparkles, Star } from 'lucide-react';
import MarketPaceProFeatures from './MarketPaceProFeatures';

const SubscriptionPlans: React.FC = () => {
  const handleSignup = () => {
    console.log('MarketPace Pro signup initiated');
    // Navigate to signup or open modal
  };

  return (
    <Card>
      <CardHeader>
        <div className="text-center">
          <div className="bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 text-white p-6 rounded-lg mb-6">
            <h2 className="text-3xl font-bold mb-2 flex items-center justify-center gap-2">
              <Crown className="w-8 h-8" />
              MarketPace Pro
            </h2>
            <p className="text-xl mb-2 font-semibold">
              All Early Subscribers will gain MarketPace Pro Access to All Features for a Limited time!
            </p>
            <div className="flex items-center justify-center gap-2 text-lg font-bold">
              <Sparkles className="w-6 h-6" />
              <span>Early Subscribers = Lifetime Benefits</span>
              <Sparkles className="w-6 h-6" />
            </div>
          </div>
          <CardTitle className="flex items-center gap-2 justify-center">
            <Star className="w-5 h-5 text-purple-600" />
            Become a MarketPace Pro
          </CardTitle>
          <p className="text-sm text-gray-600 mt-2">
            Join now and lock in pro access forever!
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <div className="max-w-4xl mx-auto">
          <div className="border-2 border-purple-300 bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 rounded-lg p-8 relative">
            <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-1">
              <Crown className="w-4 h-4 mr-1" />
              Pro Access
            </Badge>
            
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold mb-3 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                MarketPace Pro Program
              </h3>
              <div className="text-5xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-2">
                FREE
              </div>
              <p className="text-lg font-semibold mb-2 text-purple-700">
                Complete MarketPace Pro Access During Launch Campaign
              </p>
              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-4 py-2">
                <Gift className="w-4 h-4 mr-1" />
                Lifetime Pro Benefits for Early Subscribers
              </Badge>
            </div>

            <div className="mb-8">
              <MarketPaceProFeatures />
            </div>

            <Button 
              onClick={handleSignup}
              className="w-full bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 hover:from-purple-700 hover:via-pink-700 hover:to-orange-700 text-white text-lg py-6 font-bold"
            >
              <Crown className="w-5 h-5 mr-2" />
              🚀 Join MarketPace Pro Now!
            </Button>
            
            <p className="text-xs text-center text-gray-500 mt-3">
              No credit card required • Lifetime benefits • Pro access guaranteed
            </p>
          </div>
        </div>
        
        <div className="mt-8 space-y-4">
          <div className="p-6 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-200">
            <h4 className="font-bold mb-3 text-purple-800 flex items-center gap-2">
              <Zap className="w-5 h-5" />
              ⚡ Limited Time Pro Offer
            </h4>
            <div className="text-purple-700 space-y-2">
              <p className="font-medium">
                Early subscribers get LIFETIME access to ALL pro features!
              </p>
              <p className="text-sm">
                • Complete MarketPace Pro access absolutely FREE during launch
              </p>
              <p className="text-sm">
                • All pro features unlocked permanently for early supporters
              </p>
              <p className="text-sm font-semibold">
                • Lock in pro benefits forever by joining now!
              </p>
            </div>
          </div>
          
          <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
            <h4 className="font-semibold mb-2 text-blue-900">Why Join MarketPace Pro Now?</h4>
            <div className="text-sm text-blue-800 space-y-1">
              <p>• Get lifetime access to pro analytics and insights</p>
              <p>• Unlock advanced web integration and promotional tools</p>
              <p>• Enjoy discounted delivery fees and priority shipping forever</p>
              <p>• Eligible for business spotlight and pro marketing</p>
              <p>• Set your own shipping fees and offer free returns</p>
              <p>• Build your empire with our most powerful features</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SubscriptionPlans;