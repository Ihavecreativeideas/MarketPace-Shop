import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Zap, DollarSign, Clock } from 'lucide-react';
import { useState } from 'react';

interface PaymentProps {
  deliveryId: string;
  driverPay: number;
  tipAmount?: number;
}

const InstantPaymentSystem: React.FC<PaymentProps> = ({ deliveryId, driverPay, tipAmount = 0 }) => {
  const [paymentStatus, setPaymentStatus] = useState<'pending' | 'processing' | 'completed'>('pending');
  const [paymentTime, setPaymentTime] = useState<Date | null>(null);

  const processInstantPayment = async () => {
    setPaymentStatus('processing');
    
    // Simulate instant payment processing
    setTimeout(() => {
      setPaymentStatus('completed');
      setPaymentTime(new Date());
    }, 1500);
  };

  const totalPayout = driverPay + tipAmount;

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-yellow-500" />
          Instant Payment System
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <span className="font-medium">Delivery #{deliveryId}</span>
            <Badge variant={paymentStatus === 'completed' ? 'default' : 'secondary'}>
              {paymentStatus === 'completed' ? 'Paid' : 'Ready to Pay'}
            </Badge>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Base Delivery Pay:</span>
              <span className="font-medium">${driverPay.toFixed(2)}</span>
            </div>
            
            {tipAmount > 0 && (
              <div className="flex justify-between text-green-600">
                <span>Customer Tip:</span>
                <span className="font-medium">+${tipAmount.toFixed(2)}</span>
              </div>
            )}
            
            <div className="border-t pt-2">
              <div className="flex justify-between font-bold text-lg">
                <span>Total Payout:</span>
                <span className="text-green-600">${totalPayout.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        {paymentStatus === 'pending' && (
          <Button 
            onClick={processInstantPayment}
            className="w-full bg-green-600 hover:bg-green-700"
            size="lg"
          >
            <CreditCard className="w-4 h-4 mr-2" />
            Release Instant Payment
          </Button>
        )}

        {paymentStatus === 'processing' && (
          <div className="text-center py-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-2"></div>
            <p className="text-sm text-gray-600">Processing instant transfer...</p>
          </div>
        )}

        {paymentStatus === 'completed' && paymentTime && (
          <div className="bg-green-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 text-green-800 mb-2">
              <DollarSign className="w-5 h-5" />
              <span className="font-semibold">Payment Completed!</span>
            </div>
            <div className="text-sm text-green-700 space-y-1">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>Paid at: {paymentTime.toLocaleTimeString()}</span>
              </div>
              <p>• ${totalPayout.toFixed(2)} transferred to your bank account</p>
              <p>• Funds available immediately</p>
              <p>• Transaction ID: {deliveryId}-{Date.now()}</p>
            </div>
          </div>
        )}

        <div className="bg-blue-50 p-3 rounded-lg">
          <h4 className="font-medium text-blue-800 mb-2">Instant Payment Features</h4>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• No waiting periods or holds</li>
            <li>• Tips go directly to your account</li>
            <li>• Real-time payment notifications</li>
            <li>• Secure bank-grade transfers</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};

export default InstantPaymentSystem;