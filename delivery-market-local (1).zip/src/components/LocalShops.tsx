import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Clock, MapPin, Star, Play, Calendar, ShoppingBag, Eye } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface Shop {
  id: string;
  name: string;
  category: string;
  avatar: string;
  rating: number;
  hours: string;
  location: string;
  isOpen: boolean;
  hasLiveStream: boolean;
  saleEvent?: string;
  recentUpdate?: string;
  itemCount: number;
}

const LocalShops: React.FC = () => {
  const [shops] = useState<Shop[]>([
    {
      id: '1',
      name: 'Mike\'s Music Store',
      category: 'Music & Instruments',
      avatar: '/api/placeholder/60/60',
      rating: 4.8,
      hours: '9:00 AM - 8:00 PM',
      location: '123 Main St',
      isOpen: true,
      hasLiveStream: true,
      saleEvent: '50% Off All Guitars',
      recentUpdate: 'New shipment of vintage guitars arrived!',
      itemCount: 156
    },
    {
      id: '2',
      name: 'Springfield Bakery',
      category: 'Food & Bakery',
      avatar: '/api/placeholder/60/60',
      rating: 4.9,
      hours: '6:00 AM - 6:00 PM',
      location: '456 Oak Ave',
      isOpen: true,
      hasLiveStream: false,
      saleEvent: 'Fresh Bread Sale - 30% Off',
      recentUpdate: 'Special wedding cake orders now available',
      itemCount: 89
    },
    {
      id: '3',
      name: 'Tech Repair Hub',
      category: 'Electronics & Repair',
      avatar: '/api/placeholder/60/60',
      rating: 4.6,
      hours: '10:00 AM - 7:00 PM',
      location: '789 Tech Blvd',
      isOpen: false,
      hasLiveStream: false,
      recentUpdate: 'Now offering same-day phone screen repairs',
      itemCount: 234
    }
  ]);

  const handleViewShop = (shopId: string) => {
    toast({ 
      title: 'Viewing Shop', 
      description: 'Shop details page coming soon!' 
    });
  };

  const handleJoinLiveStream = (shopId: string) => {
    toast({ 
      title: 'Joining Live Stream', 
      description: 'Live stream feature coming soon!' 
    });
  };

  const handleViewItems = (shopId: string) => {
    toast({ 
      title: 'Shop Items', 
      description: 'Browse shop inventory coming soon!' 
    });
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold mb-2">Local Shops</h2>
        <p className="text-gray-600">Discover shops in your area with live updates and events</p>
      </div>

      <div className="grid gap-4">
        {shops.map((shop) => (
          <Card key={shop.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <Avatar className="w-16 h-16">
                    <AvatarImage src={shop.avatar} />
                    <AvatarFallback>{shop.name[0]}</AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-lg font-semibold">{shop.name}</h3>
                      {shop.isOpen ? (
                        <Badge className="bg-green-500 text-white">Open</Badge>
                      ) : (
                        <Badge variant="secondary">Closed</Badge>
                      )}
                      {shop.hasLiveStream && (
                        <Badge className="bg-red-500 text-white animate-pulse">
                          <Play className="w-3 h-3 mr-1" />
                          LIVE
                        </Badge>
                      )}
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-2">{shop.category}</p>
                    
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span>{shop.rating}</span>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{shop.hours}</span>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        <span>{shop.location}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <Button 
                  onClick={() => handleViewShop(shop.id)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  View Shop
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="pt-0">
              {/* Sale Event */}
              {shop.saleEvent && (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-3">
                  <div className="flex items-center gap-2 text-orange-700">
                    <Calendar className="w-4 h-4" />
                    <span className="font-medium">Sale Event:</span>
                  </div>
                  <p className="text-orange-600 mt-1">{shop.saleEvent}</p>
                </div>
              )}
              
              {/* Recent Update */}
              {shop.recentUpdate && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                  <div className="flex items-center gap-2 text-blue-700">
                    <span className="font-medium">Latest Update:</span>
                  </div>
                  <p className="text-blue-600 mt-1">{shop.recentUpdate}</p>
                </div>
              )}
              
              {/* Action Buttons */}
              <div className="flex items-center gap-3 pt-3 border-t">
                {shop.hasLiveStream && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleJoinLiveStream(shop.id)}
                    className="border-red-200 text-red-600 hover:bg-red-50"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Join Live Stream
                  </Button>
                )}
                
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleViewItems(shop.id)}
                  className="flex items-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4" />
                  Browse Items ({shop.itemCount})
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default LocalShops;