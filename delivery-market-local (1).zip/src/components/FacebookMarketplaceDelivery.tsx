import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import { Truck, Clock, MapPin } from 'lucide-react';

interface FacebookMarketplaceDeliveryProps {
  listingId: string;
  listingTitle: string;
  listingPrice: number;
  sellerName: string;
}

export default function FacebookMarketplaceDelivery({
  listingId,
  listingTitle,
  listingPrice,
  sellerName
}: FacebookMarketplaceDeliveryProps) {
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [preferredTime, setPreferredTime] = useState('');
  const [isUrgent, setIsUrgent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleRequestDelivery = async () => {
    if (!deliveryAddress.trim()) {
      toast({
        title: "Address Required",
        description: "Please enter a delivery address",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const deliveryFee = isUrgent ? 8.00 : 5.00;
      
      const { data, error } = await supabase
        .from('delivery_requests')
        .insert({
          listing_id: listingId,
          delivery_address: deliveryAddress,
          preferred_delivery_time: preferredTime || null,
          urgent: isUrgent,
          delivery_fee: deliveryFee,
          status: 'pending'
        });

      if (!error) {
        toast({
          title: "Delivery Requested!",
          description: `Your delivery request has been submitted. Fee: $${deliveryFee}`
        });
        
        // Reset form
        setDeliveryAddress('');
        setPreferredTime('');
        setIsUrgent(false);
      } else {
        throw error;
      }
    } catch (error) {
      toast({
        title: "Request Failed",
        description: "Unable to submit delivery request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Truck className="h-5 w-5 text-blue-600" />
          MarketPace Deliver Now
        </CardTitle>
        <div className="text-sm text-muted-foreground">
          <p className="font-medium">{listingTitle}</p>
          <p>Price: ${listingPrice} • Seller: {sellerName}</p>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="address">
            <MapPin className="h-4 w-4 inline mr-1" />
            Delivery Address
          </Label>
          <Textarea
            id="address"
            placeholder="Enter your full delivery address"
            value={deliveryAddress}
            onChange={(e) => setDeliveryAddress(e.target.value)}
            rows={3}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="time">
            <Clock className="h-4 w-4 inline mr-1" />
            Preferred Delivery Time (Optional)
          </Label>
          <Input
            id="time"
            type="datetime-local"
            value={preferredTime}
            onChange={(e) => setPreferredTime(e.target.value)}
          />
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="urgent"
            checked={isUrgent}
            onChange={(e) => setIsUrgent(e.target.checked)}
            className="rounded"
          />
          <Label htmlFor="urgent" className="text-sm">
            Urgent Delivery (+$3.00)
          </Label>
        </div>

        <div className="bg-muted p-3 rounded text-sm">
          <p className="font-medium">Delivery Fee: ${isUrgent ? '8.00' : '5.00'}</p>
          <p className="text-muted-foreground">
            {isUrgent ? 'Same-day delivery' : 'Standard delivery (1-2 days)'}
          </p>
        </div>

        <Button 
          onClick={handleRequestDelivery}
          disabled={isLoading || !deliveryAddress.trim()}
          className="w-full"
        >
          {isLoading ? 'Requesting...' : 'Request Delivery'}
        </Button>

        <div className="text-xs text-muted-foreground space-y-1">
          <p>• Driver will pick up from seller</p>
          <p>• Secure payment to seller upon delivery</p>
          <p>• Real-time delivery tracking</p>
        </div>
      </CardContent>
    </Card>
  );
}