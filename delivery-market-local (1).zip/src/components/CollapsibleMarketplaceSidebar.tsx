import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Menu, 
  X, 
  Filter, 
  ShoppingBag, 
  Star, 
  MapPin,
  DollarSign,
  Truck,
  Package
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface FilterState {
  priceRange: [number, number];
  category: string;
  rating: number;
  deliveryType: string;
  distance: number;
}

interface CollapsibleMarketplaceSidebarProps {
  filters: FilterState;
  onFiltersChange: (filters: Partial<FilterState>) => void;
  onClearFilters: () => void;
  onSectionChange: (section: string) => void;
  activeSection: string;
  className?: string;
}

const CollapsibleMarketplaceSidebar: React.FC<CollapsibleMarketplaceSidebarProps> = ({
  filters,
  onFiltersChange,
  onClearFilters,
  onSectionChange,
  activeSection,
  className
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const sections = [
    { id: 'marketplace', label: 'Marketplace', icon: ShoppingBag },
    { id: 'rent-anything', label: 'Rent Anything', icon: Package }
  ];

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'electronics', label: 'Electronics' },
    { value: 'clothing', label: 'Clothing' },
    { value: 'home', label: 'Home & Garden' },
    { value: 'food', label: 'Food & Beverages' },
    { value: 'services', label: 'Services' }
  ];

  const deliveryTypes = [
    { value: 'all', label: 'All Delivery' },
    { value: 'local', label: 'Local Delivery' },
    { value: 'pickup', label: 'Pickup Only' },
    { value: 'shipping', label: 'Shipping' }
  ];

  const SidebarContent = () => (
    <div className="space-y-6">
      {/* Sections */}
      <div className="space-y-3">
        <h3 className="font-semibold text-sm">
          {!isCollapsed && 'Sections'}
        </h3>
        <div className="space-y-2">
          {sections.map(section => {
            const Icon = section.icon;
            return (
              <Button
                key={section.id}
                variant={activeSection === section.id ? 'default' : 'ghost'}
                size="sm"
                className={cn(
                  "w-full justify-start",
                  isCollapsed && "px-2"
                )}
                onClick={() => onSectionChange(section.id)}
              >
                <Icon className="w-4 h-4 mr-2" />
                {!isCollapsed && section.label}
              </Button>
            );
          })}
        </div>
      </div>

      {activeSection === 'marketplace' && (
        <>
          {/* Categories */}
          <div className="space-y-3">
            <h3 className="font-semibold text-sm flex items-center gap-2">
              <ShoppingBag className="w-4 h-4" />
              {!isCollapsed && 'Categories'}
            </h3>
            <div className="space-y-2">
              {categories.map(category => (
                <Button
                  key={category.value}
                  variant={filters.category === category.value ? 'default' : 'ghost'}
                  size="sm"
                  className={cn(
                    "w-full justify-start",
                    isCollapsed && "px-2"
                  )}
                  onClick={() => onFiltersChange({ category: category.value })}
                >
                  {isCollapsed ? category.label.charAt(0) : category.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          {!isCollapsed && (
            <div className="space-y-3">
              <h3 className="font-semibold text-sm flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Price Range
              </h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="0"
                    max="500"
                    value={filters.priceRange[1]}
                    onChange={(e) => onFiltersChange({ 
                      priceRange: [filters.priceRange[0], parseInt(e.target.value)] 
                    })}
                    className="flex-1"
                  />
                </div>
                <div className="text-sm text-gray-600">
                  ${filters.priceRange[0]} - ${filters.priceRange[1]}
                </div>
              </div>
            </div>
          )}

          {/* Rating */}
          <div className="space-y-3">
            <h3 className="font-semibold text-sm flex items-center gap-2">
              <Star className="w-4 h-4" />
              {!isCollapsed && 'Min Rating'}
            </h3>
            <div className="space-y-2">
              {[4, 3, 2, 1].map(rating => (
                <Button
                  key={rating}
                  variant={filters.rating === rating ? 'default' : 'ghost'}
                  size="sm"
                  className={cn(
                    "w-full justify-start",
                    isCollapsed && "px-2"
                  )}
                  onClick={() => onFiltersChange({ rating })}
                >
                  {isCollapsed ? rating : (
                    <div className="flex items-center gap-1">
                      {rating}+ <Star className="w-3 h-3 fill-current" />
                    </div>
                  )}
                </Button>
              ))}
            </div>
          </div>

          {/* Delivery Type */}
          {!isCollapsed && (
            <div className="space-y-3">
              <h3 className="font-semibold text-sm flex items-center gap-2">
                <Truck className="w-4 h-4" />
                Delivery
              </h3>
              <div className="space-y-2">
                {deliveryTypes.map(type => (
                  <Button
                    key={type.value}
                    variant={filters.deliveryType === type.value ? 'default' : 'ghost'}
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => onFiltersChange({ deliveryType: type.value })}
                  >
                    {type.label}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Clear Filters */}
          {!isCollapsed && (
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full"
              onClick={onClearFilters}
            >
              Clear All Filters
            </Button>
          )}
        </>
      )}

      {activeSection === 'rent-anything' && !isCollapsed && (
        <div className="space-y-3">
          <div className="bg-green-50 p-3 rounded-lg text-sm">
            <p className="font-medium text-green-800 mb-1">💰 Make Money!</p>
            <p className="text-green-700">
              Rent out items you rarely use to neighbors in your area.
            </p>
          </div>
          
          <div className="bg-blue-50 p-3 rounded-lg text-sm">
            <p className="font-medium text-blue-800 mb-1">🔍 ISO Requests</p>
            <p className="text-blue-700">
              Post "In Search Of" requests for items you need to rent.
            </p>
          </div>
          
          <div className="bg-yellow-50 p-3 rounded-lg text-sm">
            <p className="font-medium text-yellow-800 mb-1">⚠️ Disclaimer</p>
            <p className="text-yellow-700">
              MarketPace is not responsible for lost, stolen, or damaged items.
            </p>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Mobile Toggle Button - Fixed positioning */}
      <Button
        variant="outline"
        size="sm"
        className="lg:hidden fixed top-20 left-4 z-50 bg-white shadow-lg"
        onClick={() => setIsMobileOpen(!isMobileOpen)}
      >
        {isMobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
        <span className="ml-2">Filters</span>
      </Button>

      {/* Mobile Sidebar - Drawer style */}
      <div className={cn(
        "lg:hidden fixed inset-y-0 left-0 z-40 w-80 bg-white shadow-xl transform transition-transform duration-300 ease-in-out",
        isMobileOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="h-full overflow-y-auto">
          <Card className="h-full border-0 rounded-none">
            <CardContent className="p-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="font-semibold">Filters</h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsMobileOpen(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <SidebarContent />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black/50 z-30"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Desktop Sidebar */}
      <Card className={cn(
        "hidden lg:block sticky top-4 h-fit transition-all duration-300 ease-in-out",
        isCollapsed ? "w-16" : "w-64",
        className
      )}>
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className={cn(
              "font-semibold transition-opacity duration-200",
              isCollapsed && "opacity-0"
            )}>
              {!isCollapsed && 'Filters'}
            </h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsCollapsed(!isCollapsed)}
              className="p-1"
            >
              {isCollapsed ? <Filter className="w-4 h-4" /> : <X className="w-4 h-4" />}
            </Button>
          </div>
          <SidebarContent />
        </CardContent>
      </Card>
    </>
  );
};

export default CollapsibleMarketplaceSidebar;