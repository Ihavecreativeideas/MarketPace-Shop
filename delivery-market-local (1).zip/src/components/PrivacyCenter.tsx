import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, FileText, Eye, Settings, Download, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PrivacyCenter = () => {
  const navigate = useNavigate();

  const privacyOptions = [
    {
      icon: FileText,
      title: 'Privacy Policy',
      description: 'Read our complete privacy policy',
      action: () => navigate('/privacy-policy')
    },
    {
      icon: FileText,
      title: 'Terms of Service',
      description: 'Review our terms and conditions',
      action: () => navigate('/terms-of-service')
    },
    {
      icon: FileText,
      title: 'Cookies Policy',
      description: 'Manage your cookie preferences',
      action: () => navigate('/cookies-policy')
    },
    {
      icon: Shield,
      title: 'Health Data Privacy',
      description: 'Learn about health information protection',
      action: () => navigate('/health-privacy')
    },
    {
      icon: FileText,
      title: 'Community Standards',
      description: 'Review our community guidelines',
      action: () => navigate('/community-standards')
    }
  ];

  const dataControls = [
    {
      icon: Eye,
      title: 'View Your Data',
      description: 'See what data we have about you',
      action: () => alert('Data export feature coming soon')
    },
    {
      icon: Download,
      title: 'Download Your Data',
      description: 'Get a copy of your information',
      action: () => alert('Data download feature coming soon')
    },
    {
      icon: Settings,
      title: 'Privacy Settings',
      description: 'Control your privacy preferences',
      action: () => navigate('/privacy-settings')
    },
    {
      icon: Trash2,
      title: 'Delete Account',
      description: 'Permanently delete your account and data',
      action: () => alert('Account deletion requires verification')
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-6 h-6" />
            Privacy Center
          </CardTitle>
          <CardDescription>
            Manage your privacy settings and learn about how we protect your information
          </CardDescription>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Privacy Policies & Guidelines</CardTitle>
          <CardDescription>
            Read our policies to understand how we handle your data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {privacyOptions.map((option, index) => (
              <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start gap-3">
                  <option.icon className="w-5 h-5 text-blue-500 mt-1" />
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">{option.title}</h3>
                    <p className="text-sm text-gray-600 mb-3">{option.description}</p>
                    <Button size="sm" onClick={option.action}>
                      View
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Your Data Controls</CardTitle>
          <CardDescription>
            Control what data we collect and how it's used
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {dataControls.map((control, index) => (
              <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start gap-3">
                  <control.icon className="w-5 h-5 text-green-500 mt-1" />
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">{control.title}</h3>
                    <p className="text-sm text-gray-600 mb-3">{control.description}</p>
                    <Button size="sm" variant="outline" onClick={control.action}>
                      Manage
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Quick Privacy Tips</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-2">
              <Shield className="w-4 h-4 text-green-500 mt-0.5" />
              <p>Review your privacy settings regularly to ensure they match your preferences</p>
            </div>
            <div className="flex items-start gap-2">
              <Shield className="w-4 h-4 text-green-500 mt-0.5" />
              <p>Be cautious about sharing personal information in public listings or messages</p>
            </div>
            <div className="flex items-start gap-2">
              <Shield className="w-4 h-4 text-green-500 mt-0.5" />
              <p>Use strong, unique passwords and enable two-factor authentication</p>
            </div>
            <div className="flex items-start gap-2">
              <Shield className="w-4 h-4 text-green-500 mt-0.5" />
              <p>Report any suspicious activity or privacy concerns to our support team</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Contact Privacy Team</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm mb-4">
            Have questions about privacy or need help with your data?
          </p>
          <div className="text-sm space-y-1">
            <p><strong>Email:</strong> privacy@marketpace.com</p>
            <p><strong>Phone:</strong> 1-800-PRIVACY (1-800-774-8229)</p>
            <p><strong>Response Time:</strong> Within 48 hours</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PrivacyCenter;