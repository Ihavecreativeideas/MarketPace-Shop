import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle, XCircle, Package, AlertTriangle, Users, Star, Crown, Diamond } from 'lucide-react';
import ReturnCalculator from './ReturnCalculator';

interface DeliveryAcceptanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccept: () => void;
  onReturn: (returnFees: { buyerFee: number; driverEarnings: number; isPartnerReturn: boolean; partnerTier?: string }) => void;
  itemName: string;
  orderId: string;
  deliveryDistance: number;
  isPartnerItem?: boolean;
  partnerTier?: 'silver' | 'gold' | 'platinum';
}

interface ReturnFees {
  buyerFee: number;
  driverEarnings: number;
  totalCost: number;
  originalFee: number;
  discount: number;
  isPartnerReturn: boolean;
  partnerTier?: string;
}

const DeliveryAcceptanceModal: React.FC<DeliveryAcceptanceModalProps> = ({
  isOpen,
  onClose,
  onAccept,
  onReturn,
  itemName,
  orderId,
  deliveryDistance,
  isPartnerItem = false,
  partnerTier
}) => {
  const [selectedAction, setSelectedAction] = useState<'accept' | 'return' | null>(null);
  const [returnFees, setReturnFees] = useState<ReturnFees>({
    buyerFee: 0,
    driverEarnings: 0,
    totalCost: 0,
    originalFee: 0,
    discount: 0,
    isPartnerReturn: false
  });

  const handleConfirm = () => {
    if (selectedAction === 'accept') {
      onAccept();
    } else if (selectedAction === 'return') {
      onReturn({
        buyerFee: returnFees.buyerFee,
        driverEarnings: returnFees.driverEarnings,
        isPartnerReturn: isPartnerItem,
        partnerTier
      });
    }
    onClose();
  };

  const handleReturnCalculation = (fees: ReturnFees) => {
    setReturnFees(fees);
  };

  const getPartnerIcon = () => {
    switch (partnerTier) {
      case 'silver': return <Star className="w-3 h-3 mr-1" />;
      case 'gold': return <Crown className="w-3 h-3 mr-1" />;
      case 'platinum': return <Diamond className="w-3 h-3 mr-1" />;
      default: return <Users className="w-3 h-3 mr-1" />;
    }
  };

  const getPartnerColor = () => {
    switch (partnerTier) {
      case 'silver': return 'bg-gray-100 text-gray-800';
      case 'gold': return 'bg-yellow-100 text-yellow-800';
      case 'platinum': return 'bg-purple-100 text-purple-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getReturnBenefit = () => {
    switch (partnerTier) {
      case 'silver': return '50% off return fees';
      case 'gold':
      case 'platinum': return 'FREE returns';
      default: return 'Standard return rates';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            Item Delivered - Action Required
            {isPartnerItem && partnerTier && (
              <Badge className={getPartnerColor()}>
                {getPartnerIcon()}
                {partnerTier.charAt(0).toUpperCase() + partnerTier.slice(1)} Partner
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="bg-green-50 p-3 rounded-lg">
            <p className="text-sm text-green-800">
              <strong>Order #{orderId}</strong>
            </p>
            <p className="text-sm text-green-700 mt-1">{itemName}</p>
            <Badge className="bg-green-600 mt-2">Delivered Successfully</Badge>
          </div>
          
          <div className="space-y-3">
            <p className="text-sm text-gray-600">
              Please choose whether to accept or return this item:
            </p>
            
            <div className="space-y-2">
              <Button
                variant={selectedAction === 'accept' ? 'default' : 'outline'}
                className="w-full justify-start"
                onClick={() => setSelectedAction('accept')}
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Accept Item - I'm satisfied with my order
              </Button>
              
              <Button
                variant={selectedAction === 'return' ? 'destructive' : 'outline'}
                className="w-full justify-start"
                onClick={() => setSelectedAction('return')}
              >
                <XCircle className="w-4 h-4 mr-2" />
                Return Item - Not as expected
                {isPartnerItem && partnerTier && (
                  <Badge className="ml-2 text-xs bg-green-100 text-green-800">
                    {getReturnBenefit()}
                  </Badge>
                )}
              </Button>
            </div>
          </div>
          
          {selectedAction === 'return' && (
            <div className="space-y-3">
              {isPartnerItem && partnerTier && (
                <div className={`p-3 rounded-lg border ${getPartnerColor().replace('text-', 'border-').replace('bg-', 'bg-').replace('-100', '-50').replace('-800', '-200')}`}>
                  <div className="flex items-start gap-2 mb-2">
                    {getPartnerIcon()}
                    <div className="text-sm">
                      <p className="font-medium">
                        {partnerTier.charAt(0).toUpperCase() + partnerTier.slice(1)} Partner Return Benefits
                      </p>
                      <p className="text-green-700 font-medium">
                        {partnerTier === 'silver' && '✨ 50% off all return fees!'}
                        {(partnerTier === 'gold' || partnerTier === 'platinum') && '✨ Completely FREE returns!'}
                      </p>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="bg-blue-50 p-3 rounded-lg">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-blue-600 mt-0.5" />
                  <div className="text-sm text-blue-800">
                    <p className="font-medium">Return Policy</p>
                    <p>Return will be automatically added to a delivery route for pickup.</p>
                    {isPartnerItem && partnerTier && (
                      <p className="mt-1 font-medium text-green-700">
                        ✨ Partner return - {getReturnBenefit()}!
                      </p>
                    )}
                  </div>
                </div>
              </div>
              
              <ReturnCalculator 
                distance={deliveryDistance}
                isPartnerReturn={isPartnerItem}
                partnerTier={partnerTier}
                onCalculate={handleReturnCalculation}
              />
            </div>
          )}
          
          <div className="bg-yellow-50 p-3 rounded-lg">
            <p className="text-xs text-yellow-800">
              <strong>Note:</strong> After making your choice, you'll have the option to tip your driver.
              {isPartnerItem && selectedAction === 'return' && (
                <span className="block mt-1 text-green-700 font-medium">
                  Driver receives full payment regardless of partner discounts.
                </span>
              )}
            </p>
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={handleConfirm} 
              className="flex-1"
              disabled={!selectedAction}
            >
              Confirm Choice
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DeliveryAcceptanceModal;