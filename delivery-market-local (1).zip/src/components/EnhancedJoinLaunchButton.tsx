import React, { useState } from 'react';
import { Button } from './ui/button';
import { Users, Rocket } from 'lucide-react';
import EnhancedAuthModal from './EnhancedAuthModal';

interface EnhancedJoinLaunchButtonProps {
  className?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  text?: string;
}

const EnhancedJoinLaunchButton: React.FC<EnhancedJoinLaunchButtonProps> = ({
  className = '',
  variant = 'default',
  size = 'md',
  text = 'Join MarketPace'
}) => {
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleJoinClick = () => {
    setShowAuthModal(true);
  };

  return (
    <>
      <Button
        onClick={handleJoinClick}
        className={`bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white font-semibold transition-all duration-300 transform hover:scale-105 ${className}`}
        variant={variant}
        size={size}
      >
        <Rocket className="w-4 h-4 mr-2" />
        {text}
      </Button>
      
      <EnhancedAuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        defaultTab="signup"
      />
    </>
  );
};

export default EnhancedJoinLaunchButton;