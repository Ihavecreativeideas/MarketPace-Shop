import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Upload, FileImage, X } from 'lucide-react';

interface DriverLicenseUploadProps {
  onFileUpload: (file: File | null) => void;
  uploadedFile: File | null;
}

const DriverLicenseUpload: React.FC<DriverLicenseUploadProps> = ({ onFileUpload, uploadedFile }) => {
  const [dragActive, setDragActive] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      handleFile(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      handleFile(files[0]);
    }
  };

  const handleFile = (file: File) => {
    if (file.type.startsWith('image/')) {
      onFileUpload(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      alert('Please upload an image file');
    }
  };

  const removeFile = () => {
    onFileUpload(null);
    setPreview(null);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileImage className="w-5 h-5" />
          Driver's License Photo *
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!uploadedFile ? (
          <div
            className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
              dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <p className="text-gray-600 mb-4">
              Drag and drop your driver's license photo here, or click to select
            </p>
            <Input
              type="file"
              accept="image/*"
              onChange={handleFileInput}
              className="hidden"
              id="license-upload"
            />
            <Label htmlFor="license-upload">
              <Button type="button" variant="outline" className="cursor-pointer">
                Select File
              </Button>
            </Label>
            <p className="text-sm text-gray-500 mt-2">
              Accepted formats: JPG, PNG, GIF (Max 5MB)
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {preview && (
              <div className="relative">
                <img
                  src={preview}
                  alt="Driver's License Preview"
                  className="max-w-full h-48 object-contain mx-auto border rounded"
                />
                <Button
                  type="button"
                  variant="destructive"
                  size="sm"
                  className="absolute top-2 right-2"
                  onClick={removeFile}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            )}
            <p className="text-green-600 text-center">
              ✓ Driver's License uploaded: {uploadedFile.name}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default DriverLicenseUpload;