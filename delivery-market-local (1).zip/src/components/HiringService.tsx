import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Briefcase, Plus, Search, MapPin, Clock, DollarSign } from 'lucide-react';
import JobPostModal from './JobPostModal';
import WorkSeekerModal from './WorkSeekerModal';

interface JobPosting {
  id: string;
  title: string;
  company: string;
  location: string;
  type: 'full-time' | 'part-time' | 'contract' | 'freelance';
  salary: string;
  description: string;
  requirements: string[];
  postedDate: string;
  isUrgent?: boolean;
}

interface WorkSeeker {
  id: string;
  name: string;
  title: string;
  location: string;
  skills: string[];
  experience: string;
  availability: string;
  postedDate: string;
}

const HiringService: React.FC = () => {
  const [activeTab, setActiveTab] = useState('jobs');
  const [searchTerm, setSearchTerm] = useState('');
  const [showJobModal, setShowJobModal] = useState(false);
  const [showWorkSeekerModal, setShowWorkSeekerModal] = useState(false);

  const mockJobs: JobPosting[] = [
    {
      id: '1',
      title: 'Delivery Driver',
      company: 'Local Restaurant',
      location: 'Downtown',
      type: 'part-time',
      salary: '$15-20/hour + tips',
      description: 'Looking for reliable delivery drivers for evening shifts',
      requirements: ['Valid driver license', 'Own vehicle', 'Clean driving record'],
      postedDate: '2 days ago',
      isUrgent: true
    },
    {
      id: '2',
      title: 'Handyman',
      company: 'Property Management Co',
      location: 'Various locations',
      type: 'contract',
      salary: '$25-35/hour',
      description: 'General maintenance and repair work for rental properties',
      requirements: ['Basic tools', '2+ years experience', 'Reliable transportation'],
      postedDate: '1 week ago'
    }
  ];

  const mockWorkSeekers: WorkSeeker[] = [
    {
      id: '1',
      name: 'John D.',
      title: 'Experienced Driver',
      location: 'City Center',
      skills: ['Commercial driving', 'Customer service', 'GPS navigation'],
      experience: '5 years delivery experience',
      availability: 'Evenings and weekends',
      postedDate: '3 days ago'
    }
  ];

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Briefcase className="h-8 w-8" />
          Hiring Center
        </h1>
        <p className="text-muted-foreground">
          Connect employers with job seekers in your local area
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="jobs">Job Opportunities</TabsTrigger>
          <TabsTrigger value="seekers">Work Seekers</TabsTrigger>
        </TabsList>

        <div className="mt-6 mb-4 flex gap-2">
          <Input
            placeholder="Search jobs, skills, locations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1"
          />
          <Button variant="outline">
            <Search className="h-4 w-4" />
          </Button>
        </div>

        <TabsContent value="jobs" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Available Positions</h2>
            <Button onClick={() => setShowJobModal(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Post Job
            </Button>
          </div>

          <div className="grid gap-4">
            {mockJobs.map((job) => (
              <Card key={job.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {job.title}
                        {job.isUrgent && (
                          <Badge variant="destructive">Urgent</Badge>
                        )}
                      </CardTitle>
                      <p className="text-muted-foreground">{job.company}</p>
                    </div>
                    <Badge variant="outline">{job.type}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {job.location}
                      </div>
                      <div className="flex items-center gap-1">
                        <DollarSign className="h-4 w-4" />
                        {job.salary}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {job.postedDate}
                      </div>
                    </div>
                    
                    <p className="text-sm">{job.description}</p>
                    
                    <div className="flex flex-wrap gap-1">
                      {job.requirements.map((req, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {req}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex gap-2 pt-2">
                      <Button size="sm">Apply Now</Button>
                      <Button size="sm" variant="outline">Save Job</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="seekers" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">People Looking for Work</h2>
            <Button onClick={() => setShowWorkSeekerModal(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Post Work Availability
            </Button>
          </div>

          <div className="grid gap-4">
            {mockWorkSeekers.map((seeker) => (
              <Card key={seeker.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle>{seeker.name}</CardTitle>
                  <p className="text-muted-foreground">{seeker.title}</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {seeker.location}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {seeker.postedDate}
                      </div>
                    </div>
                    
                    <p className="text-sm"><strong>Experience:</strong> {seeker.experience}</p>
                    <p className="text-sm"><strong>Availability:</strong> {seeker.availability}</p>
                    
                    <div className="flex flex-wrap gap-1">
                      {seeker.skills.map((skill, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex gap-2 pt-2">
                      <Button size="sm">Contact</Button>
                      <Button size="sm" variant="outline">View Profile</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <JobPostModal 
        isOpen={showJobModal} 
        onClose={() => setShowJobModal(false)} 
      />
      <WorkSeekerModal 
        isOpen={showWorkSeekerModal} 
        onClose={() => setShowWorkSeekerModal(false)} 
      />
    </div>
  );
};

export default HiringService;