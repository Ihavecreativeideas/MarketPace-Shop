import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Search, Filter, X } from 'lucide-react';

interface ForHireSearchBarProps {
  onSearch: (query: string, category: string, filters: string[]) => void;
  onClear: () => void;
}

const ForHireSearchBar: React.FC<ForHireSearchBarProps> = ({ onSearch, onClear }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [activeFilters, setActiveFilters] = useState<string[]>([]);

  const categories = [
    { value: 'all', label: 'All For Hire' },
    { value: 'dj', label: 'DJs' },
    { value: 'soundman', label: 'Sound Engineers' },
    { value: 'musician', label: 'Musicians' },
    { value: 'band', label: 'Bands' },
    { value: 'duo', label: 'Duos' },
    { value: 'solo', label: 'Solo Artists' },
    { value: 'songwriter', label: 'Songwriters' },
    { value: 'cover-band', label: 'Cover Bands' }
  ];

  const filterOptions = [
    'Available Now',
    'Weekends Only',
    'Verified',
    'Pro Subscriber',
    'Under $200/hr',
    'Experienced (5+ years)',
    'Own Equipment',
    'Travel Willing'
  ];

  const handleSearch = () => {
    onSearch(searchQuery, selectedCategory, activeFilters);
  };

  const handleFilterToggle = (filter: string) => {
    setActiveFilters(prev => 
      prev.includes(filter) 
        ? prev.filter(f => f !== filter)
        : [...prev, filter]
    );
  };

  const handleClear = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setActiveFilters([]);
    onClear();
  };

  return (
    <div className="bg-white border border-purple-200 rounded-lg p-4 space-y-4">
      <div className="flex items-center gap-2 text-purple-700 font-medium">
        <Search className="w-5 h-5" />
        <span>Search For Hire</span>
      </div>
      
      <div className="flex flex-col md:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search by name, genre, or skill..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
          />
        </div>
        
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-full md:w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {categories.map(cat => (
              <SelectItem key={cat.value} value={cat.value}>
                {cat.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Button onClick={handleSearch} className="bg-purple-600 hover:bg-purple-700">
          Search
        </Button>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Filter className="w-4 h-4" />
          <span>Quick Filters:</span>
        </div>
        
        <div className="flex flex-wrap gap-2">
          {filterOptions.map(filter => (
            <Badge
              key={filter}
              variant={activeFilters.includes(filter) ? "default" : "outline"}
              className={`cursor-pointer transition-colors ${
                activeFilters.includes(filter) 
                  ? 'bg-purple-600 hover:bg-purple-700' 
                  : 'hover:bg-purple-50'
              }`}
              onClick={() => handleFilterToggle(filter)}
            >
              {filter}
            </Badge>
          ))}
        </div>
        
        {(searchQuery || selectedCategory !== 'all' || activeFilters.length > 0) && (
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClear}
            className="text-purple-600 hover:text-purple-700"
          >
            <X className="w-4 h-4 mr-1" />
            Clear All
          </Button>
        )}
      </div>
    </div>
  );
};

export default ForHireSearchBar;