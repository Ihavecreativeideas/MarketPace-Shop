import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Flag } from 'lucide-react';

interface USAMadeBadgeProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const USAMadeBadge: React.FC<USAMadeBadgeProps> = ({ className = '', size = 'md' }) => {
  const sizeClasses = {
    sm: 'text-xs px-2 py-1',
    md: 'text-sm px-3 py-1',
    lg: 'text-base px-4 py-2'
  };

  return (
    <Badge 
      className={`bg-red-600 hover:bg-red-700 text-white border-0 ${sizeClasses[size]} ${className}`}
    >
      <Flag className={`${size === 'sm' ? 'h-3 w-3' : size === 'lg' ? 'h-5 w-5' : 'h-4 w-4'} mr-1`} />
      USA Made
    </Badge>
  );
};

export default USAMadeBadge;