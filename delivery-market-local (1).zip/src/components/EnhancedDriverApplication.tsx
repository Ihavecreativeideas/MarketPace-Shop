import React, { useState } from 'react';
import { BackButton } from './BackButton';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Alert, AlertDescription } from './ui/alert';
import { UserCheck, Shield, CheckCircle, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import DriverLicenseUpload from './DriverLicenseUpload';
import BackgroundCheckUpload from './BackgroundCheckUpload';
import VehicleTypeSelector from './VehicleTypeSelector';
import DeliveryTypeSelector from './DeliveryTypeSelector';
import DriverJobDescription from './DriverJobDescription';

const EnhancedDriverApplication: React.FC = () => {
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', phone: '', vehicleType: '',
    hasInsurance: false, hasDriversLicense: false, hasBackgroundCheck: false
  });
  const [deliveryTypes, setDeliveryTypes] = useState<string[]>([]);
  const [licenseFile, setLicenseFile] = useState<File | null>(null);
  const [backgroundFile, setBackgroundFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [applicationStatus, setApplicationStatus] = useState<'pending' | 'submitted' | 'approved' | 'rejected'>('pending');
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!licenseFile || !backgroundFile || !formData.vehicleType || deliveryTypes.length === 0) {
      alert('Please complete all required fields and upload documents.');
      return;
    }
    
    setIsSubmitting(true);
    setApplicationStatus('submitted');
    
    try {
      // Simulate AI approval process
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      const aiApprovalResponse = await fetch('https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/0801246c-b0bf-4774-9d2c-89520ad05718', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          firstName: formData.firstName,
          lastName: formData.lastName,
          email: formData.email,
          phone: formData.phone,
          vehicleType: formData.vehicleType,
          deliveryTypes,
          hasInsurance: formData.hasInsurance,
          hasDriversLicense: formData.hasDriversLicense,
          hasBackgroundCheck: formData.hasBackgroundCheck
        })
      });
      
      const result = await aiApprovalResponse.json();
      
      if (result.approved) {
        setApplicationStatus('approved');
        alert(`🎉 Application Approved!\n\nWelcome to MarketPace!\nUsername: ${result.credentials.username}\nPassword: ${result.credentials.password}\n\nYou can now start earning immediately!`);
        setTimeout(() => navigate('/driver-dashboard'), 2000);
      } else {
        setApplicationStatus('rejected');
        alert(`Application needs review: ${result.reason}\n\nPlease contact support or resubmit with corrections.`);
      }
    } catch (error) {
      setApplicationStatus('pending');
      alert('Error processing application. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isFormValid = formData.hasInsurance && formData.hasDriversLicense && 
    formData.hasBackgroundCheck && licenseFile && backgroundFile && 
    formData.vehicleType && deliveryTypes.length > 0;

  if (applicationStatus === 'submitted') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardContent className="text-center p-8">
            <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <h3 className="text-lg font-semibold mb-2">AI Processing Your Application</h3>
            <p className="text-gray-600 text-sm">Our AI is reviewing your documents and qualifications...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (applicationStatus === 'approved') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardContent className="text-center p-8">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-green-700 mb-2">Application Approved!</h3>
            <p className="text-gray-600">Welcome to MarketPace! Redirecting to your dashboard...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <BackButton to="/" />
        
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Driver Application</h1>
          <p className="text-gray-600">Join MarketPace as an Independent Contractor Driver</p>
        </div>

        <DriverJobDescription />

        <Alert className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Application received notification:</strong> You'll be notified immediately when 
            your application is received and processed by our AI approval system.
          </AlertDescription>
        </Alert>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCheck className="w-5 h-5" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input 
                    id="firstName" 
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input 
                    id="lastName" 
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                  />
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input 
                    id="phone" 
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Vehicle & Delivery Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <VehicleTypeSelector 
                value={formData.vehicleType}
                onChange={(value) => setFormData({...formData, vehicleType: value})}
              />
              <DeliveryTypeSelector 
                selectedTypes={deliveryTypes}
                onChange={setDeliveryTypes}
              />
            </CardContent>
          </Card>

          <DriverLicenseUpload 
            onFileUpload={setLicenseFile} 
            uploadedFile={licenseFile} 
          />
          
          <BackgroundCheckUpload 
            onFileUpload={setBackgroundFile} 
            uploadedFile={backgroundFile} 
          />

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Requirements Confirmation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="insurance" 
                  checked={formData.hasInsurance}
                  onCheckedChange={(checked) => setFormData({...formData, hasInsurance: !!checked})}
                />
                <Label htmlFor="insurance">I have valid vehicle insurance *</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="license" 
                  checked={formData.hasDriversLicense}
                  onCheckedChange={(checked) => setFormData({...formData, hasDriversLicense: !!checked})}
                />
                <Label htmlFor="license">I have a valid driver's license *</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="background" 
                  checked={formData.hasBackgroundCheck}
                  onCheckedChange={(checked) => setFormData({...formData, hasBackgroundCheck: !!checked})}
                />
                <Label htmlFor="background">I have provided my own background check *</Label>
              </div>
            </CardContent>
          </Card>

          <div className="text-center">
            <Button 
              type="submit" 
              size="lg" 
              className="bg-blue-600 hover:bg-blue-700 px-8"
              disabled={isSubmitting || !isFormValid}
            >
              {isSubmitting ? 'Processing...' : 'Submit Application for AI Review'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export { EnhancedDriverApplication };
export default EnhancedDriverApplication;