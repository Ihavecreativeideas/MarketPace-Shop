import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { CheckCircle, AlertCircle, Store, RefreshCw, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import { DeliveryRequirements } from './DeliveryRequirements';

interface TikTokShop {
  id: string;
  shop_name: string;
  shop_url: string;
  access_token: string;
  status: 'active' | 'inactive' | 'pending';
  created_at: string;
  last_sync: string;
  is_partner?: boolean;
}

export function TikTokShopManager() {
  const [shops, setShops] = useState<TikTokShop[]>([]);
  const [newShopUrl, setNewShopUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchShops();
  }, []);

  const fetchShops = async () => {
    try {
      const { data, error } = await supabase
        .from('tiktok_shops')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setShops(data || []);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch TikTok shops',
        variant: 'destructive'
      });
    }
  };

  const connectShop = async () => {
    if (!newShopUrl.trim()) return;

    setLoading(true);
    try {
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/d4b086fc-540e-4998-9ec0-739e8d9367d8',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ shop_url: newShopUrl, action: 'connect' })
        }
      );

      const result = await response.json();
      
      if (result.success) {
        toast({
          title: 'Success',
          description: 'TikTok shop connected successfully'
        });
        setNewShopUrl('');
        fetchShops();
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to connect TikTok shop',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <DeliveryRequirements shopType="tiktok" />
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Store className="h-5 w-5" />
            TikTok Shop Integration
          </CardTitle>
          <CardDescription>
            Connect your TikTok shops to MarketPace for local delivery integration
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter TikTok shop URL"
              value={newShopUrl}
              onChange={(e) => setNewShopUrl(e.target.value)}
            />
            <Button onClick={connectShop} disabled={loading}>
              {loading ? 'Connecting...' : 'Connect Shop'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4">
        {shops.map((shop) => (
          <Card key={shop.id}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <h3 className="font-semibold">{shop.shop_name}</h3>
                  <p className="text-sm text-muted-foreground">{shop.shop_url}</p>
                  <div className="flex items-center gap-2">
                    <Badge variant={shop.status === 'active' ? 'default' : 'secondary'}>
                      {shop.status === 'active' && <CheckCircle className="h-3 w-3 mr-1" />}
                      {shop.status === 'inactive' && <AlertCircle className="h-3 w-3 mr-1" />}
                      {shop.status}
                    </Badge>
                    {shop.is_partner && (
                      <Badge className="bg-purple-600">Partner Shop</Badge>
                    )}
                  </div>
                </div>
              </div>
              {shop.is_partner && (
                <DeliveryRequirements isPartner={true} shopType="tiktok" />
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}