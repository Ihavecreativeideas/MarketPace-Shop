import React from 'react';
import { Rocket } from 'lucide-react';

const FloatingIcon: React.FC = () => {
  return (
    <div className="fixed top-8 right-8 z-50 pointer-events-none">
      {/* Floating particles around icon */}
      <div className="relative">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400 rounded-full animate-ping"
            style={{
              left: `${20 + Math.cos(i * 45 * Math.PI / 180) * 25}px`,
              top: `${20 + Math.sin(i * 45 * Math.PI / 180) * 25}px`,
              animationDelay: `${i * 0.2}s`,
              animationDuration: '2s'
            }}
          />
        ))}
        
        {/* Main floating icon */}
        <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-cyan-500 rounded-full flex items-center justify-center shadow-lg animate-bounce">
          <Rocket className="w-6 h-6 text-white" />
        </div>
        
        {/* Glowing effect */}
        <div className="absolute inset-0 w-12 h-12 bg-gradient-to-r from-purple-600/50 to-cyan-500/50 rounded-full blur-lg animate-pulse" />
      </div>
    </div>
  );
};

export default FloatingIcon;