import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Play, Users, Calendar, MapPin, Heart, MessageCircle, Share2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface CommunityPost {
  id: string;
  type: 'livestream' | 'event' | 'update';
  author: string;
  avatar: string;
  title: string;
  description: string;
  location: string;
  timestamp: string;
  likes: number;
  comments: number;
  isLive?: boolean;
  eventDate?: string;
}

const CommunitySection: React.FC = () => {
  const [userLocation] = useState('Springfield'); // This would come from user's actual location
  
  const [posts] = useState<CommunityPost[]>([
    {
      id: '1',
      type: 'livestream',
      author: 'Mike\'s Music Store',
      avatar: '/api/placeholder/40/40',
      title: 'Live Guitar Demo - New Arrivals',
      description: 'Showcasing our latest acoustic guitars and taking requests!',
      location: 'Springfield',
      timestamp: '2 minutes ago',
      likes: 24,
      comments: 8,
      isLive: true
    },
    {
      id: '2',
      type: 'event',
      author: 'Local Jazz Band',
      avatar: '/api/placeholder/40/40',
      title: 'Jazz Night at Central Park',
      description: 'Free outdoor concert this Friday evening. Bring your own chairs!',
      location: 'Springfield',
      timestamp: '1 hour ago',
      likes: 45,
      comments: 12,
      eventDate: 'Friday, 8:00 PM'
    },
    {
      id: '3',
      type: 'update',
      author: 'Springfield Bakery',
      avatar: '/api/placeholder/40/40',
      title: 'Fresh Bread Sale - 50% Off',
      description: 'All artisan breads half price today only! While supplies last.',
      location: 'Springfield',
      timestamp: '3 hours ago',
      likes: 67,
      comments: 15
    }
  ]);

  const handleLike = (postId: string) => {
    toast({ title: 'Liked!', description: 'Post added to your favorites' });
  };

  const handleComment = (postId: string) => {
    toast({ title: 'Comment', description: 'Comment feature coming soon!' });
  };

  const handleShare = (postId: string) => {
    toast({ title: 'Shared!', description: 'Post shared successfully' });
  };

  const getPostIcon = (type: string) => {
    switch (type) {
      case 'livestream': return Play;
      case 'event': return Calendar;
      default: return MessageCircle;
    }
  };

  const getPostColor = (type: string) => {
    switch (type) {
      case 'livestream': return 'bg-red-500';
      case 'event': return 'bg-purple-500';
      default: return 'bg-blue-500';
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {/* Location Header */}
      <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
        <CardContent className="p-4">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            <h2 className="text-lg font-semibold">Community - {userLocation}</h2>
          </div>
          <p className="text-sm opacity-90 mt-1">
            Local live streams, events, and updates from your area
          </p>
        </CardContent>
      </Card>

      {/* Posts */}
      {posts.map((post) => {
        const Icon = getPostIcon(post.type);
        return (
          <Card key={post.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={post.avatar} />
                    <AvatarFallback>{post.author[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{post.author}</h3>
                      <Badge 
                        variant="secondary" 
                        className={`${getPostColor(post.type)} text-white`}
                      >
                        <Icon className="w-3 h-3 mr-1" />
                        {post.type === 'livestream' ? 'LIVE' : post.type.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-500">{post.timestamp}</p>
                  </div>
                </div>
                {post.isLive && (
                  <div className="flex items-center gap-1 text-red-500">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                    <span className="text-xs font-medium">LIVE</span>
                  </div>
                )}
              </div>
            </CardHeader>
            
            <CardContent className="pt-0">
              <h4 className="font-semibold mb-2">{post.title}</h4>
              <p className="text-gray-600 mb-3">{post.description}</p>
              
              {post.eventDate && (
                <div className="flex items-center gap-2 mb-3 text-sm text-purple-600">
                  <Calendar className="w-4 h-4" />
                  <span>{post.eventDate}</span>
                </div>
              )}
              
              <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                <MapPin className="w-4 h-4" />
                <span>{post.location}</span>
              </div>
              
              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-3 border-t">
                <div className="flex items-center gap-4">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleLike(post.id)}
                    className="flex items-center gap-1 text-gray-600 hover:text-red-500"
                  >
                    <Heart className="w-4 h-4" />
                    <span>{post.likes}</span>
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleComment(post.id)}
                    className="flex items-center gap-1 text-gray-600 hover:text-blue-500"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{post.comments}</span>
                  </Button>
                </div>
                
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => handleShare(post.id)}
                  className="flex items-center gap-1 text-gray-600 hover:text-green-500"
                >
                  <Share2 className="w-4 h-4" />
                  Share
                </Button>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};

export default CommunitySection;