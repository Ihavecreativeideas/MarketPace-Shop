import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Zap, TrendingUp, Eye, Clock, DollarSign } from 'lucide-react';

const boostOptions = [
  {
    name: 'Quick Boost',
    duration: '24 hours',
    price: '$5',
    visibility: '2x',
    description: 'Double your product visibility for a day'
  },
  {
    name: 'Power Boost',
    duration: '7 days',
    price: '$25',
    visibility: '3x',
    description: 'Triple visibility for a full week'
  },
  {
    name: 'Mega Boost',
    duration: '30 days',
    price: '$80',
    visibility: '5x',
    description: 'Maximum visibility for a month'
  }
];

interface ProductBoostModalProps {
  productName: string;
  children: React.ReactNode;
}

export default function ProductBoostModal({ productName, children }: ProductBoostModalProps) {
  const [selectedBoost, setSelectedBoost] = useState(0);
  const [customBudget, setCustomBudget] = useState('');

  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Zap className="h-6 w-6 text-lime-500" />
            Boost "{productName}"
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-blue-50 to-lime-50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-800 mb-2">How Product Boosting Works</h3>
            <p className="text-sm text-gray-600">
              Boosted products appear higher in search results and get featured placement. 
              More visibility = more sales!
            </p>
          </div>

          <div className="grid gap-4">
            <Label className="text-base font-semibold">Choose Your Boost Level:</Label>
            {boostOptions.map((option, index) => (
              <Card 
                key={index} 
                className={`cursor-pointer transition-all ${
                  selectedBoost === index 
                    ? 'border-2 border-blue-500 bg-blue-50' 
                    : 'border border-gray-200 hover:border-lime-300'
                }`}
                onClick={() => setSelectedBoost(index)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{option.name}</CardTitle>
                    <Badge className="bg-gradient-to-r from-blue-600 to-lime-500 text-white">
                      {option.visibility} visibility
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm text-gray-600">{option.description}</p>
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {option.duration}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="h-3 w-3" />
                          {option.visibility} more views
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-blue-600">{option.price}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="space-y-3">
            <Label htmlFor="custom-budget">Or Set Custom Budget:</Label>
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-gray-500" />
              <Input
                id="custom-budget"
                placeholder="Enter amount"
                value={customBudget}
                onChange={(e) => setCustomBudget(e.target.value)}
                className="flex-1"
              />
            </div>
          </div>

          <div className="bg-lime-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-5 w-5 text-lime-600" />
              <span className="font-semibold text-lime-800">Expected Results</span>
            </div>
            <p className="text-sm text-lime-700">
              Based on similar products, you can expect {boostOptions[selectedBoost].visibility} more views 
              and up to 40% increase in sales during the boost period.
            </p>
          </div>

          <div className="flex gap-3">
            <Button 
              className="flex-1 bg-gradient-to-r from-blue-600 to-lime-500 hover:from-blue-700 hover:to-lime-600 text-white"
              size="lg"
            >
              <Zap className="h-4 w-4 mr-2" />
              Start Boost - {boostOptions[selectedBoost].price}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}