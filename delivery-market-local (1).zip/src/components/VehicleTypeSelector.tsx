import React from 'react';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Car, Truck, Bike } from 'lucide-react';

interface VehicleTypeSelectorProps {
  value: string;
  onChange: (value: string) => void;
}

const VehicleTypeSelector: React.FC<VehicleTypeSelectorProps> = ({ value, onChange }) => {
  return (
    <div className="space-y-4">
      <Label className="text-base font-medium">Vehicle Type *</Label>
      <RadioGroup value={value} onValueChange={onChange}>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="car" id="car" />
          <Label htmlFor="car" className="flex items-center gap-2">
            <Car className="w-4 h-4" />
            Car/SUV
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="truck" id="truck" />
          <Label htmlFor="truck" className="flex items-center gap-2">
            <Truck className="w-4 h-4" />
            Truck/Van
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="bike" id="bike" />
          <Label htmlFor="bike" className="flex items-center gap-2">
            <Bike className="w-4 h-4" />
            Bike/Scooter
          </Label>
        </div>
      </RadioGroup>
    </div>
  );
};

export default VehicleTypeSelector;