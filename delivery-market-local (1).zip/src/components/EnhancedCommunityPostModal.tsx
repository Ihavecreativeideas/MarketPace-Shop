import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { X, Camera, Video, MessageSquare, Search, BarChart3, Image, MapPin } from 'lucide-react';

interface EnhancedCommunityPostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (postData: any) => void;
}

const EnhancedCommunityPostModal: React.FC<EnhancedCommunityPostModalProps> = ({ isOpen, onClose, onSubmit }) => {
  const [activeTab, setActiveTab] = useState('thought');
  const [content, setContent] = useState('');
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('');
  const [images, setImages] = useState<File[]>([]);
  const [category, setCategory] = useState('');
  const [isoType, setIsoType] = useState('service');

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setImages(prev => [...prev, ...files].slice(0, 5));
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    const postData = {
      type: activeTab,
      content: content.trim(),
      title: title.trim(),
      location: location.trim(),
      images,
      category,
      isoType: activeTab === 'iso' ? isoType : undefined,
      createdAt: new Date().toISOString()
    };
    
    onSubmit(postData);
    resetForm();
    onClose();
  };

  const resetForm = () => {
    setContent('');
    setTitle('');
    setLocation('');
    setImages([]);
    setCategory('');
    setIsoType('service');
    setActiveTab('thought');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-slate-800 border-slate-700 max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-white">Create Post</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5 mb-4">
              <TabsTrigger value="thought" className="text-xs">
                <MessageSquare className="h-4 w-4 mr-1" />
                Thought
              </TabsTrigger>
              <TabsTrigger value="picture" className="text-xs">
                <Camera className="h-4 w-4 mr-1" />
                Picture
              </TabsTrigger>
              <TabsTrigger value="livestream" className="text-xs">
                <Video className="h-4 w-4 mr-1" />
                Live
              </TabsTrigger>
              <TabsTrigger value="iso" className="text-xs">
                <Search className="h-4 w-4 mr-1" />
                ISO
              </TabsTrigger>
              <TabsTrigger value="poll" className="text-xs">
                <BarChart3 className="h-4 w-4 mr-1" />
                Poll
              </TabsTrigger>
            </TabsList>

            <TabsContent value="thought" className="space-y-4">
              <Textarea
                placeholder="What's on your mind?"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="bg-slate-700/50 border-slate-600 text-white min-h-[120px]"
              />
              <div className="flex gap-2">
                <Input
                  placeholder="Add location (optional)"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="bg-slate-700/50 border-slate-600 text-white"
                />
                <MapPin className="h-4 w-4 text-slate-400 mt-3" />
              </div>
            </TabsContent>

            <TabsContent value="picture" className="space-y-4">
              <Textarea
                placeholder="Share your photos with the community..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="bg-slate-700/50 border-slate-600 text-white"
              />
              <div className="space-y-2">
                <label className="text-sm text-slate-300">Upload Images (max 5)</label>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleImageUpload}
                  className="w-full bg-slate-700/50 border border-slate-600 text-white rounded-md px-3 py-2"
                />
                {images.length > 0 && (
                  <div className="grid grid-cols-3 gap-2 mt-2">
                    {images.map((image, index) => (
                      <div key={index} className="relative">
                        <div className="bg-slate-700 h-20 rounded flex items-center justify-center">
                          <Image className="h-6 w-6 text-slate-400" />
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeImage(index)}
                          className="absolute -top-2 -right-2 h-6 w-6 p-0 bg-red-500 hover:bg-red-600 text-white rounded-full"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="livestream" className="space-y-4">
              <div className="text-center p-8 bg-slate-700/30 rounded-lg">
                <Video className="h-16 w-16 text-slate-400 mx-auto mb-4" />
                <h3 className="text-white font-semibold mb-2">Start Livestream</h3>
                <p className="text-slate-400 text-sm mb-4">Go live and connect with your community in real-time</p>
                <Button className="bg-red-500 hover:bg-red-600 text-white">
                  <Video className="h-4 w-4 mr-2" />
                  Go Live
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="iso" className="space-y-4">
              <Input
                placeholder="What are you looking for?"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="bg-slate-700/50 border-slate-600 text-white"
              />
              <Textarea
                placeholder="Describe what you need in detail..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="bg-slate-700/50 border-slate-600 text-white"
              />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-slate-300 mb-2 block">Category</label>
                  <select
                    value={isoType}
                    onChange={(e) => setIsoType(e.target.value)}
                    className="w-full bg-slate-700/50 border border-slate-600 text-white rounded-md px-3 py-2"
                  >
                    <option value="service">Service</option>
                    <option value="item">Item</option>
                    <option value="housing">Housing</option>
                    <option value="job">Job</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-slate-300 mb-2 block">Location</label>
                  <Input
                    placeholder="Where?"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="bg-slate-700/50 border-slate-600 text-white"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="poll" className="space-y-4">
              <div className="text-center p-8 bg-slate-700/30 rounded-lg">
                <BarChart3 className="h-16 w-16 text-slate-400 mx-auto mb-4" />
                <h3 className="text-white font-semibold mb-2">Create Poll</h3>
                <p className="text-slate-400 text-sm mb-4">Get community feedback on your questions</p>
                <Button className="bg-teal-500 hover:bg-teal-600 text-white">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Create Poll
                </Button>
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex gap-2 pt-4 border-t border-slate-700 mt-6">
            <Button 
              onClick={handleSubmit}
              className="bg-teal-500 hover:bg-teal-600 flex-1"
              disabled={!content.trim() && !title.trim()}
            >
              Post
            </Button>
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EnhancedCommunityPostModal;
export { EnhancedCommunityPostModal };