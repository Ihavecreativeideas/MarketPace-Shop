import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Truck, MapPin, Clock } from 'lucide-react';

interface DeliveryFeeCalculatorProps {
  pickupCount: number;
  dropoffCount: number;
  totalMiles: number;
  showBreakdown?: boolean;
}

export const DeliveryFeeCalculator: React.FC<DeliveryFeeCalculatorProps> = ({
  pickupCount,
  dropoffCount,
  totalMiles,
  showBreakdown = true
}) => {
  const PICKUP_FEE = 4.00;
  const DROPOFF_FEE = 2.00;
  const MILE_FEE = 0.75;

  const pickupTotal = pickupCount * PICKUP_FEE;
  const dropoffTotal = dropoffCount * DROPOFF_FEE;
  const mileageTotal = totalMiles * MILE_FEE;
  const totalDeliveryFee = pickupTotal + dropoffTotal + mileageTotal;

  const buyerShare = totalDeliveryFee * 0.6; // 60% buyer
  const sellerShare = totalDeliveryFee * 0.4; // 40% seller

  if (!showBreakdown) {
    return (
      <div className="text-sm text-gray-600">
        Delivery Fee: ${totalDeliveryFee.toFixed(2)}
      </div>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Truck className="h-5 w-5" />
          Delivery Fee Breakdown
        </CardTitle>
        <Badge variant="secondary" className="w-fit">
          🚀 Startup Trial - No Extra Fees!
        </Badge>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-blue-500" />
            <div>
              <div className="text-sm font-medium">{pickupCount} Pickups</div>
              <div className="text-xs text-gray-500">${PICKUP_FEE} each</div>
              <div className="font-semibold">${pickupTotal.toFixed(2)}</div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-green-500" />
            <div>
              <div className="text-sm font-medium">{dropoffCount} Drop-offs</div>
              <div className="text-xs text-gray-500">${DROPOFF_FEE} each</div>
              <div className="font-semibold">${dropoffTotal.toFixed(2)}</div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-orange-500" />
            <div>
              <div className="text-sm font-medium">{totalMiles} Miles</div>
              <div className="text-xs text-gray-500">${MILE_FEE}/mile</div>
              <div className="font-semibold">${mileageTotal.toFixed(2)}</div>
            </div>
          </div>
        </div>

        <div className="border-t pt-4">
          <div className="flex justify-between items-center mb-2">
            <span className="font-medium">Total Delivery Fee:</span>
            <span className="font-bold text-lg">${totalDeliveryFee.toFixed(2)}</span>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="bg-blue-50 p-3 rounded">
              <div className="font-medium text-blue-700">Buyer Pays (60%)</div>
              <div className="text-blue-900 font-semibold">${buyerShare.toFixed(2)}</div>
            </div>
            <div className="bg-green-50 p-3 rounded">
              <div className="font-medium text-green-700">Seller Pays (40%)</div>
              <div className="text-green-900 font-semibold">${sellerShare.toFixed(2)}</div>
            </div>
          </div>
        </div>

        <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
          <div className="text-sm text-yellow-800">
            <div className="font-semibold mb-1">🎯 Startup Trial Benefits</div>
            <p>100% of delivery fees go directly to our drivers - no platform markup!</p>
            <p className="mt-2 text-xs">
              <strong>Future:</strong> To ensure sustainability, MarketPace will add a small Sustainability Fee. 
              Early members get lifetime discounts for supporting our success!
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DeliveryFeeCalculator;