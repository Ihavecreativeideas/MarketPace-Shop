import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface CategorySelectorProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

const categories = [
  { id: 'all', name: 'All Items', icon: '🛍️' },
  { id: 'handcrafted', name: 'Handcrafted', icon: '🎨' },
  { id: 'baby-clothes', name: 'Baby Clothes', icon: '👶' },
  { id: 'baby-accessories', name: 'Baby Accessories', icon: '🍼' },
  { id: 'toddler-clothes', name: 'Toddler Clothes', icon: '👧' },
  { id: 'women-clothes', name: 'Women Clothes', icon: '👗' },
  { id: 'men-clothes', name: 'Men Clothes', icon: '👔' },
  { id: 'shoes', name: 'Shoes', icon: '👟' },
  { id: 'electronics', name: 'Electronics', icon: '📱' },
  { id: 'home', name: 'Home & Garden', icon: '🏠' },
  { id: 'sports', name: 'Sports', icon: '⚽' },
  { id: 'books', name: 'Books', icon: '📚' },
  { id: 'toys', name: 'Toys', icon: '🧸' }
];

export const CategorySelector: React.FC<CategorySelectorProps> = ({
  selectedCategory,
  onCategoryChange
}) => {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2">
      {categories.map((category) => (
        <Button
          key={category.id}
          variant={selectedCategory === category.id ? "default" : "outline"}
          size="sm"
          onClick={() => onCategoryChange(category.id)}
          className={`whitespace-nowrap flex items-center gap-2 ${
            selectedCategory === category.id
              ? 'bg-blue-600 text-white'
              : 'border-white/20 text-white hover:bg-white/10'
          }`}
        >
          <span>{category.icon}</span>
          {category.name}
        </Button>
      ))}
    </div>
  );
};