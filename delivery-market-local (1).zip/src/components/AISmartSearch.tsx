import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Mic, Camera, Brain, Sparkles } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const AISmartSearch = () => {
  const [query, setQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const aiSuggestions = [
    'Find musicians near me',
    'Best coffee shops with WiFi',
    'Handmade jewelry under $50',
    'Live music venues tonight',
    'Local art supplies'
  ];

  const handleVoiceSearch = () => {
    setIsListening(!isListening);
    // Voice search simulation
    setTimeout(() => setIsListening(false), 3000);
  };

  const handleSearch = (searchQuery: string) => {
    setQuery(searchQuery);
    // Simulate AI suggestions
    const filtered = aiSuggestions.filter(s => 
      s.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setSuggestions(filtered);
  };

  return (
    <motion.div 
      className="relative max-w-4xl mx-auto mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-2xl blur-xl" />
        
        <div className="relative bg-white/10 backdrop-blur-lg border border-white/20 rounded-2xl p-6 shadow-2xl">
          <div className="flex items-center space-x-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                value={query}
                onChange={(e) => handleSearch(e.target.value)}
                placeholder="Ask AI to find anything..."
                className="pl-12 pr-4 py-4 text-lg bg-white/5 border-white/10 rounded-xl focus:ring-2 focus:ring-cyan-400 focus:border-transparent"
              />
              
              {query && (
                <motion.div 
                  className="absolute right-4 top-1/2 transform -translate-y-1/2"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                >
                  <Brain className="w-5 h-5 text-cyan-400" />
                </motion.div>
              )}
            </div>
            
            <Button
              onClick={handleVoiceSearch}
              variant="ghost"
              size="lg"
              className={`p-4 rounded-xl transition-all duration-300 ${
                isListening 
                  ? 'bg-red-500/20 text-red-400 animate-pulse' 
                  : 'bg-white/5 hover:bg-white/10 text-gray-300'
              }`}
            >
              <Mic className="w-6 h-6" />
            </Button>
            
            <Button
              variant="ghost"
              size="lg"
              className="p-4 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300"
            >
              <Camera className="w-6 h-6" />
            </Button>
          </div>
          
          {/* AI Suggestions */}
          {suggestions.length > 0 && (
            <motion.div 
              className="mt-4 space-y-2"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              transition={{ duration: 0.3 }}
            >
              {suggestions.map((suggestion, index) => (
                <motion.button
                  key={index}
                  onClick={() => setQuery(suggestion)}
                  className="flex items-center space-x-2 w-full text-left p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  whileHover={{ x: 4 }}
                >
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <span className="text-gray-300">{suggestion}</span>
                </motion.button>
              ))}
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default AISmartSearch;