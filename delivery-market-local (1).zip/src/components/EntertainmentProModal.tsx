import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Crown, TrendingUp, Calendar, Verified, BarChart3, Zap, ExternalLink, CheckCircle } from 'lucide-react';
import { useState } from 'react';
import { toast } from '@/hooks/use-toast';

interface EntertainmentProModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgrade: (plan: string) => void;
}

const EntertainmentProModal: React.FC<EntertainmentProModalProps> = ({ isOpen, onClose, onUpgrade }) => {
  const [selectedPlan, setSelectedPlan] = useState('pro');

  const proFeatures = [
    {
      icon: TrendingUp,
      title: 'Promotional Boosts',
      description: 'Get your profile featured and reach more potential clients'
    },
    {
      icon: Calendar,
      title: 'Event Scheduling Tools',
      description: 'Advanced calendar management and booking coordination'
    },
    {
      icon: Verified,
      title: 'Verified Badge',
      description: 'Stand out with official verification and build trust'
    },
    {
      icon: BarChart3,
      title: 'Analytics Dashboard',
      description: 'Track views, bookings, and performance metrics'
    },
    {
      icon: ExternalLink,
      title: 'External Integrations',
      description: 'Connect Spotify, YouTube, Bandzoogle, and websites'
    },
    {
      icon: Zap,
      title: 'Priority Support',
      description: '24/7 priority customer support and account management'
    }
  ];

  const plans = [
    {
      id: 'pro',
      name: 'Entertainment Pro',
      price: '$29',
      period: '/month',
      popular: true,
      features: [
        'All Pro features included',
        'Unlimited media uploads',
        'Advanced analytics',
        'Priority booking placement',
        'External integrations',
        'Verified badge'
      ]
    },
    {
      id: 'premium',
      name: 'Entertainment Premium',
      price: '$49',
      period: '/month',
      popular: false,
      features: [
        'Everything in Pro',
        'Featured profile placement',
        'Advanced promotional tools',
        'Custom branding options',
        'Dedicated account manager',
        'White-label booking page'
      ]
    }
  ];

  const handleUpgrade = () => {
    onUpgrade(selectedPlan);
    toast({ 
      title: 'Upgrade Successful!', 
      description: 'Welcome to Entertainment Pro! Your new features are now active.' 
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-center text-2xl font-bold flex items-center justify-center gap-2">
            <Crown className="w-6 h-6 text-purple-600" />
            Upgrade to Entertainment Pro
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {proFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="border-2 border-purple-100">
                  <CardContent className="p-4 text-center">
                    <div className="flex justify-center mb-3">
                      <div className="bg-purple-100 p-3 rounded-full">
                        <Icon className="w-6 h-6 text-purple-600" />
                      </div>
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Pricing Plans */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {plans.map((plan) => (
              <Card 
                key={plan.id}
                className={`relative cursor-pointer transition-all ${
                  selectedPlan === plan.id 
                    ? 'border-2 border-purple-500 shadow-lg' 
                    : 'border border-gray-200 hover:border-purple-300'
                }`}
                onClick={() => setSelectedPlan(plan.id)}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-purple-600 text-white px-3 py-1">
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <CardContent className="p-6">
                  <div className="text-center mb-4">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">
                      {plan.name}
                    </h3>
                    <div className="flex items-baseline justify-center">
                      <span className="text-3xl font-bold text-purple-600">
                        {plan.price}
                      </span>
                      <span className="text-gray-600 ml-1">
                        {plan.period}
                      </span>
                    </div>
                  </div>
                  
                  <ul className="space-y-3">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Integration Preview */}
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-center mb-4">
                Connect Your External Platforms
              </h3>
              <div className="flex justify-center gap-6 flex-wrap">
                {[
                  { name: 'Spotify', color: 'bg-green-500' },
                  { name: 'YouTube', color: 'bg-red-500' },
                  { name: 'Bandzoogle', color: 'bg-blue-500' },
                  { name: 'Website', color: 'bg-gray-600' }
                ].map((platform) => (
                  <div key={platform.name} className="text-center">
                    <div className={`w-12 h-12 ${platform.color} rounded-full flex items-center justify-center mb-2 mx-auto`}>
                      <ExternalLink className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-sm font-medium">{platform.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Maybe Later
            </Button>
            <Button 
              onClick={handleUpgrade}
              className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Crown className="w-4 h-4 mr-2" />
              Upgrade Now
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EntertainmentProModal;