import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CreditCard, DollarSign, Plus, Trash2, Shield, CheckCircle } from 'lucide-react';

const PaymentsPayouts = () => {
  const [cards, setCards] = useState([
    { id: 1, type: 'Visa', last4: '4242', expiry: '12/25', isDefault: true },
    { id: 2, type: 'Mastercard', last4: '5555', expiry: '08/26', isDefault: false }
  ]);
  const [showAddCard, setShowAddCard] = useState(false);

  const handleAddCard = () => {
    setShowAddCard(false);
    // Handle card addition logic
  };

  const handleDeleteCard = (cardId: number) => {
    setCards(cards.filter(card => card.id !== cardId));
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="w-6 h-6" />
            Payments & Payouts
          </CardTitle>
          <CardDescription>
            Manage your payment methods and payout preferences
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="payment-methods" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="payment-methods">Payment Methods</TabsTrigger>
          <TabsTrigger value="payout-settings">Payout Settings</TabsTrigger>
          <TabsTrigger value="transaction-history">Transaction History</TabsTrigger>
        </TabsList>

        <TabsContent value="payment-methods" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Your Payment Methods</CardTitle>
              <CardDescription>
                Add and manage your credit cards and payment options
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {cards.map((card) => (
                <div key={card.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <CreditCard className="w-5 h-5" />
                    <div>
                      <p className="font-medium">{card.type} •••• {card.last4}</p>
                      <p className="text-sm text-gray-500">Expires {card.expiry}</p>
                    </div>
                    {card.isDefault && (
                      <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                        Default
                      </span>
                    )}
                  </div>
                  <div className="flex gap-2">
                    {!card.isDefault && (
                      <Button size="sm" variant="outline">
                        Set Default
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDeleteCard(card.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}

              {showAddCard ? (
                <div className="border rounded-lg p-4 space-y-4">
                  <h3 className="font-semibold">Add New Card</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input id="cardNumber" placeholder="1234 5678 9012 3456" />
                    </div>
                    <div>
                      <Label htmlFor="cardName">Cardholder Name</Label>
                      <Input id="cardName" placeholder="John Doe" />
                    </div>
                    <div>
                      <Label htmlFor="expiry">Expiry Date</Label>
                      <Input id="expiry" placeholder="MM/YY" />
                    </div>
                    <div>
                      <Label htmlFor="cvv">CVV</Label>
                      <Input id="cvv" placeholder="123" />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleAddCard}>Add Card</Button>
                    <Button variant="outline" onClick={() => setShowAddCard(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <Button onClick={() => setShowAddCard(true)} className="w-full">
                  <Plus className="w-4 h-4 mr-2" />
                  Add New Payment Method
                </Button>
              )}
            </CardContent>
          </Card>

          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              Your payment information is encrypted and secure. We never store your full card details.
            </AlertDescription>
          </Alert>
        </TabsContent>

        <TabsContent value="payout-settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Payout Preferences</CardTitle>
              <CardDescription>
                Set up how you want to receive payments from sales
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="payoutMethod">Payout Method</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select payout method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bank">Bank Transfer</SelectItem>
                    <SelectItem value="paypal">PayPal</SelectItem>
                    <SelectItem value="stripe">Stripe Express</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="bankAccount">Bank Account</Label>
                <Input id="bankAccount" placeholder="Account Number" />
              </div>

              <div>
                <Label htmlFor="routingNumber">Routing Number</Label>
                <Input id="routingNumber" placeholder="Routing Number" />
              </div>

              <div>
                <Label htmlFor="payoutSchedule">Payout Schedule</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select schedule" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button>Save Payout Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transaction-history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Transactions</CardTitle>
              <CardDescription>
                View your payment and payout history
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { date: '2024-01-15', type: 'Payment', amount: '$45.99', status: 'Completed' },
                  { date: '2024-01-14', type: 'Payout', amount: '$125.50', status: 'Pending' },
                  { date: '2024-01-13', type: 'Payment', amount: '$23.75', status: 'Completed' },
                  { date: '2024-01-12', type: 'Refund', amount: '$15.00', status: 'Completed' }
                ].map((transaction, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <DollarSign className="w-5 h-5 text-green-500" />
                      <div>
                        <p className="font-medium">{transaction.type}</p>
                        <p className="text-sm text-gray-500">{transaction.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{transaction.amount}</p>
                      <div className="flex items-center gap-1">
                        {transaction.status === 'Completed' && (
                          <CheckCircle className="w-3 h-3 text-green-500" />
                        )}
                        <span className={`text-xs ${
                          transaction.status === 'Completed' ? 'text-green-600' : 'text-yellow-600'
                        }`}>
                          {transaction.status}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PaymentsPayouts;