import React, { useState } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Clock, Zap, Globe, ArrowRight, X } from 'lucide-react';

interface TrialWebIntegrationBannerProps {
  onStartIntegration: () => void;
}

const TrialWebIntegrationBanner: React.FC<TrialWebIntegrationBannerProps> = ({ onStartIntegration }) => {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-2 border-orange-200 mb-6">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-orange-600" />
              <Badge className="bg-orange-500 text-white animate-pulse">
                LIMITED TIME
              </Badge>
            </div>
            <div>
              <h3 className="font-bold text-orange-900">
                Trial Era: Test Website Integration FREE!
              </h3>
              <p className="text-sm text-orange-700">
                Connect your shop/website and sync products to MarketPace - Take advantage while it lasts!
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              onClick={onStartIntegration}
              className="bg-orange-600 hover:bg-orange-700 text-white"
            >
              <Globe className="w-4 h-4 mr-2" />
              Start Integration
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setDismissed(true)}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TrialWebIntegrationBanner;