import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/components/EnhancedCartContext';
import { Calculator, Star, Clock } from 'lucide-react';

interface CartSummaryWithFeesProps {
  showStartupMessage?: boolean;
}

export const CartSummaryWithFees: React.FC<CartSummaryWithFeesProps> = ({
  showStartupMessage = true
}) => {
  const { cartItems, getCartTotal, getDeliveryRoute } = useCart();
  
  if (cartItems.length === 0) return null;

  const route = getDeliveryRoute();
  const productTotal = getCartTotal();
  
  // Fee calculations
  const PICKUP_FEE = 4.00;
  const DROPOFF_FEE = 2.00;
  const MILE_FEE = 0.75;
  
  const pickupCount = route.pickupLocations.length;
  const dropoffCount = 1;
  const totalMiles = route.estimatedMiles;
  
  const pickupFees = pickupCount * PICKUP_FEE;
  const dropoffFees = dropoffCount * DROPOFF_FEE;
  const mileageFees = totalMiles * MILE_FEE;
  const totalDeliveryFee = pickupFees + dropoffFees + mileageFees;
  
  // Split between buyer and seller
  const buyerDeliveryShare = totalDeliveryFee * 0.6;
  const sellerDeliveryShare = totalDeliveryFee * 0.4;
  
  const grandTotal = productTotal + buyerDeliveryShare;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-5 w-5" />
          Order Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Product Summary */}
        <div>
          <div className="flex justify-between items-center">
            <span>Products ({cartItems.length} items)</span>
            <span className="font-semibold">${productTotal.toFixed(2)}</span>
          </div>
          <div className="text-xs text-gray-500 mt-1">
            From {pickupCount} seller{pickupCount > 1 ? 's' : ''}
          </div>
        </div>

        <Separator />

        {/* Delivery Breakdown */}
        <div className="space-y-2">
          <div className="font-medium text-sm">Delivery Fee Breakdown:</div>
          
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="text-center p-2 bg-blue-50 rounded">
              <div className="font-medium">{pickupCount} Pickups</div>
              <div className="text-blue-600">${pickupFees.toFixed(2)}</div>
            </div>
            <div className="text-center p-2 bg-green-50 rounded">
              <div className="font-medium">{dropoffCount} Drop-off</div>
              <div className="text-green-600">${dropoffFees.toFixed(2)}</div>
            </div>
            <div className="text-center p-2 bg-orange-50 rounded">
              <div className="font-medium">{totalMiles} Miles</div>
              <div className="text-orange-600">${mileageFees.toFixed(2)}</div>
            </div>
          </div>
          
          <div className="flex justify-between text-sm">
            <span>Total Delivery Fee:</span>
            <span className="font-semibold">${totalDeliveryFee.toFixed(2)}</span>
          </div>
          
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-blue-50 p-2 rounded">
              <div className="text-blue-700">You Pay (60%)</div>
              <div className="font-semibold text-blue-900">${buyerDeliveryShare.toFixed(2)}</div>
            </div>
            <div className="bg-gray-50 p-2 rounded">
              <div className="text-gray-700">Seller Pays (40%)</div>
              <div className="font-semibold text-gray-900">${sellerDeliveryShare.toFixed(2)}</div>
            </div>
          </div>
        </div>

        <Separator />

        {/* Total */}
        <div className="flex justify-between items-center text-lg font-bold">
          <span>Your Total:</span>
          <span>${grandTotal.toFixed(2)}</span>
        </div>

        {/* Estimated Time */}
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Clock className="h-4 w-4" />
          <span>Estimated delivery: {route.estimatedTime} minutes</span>
        </div>

        {/* Startup Message */}
        {showStartupMessage && (
          <div className="bg-gradient-to-r from-yellow-50 to-orange-50 p-3 rounded-lg border border-yellow-200">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                <Star className="h-3 w-3 mr-1" />
                Startup Trial
              </Badge>
            </div>
            <div className="text-xs text-yellow-800 space-y-1">
              <p><strong>100% of delivery fees go to drivers!</strong></p>
              <p>No platform markup during our startup trial.</p>
              <p className="text-yellow-700">
                <strong>Future:</strong> Small sustainability fee will be added. 
                Early members get lifetime discounts!
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CartSummaryWithFees;