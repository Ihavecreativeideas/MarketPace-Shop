import React from 'react';
import { Button } from '@/components/ui/button';
import { Mail, Facebook, Linkedin, UserCheck, Chrome } from 'lucide-react';

interface EnhancedSocialAuthButtonsProps {
  onGoogleAuth: () => void;
  onGmailAuth: () => void;
  onFacebookAuth: () => void;
  onLinkedInAuth: () => void;
  onEmailAuth: () => void;
  onGuestAuth: () => void;
  loading?: boolean;
}

const EnhancedSocialAuthButtons: React.FC<EnhancedSocialAuthButtonsProps> = ({
  onGoogleAuth,
  onGmailAuth,
  onFacebookAuth,
  onLinkedInAuth,
  onEmailAuth,
  onGuestAuth,
  loading = false
}) => {
  return (
    <div className="space-y-3">
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-background px-2 text-muted-foreground">Quick Sign Up Options</span>
        </div>
      </div>
      
      {/* Primary Social Auth Options */}
      <div className="grid grid-cols-2 gap-3">
        <Button 
          variant="outline" 
          onClick={onGoogleAuth} 
          disabled={loading}
          className="flex items-center gap-2 hover:bg-red-50 hover:border-red-200 transition-colors"
        >
          <Chrome className="h-4 w-4 text-red-500" />
          Google
        </Button>
        
        <Button 
          variant="outline" 
          onClick={onFacebookAuth} 
          disabled={loading}
          className="flex items-center gap-2 hover:bg-blue-50 hover:border-blue-200 transition-colors"
        >
          <Facebook className="h-4 w-4 text-blue-600" />
          Facebook
        </Button>
      </div>
      
      {/* Secondary Options */}
      <div className="grid grid-cols-2 gap-3">
        <Button 
          variant="outline" 
          onClick={onGmailAuth} 
          disabled={loading}
          className="flex items-center gap-2 hover:bg-orange-50 hover:border-orange-200 transition-colors"
        >
          <Mail className="h-4 w-4 text-orange-500" />
          Gmail
        </Button>
        
        <Button 
          variant="outline" 
          onClick={onLinkedInAuth} 
          disabled={loading}
          className="flex items-center gap-2 hover:bg-blue-50 hover:border-blue-300 transition-colors"
        >
          <Linkedin className="h-4 w-4 text-blue-700" />
          LinkedIn
        </Button>
      </div>
      
      {/* Email and Guest Options */}
      <div className="grid grid-cols-2 gap-3">
        <Button 
          variant="outline" 
          onClick={onEmailAuth} 
          disabled={loading}
          className="flex items-center gap-2 hover:bg-gray-50 hover:border-gray-300 transition-colors"
        >
          <Mail className="h-4 w-4 text-gray-600" />
          Email
        </Button>
        
        <Button 
          variant="outline" 
          onClick={onGuestAuth} 
          disabled={loading}
          className="flex items-center gap-2 hover:bg-teal-50 hover:border-teal-200 transition-colors"
        >
          <UserCheck className="h-4 w-4 text-teal-600" />
          Guest Mode
        </Button>
      </div>
      
      <div className="text-xs text-center text-muted-foreground mt-4">
        Choose your preferred sign-up method above
      </div>
    </div>
  );
};

export default EnhancedSocialAuthButtons;