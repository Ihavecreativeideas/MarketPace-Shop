import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Star, MapPin, Heart, Search, Palette } from 'lucide-react';

interface Crafter {
  id: string;
  name: string;
  craft: string;
  description: string;
  rating: number;
  reviewCount: number;
  distance: number;
  location: string;
  specialties: string[];
  priceRange: string;
  image: string;
  isVerified: boolean;
}

const HandcraftedSearch: React.FC = () => {
  const [crafters, setCrafters] = useState<Crafter[]>([]);
  const [filteredCrafters, setFilteredCrafters] = useState<Crafter[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCraft, setSelectedCraft] = useState('all');
  const [loading, setLoading] = useState(true);

  const craftCategories = [
    'all', 'jewelry', 'pottery', 'woodworking', 'textiles', 
    'art', 'candles', 'soap', 'leather', 'metalwork'
  ];

  const mockCrafters: Crafter[] = [
    {
      id: '1',
      name: 'Sarah\'s Handmade Jewelry',
      craft: 'jewelry',
      description: 'Custom sterling silver and gemstone jewelry',
      rating: 4.9,
      reviewCount: 87,
      distance: 1.2,
      location: 'Downtown Arts District',
      specialties: ['Rings', 'Necklaces', 'Custom Pieces'],
      priceRange: '$25-$200',
      image: '/placeholder.svg',
      isVerified: true
    },
    {
      id: '2',
      name: 'Mountain View Pottery',
      craft: 'pottery',
      description: 'Functional ceramics and decorative pieces',
      rating: 4.8,
      reviewCount: 52,
      distance: 3.5,
      location: 'Artisan Quarter',
      specialties: ['Bowls', 'Mugs', 'Vases', 'Custom Orders'],
      priceRange: '$15-$150',
      image: '/placeholder.svg',
      isVerified: true
    },
    {
      id: '3',
      name: 'Rustic Wood Creations',
      craft: 'woodworking',
      description: 'Handcrafted furniture and home decor',
      rating: 4.7,
      reviewCount: 34,
      distance: 5.8,
      location: 'Craftsman Village',
      specialties: ['Tables', 'Shelves', 'Cutting Boards'],
      priceRange: '$30-$500',
      image: '/placeholder.svg',
      isVerified: false
    }
  ];

  useEffect(() => {
    setTimeout(() => {
      setCrafters(mockCrafters);
      setFilteredCrafters(mockCrafters);
      setLoading(false);
    }, 800);
  }, []);

  useEffect(() => {
    let filtered = crafters;
    
    if (searchTerm) {
      filtered = filtered.filter(crafter => 
        crafter.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        crafter.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        crafter.specialties.some(specialty => 
          specialty.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }
    
    if (selectedCraft !== 'all') {
      filtered = filtered.filter(crafter => crafter.craft === selectedCraft);
    }
    
    setFilteredCrafters(filtered);
  }, [searchTerm, selectedCraft, crafters]);

  return (
    <div className="mt-8">
      <div className="flex items-center gap-2 mb-4">
        <Palette className="h-6 w-6 text-purple-600" />
        <h2 className="text-2xl font-bold">Handcrafted & Artisan</h2>
      </div>
      <p className="text-muted-foreground mb-6">
        Discover local artisans and crafters creating unique handmade items
      </p>

      <div className="mb-6 space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Search crafters, specialties..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1"
          />
          <Button variant="outline">
            <Search className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex gap-2 flex-wrap">
          {craftCategories.map((category) => (
            <Button
              key={category}
              variant={selectedCraft === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCraft(category)}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </Button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <div className="h-40 bg-gray-200 rounded-t-lg"></div>
              <CardContent className="p-4">
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded mb-4"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCrafters.map((crafter) => (
            <Card key={crafter.id} className="hover:shadow-lg transition-shadow">
              <div className="relative">
                <img 
                  src={crafter.image} 
                  alt={crafter.name}
                  className="w-full h-40 object-cover rounded-t-lg"
                />
                {crafter.isVerified && (
                  <Badge className="absolute top-2 left-2 bg-purple-600">
                    Verified Artisan
                  </Badge>
                )}
                <Button 
                  size="sm" 
                  variant="secondary" 
                  className="absolute top-2 right-2"
                >
                  <Heart className="h-4 w-4" />
                </Button>
              </div>
              
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold">{crafter.name}</h3>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm">{crafter.rating}</span>
                  </div>
                </div>
                
                <p className="text-sm text-muted-foreground mb-2">{crafter.description}</p>
                
                <div className="flex items-center gap-2 text-sm mb-2">
                  <MapPin className="h-4 w-4" />
                  <span>{crafter.location} • {crafter.distance} mi</span>
                </div>
                
                <div className="mb-3">
                  <div className="flex flex-wrap gap-1">
                    {crafter.specialties.slice(0, 2).map((specialty, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {specialty}
                      </Badge>
                    ))}
                    {crafter.specialties.length > 2 && (
                      <Badge variant="secondary" className="text-xs">
                        +{crafter.specialties.length - 2}
                      </Badge>
                    )}
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-green-600">
                    {crafter.priceRange}
                  </span>
                  <Button size="sm">View Shop</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {!loading && filteredCrafters.length === 0 && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">
            No artisans found matching your search.
          </p>
        </div>
      )}
    </div>
  );
};

export default HandcraftedSearch;