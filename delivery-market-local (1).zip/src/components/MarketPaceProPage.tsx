import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Crown, Truck, Globe, DollarSign, TrendingUp, Leaf, Star, Check, BarChart3, Zap } from 'lucide-react';

const benefits = [
  {
    icon: Truck,
    title: 'Discount Deliveries',
    description: 'Lifetime reduced delivery fees on all orders'
  },
  {
    icon: Globe,
    title: 'Web Integration',
    description: 'Full API access and website integration tools'
  },
  {
    icon: DollarSign,
    title: 'No Commission Charges',
    description: 'Zero commission fees on all transactions, forever'
  },
  {
    icon: TrendingUp,
    title: 'Priority Algorithm Visibility',
    description: 'Your listings appear first in search results'
  },
  {
    icon: Leaf,
    title: 'No Sustainability Charges',
    description: 'Waived environmental fees for life'
  },
  {
    icon: BarChart3,
    title: 'Advanced Analytics',
    description: 'Deep insights into sales, traffic, and customer behavior'
  },
  {
    icon: Zap,
    title: 'Product Boosting',
    description: 'Pay to promote your products for maximum visibility'
  }
];

export default function MarketPaceProPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-lime-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-lime-500 text-white px-6 py-3 rounded-full mb-6">
            <Crown className="h-6 w-6" />
            <span className="font-bold text-lg">MarketPace Pro</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 to-lime-500 bg-clip-text text-transparent mb-4">
            Thank You for Your Support!
          </h1>
          
          <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto">
            As an early subscriber to MarketPace Pro, you're not just a customer - you're a VIP with lifetime benefits!
          </p>
        </div>

        {/* VIP Badge */}
        <div className="text-center mb-12">
          <Badge className="bg-gradient-to-r from-lime-400 to-blue-500 text-white px-8 py-3 text-lg font-bold">
            <Star className="h-5 w-5 mr-2" />
            YOU'RE NOT ONLY A MARKETPACE PRO - YOU'RE A VIP!
          </Badge>
        </div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <Card key={index} className="border-2 border-blue-200 hover:border-lime-400 transition-colors bg-white/80 backdrop-blur">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-gradient-to-r from-blue-600 to-lime-500 rounded-lg">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-lg text-gray-800">{benefit.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base text-gray-600">
                    {benefit.description}
                  </CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Lifetime Promise */}
        <Card className="bg-gradient-to-r from-blue-600 to-lime-500 text-white mb-8">
          <CardHeader>
            <CardTitle className="text-2xl text-center flex items-center justify-center gap-2">
              <Check className="h-8 w-8" />
              Lifetime Benefits Guaranteed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-center text-lg">
              These benefits are yours forever - no expiration dates, no fine print. 
              You believed in us early, and we're committed to rewarding that trust for life.
            </p>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <div className="text-center">
          <Button 
            size="lg" 
            className="bg-gradient-to-r from-lime-400 to-blue-500 hover:from-lime-500 hover:to-blue-600 text-white font-bold px-8 py-4 text-lg"
          >
            <Crown className="h-5 w-5 mr-2" />
            Activate Your VIP Status
          </Button>
          
          <p className="text-sm text-gray-600 mt-4">
            Join thousands of early supporters who are already enjoying VIP benefits
          </p>
        </div>
      </div>
    </div>
  );
}