import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Star, MapPin, Calendar, DollarSign, Package, Users, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Business {
  id: string;
  name: string;
  type: 'shop' | 'service' | 'entertainment';
  category: string;
  city: string;
  status: 'active' | 'inactive' | 'trial' | 'expired';
  rating: number;
  totalOrders: number;
  revenue: number;
  subscriptionStatus: 'trial' | 'active' | 'expired';
  deliveryDays: string[];
  joinedDate: string;
  lastActive: string;
}

export default function AdminBusinessTable() {
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBusinesses();
  }, []);

  const loadBusinesses = async () => {
    try {
      const { data, error } = await supabase
        .from('business_profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedBusinesses: Business[] = (data || []).map(business => ({
        id: business.id,
        name: business.business_name || 'Unknown Business',
        type: business.business_type || 'shop',
        category: business.category || 'General',
        city: business.city || 'Unknown',
        status: business.status || 'active',
        rating: business.rating || 0,
        totalOrders: business.total_orders || 0,
        revenue: business.total_revenue || 0,
        subscriptionStatus: business.subscription_status || 'trial',
        deliveryDays: business.delivery_days || [],
        joinedDate: business.created_at,
        lastActive: business.last_active || business.created_at
      }));

      setBusinesses(formattedBusinesses);
    } catch (error) {
      console.error('Error loading businesses:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateBusinessStatus = async (businessId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('business_profiles')
        .update({ status: newStatus })
        .eq('id', businessId);

      if (error) throw error;
      loadBusinesses();
    } catch (error) {
      console.error('Error updating business status:', error);
    }
  };

  const cities = ['all', ...new Set(businesses.map(b => b.city))];
  const types = ['all', 'shop', 'service', 'entertainment'];
  
  const filteredBusinesses = businesses.filter(business => {
    const cityMatch = selectedCity === 'all' || business.city === selectedCity;
    const typeMatch = selectedType === 'all' || business.type === selectedType;
    return cityMatch && typeMatch;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active': return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'inactive': return <Badge className="bg-gray-100 text-gray-800">Inactive</Badge>;
      case 'trial': return <Badge className="bg-blue-100 text-blue-800">Trial</Badge>;
      case 'expired': return <Badge className="bg-red-100 text-red-800">Expired</Badge>;
      default: return <Badge>{status}</Badge>;
    }
  };

  const getSubscriptionBadge = (status: string) => {
    switch (status) {
      case 'active': return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'trial': return <Badge className="bg-yellow-100 text-yellow-800">Trial</Badge>;
      case 'expired': return <Badge className="bg-red-100 text-red-800">Expired</Badge>;
      default: return <Badge>{status}</Badge>;
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'shop': return <Badge className="bg-purple-100 text-purple-800">🏪 Shop</Badge>;
      case 'service': return <Badge className="bg-orange-100 text-orange-800">🔧 Service</Badge>;
      case 'entertainment': return <Badge className="bg-pink-100 text-pink-800">🎵 Entertainment</Badge>;
      default: return <Badge>{type}</Badge>;
    }
  };

  const businessStats = {
    total: businesses.length,
    active: businesses.filter(b => b.status === 'active').length,
    shops: businesses.filter(b => b.type === 'shop').length,
    services: businesses.filter(b => b.type === 'service').length,
    entertainment: businesses.filter(b => b.type === 'entertainment').length,
    totalRevenue: businesses.reduce((sum, b) => sum + b.revenue, 0)
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading businesses...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">🏪 Vendor Oversight</h2>
        <div className="flex gap-2">
          <Select value={selectedCity} onValueChange={setSelectedCity}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by city" />
            </SelectTrigger>
            <SelectContent>
              {cities.map(city => (
                <SelectItem key={city} value={city}>
                  {city === 'all' ? 'All Cities' : city}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={selectedType} onValueChange={setSelectedType}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              {types.map(type => (
                <SelectItem key={type} value={type}>
                  {type === 'all' ? 'All Types' : type.charAt(0).toUpperCase() + type.slice(1)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Business Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Businesses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{businessStats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{businessStats.active}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Shops</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{businessStats.shops}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Services</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{businessStats.services}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Entertainment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-pink-600">{businessStats.entertainment}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">${businessStats.totalRevenue.toLocaleString()}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Business Directory ({filteredBusinesses.length} businesses)</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Business</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>City</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Subscription</TableHead>
                <TableHead>Rating</TableHead>
                <TableHead>Orders</TableHead>
                <TableHead>Revenue</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredBusinesses.map(business => (
                <TableRow key={business.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{business.name}</div>
                      <div className="text-sm text-muted-foreground">{business.category}</div>
                    </div>
                  </TableCell>
                  <TableCell>{getTypeBadge(business.type)}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {business.city}
                    </div>
                  </TableCell>
                  <TableCell>{getStatusBadge(business.status)}</TableCell>
                  <TableCell>{getSubscriptionBadge(business.subscriptionStatus)}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      {business.rating.toFixed(1)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Package className="h-4 w-4" />
                      {business.totalOrders}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      ${business.revenue.toLocaleString()}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Select onValueChange={(value) => updateBusinessStatus(business.id, value)}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Actions" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Activate</SelectItem>
                        <SelectItem value="inactive">Deactivate</SelectItem>
                        <SelectItem value="trial">Set Trial</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}