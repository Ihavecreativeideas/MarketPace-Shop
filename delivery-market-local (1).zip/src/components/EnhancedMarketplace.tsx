import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { CounterOfferSystem } from './CounterOfferSystem';
import { CategorySelector } from './CategorySelector';
import { ProductFilters } from './ProductFilters';
import { SellToMarketplaceButton } from './SellToMarketplaceButton';
import { Search, Filter, Heart, Star, MapPin, Clock, Plus } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface MarketplaceItem {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  size?: string;
  age_range?: string;
  condition: string;
  location: string;
  seller_name: string;
  seller_id: string;
  images: string[];
  created_at: string;
  is_promoted: boolean;
  favorites_count: number;
  source_page?: string;
  self_pickup_available?: boolean;
  marketplace_delivery_available?: boolean;
  shop_delivery_available?: boolean;
}

const EnhancedMarketplace: React.FC = () => {
  const [items, setItems] = useState<MarketplaceItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedSize, setSelectedSize] = useState('all');
  const [selectedAge, setSelectedAge] = useState('all');
  const [selectedItem, setSelectedItem] = useState<MarketplaceItem | null>(null);
  const [showOffers, setShowOffers] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    fetchItems();
  }, [selectedCategory, searchTerm, selectedSize, selectedAge]);

  const fetchItems = async () => {
    setLoading(true);
    let query = supabase
      .from('marketplace_items')
      .select(`
        *,
        seller:user_profiles!seller_id(name)
      `)
      .order('is_promoted', { ascending: false })
      .order('created_at', { ascending: false });

    if (selectedCategory !== 'all') {
      query = query.eq('category', selectedCategory);
    }

    if (searchTerm) {
      query = query.ilike('title', `%${searchTerm}%`);
    }

    if (selectedSize !== 'all') {
      query = query.eq('size', selectedSize);
    }

    if (selectedAge !== 'all') {
      query = query.eq('age_range', selectedAge);
    }

    const { data, error } = await query;

    if (data) {
      setItems(data.map(item => ({
        ...item,
        seller_name: item.seller?.name || 'Anonymous',
        marketplace_delivery_available: item.marketplace_delivery_available ?? true
      })));
    }
    setLoading(false);
  };

  const handleFavorite = async (itemId: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    console.log('Toggle favorite for item:', itemId);
  };

  const handlePromoteItem = async (itemId: string) => {
    const { error } = await supabase
      .from('marketplace_items')
      .update({ is_promoted: true })
      .eq('id', itemId);

    if (!error) {
      fetchItems();
    }
  };

  const getDeliveryOptions = (item: MarketplaceItem) => {
    const options = [];
    if (item.self_pickup_available) options.push('Self Pickup');
    if (item.marketplace_delivery_available) options.push('MarketPace Delivery');
    if (item.shop_delivery_available) options.push('Shop Delivery');
    return options;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold text-white mb-4">MarketPace</h1>
            <p className="text-gray-300">Buy, sell, and discover amazing items in your community</p>
          </div>
          <SellToMarketplaceButton className="" />
        </div>

        {/* Search and Filters */}
        <div className="mb-6 space-y-4">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search items..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white/10 border-white/20 text-white"
              />
            </div>
            <Button 
              variant="outline" 
              className="border-white/20 text-white"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="w-4 h-4 mr-2" />
              Filters
            </Button>
          </div>

          {/* Category Selector */}
          <CategorySelector
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />

          {/* Product Filters */}
          {showFilters && (
            <ProductFilters
              selectedSize={selectedSize}
              selectedAge={selectedAge}
              onSizeChange={setSelectedSize}
              onAgeChange={setSelectedAge}
              category={selectedCategory}
            />
          )}
        </div>

        {/* Items Grid */}
        {loading ? (
          <div className="text-center text-white py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto"></div>
            <p className="mt-4">Loading items...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {items.map((item) => {
              const deliveryOptions = getDeliveryOptions(item);
              return (
                <Card key={item.id} className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all">
                  {item.is_promoted && (
                    <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs font-bold px-2 py-1 rounded-t-lg">
                      ⭐ PROMOTED
                    </div>
                  )}
                  
                  <CardHeader className="pb-2">
                    <div className="aspect-square bg-white/5 rounded-lg mb-3 flex items-center justify-center relative">
                      {item.images?.length > 0 ? (
                        <img 
                          src={item.images[0]} 
                          alt={item.title}
                          className="w-full h-full object-cover rounded-lg"
                        />
                      ) : (
                        <div className="text-gray-400 text-4xl">📦</div>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleFavorite(item.id)}
                        className="absolute top-2 left-2 bg-white/90 hover:bg-white text-red-500 hover:text-red-600 w-8 h-8 p-0 rounded-full shadow-lg"
                      >
                        <Heart className="w-4 h-4" />
                      </Button>
                    </div>
                    
                    <CardTitle className="text-white text-lg line-clamp-2">
                      {item.title}
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent className="pt-0">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-2xl font-bold text-green-400">
                          ${item.price.toFixed(2)}
                        </span>
                      </div>
                      
                      <p className="text-gray-300 text-sm line-clamp-2">
                        {item.description}
                      </p>
                      
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="secondary" className="text-xs">
                          {item.category.replace('-', ' ')}
                        </Badge>
                        {item.size && (
                          <Badge variant="outline" className="text-xs border-blue-400 text-blue-400">
                            Size: {item.size}
                          </Badge>
                        )}
                        {item.age_range && (
                          <Badge variant="outline" className="text-xs border-green-400 text-green-400">
                            Age: {item.age_range}
                          </Badge>
                        )}
                        <Badge variant="outline" className="text-xs border-purple-400 text-purple-400">
                          {item.condition}
                        </Badge>
                      </div>
                      
                      {deliveryOptions.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {deliveryOptions.map((option) => (
                            <Badge key={option} variant="outline" className="text-xs border-orange-400 text-orange-400">
                              {option}
                            </Badge>
                          ))}
                        </div>
                      )}
                      
                      <div className="flex items-center gap-2 text-xs text-gray-400">
                        <MapPin className="w-3 h-3" />
                        <span>{item.location}</span>
                        <Clock className="w-3 h-3 ml-2" />
                        <span>{new Date(item.created_at).toLocaleDateString()}</span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-400">
                          by {item.seller_name}
                        </span>
                        {item.source_page && (
                          <Badge variant="outline" className="text-xs">
                            from {item.source_page}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          className="flex-1 bg-blue-600 hover:bg-blue-700"
                          onClick={() => {
                            setSelectedItem(item);
                            setShowOffers(true);
                          }}
                        >
                          Make Offer
                        </Button>
                        
                        {!item.is_promoted && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handlePromoteItem(item.id)}
                            className="border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black"
                          >
                            <Star className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Counter Offer Modal */}
        {showOffers && selectedItem && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold text-white">{selectedItem.title}</h2>
                  <Button
                    variant="ghost"
                    onClick={() => setShowOffers(false)}
                    className="text-gray-400 hover:text-white"
                  >
                    ✕
                  </Button>
                </div>
                
                <CounterOfferSystem
                  itemId={selectedItem.id}
                  originalPrice={selectedItem.price}
                  sellerId={selectedItem.seller_id}
                  buyerId="current-user-id"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EnhancedMarketplace;
export { EnhancedMarketplace };