import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, Star, Crown, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface SponsorshipTier {
  id: string;
  name: string;
  price: number;
  icon: React.ReactNode;
  color: string;
  benefits: string[];
  featured?: boolean;
}

const sponsorshipTiers: SponsorshipTier[] = [
  {
    id: 'bronze',
    name: 'Bronze Partner',
    price: 500,
    icon: <Star className="w-6 h-6" />,
    color: 'from-amber-600 to-amber-800',
    benefits: [
      'Business cards with QR codes',
      'Window sticker with QR code',
      'No extra added delivery fees for 6 months',
      'Partners pay driver only (no upcharge)',
      'Basic MarketPace Partners Page listing',
      'Social media mention'
    ]
  },
  {
    id: 'silver',
    name: 'Silver Partner',
    price: 1000,
    icon: <Crown className="w-6 h-6" />,
    color: 'from-gray-400 to-gray-600',
    benefits: [
      'Premium business cards with QR codes',
      'Large window sticker with QR code',
      'No extra added delivery fees for 1 year',
      'Partners pay driver only (no upcharge)',
      'Featured MarketPace Partners Page listing',
      'Dedicated social media post',
      '50 reusable MarketPace gift bags',
      'Monthly promotional spotlight'
    ],
    featured: true
  },
  {
    id: 'gold',
    name: 'Gold Partner',
    price: 1500,
    icon: <Zap className="w-6 h-6" />,
    color: 'from-yellow-400 to-yellow-600',
    benefits: [
      'Premium business cards with QR codes',
      'Large window sticker with QR code',
      'No extra added delivery fees for 1 year',
      'Partners pay driver only (no upcharge)',
      'Top-tier MarketPace Partners Page listing',
      'Weekly social media features',
      '100 reusable MarketPace gift bags',
      'Bi-weekly promotional campaigns',
      'Priority customer support',
      'Co-marketing opportunities'
    ]
  }
];

export default function SponsorshipTiers() {
  const [selectedTier, setSelectedTier] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleSelectTier = (tierId: string) => {
    setSelectedTier(tierId);
    navigate(`/partner-signup?tier=${tierId}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 py-8">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Become a MarketPace Partner
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join our startup campaign and receive the exclusive Proud Partners Pack.
            Help us launch while growing your business with premium benefits.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {sponsorshipTiers.map((tier) => (
            <Card 
              key={tier.id} 
              className={`relative overflow-hidden transition-all duration-300 hover:shadow-xl ${
                tier.featured ? 'ring-2 ring-purple-500 scale-105' : ''
              }`}
            >
              {tier.featured && (
                <Badge className="absolute top-4 right-4 bg-purple-600">
                  Most Popular
                </Badge>
              )}
              
              <CardHeader className="text-center pb-4">
                <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-r ${tier.color} flex items-center justify-center text-white mb-4`}>
                  {tier.icon}
                </div>
                <CardTitle className="text-2xl font-bold">{tier.name}</CardTitle>
                <div className="text-3xl font-bold text-purple-600">
                  ${tier.price.toLocaleString()}
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <ul className="space-y-3 mb-6">
                  {tier.benefits.map((benefit, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-700">{benefit}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  onClick={() => handleSelectTier(tier.id)}
                  className={`w-full ${tier.featured ? 'bg-purple-600 hover:bg-purple-700' : ''}`}
                  variant={tier.featured ? 'default' : 'outline'}
                >
                  Choose {tier.name}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-center mb-6">Proud Partners Pack Includes</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">📇</span>
              </div>
              <h3 className="font-semibold mb-2">Business Cards</h3>
              <p className="text-sm text-gray-600">Premium cards with QR codes linking to your MarketPace profile</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">🏪</span>
              </div>
              <h3 className="font-semibold mb-2">Window Stickers</h3>
              <p className="text-sm text-gray-600">Eye-catching stickers with QR codes for your storefront</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">🚚</span>
              </div>
              <h3 className="font-semibold mb-2">Delivery Benefits</h3>
              <p className="text-sm text-gray-600">No extra added delivery fees, no upcharge - Partners pay driver only</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">🛍️</span>
              </div>
              <h3 className="font-semibold mb-2">Gift Bags</h3>
              <p className="text-sm text-gray-600">Reusable MarketPace branded bags for your customers</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}