import React from 'react';
import PlatformDropdown from './PlatformDropdown';

interface UniversalPageWrapperProps {
  children: React.ReactNode;
  className?: string;
}

const UniversalPageWrapper: React.FC<UniversalPageWrapperProps> = ({ children, className = '' }) => {
  return (
    <div className={`min-h-screen ${className}`}>
      {/* Platform Navigation Dropdown - appears on every page */}
      <div className="container mx-auto px-4 pt-6 flex justify-end">
        <PlatformDropdown />
      </div>
      
      {/* Page Content */}
      <div className="container mx-auto px-4">
        {children}
      </div>
    </div>
  );
};

export default UniversalPageWrapper;
export { UniversalPageWrapper };