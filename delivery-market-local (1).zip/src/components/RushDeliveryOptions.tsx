import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, Zap, MapPin, Shield, Calendar } from 'lucide-react';

interface RushDeliveryOptionsProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRush: () => void;
  onSelectScheduled: () => void;
  baseDeliveryFee: number;
}

const DELIVERY_TIMES = [
  { time: '9:00 AM', available: true },
  { time: '12:00 PM', available: true },
  { time: '3:00 PM', available: false },
  { time: '6:00 PM', available: true },
  { time: '9:00 PM', available: true }
];

export const RushDeliveryOptions: React.FC<RushDeliveryOptionsProps> = ({
  isOpen,
  onClose,
  onSelectRush,
  onSelectScheduled,
  baseDeliveryFee
}) => {
  const rushFee = 5.00;
  const driverBonus = 2.50;
  const platformFee = 2.50;
  const totalWithRush = baseDeliveryFee + rushFee;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-green-600" />
            Choose Your Delivery Option
          </DialogTitle>
          <p className="text-sm text-gray-600 mt-2">
            Safe contactless delivery to your door - no pickup required!
          </p>
        </DialogHeader>
        
        <div className="grid md:grid-cols-2 gap-4">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow border-orange-200" onClick={onSelectRush}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-orange-500" />
                Rush Delivery
                <Badge variant="outline" className="text-orange-600 border-orange-300">
                  +$5.00
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm text-gray-600">
                  Get your order delivered immediately by the next available driver
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">30-60 minutes</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">Direct delivery</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Contactless delivery</span>
                  </div>
                </div>
                <div className="bg-orange-50 p-3 rounded-lg">
                  <div className="text-sm space-y-1">
                    <div className="flex justify-between">
                      <span>Base delivery:</span>
                      <span>${baseDeliveryFee.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Rush fee:</span>
                      <span>+${rushFee.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-bold border-t pt-1">
                      <span>Total:</span>
                      <span>${totalWithRush.toFixed(2)}</span>
                    </div>
                    <div className="text-xs text-gray-500 mt-2">
                      Driver gets ${driverBonus.toFixed(2)} bonus
                    </div>
                  </div>
                </div>
                <Button className="w-full bg-orange-600 hover:bg-orange-700" onClick={onSelectRush}>
                  Select Rush Delivery
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow border-blue-200" onClick={onSelectScheduled}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-500" />
                Scheduled Delivery
                <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                  Standard Rate
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm text-gray-600">
                  Wait for the next scheduled delivery route in your area
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">Next available time slot</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">Optimized route</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Contactless delivery</span>
                  </div>
                </div>
                <div className="bg-blue-50 p-3 rounded-lg">
                  <div className="text-sm font-medium mb-2">Available Time Slots Today:</div>
                  <div className="space-y-1">
                    {DELIVERY_TIMES.map((slot, index) => (
                      <div key={index} className={`flex justify-between items-center ${
                        slot.available ? 'text-green-600' : 'text-gray-400'
                      }`}>
                        <span>{slot.time}</span>
                        <Badge variant={slot.available ? 'default' : 'secondary'} className="text-xs">
                          {slot.available ? 'Available' : 'Full'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                  <div className="text-sm font-bold mt-3 pt-2 border-t">
                    Delivery fee: ${baseDeliveryFee.toFixed(2)}
                  </div>
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={onSelectScheduled}>
                  Select Scheduled Delivery
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex items-center gap-2 text-green-700">
            <Shield className="w-4 h-4" />
            <span className="font-medium">Safe Delivery Guarantee</span>
          </div>
          <p className="text-sm text-green-600 mt-1">
            All deliveries are contactless and brought safely to your door. No pickup required!
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};