import React from 'react';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Camera, Edit, Star, MapPin } from 'lucide-react';

interface ProfileHeaderProps {
  user: {
    name: string;
    email: string;
    avatar?: string;
    membershipType: string;
    location?: string;
    rating?: number;
    verified?: boolean;
  };
  onEditProfile: () => void;
}

export const ProfileHeader: React.FC<ProfileHeaderProps> = ({ user, onEditProfile }) => {
  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getMembershipColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'pro': return 'bg-gradient-to-r from-yellow-400 to-yellow-600';
      case 'business': return 'bg-gradient-to-r from-blue-500 to-blue-700';
      case 'driver': return 'bg-gradient-to-r from-green-500 to-green-700';
      case 'musician': return 'bg-gradient-to-r from-purple-500 to-purple-700';
      default: return 'bg-gradient-to-r from-gray-500 to-gray-700';
    }
  };

  return (
    <Card className="bg-gradient-to-r from-slate-800 to-slate-900 border-slate-700 p-6">
      <div className="flex flex-col md:flex-row items-center gap-6">
        <div className="relative">
          <Avatar className="w-24 h-24 border-4 border-slate-600">
            <AvatarImage src={user.avatar} alt={user.name} />
            <AvatarFallback className="text-2xl font-bold bg-slate-700">
              {getInitials(user.name)}
            </AvatarFallback>
          </Avatar>
          <Button
            size="sm"
            className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 p-0"
            variant="secondary"
          >
            <Camera className="w-4 h-4" />
          </Button>
        </div>
        
        <div className="flex-1 text-center md:text-left">
          <div className="flex items-center gap-2 justify-center md:justify-start mb-2">
            <h1 className="text-2xl font-bold text-white">{user.name}</h1>
            {user.verified && (
              <Badge variant="secondary" className="bg-blue-600 text-white">
                ✓ Verified
              </Badge>
            )}
          </div>
          
          <p className="text-slate-300 mb-2">{user.email}</p>
          
          <div className="flex items-center gap-4 justify-center md:justify-start mb-3">
            {user.location && (
              <div className="flex items-center gap-1 text-slate-400">
                <MapPin className="w-4 h-4" />
                <span className="text-sm">{user.location}</span>
              </div>
            )}
            
            {user.rating && (
              <div className="flex items-center gap-1 text-yellow-400">
                <Star className="w-4 h-4 fill-current" />
                <span className="text-sm font-medium">{user.rating.toFixed(1)}</span>
              </div>
            )}
          </div>
          
          <Badge className={`${getMembershipColor(user.membershipType)} text-white font-semibold`}>
            {user.membershipType.toUpperCase()} MEMBER
          </Badge>
        </div>
        
        <Button onClick={onEditProfile} variant="outline" className="border-slate-600">
          <Edit className="w-4 h-4 mr-2" />
          Edit Profile
        </Button>
      </div>
    </Card>
  );
};