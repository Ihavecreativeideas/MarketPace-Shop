import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Clock, Package, Truck, AlertCircle } from 'lucide-react';
import { DeliveryNotificationModal } from './DeliveryNotificationModal';
import TipRatingSystem from './TipRatingSystem';

interface DeliveryItem {
  id: string;
  name: string;
  seller: string;
  buyer: string;
  sellerAddress: string;
  buyerAddress: string;
  status: 'picked_up' | 'in_transit' | 'delivered' | 'accepted' | 'declined';
  pickupTime?: string;
  deliveryTime?: string;
}

const DeliveryTrackingDemo = () => {
  const [selectedItem, setSelectedItem] = useState<DeliveryItem | null>(null);
  const [showNotification, setShowNotification] = useState(false);
  const [showTipRating, setShowTipRating] = useState(false);
  const [userType, setUserType] = useState<'buyer' | 'seller'>('buyer');
  
  const [deliveryItems, setDeliveryItems] = useState<DeliveryItem[]>([
    {
      id: 'A1',
      name: 'Vintage Guitar',
      seller: 'John Music Store',
      buyer: 'Sarah Johnson',
      sellerAddress: '123 Oak St',
      buyerAddress: '321 Maple Ln',
      status: 'delivered',
      pickupTime: '10:15 AM',
      deliveryTime: '11:30 AM'
    },
    {
      id: 'B2',
      name: 'Gaming Laptop',
      seller: 'Tech Solutions',
      buyer: 'Mike Chen',
      sellerAddress: '456 Pine Ave',
      buyerAddress: '987 Birch St',
      status: 'in_transit',
      pickupTime: '10:45 AM'
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'picked_up': return 'bg-blue-100 text-blue-800';
      case 'in_transit': return 'bg-yellow-100 text-yellow-800';
      case 'delivered': return 'bg-orange-100 text-orange-800';
      case 'accepted': return 'bg-green-100 text-green-800';
      case 'declined': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleDeliveryNotification = (item: DeliveryItem) => {
    setSelectedItem(item);
    setShowNotification(true);
  };

  const handleAcceptItem = () => {
    if (selectedItem) {
      setDeliveryItems(prev => 
        prev.map(item => 
          item.id === selectedItem.id 
            ? { ...item, status: 'accepted' }
            : item
        )
      );
      setShowNotification(false);
      setShowTipRating(true);
    }
  };

  const handleDeclineItem = () => {
    if (selectedItem) {
      setDeliveryItems(prev => 
        prev.map(item => 
          item.id === selectedItem.id 
            ? { ...item, status: 'declined' }
            : item
        )
      );
      setShowNotification(false);
      alert('Item will be returned. Seller pays return fees.');
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck className="h-5 w-5" />
            Live Delivery Tracking Demo
          </CardTitle>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              variant={userType === 'buyer' ? 'default' : 'outline'}
              onClick={() => setUserType('buyer')}
            >
              View as Buyer
            </Button>
            <Button 
              size="sm" 
              variant={userType === 'seller' ? 'default' : 'outline'}
              onClick={() => setUserType('seller')}
            >
              View as Seller
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {deliveryItems.map((item) => (
              <div key={item.id} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-medium">{item.name}</h3>
                    <p className="text-sm text-gray-600">ID: {item.id}</p>
                  </div>
                  <Badge className={getStatusColor(item.status)}>
                    {item.status.replace('_', ' ').toUpperCase()}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Package className="h-4 w-4 text-gray-500" />
                      <span>From: {item.seller}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="h-4 w-4" />
                      <span>{item.sellerAddress}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Package className="h-4 w-4 text-gray-500" />
                      <span>To: {item.buyer}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="h-4 w-4" />
                      <span>{item.buyerAddress}</span>
                    </div>
                  </div>
                </div>
                
                {item.status === 'delivered' && (
                  <div className="bg-orange-50 border border-orange-200 rounded p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertCircle className="h-4 w-4 text-orange-600" />
                      <span className="text-sm font-medium text-orange-800">
                        Delivery Confirmation Required
                      </span>
                    </div>
                    <Button 
                      size="sm" 
                      onClick={() => handleDeliveryNotification(item)}
                      className="bg-orange-600 hover:bg-orange-700"
                    >
                      {userType === 'seller' ? 'Respond to Delivery' : 'View Status'}
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {selectedItem && (
        <>
          <DeliveryNotificationModal
            isOpen={showNotification}
            onClose={() => setShowNotification(false)}
            itemName={selectedItem.name}
            buyerAddress={selectedItem.buyerAddress}
            sellerAddress={selectedItem.sellerAddress}
            userType={userType}
            onAccept={handleAcceptItem}
            onDecline={handleDeclineItem}
          />
          
          <TipRatingSystem
            isOpen={showTipRating}
            onClose={() => setShowTipRating(false)}
            driverName="Alex Rodriguez"
            deliveryId={selectedItem.id}
            userType={userType}
            onSubmit={() => setShowTipRating(false)}
          />
        </>
      )}
    </div>
  );
};

export default DeliveryTrackingDemo;
export { DeliveryTrackingDemo };