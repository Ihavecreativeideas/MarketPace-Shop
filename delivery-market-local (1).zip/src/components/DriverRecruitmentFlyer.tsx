import React from 'react';
import { Button } from './ui/button';
import { Car, Clock, DollarSign, MapPin, Users } from 'lucide-react';

interface DriverRecruitmentFlyerProps {
  onApplyNow?: () => void;
}

const DriverRecruitmentFlyer: React.FC<DriverRecruitmentFlyerProps> = ({ onApplyNow }) => {
  return (
    <div className="bg-gradient-to-br from-orange-400 via-pink-500 to-purple-600 p-8 rounded-2xl shadow-2xl text-white max-w-md mx-auto transform hover:scale-105 transition-transform duration-300">
      {/* Header with Car */}
      <div className="text-center mb-6">
        <div className="relative inline-block">
          <Car className="h-16 w-16 text-yellow-300 mx-auto mb-2 animate-bounce" />
          <div className="absolute -top-2 -right-2 bg-yellow-300 rounded-full p-1">
            <span className="text-xs text-purple-600 font-bold">🚗</span>
          </div>
        </div>
        <h1 className="text-2xl font-bold mb-2 text-yellow-200">
          MarketPace
        </h1>
        <p className="text-lg font-semibold">
          Delivering Opportunities to a town near you!
        </p>
      </div>

      {/* Main Message */}
      <div className="text-center mb-6">
        <p className="text-base font-medium mb-4">
          Apply to become a driver today! Flexible hours, competitive pay, and the chance to support your local community.
        </p>
      </div>

      {/* Benefits Grid */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white/20 rounded-lg p-3 text-center backdrop-blur-sm">
          <Clock className="h-6 w-6 mx-auto mb-1 text-yellow-300" />
          <p className="text-sm font-semibold">Flexible Hours</p>
        </div>
        <div className="bg-white/20 rounded-lg p-3 text-center backdrop-blur-sm">
          <DollarSign className="h-6 w-6 mx-auto mb-1 text-yellow-300" />
          <p className="text-sm font-semibold">Great Pay</p>
        </div>
        <div className="bg-white/20 rounded-lg p-3 text-center backdrop-blur-sm">
          <MapPin className="h-6 w-6 mx-auto mb-1 text-yellow-300" />
          <p className="text-sm font-semibold">Local Routes</p>
        </div>
        <div className="bg-white/20 rounded-lg p-3 text-center backdrop-blur-sm">
          <Users className="h-6 w-6 mx-auto mb-1 text-yellow-300" />
          <p className="text-sm font-semibold">Community Impact</p>
        </div>
      </div>

      {/* CTA Button */}
      <div className="text-center">
        <Button 
          onClick={onApplyNow}
          className="bg-yellow-400 hover:bg-yellow-300 text-purple-800 font-bold py-3 px-6 rounded-full text-lg shadow-lg transform hover:scale-105 transition-all duration-200"
          size="lg"
        >
          Apply to Drive Now
        </Button>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-4 right-4 opacity-20">
        <div className="w-8 h-8 bg-yellow-300 rounded-full animate-pulse"></div>
      </div>
      <div className="absolute bottom-4 left-4 opacity-20">
        <div className="w-6 h-6 bg-pink-300 rounded-full animate-pulse delay-1000"></div>
      </div>
    </div>
  );
};

export default DriverRecruitmentFlyer;