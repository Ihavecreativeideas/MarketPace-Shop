import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, MapPin, Users, Clock, Star, Ticket, Heart, Share2 } from 'lucide-react';
import { useState } from 'react';

interface LiveEventsProps {
  onBookEvent?: (event: any) => void;
}

const LiveEvents: React.FC<LiveEventsProps> = ({ onBookEvent }) => {
  const [favorites, setFavorites] = useState<number[]>([]);

  const mockEvents = [
    {
      id: 1,
      title: 'Jazz Night at Blue Moon',
      artist: 'The Midnight Blues',
      venue: 'Blue Moon Cafe',
      date: '2024-01-15',
      time: '8:00 PM',
      location: 'Downtown',
      price: '$25-45',
      category: 'Jazz',
      image: '/placeholder.svg',
      rating: 4.8,
      attendees: 156,
      description: 'An intimate evening of smooth jazz featuring local favorites.',
      ticketsLeft: 23,
      isPopular: true
    },
    {
      id: 2,
      title: 'Rock the Night',
      artist: 'Electric Storm',
      venue: 'The Underground',
      date: '2024-01-18',
      time: '9:30 PM',
      location: 'Midtown',
      price: '$35-60',
      category: 'Rock',
      image: '/placeholder.svg',
      rating: 4.9,
      attendees: 89,
      description: 'High-energy rock concert with special guest appearances.',
      ticketsLeft: 45,
      isPopular: false
    },
    {
      id: 3,
      title: 'Acoustic Sessions',
      artist: 'Sarah Mitchell',
      venue: 'Coffee House Central',
      date: '2024-01-20',
      time: '7:00 PM',
      location: 'Uptown',
      price: '$15-25',
      category: 'Acoustic',
      image: '/placeholder.svg',
      rating: 4.7,
      attendees: 67,
      description: 'Intimate acoustic performance in a cozy setting.',
      ticketsLeft: 12,
      isPopular: true
    },
    {
      id: 4,
      title: 'Comedy Night Live',
      artist: 'Various Comedians',
      venue: 'Laugh Track Club',
      date: '2024-01-22',
      time: '8:30 PM',
      location: 'Downtown',
      price: '$20-35',
      category: 'Comedy',
      image: '/placeholder.svg',
      rating: 4.6,
      attendees: 134,
      description: 'Stand-up comedy featuring local and touring comedians.',
      ticketsLeft: 38,
      isPopular: false
    }
  ];

  const toggleFavorite = (eventId: number) => {
    setFavorites(prev => 
      prev.includes(eventId) 
        ? prev.filter(id => id !== eventId)
        : [...prev, eventId]
    );
  };

  const handleBookEvent = (event: any) => {
    if (onBookEvent) {
      onBookEvent(event);
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'jazz': return 'bg-blue-100 text-blue-800';
      case 'rock': return 'bg-red-100 text-red-800';
      case 'acoustic': return 'bg-green-100 text-green-800';
      case 'comedy': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-gray-900">Live Events</h2>
        <p className="text-gray-600">Discover and book tickets for upcoming live performances</p>
      </div>

      {/* Events Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockEvents.map((event) => (
          <Card key={event.id} className="hover:shadow-lg transition-all duration-200">
            <CardHeader className="p-0 relative">
              <img 
                src={event.image} 
                alt={event.title} 
                className="w-full h-48 object-cover rounded-t-lg" 
              />
              <div className="absolute top-2 right-2 flex gap-1">
                {event.isPopular && (
                  <Badge className="bg-orange-600">Popular</Badge>
                )}
                <Badge className={getCategoryColor(event.category)}>
                  {event.category}
                </Badge>
              </div>
              <div className="absolute top-2 left-2">
                <Button
                  size="sm"
                  variant="ghost"
                  className="bg-white/80 hover:bg-white"
                  onClick={() => toggleFavorite(event.id)}
                >
                  <Heart 
                    className={`w-4 h-4 ${
                      favorites.includes(event.id) 
                        ? 'fill-red-500 text-red-500' 
                        : 'text-gray-600'
                    }`} 
                  />
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="p-4 space-y-3">
              <div>
                <CardTitle className="text-lg">{event.title}</CardTitle>
                <p className="text-sm text-gray-600 font-medium">{event.artist}</p>
              </div>

              {/* Event Details */}
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>{new Date(event.date).toLocaleDateString()}</span>
                  <Clock className="w-4 h-4 ml-2" />
                  <span>{event.time}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>{event.venue}, {event.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  <span>{event.attendees} attending</span>
                  <Star className="w-4 h-4 ml-2 fill-yellow-400 text-yellow-400" />
                  <span>{event.rating}</span>
                </div>
              </div>

              {/* Description */}
              <p className="text-sm text-gray-700">{event.description}</p>

              {/* Price and Tickets */}
              <div className="flex justify-between items-center">
                <div className="text-lg font-bold text-green-600">
                  {event.price}
                </div>
                <div className="text-sm text-orange-600">
                  {event.ticketsLeft} tickets left
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-2">
                <Button 
                  size="sm" 
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  onClick={() => handleBookEvent(event)}
                >
                  <Ticket className="w-4 h-4 mr-1" />
                  Buy Tickets
                </Button>
                <Button size="sm" variant="outline">
                  <Share2 className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default LiveEvents;