import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, UserX, Flag, AlertTriangle } from 'lucide-react';

const BlockReportMembers = () => {
  const [reportType, setReportType] = useState('');
  const [memberToReport, setMemberToReport] = useState('');
  const [description, setDescription] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const reportTypes = [
    'Spam or fake account',
    'Harassment or bullying',
    'Inappropriate content',
    'Scam or fraud',
    'Selling prohibited items',
    'Impersonation',
    'Other'
  ];

  const handleSubmitReport = () => {
    // Handle report submission
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const handleBlockMember = () => {
    // Handle blocking member
    alert(`Member ${memberToReport} has been blocked`);
  };

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-6 h-6" />
            Block & Report Members
          </CardTitle>
          <CardDescription>
            Help keep our community safe by reporting inappropriate behavior or blocking members
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {submitted && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Thank you for your report. Our team will review it within 24 hours.
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Member Username or ID</label>
              <Input
                placeholder="Enter username or member ID"
                value={memberToReport}
                onChange={(e) => setMemberToReport(e.target.value)}
              />
            </div>

            <div className="flex gap-2">
              <Button
                variant="destructive"
                onClick={handleBlockMember}
                disabled={!memberToReport}
                className="flex items-center gap-2"
              >
                <UserX className="w-4 h-4" />
                Block Member
              </Button>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Flag className="w-5 h-5" />
              Report Member
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Report Type</label>
                <Select value={reportType} onValueChange={setReportType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select reason for report" />
                  </SelectTrigger>
                  <SelectContent>
                    {reportTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Description</label>
                <Textarea
                  placeholder="Please provide details about the issue..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                />
              </div>

              <Button
                onClick={handleSubmitReport}
                disabled={!memberToReport || !reportType || !description}
                className="w-full"
              >
                Submit Report
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Community Safety Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <p>• Reports are reviewed by our moderation team within 24 hours</p>
            <p>• False reports may result in account restrictions</p>
            <p>• Blocked members cannot contact you or see your listings</p>
            <p>• You can unblock members at any time from your settings</p>
            <p>• For urgent safety concerns, contact our support team directly</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BlockReportMembers;