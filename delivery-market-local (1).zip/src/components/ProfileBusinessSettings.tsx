import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Store, Globe, Truck, TrendingUp, Download, Link } from 'lucide-react';

const ProfileBusinessSettings: React.FC = () => {
  const [businessData, setBusinessData] = useState({
    businessName: 'John\'s Electronics',
    businessType: 'shops' as 'shops' | 'services' | 'entertainment',
    ein: '12-3456789',
    website: 'https://johnselectronics.com',
    description: 'Premium electronics and gadgets for tech enthusiasts.',
    deliverySettings: {
      useOwnDelivery: true,
      splitDeliveryFee: false,
      additionalFees: 5.99,
      freeDeliveryThreshold: 50
    },
    websiteIntegration: {
      connected: true,
      productsSynced: 24,
      lastSync: '2 hours ago',
      autoSync: true
    },
    promotions: {
      aiAnalytics: true,
      monthlyBudget: 200,
      activePromotions: 3
    }
  });

  const [activeTab, setActiveTab] = useState('general');

  const handleInputChange = (field: string, value: any) => {
    setBusinessData(prev => ({ ...prev, [field]: value }));
  };

  const handleNestedChange = (parent: string, field: string, value: any) => {
    setBusinessData(prev => ({
      ...prev,
      [parent]: { ...prev[parent as keyof typeof prev] as any, [field]: value }
    }));
  };

  const businessMetrics = [
    { label: 'Monthly Revenue', value: '$3,245', change: '+18%' },
    { label: 'Total Orders', value: '127', change: '+12%' },
    { label: 'Conversion Rate', value: '4.2%', change: '+0.9%' },
    { label: 'Avg Order Value', value: '$78', change: '+8%' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Business Settings</h1>
          <p className="text-gray-600">Manage your business profile and integrations</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {businessMetrics.map((metric, index) => (
            <Card key={index}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{metric.label}</p>
                    <p className="text-2xl font-bold">{metric.value}</p>
                  </div>
                  <div className="text-sm font-medium text-green-500">{metric.change}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="website">Website</TabsTrigger>
            <TabsTrigger value="delivery">Delivery</TabsTrigger>
            <TabsTrigger value="promotions">Promotions</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Store className="w-5 h-5" />Business Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="businessName">Business Name</Label>
                    <Input id="businessName" value={businessData.businessName} onChange={(e) => handleInputChange('businessName', e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ein">EIN (Tax ID)</Label>
                    <Input id="ein" value={businessData.ein} onChange={(e) => handleInputChange('ein', e.target.value)} placeholder="12-3456789" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="businessType">Business Type</Label>
                  <Select value={businessData.businessType} onValueChange={(value) => handleInputChange('businessType', value)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="shops">Shops - Physical Products</SelectItem>
                      <SelectItem value="services">Services - Professional Services</SelectItem>
                      <SelectItem value="entertainment">Entertainment - Musicians/DJs</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Business Description</Label>
                  <Textarea id="description" value={businessData.description} onChange={(e) => handleInputChange('description', e.target.value)} className="min-h-[100px]" />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="website" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5" />Website Integration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="website">Website URL</Label>
                  <Input id="website" value={businessData.website} onChange={(e) => handleInputChange('website', e.target.value)} placeholder="https://yourwebsite.com" />
                </div>
                <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <div>
                      <p className="font-medium">Website Connected</p>
                      <p className="text-sm text-gray-600">Products are syncing automatically</p>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-800">{businessData.websiteIntegration.productsSynced} Products</Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Last Sync</Label>
                    <p className="text-sm text-gray-600">{businessData.websiteIntegration.lastSync}</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Auto Sync</Label>
                    <Switch checked={businessData.websiteIntegration.autoSync} onCheckedChange={(checked) => handleNestedChange('websiteIntegration', 'autoSync', checked)} />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button className="flex items-center gap-2"><Download className="w-4 h-4" />Sync Now</Button>
                  <Button variant="outline" className="flex items-center gap-2"><Link className="w-4 h-4" />Integration Guide</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="delivery" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Truck className="w-5 h-5" />Delivery Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Use Own Delivery Service</Label>
                    <p className="text-sm text-gray-600">Integrate with your existing delivery system</p>
                  </div>
                  <Switch checked={businessData.deliverySettings.useOwnDelivery} onCheckedChange={(checked) => handleNestedChange('deliverySettings', 'useOwnDelivery', checked)} />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Split Delivery Fee</Label>
                    <p className="text-sm text-gray-600">Share delivery costs with customers</p>
                  </div>
                  <Switch checked={businessData.deliverySettings.splitDeliveryFee} onCheckedChange={(checked) => handleNestedChange('deliverySettings', 'splitDeliveryFee', checked)} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="additionalFees">Additional Handling Fee ($)</Label>
                    <Input id="additionalFees" type="number" step="0.01" value={businessData.deliverySettings.additionalFees} onChange={(e) => handleNestedChange('deliverySettings', 'additionalFees', parseFloat(e.target.value))} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="freeDeliveryThreshold">Free Delivery Threshold ($)</Label>
                    <Input id="freeDeliveryThreshold" type="number" value={businessData.deliverySettings.freeDeliveryThreshold} onChange={(e) => handleNestedChange('deliverySettings', 'freeDeliveryThreshold', parseInt(e.target.value))} />
                  </div>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium mb-2">Delivery Fee Structure</h4>
                  <div className="space-y-2 text-sm">
                    <p>• Personal accounts: Fees split 50/50 between buyer and seller</p>
                    <p>• Business accounts: You control fee distribution</p>
                    <p>• You can absorb fees, pass to customer, or split as preferred</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="promotions" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />AI Analytics & Promotions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">AI Analytics</Label>
                    <p className="text-sm text-gray-600">Get AI-powered insights and recommendations</p>
                  </div>
                  <Switch checked={businessData.promotions.aiAnalytics} onCheckedChange={(checked) => handleNestedChange('promotions', 'aiAnalytics', checked)} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="monthlyBudget">Monthly Promotion Budget ($)</Label>
                    <Input id="monthlyBudget" type="number" value={businessData.promotions.monthlyBudget} onChange={(e) => handleNestedChange('promotions', 'monthlyBudget', parseInt(e.target.value))} />
                  </div>
                  <div className="space-y-2">
                    <Label>Active Promotions</Label>
                    <p className="text-2xl font-bold">{businessData.promotions.activePromotions}</p>
                  </div>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <h4 className="font-medium mb-2">AI Insights</h4>
                  <div className="space-y-2 text-sm">
                    <p>• Optimize pricing based on market trends</p>
                    <p>• Target promotions to interested customers</p>
                    <p>• Analyze competitor pricing and positioning</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ProfileBusinessSettings;