import React from 'react';
import { Checkbox } from './ui/checkbox';
import { Label } from './ui/label';
import { Package, Package2, Truck } from 'lucide-react';

interface DeliveryTypeSelectorProps {
  selectedTypes: string[];
  onChange: (types: string[]) => void;
}

const DeliveryTypeSelector: React.FC<DeliveryTypeSelectorProps> = ({ selectedTypes, onChange }) => {
  const handleTypeChange = (type: string, checked: boolean) => {
    if (checked) {
      onChange([...selectedTypes, type]);
    } else {
      onChange(selectedTypes.filter(t => t !== type));
    }
  };

  return (
    <div className="space-y-4">
      <Label className="text-base font-medium">Delivery Types You Can Handle *</Label>
      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          <Checkbox 
            id="small" 
            checked={selectedTypes.includes('small')}
            onCheckedChange={(checked) => handleTypeChange('small', !!checked)}
          />
          <Label htmlFor="small" className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            Small Items (documents, food, small packages)
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox 
            id="medium" 
            checked={selectedTypes.includes('medium')}
            onCheckedChange={(checked) => handleTypeChange('medium', !!checked)}
          />
          <Label htmlFor="medium" className="flex items-center gap-2">
            <Package2 className="w-4 h-4" />
            Medium Items (electronics, clothing, groceries)
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox 
            id="large" 
            checked={selectedTypes.includes('large')}
            onCheckedChange={(checked) => handleTypeChange('large', !!checked)}
          />
          <Label htmlFor="large" className="flex items-center gap-2">
            <Truck className="w-4 h-4" />
            Large Items (furniture, appliances, workout equipment)
          </Label>
        </div>
      </div>
    </div>
  );
};

export default DeliveryTypeSelector;