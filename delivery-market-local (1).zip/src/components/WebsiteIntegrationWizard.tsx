import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Globe, Code, Zap, CheckCircle, ArrowRight, Copy } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface WebsiteIntegrationWizardProps {
  onClose: () => void;
}

export default function WebsiteIntegrationWizard({ onClose }: WebsiteIntegrationWizardProps) {
  const [step, setStep] = useState(1);
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [platform, setPlatform] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [integrationCode, setIntegrationCode] = useState('');
  const [syncSettings, setSyncSettings] = useState({
    autoSync: true,
    syncImages: true,
    syncPrices: true,
    syncInventory: true
  });

  const generateIntegrationCode = () => {
    const code = `
<!-- MarketPace Integration Code -->
<script>
  window.MarketPaceConfig = {
    businessId: '${Math.random().toString(36).substr(2, 9)}',
    websiteUrl: '${websiteUrl}',
    platform: '${platform}',
    syncSettings: ${JSON.stringify(syncSettings, null, 2)}
  };
</script>
<script src="https://cdn.marketpace.com/integration.js"></script>
    `.trim();
    
    setIntegrationCode(code);
    setApiKey(`mp_${Math.random().toString(36).substr(2, 32)}`);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard!" });
  };

  const handleNext = () => {
    if (step === 2) {
      generateIntegrationCode();
    }
    setStep(step + 1);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Website Integration Wizard
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Progress Bar */}
          <div className="flex items-center justify-between">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className={`flex items-center ${
                i < 4 ? 'flex-1' : ''
              }`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step >= i ? 'bg-blue-600 text-white' : 'bg-gray-200'
                }`}>
                  {step > i ? <CheckCircle className="h-4 w-4" /> : i}
                </div>
                {i < 4 && (
                  <div className={`flex-1 h-1 mx-2 ${
                    step > i ? 'bg-blue-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>

          {/* Step 1: Website Details */}
          {step === 1 && (
            <Card>
              <CardHeader>
                <CardTitle>Website Information</CardTitle>
                <CardDescription>Tell us about your existing website</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="website-url">Website URL</Label>
                  <Input
                    id="website-url"
                    placeholder="https://yourstore.com"
                    value={websiteUrl}
                    onChange={(e) => setWebsiteUrl(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="platform">Platform</Label>
                  <Select value={platform} onValueChange={setPlatform}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your platform" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="shopify">Shopify</SelectItem>
                      <SelectItem value="woocommerce">WooCommerce</SelectItem>
                      <SelectItem value="magento">Magento</SelectItem>
                      <SelectItem value="squarespace">Squarespace</SelectItem>
                      <SelectItem value="custom">Custom/Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 2: Sync Settings */}
          {step === 2 && (
            <Card>
              <CardHeader>
                <CardTitle>Synchronization Settings</CardTitle>
                <CardDescription>Configure how your products sync with MarketPace</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Auto-sync products</Label>
                    <p className="text-sm text-gray-600">Automatically sync new products</p>
                  </div>
                  <Switch
                    checked={syncSettings.autoSync}
                    onCheckedChange={(checked) => setSyncSettings({...syncSettings, autoSync: checked})}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Sync product images</Label>
                    <p className="text-sm text-gray-600">Mirror product photos perfectly</p>
                  </div>
                  <Switch
                    checked={syncSettings.syncImages}
                    onCheckedChange={(checked) => setSyncSettings({...syncSettings, syncImages: checked})}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Sync pricing</Label>
                    <p className="text-sm text-gray-600">Keep prices synchronized</p>
                  </div>
                  <Switch
                    checked={syncSettings.syncPrices}
                    onCheckedChange={(checked) => setSyncSettings({...syncSettings, syncPrices: checked})}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Sync inventory</Label>
                    <p className="text-sm text-gray-600">Real-time stock updates</p>
                  </div>
                  <Switch
                    checked={syncSettings.syncInventory}
                    onCheckedChange={(checked) => setSyncSettings({...syncSettings, syncInventory: checked})}
                  />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Integration Code */}
          {step === 3 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  Integration Code
                </CardTitle>
                <CardDescription>Add this code to your website</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>API Key</Label>
                  <div className="flex gap-2">
                    <Input value={apiKey} readOnly />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(apiKey)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div>
                  <Label>Integration Code</Label>
                  <div className="relative">
                    <Textarea
                      value={integrationCode}
                      readOnly
                      rows={10}
                      className="font-mono text-sm"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={() => copyToClipboard(integrationCode)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 4: Complete */}
          {step === 4 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  Integration Complete!
                </CardTitle>
                <CardDescription>Your website is now connected to MarketPace</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="font-medium text-green-800">What happens next?</h3>
                  <ul className="text-sm text-green-700 mt-2 space-y-1">
                    <li>• Products will sync automatically within 24 hours</li>
                    <li>• Images and prices will be mirrored perfectly</li>
                    <li>• You can manage sync settings from your dashboard</li>
                    <li>• Orders from MarketPace will appear in your system</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Navigation */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => step > 1 ? setStep(step - 1) : onClose()}
            >
              {step > 1 ? 'Back' : 'Cancel'}
            </Button>
            <Button
              onClick={step < 4 ? handleNext : onClose}
              disabled={step === 1 && (!websiteUrl || !platform)}
            >
              {step < 4 ? (
                <>
                  Next <ArrowRight className="h-4 w-4 ml-1" />
                </>
              ) : (
                'Finish'
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}