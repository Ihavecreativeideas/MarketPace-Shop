import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DollarSign, MapPin, Clock, CheckCircle, Zap, Truck, Heart } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface DeliveryRoute {
  id: string;
  driver_id: string;
  status: 'assigned' | 'in_progress' | 'completed';
  pickups: number;
  dropoffs: number;
  total_miles: number;
  is_large_item: boolean;
  is_urgent: boolean;
  base_pay: number;
  mileage_pay: number;
  large_item_pay?: number;
  urgent_bonus?: number;
  tips: number;
  total_earnings: number;
  completed_at?: string;
}

interface DriverPaymentSystemProps {
  driverId: string;
}

const DriverPaymentSystem: React.FC<DriverPaymentSystemProps> = ({ driverId }) => {
  const [routes, setRoutes] = useState<DeliveryRoute[]>([]);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [pendingPayment, setPendingPayment] = useState(0);

  useEffect(() => {
    fetchDriverRoutes();
  }, [driverId]);

  const fetchDriverRoutes = async () => {
    try {
      const { data, error } = await supabase
        .from('delivery_routes')
        .select('*')
        .eq('driver_id', driverId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRoutes(data || []);
      
      const total = data?.reduce((sum, route) => sum + route.total_earnings, 0) || 0;
      setTotalEarnings(total);
      
      const pending = data?.filter(route => route.status === 'completed' && !route.paid_at)
        .reduce((sum, route) => sum + route.total_earnings, 0) || 0;
      setPendingPayment(pending);
    } catch (error) {
      console.error('Error fetching driver routes:', error);
    }
  };

  const processInstantPayment = async (routeId: string) => {
    try {
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/4f9b62c2-db04-4293-88fb-fce001aa326c',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            route_id: routeId,
            driver_id: driverId,
            payment_type: 'instant_route_completion'
          })
        }
      );

      if (response.ok) {
        await fetchDriverRoutes();
      }
    } catch (error) {
      console.error('Error processing payment:', error);
    }
  };

  const calculateRoutePay = (pickups: number, dropoffs: number, miles: number, isLarge: boolean, isUrgent: boolean, tips: number = 0) => {
    let basePay = 0;
    let mileagePay = miles * 0.50;
    let largeItemPay = 0;
    let urgentBonus = 0;

    if (isLarge) {
      largeItemPay = 40; // $40+ for large items requiring heavy pickup, truck, or trailer
    } else {
      basePay = (pickups * 4) + (dropoffs * 2);
    }

    if (isUrgent) {
      const baseAmount = basePay + mileagePay + largeItemPay;
      urgentBonus = baseAmount * 0.35; // 35% bonus for urgent deliveries
    }

    return {
      basePay,
      mileagePay,
      largeItemPay,
      urgentBonus,
      tips, // Drivers keep 100% of tips
      total: basePay + mileagePay + largeItemPay + urgentBonus + tips
    };
  };

  return (
    <div className="space-y-6">
      {/* Tips Highlight */}
      <Card className="border-2 border-green-300 bg-green-50">
        <CardContent className="pt-6">
          <div className="flex items-center justify-center gap-2 text-green-800">
            <Heart className="w-6 h-6" />
            <h3 className="text-xl font-bold">You Keep 100% of All Tips!</h3>
          </div>
          <p className="text-center text-green-700 mt-2">No platform fees or deductions on customer tips</p>
        </CardContent>
      </Card>

      {/* Earnings Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalEarnings.toFixed(2)}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Payment</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">${pendingPayment.toFixed(2)}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Routes Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{routes.filter(r => r.status === 'completed').length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Pay Structure Info */}
      <Card>
        <CardHeader>
          <CardTitle>Driver Pay Structure</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm mb-4">
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="font-bold text-green-600">$4.00</div>
              <div className="text-gray-600">Per Pickup</div>
            </div>
            <div className="text-center p-3 bg-blue-50 rounded-lg">
              <div className="font-bold text-blue-600">$2.00</div>
              <div className="text-gray-600">Per Drop-off</div>
            </div>
            <div className="text-center p-3 bg-purple-50 rounded-lg">
              <div className="font-bold text-purple-600">$0.50</div>
              <div className="text-gray-600">Per Mile</div>
            </div>
            <div className="text-center p-3 bg-orange-50 rounded-lg">
              <div className="font-bold text-orange-600">$40+</div>
              <div className="text-gray-600">Large Items</div>
            </div>
            <div className="text-center p-3 bg-red-50 rounded-lg">
              <div className="font-bold text-red-600">Bonus</div>
              <div className="text-gray-600">Urgent Delivery</div>
            </div>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                Standard Route Example:
              </h4>
              <p className="text-sm text-gray-600">
                3 pickups + 3 drop-offs + 10 miles = $12.00 + $6.00 + $5.00 = <strong>$23.00</strong>
              </p>
            </div>
            <div className="p-4 bg-orange-50 rounded-lg">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Truck className="w-4 h-4" />
                Large Item Example:
              </h4>
              <p className="text-sm text-gray-600">
                Heavy pickup + 8 miles = $40.00 + $4.00 = <strong>$44.00</strong>
              </p>
            </div>
          </div>
          <div className="mt-4 p-4 bg-yellow-50 rounded-lg">
            <h4 className="font-semibold mb-2 flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Large Items & Urgent Delivery:
            </h4>
            <p className="text-sm text-gray-600">
              $40+ for large items requiring heavy pickup, truck, or trailer. Urgent delivery bonus available.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Recent Routes */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Delivery Routes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {routes.map((route) => {
              const pay = calculateRoutePay(
                route.pickups, 
                route.dropoffs, 
                route.total_miles, 
                route.is_large_item,
                route.is_urgent,
                route.tips
              );
              return (
                <div key={route.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant={route.status === 'completed' ? 'default' : 'secondary'}>
                        {route.status.replace('_', ' ').toUpperCase()}
                      </Badge>
                      {route.is_large_item && <Badge className="bg-orange-600">Large Item</Badge>}
                      {route.is_urgent && <Badge className="bg-red-600">Urgent</Badge>}
                      <span className="text-sm text-gray-600">
                        {route.completed_at && new Date(route.completed_at).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {route.pickups} pickups, {route.dropoffs} drop-offs
                      </div>
                      <div>{route.total_miles} miles</div>
                      <div className="font-semibold">${pay.total.toFixed(2)} total</div>
                    </div>
                    {(route.tips > 0 || route.is_urgent) && (
                      <div className="text-xs mt-1 space-y-1">
                        {route.tips > 0 && <div className="text-green-600">Tips (100% yours): ${route.tips.toFixed(2)}</div>}
                        {route.is_urgent && <div className="text-red-600">Urgent delivery bonus</div>}
                      </div>
                    )}
                  </div>
                  
                  {route.status === 'completed' && (
                    <Button 
                      onClick={() => processInstantPayment(route.id)}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Get Paid Now
                    </Button>
                  )}
                </div>
              );
            })}
            
            {routes.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No delivery routes yet. Complete your first route to see earnings!
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DriverPaymentSystem;