import { useState } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Play, Users, Calendar, MapPin, Heart, MessageCircle, Share2, Video, Music, Briefcase, Image, BarChart3, MessageSquare } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface CommunityPost {
  id: string;
  type: 'livestream' | 'event' | 'thought' | 'sale' | 'music' | 'hire' | 'job' | 'picture' | 'poll';
  author: string;
  avatar: string;
  title: string;
  description: string;
  location: string;
  timestamp: string;
  likes: number;
  comments: number;
  isLive?: boolean;
  eventDate?: string;
  price?: string;
  pollOptions?: { text: string; votes: number }[];
  totalVotes?: number;
  pollEndsIn?: string;
}

const CommunityFeed: React.FC = () => {
  const [posts] = useState<CommunityPost[]>([
    {
      id: '1',
      type: 'livestream',
      author: 'Mike\'s Music Store',
      avatar: '/api/placeholder/40/40',
      title: 'Live Guitar Demo - New Arrivals',
      description: 'Showcasing our latest acoustic guitars and taking requests!',
      location: 'Springfield',
      timestamp: '2 minutes ago',
      likes: 24,
      comments: 8,
      isLive: true
    },
    {
      id: '2',
      type: 'poll',
      author: 'Community Manager',
      avatar: '/api/placeholder/40/40',
      title: 'What type of events would you like to see more of?',
      description: 'Help us plan better community events by voting!',
      location: 'Springfield',
      timestamp: '1 hour ago',
      likes: 15,
      comments: 23,
      pollOptions: [
        { text: 'Live Music Concerts', votes: 45 },
        { text: 'Food Festivals', votes: 32 },
        { text: 'Art & Craft Shows', votes: 28 },
        { text: 'Sports Events', votes: 19 }
      ],
      totalVotes: 124,
      pollEndsIn: '23 hours'
    },
    {
      id: '3',
      type: 'sale',
      author: 'Sarah\'s Vintage Shop',
      avatar: '/api/placeholder/40/40',
      title: 'Vintage Guitar Collection - Must Go!',
      description: 'Moving sale! Beautiful vintage guitars, some rare finds. Serious buyers only.',
      location: 'Springfield',
      timestamp: '2 hours ago',
      likes: 67,
      comments: 15,
      price: '$200-$1500'
    },
    {
      id: '4',
      type: 'music',
      author: 'The Local Band',
      avatar: '/api/placeholder/40/40',
      title: 'New Single Released: "Springfield Nights"',
      description: 'Our love letter to this amazing town! Available on all streaming platforms.',
      location: 'Springfield',
      timestamp: '4 hours ago',
      likes: 89,
      comments: 34
    },
    {
      id: '5',
      type: 'hire',
      author: 'DJ Mike',
      avatar: '/api/placeholder/40/40',
      title: 'Available for Weddings & Private Events',
      description: 'Professional DJ services with 10+ years experience. Full sound system included.',
      location: 'Springfield',
      timestamp: '6 hours ago',
      likes: 23,
      comments: 7
    },
    {
      id: '6',
      type: 'thought',
      author: 'Community Member',
      avatar: '/api/placeholder/40/40',
      title: 'Concern: Need Better Lighting at Central Park',
      description: 'The walking paths are too dark in the evenings. Has anyone else noticed this safety issue?',
      location: 'Springfield',
      timestamp: '8 hours ago',
      likes: 156,
      comments: 42
    }
  ]);

  const handleLike = (postId: string) => {
    toast({ title: 'Liked!', description: 'Post added to your favorites' });
  };

  const handleComment = (postId: string) => {
    toast({ title: 'Comment', description: 'Comment feature coming soon!' });
  };

  const handleShare = (postId: string) => {
    toast({ title: 'Shared!', description: 'Post shared successfully' });
  };

  const handleVote = (postId: string, optionIndex: number) => {
    toast({ title: 'Vote Recorded!', description: 'Thank you for participating in the poll' });
  };

  const getPostIcon = (type: string) => {
    switch (type) {
      case 'livestream': return Video;
      case 'event': return Calendar;
      case 'thought': return MessageSquare;
      case 'sale': return BarChart3;
      case 'music': return Music;
      case 'hire': return Briefcase;
      case 'job': return Briefcase;
      case 'picture': return Image;
      case 'poll': return BarChart3;
      default: return MessageCircle;
    }
  };

  const getPostColor = (type: string) => {
    switch (type) {
      case 'livestream': return 'bg-red-500';
      case 'event': return 'bg-purple-500';
      case 'thought': return 'bg-blue-500';
      case 'sale': return 'bg-green-500';
      case 'music': return 'bg-pink-500';
      case 'hire': return 'bg-orange-500';
      case 'job': return 'bg-indigo-500';
      case 'picture': return 'bg-teal-500';
      case 'poll': return 'bg-purple-600';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-4">
      {posts.map((post) => {
        const Icon = getPostIcon(post.type);
        return (
          <Card key={post.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={post.avatar} />
                    <AvatarFallback>{post.author[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-black">{post.author}</h3>
                      <Badge 
                        variant="secondary" 
                        className={`${getPostColor(post.type)} text-white`}
                      >
                        <Icon className="w-3 h-3 mr-1" />
                        {post.type === 'livestream' ? 'LIVE' : post.type.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-500">{post.timestamp}</p>
                  </div>
                </div>
                {post.isLive && (
                  <div className="flex items-center gap-1 text-red-500">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                    <span className="text-xs font-medium">LIVE</span>
                  </div>
                )}
              </div>
            </CardHeader>
            
            <CardContent className="pt-0">
              <h4 className="font-semibold mb-2 text-black">{post.title}</h4>
              <p className="text-gray-600 mb-3">{post.description}</p>
              
              {post.eventDate && (
                <div className="flex items-center gap-2 mb-3 text-sm text-purple-600">
                  <Calendar className="w-4 h-4" />
                  <span>{post.eventDate}</span>
                </div>
              )}
              
              {post.price && (
                <div className="flex items-center gap-2 mb-3 text-sm text-green-600 font-semibold">
                  <span>Price: {post.price}</span>
                </div>
              )}
              
              {post.pollOptions && (
                <div className="mb-4 space-y-2">
                  {post.pollOptions.map((option, index) => {
                    const percentage = post.totalVotes ? (option.votes / post.totalVotes) * 100 : 0;
                    return (
                      <div key={index} className="space-y-1">
                        <div className="flex justify-between items-center">
                          <Button
                            variant="ghost"
                            className="text-left justify-start p-0 h-auto font-normal text-black hover:text-purple-600"
                            onClick={() => handleVote(post.id, index)}
                          >
                            {option.text}
                          </Button>
                          <span className="text-sm text-gray-500">{option.votes} votes</span>
                        </div>
                        <Progress value={percentage} className="h-2" />
                      </div>
                    );
                  })}
                  <div className="text-xs text-gray-500 mt-2">
                    {post.totalVotes} total votes • Poll ends in {post.pollEndsIn}
                  </div>
                </div>
              )}
              
              <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                <MapPin className="w-4 h-4" />
                <span>{post.location}</span>
              </div>
              
              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-3 border-t">
                <div className="flex items-center gap-4">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleLike(post.id)}
                    className="flex items-center gap-1 text-gray-600 hover:text-red-500"
                  >
                    <Heart className="w-4 h-4" />
                    <span>{post.likes}</span>
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleComment(post.id)}
                    className="flex items-center gap-1 text-gray-600 hover:text-blue-500"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{post.comments}</span>
                  </Button>
                </div>
                
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => handleShare(post.id)}
                  className="flex items-center gap-1 text-gray-600 hover:text-green-500"
                >
                  <Share2 className="w-4 h-4" />
                  Share
                </Button>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};

export default CommunityFeed;