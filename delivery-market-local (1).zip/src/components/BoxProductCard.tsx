import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Heart, Star } from 'lucide-react';

interface BoxProductCardProps {
  id: string;
  title: string;
  price: number;
  image?: string;
  location: string;
  rating?: number;
  isRental?: boolean;
  isAvailable?: boolean;
  onRent?: () => void;
  onBuy?: () => void;
  onFavorite?: () => void;
  isFavorited?: boolean;
}

const BoxProductCard: React.FC<BoxProductCardProps> = ({
  id,
  title,
  price,
  image,
  location,
  rating = 0,
  isRental = false,
  isAvailable = true,
  onRent,
  onBuy,
  onFavorite,
  isFavorited = false
}) => {
  const handleAction = () => {
    if (isRental && onRent) {
      onRent();
    } else if (onBuy) {
      onBuy();
    }
  };

  return (
    <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 group">
      <CardContent className="p-4">
        <div className="relative mb-4">
          <div className="w-full h-48 bg-white/10 rounded-lg overflow-hidden">
            {image ? (
              <img 
                src={image} 
                alt={title} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-6xl">
                📦
              </div>
            )}
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-2 right-2 bg-black/20 hover:bg-black/40 text-white p-2"
            onClick={onFavorite}
          >
            <Heart className={`w-4 h-4 ${isFavorited ? 'fill-red-500 text-red-500' : ''}`} />
          </Button>
          
          {!isAvailable && (
            <Badge className="absolute top-2 left-2 bg-red-500/80 text-white">
              Unavailable
            </Badge>
          )}
          
          {isRental && (
            <Badge className="absolute bottom-2 left-2 bg-purple-500/80 text-white">
              For Rent
            </Badge>
          )}
        </div>
        
        <div className="space-y-3">
          <div>
            <h3 className="text-white font-semibold text-lg truncate group-hover:text-purple-300 transition-colors">
              {title}
            </h3>
            
            <div className="flex items-center gap-1 text-gray-400 text-sm mt-1">
              <MapPin className="w-3 h-3 flex-shrink-0" />
              <span className="truncate">{location}</span>
            </div>
            
            {rating > 0 && (
              <div className="flex items-center gap-1 mt-1">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                <span className="text-yellow-400 text-sm">{rating.toFixed(1)}</span>
              </div>
            )}
          </div>
          
          <div className="flex items-center justify-between">
            <div className="text-green-400 font-bold text-xl">
              ${price.toFixed(2)}{isRental ? '/day' : ''}
            </div>
            
            <Button
              onClick={handleAction}
              disabled={!isAvailable}
              className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-6 py-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isRental ? 'Rent Now' : 'Buy Now'}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default BoxProductCard;
export { BoxProductCard };