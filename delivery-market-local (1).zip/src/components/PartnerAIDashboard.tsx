import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bot, CheckCircle, Circle, ArrowRight, Code, Globe, Zap, MessageCircle, Gift } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { BackButton } from './BackButton';

interface PartnerAIDashboardProps {
  partnerTier?: 'marketplace' | 'silver' | 'gold' | 'platinum';
  userId: string;
}

const PartnerAIDashboard: React.FC<PartnerAIDashboardProps> = ({ partnerTier = 'marketplace', userId }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [chatMessages, setChatMessages] = useState<Array<{id: string, type: 'ai' | 'user', message: string}>>([]);
  const [inputMessage, setInputMessage] = useState('');
  const { toast } = useToast();

  const integrationSteps = [
    { id: 'setup', title: 'Initial Setup', description: 'Configure your MarketPlace Partner account' },
    { id: 'website', title: 'Website Integration', description: 'Connect your website to our platform' },
    { id: 'social', title: 'Social Media Setup', description: 'Configure social media integration' },
    { id: 'analytics', title: 'Analytics Setup', description: 'Set up performance tracking' },
    { id: 'launch', title: 'Go Live', description: 'Launch your integrated solution' }
  ];

  const partnerBenefits = [
    'Website integration included',
    'Platform to promote your business', 
    'No added delivery fees (customers pay driver only)',
    'Social media integration tools',
    'Analytics and performance insights',
    'Customer messaging system',
    'Inventory management tools',
    'Marketing promotion features',
    'Priority customer support',
    'Mobile app access for business management'
  ];

  useEffect(() => {
    setChatMessages([{
      id: '1',
      type: 'ai',
      message: `Welcome to your FREE MarketPlace Partner AI Assistant! I'm here to help you set up your business integration and make the most of all your benefits. What would you like to start with?`
    }]);
  }, []);

  const handleStepComplete = (stepId: string) => {
    if (!completedSteps.includes(stepId)) {
      const newCompleted = [...completedSteps, stepId];
      setCompletedSteps(newCompleted);
      
      toast({
        title: 'Step Completed!',
        description: `${stepId} setup has been completed successfully`
      });
      
      if (currentStep < integrationSteps.length - 1) {
        setCurrentStep(currentStep + 1);
      }
    }
  };

  const sendMessage = (message: string) => {
    if (!message.trim()) return;
    
    const userMessage = { id: Date.now().toString(), type: 'user' as const, message };
    setChatMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    
    // Simple AI responses for beta
    const aiResponses = [
      "Great question! During our beta testing, all features are completely FREE. I can help you set up website integration, social media tools, and analytics.",
      "I'm here to help you maximize your MarketPlace Partner benefits! What specific integration would you like to work on?",
      "As a beta tester, you're getting incredible value - all premium features at no cost. Let me guide you through the setup process."
    ];
    
    const aiMessage = {
      id: (Date.now() + 1).toString(),
      type: 'ai' as const,
      message: aiResponses[Math.floor(Math.random() * aiResponses.length)]
    };
    
    setTimeout(() => {
      setChatMessages(prev => [...prev, aiMessage]);
    }, 1000);
  };

  const progress = (completedSteps.length / integrationSteps.length) * 100;

  return (
    <div className="max-w-6xl mx-auto space-y-6 p-6">
      <BackButton to="/" />
      
      <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bot className="h-10 w-10 text-green-600" />
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                  MarketPlace Partner AI Assistant
                </h1>
                <p className="text-gray-600 mt-1">Your FREE guide to business integration and premium benefits</p>
              </div>
            </div>
            <Badge className="bg-green-600 text-white">
              <Gift className="w-3 h-3 mr-1" />
              FREE BETA
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="h-5 w-5 text-green-600" />
              AI Chat Assistant
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="h-64 overflow-y-auto space-y-3 p-3 bg-gray-50 rounded-lg">
              {chatMessages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-xs p-3 rounded-lg ${msg.type === 'user' ? 'bg-green-600 text-white' : 'bg-white border shadow-sm'}`}>
                    <p className="text-sm">{msg.message}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="Ask me about your MarketPlace Partner benefits..."
                className="flex-1 p-2 border rounded-lg"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage(inputMessage)}
              />
              <Button size="sm" onClick={() => sendMessage(inputMessage)} className="bg-green-600 hover:bg-green-700">Send</Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Code className="h-5 w-5" />
              Setup Progress
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Integration Progress</span>
                <span className="text-sm text-gray-600">{Math.round(progress)}% Complete</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-600 h-2 rounded-full transition-all duration-300" style={{width: `${progress}%`}}></div>
              </div>
            </div>
            
            <div className="space-y-3">
              {integrationSteps.map((step, index) => {
                const isCompleted = completedSteps.includes(step.id);
                const isCurrent = index === currentStep;
                
                return (
                  <div key={step.id} className={`p-3 rounded-lg border ${isCurrent ? 'border-green-300 bg-green-50' : isCompleted ? 'border-green-300 bg-green-50' : 'border-gray-200'}`}>
                    <div className="flex items-start gap-3">
                      {isCompleted ? (
                        <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      ) : (
                        <Circle className={`h-5 w-5 mt-0.5 ${isCurrent ? 'text-green-600' : 'text-gray-400'}`} />
                      )}
                      <div className="flex-1">
                        <h4 className="font-semibold text-sm">{step.title}</h4>
                        <p className="text-xs text-gray-600">{step.description}</p>
                        {isCurrent && (
                          <Button size="sm" className="mt-2 bg-green-600 hover:bg-green-700" onClick={() => handleStepComplete(step.id)}>
                            Complete <ArrowRight className="h-3 w-3 ml-1" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Your FREE MarketPlace Partner Benefits
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              {partnerBenefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">{benefit}</span>
                </div>
              ))}
            </div>
            <div className="space-y-2">
              <Button variant="outline" className="w-full" onClick={() => sendMessage('Tell me more about website integration')}>
                <Globe className="h-4 w-4 mr-2" />
                Website Integration Help
              </Button>
              <Button variant="outline" className="w-full" onClick={() => sendMessage('How do I set up social media integration?')}>
                <Code className="h-4 w-4 mr-2" />
                Social Media Setup
              </Button>
              <Button variant="outline" className="w-full" onClick={() => sendMessage('Show me analytics features')}>
                <Zap className="h-4 w-4 mr-2" />
                Analytics & Insights
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PartnerAIDashboard;