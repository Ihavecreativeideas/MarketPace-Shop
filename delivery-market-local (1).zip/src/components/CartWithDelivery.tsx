import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ShoppingCart, Trash2, Plus, Minus, MapPin } from 'lucide-react';
import { useCart } from '@/components/CartContext';
import { DeliveryFeeCalculator } from '@/components/DeliveryFeeCalculator';

interface CartWithDeliveryProps {
  onCheckout?: () => void;
}

export const CartWithDelivery: React.FC<CartWithDeliveryProps> = ({ onCheckout }) => {
  const { cartItems, removeFromCart, clearCart, getCartTotal } = useCart();
  const [estimatedMiles, setEstimatedMiles] = useState(5); // Default estimate

  // Calculate unique pickup locations (assuming different sellers)
  const uniqueSellers = new Set(cartItems.map(item => item.id.split('-')[0])).size;
  const pickupCount = uniqueSellers || 1;
  const dropoffCount = 1; // Assuming single delivery address

  const productTotal = getCartTotal();
  
  const updateQuantity = (id: string, change: number) => {
    const item = cartItems.find(item => item.id === id);
    if (item) {
      if (change < 0 && item.quantity === 1) {
        removeFromCart(id);
      } else {
        // This would need to be implemented in CartContext
        console.log('Update quantity not implemented');
      }
    }
  };

  if (cartItems.length === 0) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="p-6 text-center">
          <ShoppingCart className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-500">Your cart is empty</p>
          <p className="text-sm text-gray-400 mt-2">
            Add items to create your delivery route
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            Your Cart ({cartItems.length} items)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {cartItems.map((item) => (
              <div key={item.id} className="flex items-center gap-4 p-4 border rounded-lg">
                <img 
                  src={item.image} 
                  alt={item.name}
                  className="w-16 h-16 object-cover rounded"
                />
                <div className="flex-1">
                  <h3 className="font-medium">{item.name}</h3>
                  <p className="text-sm text-gray-500">${item.price.toFixed(2)} each</p>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => updateQuantity(item.id, -1)}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="w-8 text-center">{item.quantity}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => updateQuantity(item.id, 1)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <div className="text-right">
                  <div className="font-semibold">
                    ${(item.price * item.quantity).toFixed(2)}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFromCart(item.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <Separator className="my-4" />
          
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Product Subtotal:</span>
              <span className="font-semibold">${productTotal.toFixed(2)}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <MapPin className="h-4 w-4" />
              <span>Estimated delivery route: {estimatedMiles} miles</span>
            </div>
          </div>

          <div className="flex gap-2 mt-4">
            <Button variant="outline" onClick={clearCart} className="flex-1">
              Clear Cart
            </Button>
            <Button onClick={onCheckout} className="flex-1">
              Proceed to Checkout
            </Button>
          </div>
        </CardContent>
      </Card>

      <DeliveryFeeCalculator
        pickupCount={pickupCount}
        dropoffCount={dropoffCount}
        totalMiles={estimatedMiles}
        showBreakdown={true}
      />

      <Card>
        <CardContent className="p-4">
          <div className="bg-gradient-to-r from-blue-50 to-green-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="secondary">🎯 Early Member Benefits</Badge>
            </div>
            <p className="text-sm text-gray-700">
              Join during our startup trial and lock in lifetime discounts! 
              Support MarketPace's success and benefit from reduced fees forever.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CartWithDelivery;