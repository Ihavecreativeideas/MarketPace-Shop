import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import EmailVerification from '@/components/EmailVerification';
import PasswordReset from '@/components/PasswordReset';
import OrderTracking from '@/components/OrderTracking';
import SellerDashboard from '@/components/SellerDashboard';
import ReviewSystem from '@/components/ReviewSystem';
import SearchAndFilter from '@/components/SearchAndFilter';
import { CheckCircle, Mail, KeyRound, Package, Store, Star, Search } from 'lucide-react';

export default function MissingFeaturesIntegration() {
  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-600" />
        <h1 className="text-3xl font-bold mb-2">All Features Implemented!</h1>
        <p className="text-muted-foreground">
          All requested missing features have been successfully added to MarketPace
        </p>
      </div>

      <Tabs defaultValue="email" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="email" className="flex items-center gap-1">
            <Mail className="h-4 w-4" />
            Email
          </TabsTrigger>
          <TabsTrigger value="password" className="flex items-center gap-1">
            <KeyRound className="h-4 w-4" />
            Password
          </TabsTrigger>
          <TabsTrigger value="tracking" className="flex items-center gap-1">
            <Package className="h-4 w-4" />
            Tracking
          </TabsTrigger>
          <TabsTrigger value="seller" className="flex items-center gap-1">
            <Store className="h-4 w-4" />
            Seller
          </TabsTrigger>
          <TabsTrigger value="reviews" className="flex items-center gap-1">
            <Star className="h-4 w-4" />
            Reviews
          </TabsTrigger>
          <TabsTrigger value="search" className="flex items-center gap-1">
            <Search className="h-4 w-4" />
            Search
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="email" className="mt-6">
          <EmailVerification />
        </TabsContent>
        
        <TabsContent value="password" className="mt-6">
          <PasswordReset />
        </TabsContent>
        
        <TabsContent value="tracking" className="mt-6">
          <OrderTracking />
        </TabsContent>
        
        <TabsContent value="seller" className="mt-6">
          <SellerDashboard />
        </TabsContent>
        
        <TabsContent value="reviews" className="mt-6">
          <ReviewSystem allowReview={true} />
        </TabsContent>
        
        <TabsContent value="search" className="mt-6">
          <SearchAndFilter />
        </TabsContent>
      </Tabs>
    </div>
  );
}