import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { FloatingBottomNavigation } from './FloatingBottomNavigation';
import { User, Car, Building, Shield, Package, Truck, Music, Store, Settings, Edit, History, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

// Updated UserProfile with navigation to professional pages
export const UserProfile: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-20">
      <div className="max-w-2xl mx-auto px-4 py-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-teal-500 rounded-full mx-auto mb-4 flex items-center justify-center">
              <User className="h-10 w-10 text-white" />
            </div>
            <CardTitle className="text-white">User Profile</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center text-slate-300">
              <p>Welcome to your profile page!</p>
              <p className="text-sm text-slate-400 mt-2">Manage your account settings and preferences here.</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Button 
                variant="outline" 
                className="text-white flex items-center gap-2"
                onClick={() => navigate('/edit-profile')}
              >
                <Edit className="h-4 w-4" />
                Edit Profile
              </Button>
              <Button 
                variant="outline" 
                className="text-white flex items-center gap-2"
                onClick={() => navigate('/settings')}
              >
                <Settings className="h-4 w-4" />
                Settings
              </Button>
              <Button 
                variant="outline" 
                className="text-white flex items-center gap-2"
                onClick={() => navigate('/order-history')}
              >
                <History className="h-4 w-4" />
                Order History
              </Button>
              <Button 
                variant="outline" 
                className="text-white flex items-center gap-2"
                onClick={() => navigate('/favorites')}
              >
                <Heart className="h-4 w-4" />
                Favorites
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      <FloatingBottomNavigation />
    </div>
  );
};

// Updated DriverDashboard with floating nav
export const DriverDashboard: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-20">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <Card className="bg-slate-800/50 border-slate-700 mb-6">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-blue-500 rounded-full mx-auto mb-4 flex items-center justify-center">
              <Car className="h-10 w-10 text-white" />
            </div>
            <CardTitle className="text-white">Driver Dashboard</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center text-slate-300">
              <p>Welcome to your driver dashboard!</p>
              <p className="text-sm text-slate-400 mt-2">Manage your deliveries and routes here.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-slate-700/50 border-slate-600">
                <CardContent className="p-4">
                  <h3 className="text-white font-semibold mb-2">Available Routes</h3>
                  <p className="text-slate-400 text-sm">2 routes available in your area</p>
                  <Button className="mt-2 bg-teal-500 hover:bg-teal-600">View Routes</Button>
                </CardContent>
              </Card>
              <Card className="bg-slate-700/50 border-slate-600">
                <CardContent className="p-4">
                  <h3 className="text-white font-semibold mb-2">Earnings</h3>
                  <p className="text-slate-400 text-sm">$125.50 this week</p>
                  <Button className="mt-2 bg-green-500 hover:bg-green-600">View Earnings</Button>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      </div>
      <FloatingBottomNavigation />
    </div>
  );
};

// Updated BusinessDashboard with floating nav
export const BusinessDashboard: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-20">
      <div className="max-w-4xl mx-auto px-4 py-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-purple-500 rounded-full mx-auto mb-4 flex items-center justify-center">
              <Building className="h-10 w-10 text-white" />
            </div>
            <CardTitle className="text-white">Business Dashboard</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center text-slate-300">
              <p>Manage your business on MarketPace</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="outline" className="text-white">Inventory</Button>
              <Button variant="outline" className="text-white">Orders</Button>
              <Button variant="outline" className="text-white">Analytics</Button>
            </div>
          </CardContent>
        </Card>
      </div>
      <FloatingBottomNavigation />
    </div>
  );
};

// Updated AdminDashboard with floating nav
export const AdminDashboard: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-20">
      <div className="max-w-6xl mx-auto px-4 py-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-red-500 rounded-full mx-auto mb-4 flex items-center justify-center">
              <Shield className="h-10 w-10 text-white" />
            </div>
            <CardTitle className="text-white">Admin Dashboard</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center text-slate-300">
              <p>System administration and monitoring</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button variant="outline" className="text-white">Users</Button>
              <Button variant="outline" className="text-white">Drivers</Button>
              <Button variant="outline" className="text-white">Businesses</Button>
              <Button variant="outline" className="text-white">Analytics</Button>
            </div>
          </CardContent>
        </Card>
      </div>
      <FloatingBottomNavigation />
    </div>
  );
};

// Simple placeholder components
export const DeliverNowPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-20">
      <div className="max-w-2xl mx-auto px-4 py-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader className="text-center">
            <Truck className="h-12 w-12 text-teal-400 mx-auto mb-4" />
            <CardTitle className="text-white">Delivery Service</CardTitle>
          </CardHeader>
          <CardContent className="text-center text-slate-300">
            <p>Fast local delivery service coming soon!</p>
          </CardContent>
        </Card>
      </div>
      <FloatingBottomNavigation />
    </div>
  );
};

export const DriverApplicationPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-20">
      <div className="max-w-2xl mx-auto px-4 py-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader className="text-center">
            <Car className="h-12 w-12 text-blue-400 mx-auto mb-4" />
            <CardTitle className="text-white">Become a Driver</CardTitle>
          </CardHeader>
          <CardContent className="text-center text-slate-300">
            <p>Apply to become a MarketPace driver!</p>
            <Button className="mt-4 bg-teal-500 hover:bg-teal-600">Apply Now</Button>
          </CardContent>
        </Card>
      </div>
      <FloatingBottomNavigation />
    </div>
  );
};