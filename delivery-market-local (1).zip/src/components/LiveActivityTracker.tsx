import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface OnlineUser {
  user_id: string;
  username: string;
  last_active: string;
}

interface TrendingItem {
  id: string;
  type: string;
  item_id: string;
  views: number;
  created_at: string;
}

interface LiveActivity {
  id: string;
  user_id: string;
  username: string;
  activity: string;
  created_at: string;
}

export const LiveActivityTracker: React.FC = () => {
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([]);
  const [trendingItems, setTrendingItems] = useState<TrendingItem[]>([]);
  const [liveActivity, setLiveActivity] = useState<LiveActivity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchData = async () => {
    try {
      const [onlineRes, trendingRes, activityRes] = await Promise.all([
        supabase.from('online_users').select('*').order('last_active', { ascending: false }).limit(10),
        supabase.from('trending_items').select('*').order('views', { ascending: false }).limit(5),
        supabase.from('live_activity').select('*').order('created_at', { ascending: false }).limit(10)
      ]);

      if (onlineRes.data) setOnlineUsers(onlineRes.data);
      if (trendingRes.data) setTrendingItems(trendingRes.data);
      if (activityRes.data) setLiveActivity(activityRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="p-4">Loading live data...</div>;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-green-600">Online Users ({onlineUsers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {onlineUsers.map((user) => (
              <div key={user.user_id} className="flex items-center justify-between">
                <span className="text-sm">{user.username || 'Anonymous'}</span>
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  Online
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-orange-600">Trending Items</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {trendingItems.map((item) => (
              <div key={item.id} className="flex items-center justify-between">
                <span className="text-sm capitalize">{item.type}</span>
                <Badge variant="outline">{item.views} views</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-blue-600">Live Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {liveActivity.map((activity) => (
              <div key={activity.id} className="text-sm">
                <span className="font-medium">{activity.username || 'User'}</span>
                <span className="text-gray-600 ml-1">{activity.activity}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LiveActivityTracker;