import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
}

const faqItems: FAQItem[] = [
  {
    question: "What's included in the Proud Partners Pack?",
    answer: "Each tier includes business cards with QR codes, window stickers, delivery fee waivers, MarketPace gift bags, and marketing support. Higher tiers get more benefits and longer durations."
  },
  {
    question: "How long do the delivery fee waivers last?",
    answer: "Bronze partners get 6 months of no delivery fees, while Silver and Gold partners get a full year of delivery fee waivers."
  },
  {
    question: "What does 'Partners pay driver only' mean?",
    answer: "As a partner, you only pay the driver directly - no platform fees or upcharges from MarketPace. This saves you money on every delivery."
  },
  {
    question: "How does the MarketPace Partners Page work?",
    answer: "Your business gets featured on our dedicated Partners Page with increased visibility. Gold partners get top placement, Silver gets featured spots, and Bronze gets basic listings."
  },
  {
    question: "Can I upgrade my partnership tier later?",
    answer: "Yes! You can upgrade to a higher tier at any time. We'll credit your previous investment toward the new tier price."
  },
  {
    question: "What kind of social media promotion do partners get?",
    answer: "Bronze gets mentions, Silver gets dedicated posts monthly, and Gold gets weekly features plus co-marketing opportunities."
  }
];

export default function SponsorshipFAQ() {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <HelpCircle className="w-8 h-8 text-blue-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-gray-600">
            Get answers to common questions about MarketPace partnerships
          </p>
        </div>

        <div className="max-w-3xl mx-auto space-y-4">
          {faqItems.map((item, index) => (
            <Card key={index} className="overflow-hidden">
              <CardHeader className="pb-0">
                <Button
                  variant="ghost"
                  className="w-full justify-between p-0 h-auto text-left"
                  onClick={() => toggleItem(index)}
                >
                  <CardTitle className="text-lg font-semibold text-gray-900">
                    {item.question}
                  </CardTitle>
                  {openItems.includes(index) ? (
                    <ChevronUp className="w-5 h-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-500" />
                  )}
                </Button>
              </CardHeader>
              {openItems.includes(index) && (
                <CardContent className="pt-4">
                  <p className="text-gray-700 leading-relaxed">{item.answer}</p>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}