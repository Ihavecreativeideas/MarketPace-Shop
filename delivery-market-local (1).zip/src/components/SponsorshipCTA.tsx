import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Clock, Users, TrendingUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const stats = [
  { icon: <Users className="w-5 h-5" />, value: '500+', label: 'Active Partners' },
  { icon: <TrendingUp className="w-5 h-5" />, value: '25%', label: 'Avg. Sales Increase' },
  { icon: <Clock className="w-5 h-5" />, value: '48hrs', label: 'Setup Time' }
];

export default function SponsorshipCTA() {
  const navigate = useNavigate();

  return (
    <div className="py-16 bg-gradient-to-r from-purple-600 to-blue-600">
      <div className="container mx-auto px-4">
        <Card className="max-w-4xl mx-auto bg-white/95 backdrop-blur">
          <CardContent className="p-8 text-center">
            <Badge className="mb-4 bg-orange-500 hover:bg-orange-600">
              Limited Time Offer
            </Badge>
            
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Ready to Join the MarketPace Family?
            </h2>
            
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Don't miss out on this exclusive opportunity to be part of our startup campaign.
              Early partners get the best benefits and help shape the future of local commerce.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2 text-purple-600">
                    {stat.icon}
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                size="lg" 
                className="bg-purple-600 hover:bg-purple-700 text-white px-8"
                onClick={() => navigate('/partner-signup')}
              >
                Start Your Partnership
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => window.location.href = 'mailto:partners@marketpace.com'}
              >
                Contact Our Team
              </Button>
            </div>
            
            <p className="text-sm text-gray-500 mt-6">
              Questions? Email us at{' '}
              <a href="mailto:partners@marketpace.com" className="text-purple-600 hover:underline">
                partners@marketpace.com
              </a>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}