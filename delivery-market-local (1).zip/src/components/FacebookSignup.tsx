import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Facebook } from 'lucide-react';
import { useLaunch } from '@/contexts/LaunchContext';
import { toast } from './ui/use-toast';
import { supabase } from '@/lib/supabase';

interface FacebookSignupProps {
  onSuccess?: (userId: string) => void;
}

const FacebookSignup: React.FC<FacebookSignupProps> = ({ onSuccess }) => {
  const [loading, setLoading] = useState(false);
  const [fbReady, setFbReady] = useState(false);
  const { incrementSignups, isLaunched } = useLaunch();

  useEffect(() => {
    const initFB = () => {
      if (window.FB) {
        window.FB.init({
          appId: '1234567890123456', // Replace with your actual Facebook App ID
          cookie: true,
          xfbml: true,
          version: 'v18.0'
        });
        setFbReady(true);
      }
    };

    if (window.FB) {
      initFB();
    } else {
      window.fbAsyncInit = initFB;
    }
  }, []);

  const handleFacebookSignup = async () => {
    if (!fbReady) {
      toast({ title: 'Facebook is still loading, please try again', variant: 'destructive' });
      return;
    }

    setLoading(true);
    
    window.FB.login(async (response) => {
      try {
        if (response.authResponse) {
          // Get user info from Facebook
          window.FB.api('/me', { fields: 'name,email' }, async (userInfo) => {
            try {
              // Check if user already exists
              const { data: existingUser } = await supabase
                .from('users')
                .select('id')
                .eq('facebook_id', response.authResponse!.userID)
                .single();

              if (existingUser) {
                toast({ 
                  title: 'Welcome back!', 
                  description: 'You are already registered with Facebook.' 
                });
                if (onSuccess) onSuccess(existingUser.id);
                return;
              }

              // Create new user
              const { data: userData, error } = await supabase
                .from('users')
                .insert({
                  name: userInfo.name || 'Facebook User',
                  email: userInfo.email || `fb_${response.authResponse!.userID}@facebook.local`,
                  user_type: 'member',
                  is_pre_launch: !isLaunched,
                  facebook_id: response.authResponse!.userID
                })
                .select()
                .single();

              if (error) throw error;

              incrementSignups();
              
              const benefitMessage = !isLaunched 
                ? 'As a pre-launch member, you get 3 months with no sustainability fee!' 
                : 'Welcome! The sustainability fee is $4/month.';
              
              toast({ 
                title: 'Welcome to MarketPace!', 
                description: benefitMessage 
              });

              if (onSuccess) {
                onSuccess(userData.id);
              }
            } catch (error) {
              console.error('Error saving user:', error);
              toast({ title: 'Error completing signup', variant: 'destructive' });
            }
          });
        } else {
          toast({ title: 'Facebook login was cancelled', variant: 'destructive' });
        }
      } catch (error) {
        console.error('Facebook login error:', error);
        toast({ title: 'Error with Facebook login', variant: 'destructive' });
      } finally {
        setLoading(false);
      }
    }, { scope: 'email' });
  };

  return (
    <Card className="bg-gradient-to-br from-blue-600 to-blue-700 text-white border-blue-500">
      <CardHeader>
        <CardTitle className="text-center text-white flex items-center justify-center gap-2">
          <Facebook className="h-6 w-6" />
          Sign up with Facebook
        </CardTitle>
        {!isLaunched && (
          <p className="text-center text-sm text-blue-100 font-medium">
            🎉 Pre-Launch Special: 3 Months FREE!
          </p>
        )}
      </CardHeader>
      <CardContent>
        <Button 
          onClick={handleFacebookSignup}
          className="w-full bg-white text-blue-600 hover:bg-blue-50 font-semibold"
          disabled={loading || !fbReady}
        >
          {loading ? 'Connecting...' : !fbReady ? 'Loading Facebook...' : 'Continue with Facebook'}
        </Button>
        <p className="text-xs text-blue-100 text-center mt-2">
          Quick signup with your Facebook account
        </p>
      </CardContent>
    </Card>
  );
};

export default FacebookSignup;