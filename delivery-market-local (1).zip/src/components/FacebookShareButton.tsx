import React from 'react';
import { Button } from '@/components/ui/button';
import { Share2, Truck, Calendar, Home } from 'lucide-react';
import { toast } from 'sonner';

interface FacebookShareButtonProps {
  item: {
    id: string;
    title: string;
    description: string;
    price: number;
    image?: string;
    category: 'product' | 'service' | 'rental' | 'event';
    location?: string;
  };
  className?: string;
}

export default function FacebookShareButton({ item, className = '' }: FacebookShareButtonProps) {
  const getActionButton = () => {
    switch (item.category) {
      case 'product':
        return {
          text: 'Deliver Now',
          icon: <Truck className="h-4 w-4" />,
          color: 'bg-teal-600 hover:bg-teal-700'
        };
      case 'service':
        return {
          text: 'Book Now',
          icon: <Calendar className="h-4 w-4" />,
          color: 'bg-blue-600 hover:bg-blue-700'
        };
      case 'rental':
        return {
          text: 'Rent Now',
          icon: <Home className="h-4 w-4" />,
          color: 'bg-purple-600 hover:bg-purple-700'
        };
      case 'event':
        return {
          text: 'Book Now',
          icon: <Calendar className="h-4 w-4" />,
          color: 'bg-orange-600 hover:bg-orange-700'
        };
      default:
        return {
          text: 'Get Now',
          icon: <Truck className="h-4 w-4" />,
          color: 'bg-teal-600 hover:bg-teal-700'
        };
    }
  };

  const shareToFacebook = () => {
    const actionButton = getActionButton();
    const shareUrl = `${window.location.origin}/marketplace/${item.id}`;
    const shareText = `Check out this ${item.category}: ${item.title} - $${item.price.toFixed(2)}\n\n${item.description}\n\n${actionButton.text} on MarketPace!`;
    
    // Create Facebook share URL
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
    
    // Open Facebook share dialog
    window.open(
      facebookUrl,
      'facebook-share-dialog',
      'width=626,height=436,resizable=yes,scrollbars=yes'
    );
    
    toast.success('Shared to Facebook!');
  };

  const actionButton = getActionButton();

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <Button
        onClick={shareToFacebook}
        variant="outline"
        size="sm"
        className="flex items-center gap-2"
      >
        <Share2 className="h-4 w-4" />
        Share to Facebook
      </Button>
      <Button
        className={`flex items-center gap-2 text-white ${actionButton.color}`}
        size="sm"
        onClick={() => {
          toast.success(`${actionButton.text} clicked for ${item.title}`);
          // Add actual action logic here
        }}
      >
        {actionButton.icon}
        {actionButton.text}
      </Button>
    </div>
  );
}