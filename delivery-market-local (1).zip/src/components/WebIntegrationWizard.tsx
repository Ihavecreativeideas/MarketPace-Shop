import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { CheckCircle, Globe, Zap, ArrowRight, ExternalLink } from 'lucide-react';

interface WebIntegrationWizardProps {
  onClose: () => void;
}

const WebIntegrationWizard: React.FC<WebIntegrationWizardProps> = ({ onClose }) => {
  const [step, setStep] = useState(1);
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [platform, setPlatform] = useState('');
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    // Simulate connection process
    setTimeout(() => {
      setIsConnecting(false);
      setStep(4);
    }, 2000);
  };

  const platforms = [
    { name: 'Shopify', icon: '🛍️' },
    { name: 'WooCommerce', icon: '🛒' },
    { name: 'Etsy', icon: '🎨' },
    { name: 'Square', icon: '⬜' },
    { name: 'Other', icon: '🌐' }
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <Globe className="w-6 h-6 text-blue-600" />
                <span>Website Integration Wizard</span>
              </CardTitle>
              <Badge className="bg-orange-500 text-white mt-2">
                Trial Era - FREE Access
              </Badge>
            </div>
            <Button variant="ghost" onClick={onClose}>×</Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {step === 1 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Step 1: Choose Your Platform</h3>
              <div className="grid grid-cols-2 gap-3">
                {platforms.map((p) => (
                  <Button
                    key={p.name}
                    variant={platform === p.name ? "default" : "outline"}
                    onClick={() => setPlatform(p.name)}
                    className="h-16 flex flex-col space-y-1"
                  >
                    <span className="text-2xl">{p.icon}</span>
                    <span>{p.name}</span>
                  </Button>
                ))}
              </div>
              <Button 
                onClick={() => setStep(2)} 
                disabled={!platform}
                className="w-full"
              >
                Next <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Step 2: Enter Your Website URL</h3>
              <Input
                placeholder="https://yourstore.com"
                value={websiteUrl}
                onChange={(e) => setWebsiteUrl(e.target.value)}
              />
              <div className="flex space-x-2">
                <Button variant="outline" onClick={() => setStep(1)}>Back</Button>
                <Button 
                  onClick={() => setStep(3)} 
                  disabled={!websiteUrl}
                  className="flex-1"
                >
                  Next <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Step 3: Connect & Sync</h3>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-blue-800 mb-2">
                  We'll connect to your {platform} store and import your products to MarketPace.
                </p>
                <ul className="text-xs text-blue-700 space-y-1">
                  <li>• Product titles, descriptions, and images</li>
                  <li>• Pricing and inventory levels</li>
                  <li>• Categories and tags</li>
                </ul>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" onClick={() => setStep(2)}>Back</Button>
                <Button 
                  onClick={handleConnect}
                  disabled={isConnecting}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  {isConnecting ? (
                    <><Zap className="w-4 h-4 mr-2 animate-spin" /> Connecting...</>
                  ) : (
                    <>Connect Now <ArrowRight className="w-4 h-4 ml-2" /></>
                  )}
                </Button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4 text-center">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto" />
              <h3 className="text-lg font-semibold text-green-800">Integration Complete!</h3>
              <p className="text-gray-600">
                Your products are now synced with MarketPace. They'll appear in your marketplace profile.
              </p>
              <div className="bg-yellow-50 p-4 rounded-lg">
                <p className="text-sm text-yellow-800">
                  <strong>Trial Era Benefit:</strong> This integration is FREE during our trial period. 
                  Take advantage of this limited-time offer!
                </p>
              </div>
              <Button onClick={onClose} className="w-full">
                View My Products <ExternalLink className="w-4 h-4 ml-2" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default WebIntegrationWizard;