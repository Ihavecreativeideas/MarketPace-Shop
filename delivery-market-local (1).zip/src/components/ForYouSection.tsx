import React from 'react';
import { PersonalizedForYouSection } from './PersonalizedForYouSection';

interface ForYouSectionProps {
  userId: string;
}

export const ForYouSection: React.FC<ForYouSectionProps> = ({ userId }) => {
  return <PersonalizedForYouSection userId={userId} />;
};