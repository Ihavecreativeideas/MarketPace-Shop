import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart3, TrendingUp, Users, Eye, ShoppingCart, DollarSign } from 'lucide-react';

const analyticsData = [
  { label: 'Total Views', value: '12,847', change: '+23%', icon: Eye },
  { label: 'Sales', value: '$4,892', change: '+18%', icon: DollarSign },
  { label: 'Customers', value: '1,234', change: '+12%', icon: Users },
  { label: 'Conversion', value: '3.2%', change: '+0.8%', icon: ShoppingCart }
];

const topProducts = [
  { name: 'Vintage Guitar', sales: 45, revenue: '$2,250' },
  { name: 'Art Print Set', sales: 32, revenue: '$960' },
  { name: 'Handmade Jewelry', sales: 28, revenue: '$1,400' },
  { name: 'Custom Portrait', sales: 15, revenue: '$750' }
];

export default function ProAnalyticsDashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-lime-500 bg-clip-text text-transparent">
          Advanced Analytics
        </h2>
        <Badge className="bg-gradient-to-r from-blue-600 to-lime-500 text-white">
          <BarChart3 className="h-4 w-4 mr-1" />
          Pro Feature
        </Badge>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {analyticsData.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <Card key={index} className="bg-gradient-to-br from-white to-blue-50 border-blue-200">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <Icon className="h-5 w-5 text-blue-600" />
                  <Badge variant="secondary" className="text-xs bg-lime-100 text-lime-700">
                    {metric.change}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-800">{metric.value}</div>
                <p className="text-sm text-gray-600">{metric.label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Top Products */}
      <Card className="bg-gradient-to-br from-white to-lime-50 border-lime-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-800">
            <TrendingUp className="h-5 w-5 text-lime-600" />
            Top Performing Products
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topProducts.map((product, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-white rounded-lg border border-lime-100">
                <div>
                  <p className="font-medium text-gray-800">{product.name}</p>
                  <p className="text-sm text-gray-600">{product.sales} sales</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lime-600">{product.revenue}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Insights */}
      <Card className="bg-gradient-to-r from-blue-600 to-lime-500 text-white">
        <CardHeader>
          <CardTitle>AI-Powered Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            <li>• Your vintage items perform 40% better on weekends</li>
            <li>• Customers from urban areas spend 25% more on average</li>
            <li>• Adding more photos increases sales by 60%</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}