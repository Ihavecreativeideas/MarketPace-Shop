import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Truck, Package, CheckCircle, Clock, MapPin } from 'lucide-react';

interface Order {
  id: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  items: string[];
  total: number;
  estimatedDelivery: string;
  trackingNumber?: string;
  location?: string;
}

interface OrderTrackingProps {
  orderId?: string;
}

export default function OrderTracking({ orderId }: OrderTrackingProps) {
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching order data
    const fetchOrder = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockOrder: Order = {
        id: orderId || 'ORD-001',
        status: 'shipped',
        items: ['Product A', 'Product B'],
        total: 99.99,
        estimatedDelivery: '2024-01-15',
        trackingNumber: 'TRK123456789',
        location: 'Distribution Center - City'
      };
      
      setOrder(mockOrder);
      setLoading(false);
    };

    fetchOrder();
  }, [orderId]);

  const getStatusProgress = (status: string) => {
    switch (status) {
      case 'pending': return 25;
      case 'processing': return 50;
      case 'shipped': return 75;
      case 'delivered': return 100;
      default: return 0;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="h-4 w-4" />;
      case 'processing': return <Package className="h-4 w-4" />;
      case 'shipped': return <Truck className="h-4 w-4" />;
      case 'delivered': return <CheckCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="h-8 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!order) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <p>Order not found</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Order #{order.id}</span>
            <Badge variant={order.status === 'delivered' ? 'default' : 'secondary'}>
              {getStatusIcon(order.status)}
              <span className="ml-1 capitalize">{order.status}</span>
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Order Progress</span>
              <span>{getStatusProgress(order.status)}%</span>
            </div>
            <Progress value={getStatusProgress(order.status)} className="h-2" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium mb-2">Order Details</h4>
              <div className="space-y-1 text-sm">
                <p><strong>Items:</strong> {order.items.join(', ')}</p>
                <p><strong>Total:</strong> ${order.total}</p>
                <p><strong>Est. Delivery:</strong> {order.estimatedDelivery}</p>
                {order.trackingNumber && (
                  <p><strong>Tracking:</strong> {order.trackingNumber}</p>
                )}
              </div>
            </div>
            
            {order.location && (
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Current Location
                </h4>
                <p className="text-sm">{order.location}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Tracking Timeline</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { status: 'pending', label: 'Order Placed', completed: true },
              { status: 'processing', label: 'Processing', completed: true },
              { status: 'shipped', label: 'Shipped', completed: order.status === 'shipped' || order.status === 'delivered' },
              { status: 'delivered', label: 'Delivered', completed: order.status === 'delivered' }
            ].map((step, index) => (
              <div key={index} className={`flex items-center gap-3 ${step.completed ? 'text-primary' : 'text-muted-foreground'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step.completed ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                  {step.completed ? <CheckCircle className="h-4 w-4" /> : <Clock className="h-4 w-4" />}
                </div>
                <span className="font-medium">{step.label}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}