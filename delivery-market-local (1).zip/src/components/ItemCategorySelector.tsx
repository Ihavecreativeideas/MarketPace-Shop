import React from 'react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';

interface ItemCategorySelectorProps {
  value: string;
  onChange: (value: string) => void;
  showFoodWarning?: boolean;
}

const CATEGORIES = [
  { value: 'electronics', label: 'Electronics' },
  { value: 'clothing', label: 'Clothing & Accessories' },
  { value: 'home', label: 'Home & Garden' },
  { value: 'books', label: 'Books & Media' },
  { value: 'sports', label: 'Sports & Outdoors' },
  { value: 'toys', label: 'Toys & Games' },
  { value: 'beauty', label: 'Beauty & Personal Care' },
  { value: 'automotive', label: 'Automotive' },
  { value: 'crafts', label: 'Arts & Crafts' },
  { value: 'food', label: 'Food & Beverages' },
  { value: 'other', label: 'Other' }
];

const ItemCategorySelector: React.FC<ItemCategorySelectorProps> = ({
  value,
  onChange,
  showFoodWarning = true
}) => {
  const isFoodCategory = value === 'food';

  return (
    <div className="space-y-3">
      <div className="space-y-2">
        <Label htmlFor="category">Category *</Label>
        <Select value={value} onValueChange={onChange}>
          <SelectTrigger>
            <SelectValue placeholder="Select a category" />
          </SelectTrigger>
          <SelectContent>
            {CATEGORIES.map((category) => (
              <SelectItem key={category.value} value={category.value}>
                <div className="flex items-center gap-2">
                  {category.label}
                  {category.value === 'food' && (
                    <Badge variant="outline" className="text-xs">
                      External Delivery
                    </Badge>
                  )}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {isFoodCategory && showFoodWarning && (
        <Alert className="border-orange-200 bg-orange-50">
          <AlertTriangle className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-800">
            <strong>Food Items Notice:</strong> MarketPlace drivers cannot deliver food products. 
            Food items will be promoted on our platform, but customers will be directed to 
            order through Uber Eats, DoorDash, or pickup directly from your location.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
};

export default ItemCategorySelector;