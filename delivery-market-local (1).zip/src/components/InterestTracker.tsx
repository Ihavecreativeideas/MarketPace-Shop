import React from 'react';

interface InterestTrackerProps {
  userId: string;
}

export const InterestTracker: React.FC<InterestTrackerProps> = ({ userId }) => {
  // Simple interest tracker - just returns null for now
  return null;
};