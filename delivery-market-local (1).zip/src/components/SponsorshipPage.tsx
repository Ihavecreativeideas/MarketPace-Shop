import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Crown, Star, Zap, Upload, ArrowLeft, Check, Truck, Gift, TrendingUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function SponsorshipPage() {
  const navigate = useNavigate();
  const [selectedTier, setSelectedTier] = useState<number | null>(null);
  const [sponsorInfo, setSponsorInfo] = useState({
    companyName: '',
    contactName: '',
    email: '',
    phone: '',
    website: '',
    description: '',
    logo: null as File | null
  });
  const [isProcessing, setIsProcessing] = useState(false);

  const sponsorshipTiers = [
    {
      id: 1,
      name: 'Community Partner',
      price: 500,
      color: 'from-blue-500 to-blue-600',
      icon: Star,
      benefits: [
        'No delivery fees for 1 year',
        'Logo on sponsor page',
        'Monthly newsletter mention',
        'Basic analytics dashboard',
        'Community recognition',
        'Early feature access'
      ],
      promotional: [
        'Featured in 2 social media posts',
        'Mention in launch announcement',
        'Community spotlight article'
      ]
    },
    {
      id: 2,
      name: 'Growth Sponsor',
      price: 1000,
      color: 'from-purple-500 to-purple-600',
      icon: TrendingUp,
      popular: true,
      benefits: [
        'No delivery fees for 1 year',
        'Premium logo placement',
        'Weekly newsletter feature',
        'Advanced analytics access',
        'Priority customer support',
        'Beta feature testing',
        'Quarterly business review'
      ],
      promotional: [
        'Featured in 5 social media posts',
        'Dedicated blog post about partnership',
        'Logo in app loading screen',
        'Email signature inclusion'
      ]
    },
    {
      id: 3,
      name: 'Launch Champion',
      price: 1500,
      color: 'from-gold-500 to-yellow-600',
      icon: Crown,
      benefits: [
        'No delivery fees for 1 year',
        'Hero logo placement',
        'Dedicated sponsor section',
        'Full analytics suite',
        'VIP customer support',
        'Exclusive feature previews',
        'Monthly strategy calls',
        'Custom integration options'
      ],
      promotional: [
        'Featured in 10 social media posts',
        'Co-branded marketing materials',
        'Speaking opportunity at launch event',
        'Press release co-announcement',
        'App store listing mention',
        'Custom promotional campaign'
      ]
    }
  ];

  const handleTierSelect = (tierId: number) => {
    setSelectedTier(tierId);
  };

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSponsorInfo({...sponsorInfo, logo: file});
    }
  };

  const handleSubmitSponsorship = async () => {
    if (!selectedTier) {
      alert('Please select a sponsorship tier');
      return;
    }

    setIsProcessing(true);
    
    try {
      const selectedTierData = sponsorshipTiers.find(t => t.id === selectedTier);
      
      const sponsorshipData = {
        tier: selectedTierData,
        sponsor: sponsorInfo,
        timestamp: new Date().toISOString()
      };
      
      console.log('Processing sponsorship:', sponsorshipData);
      
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      alert(`Thank you for becoming a ${selectedTierData?.name}! We'll contact you within 24 hours.`);
      
      // Reset form
      setSelectedTier(null);
      setSponsorInfo({
        companyName: '',
        contactName: '',
        email: '',
        phone: '',
        website: '',
        description: '',
        logo: null
      });
      
    } catch (error) {
      console.error('Sponsorship error:', error);
      alert('There was an error processing your sponsorship. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const selectedTierData = sponsorshipTiers.find(t => t.id === selectedTier);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white py-12">
        <div className="container mx-auto px-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20 mb-4"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div className="text-center">
            <Crown className="h-16 w-16 mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Sponsorship Opportunities</h1>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              Partner with us to build the future of community commerce
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8">Choose Your Partnership Level</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {sponsorshipTiers.map((tier) => (
              <Card 
                key={tier.id}
                className={`relative cursor-pointer transition-all duration-300 hover:shadow-lg ${
                  selectedTier === tier.id 
                    ? 'ring-2 ring-purple-500 shadow-lg' 
                    : 'hover:shadow-md'
                } ${tier.popular ? 'border-2 border-purple-400' : ''}`}
                onClick={() => handleTierSelect(tier.id)}
              >
                {tier.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-purple-600">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${tier.color} flex items-center justify-center`}>
                    <tier.icon className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-xl">{tier.name}</CardTitle>
                  <div className="text-3xl font-bold text-purple-600">
                    ${tier.price.toLocaleString()}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Gift className="h-4 w-4" />
                      Core Benefits
                    </h4>
                    <ul className="space-y-1 text-sm">
                      {tier.benefits.map((benefit, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                          <span>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Zap className="h-4 w-4" />
                      Promotional Bonuses
                    </h4>
                    <ul className="space-y-1 text-sm">
                      {tier.promotional.map((promo, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <Star className="h-4 w-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                          <span>{promo}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {selectedTier && (
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="text-center">
                Complete Your {selectedTierData?.name} Application
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="company-name">Company Name *</Label>
                  <Input
                    id="company-name"
                    placeholder="Your Company"
                    value={sponsorInfo.companyName}
                    onChange={(e) => setSponsorInfo({...sponsorInfo, companyName: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="contact-name">Contact Name *</Label>
                  <Input
                    id="contact-name"
                    placeholder="Your Name"
                    value={sponsorInfo.contactName}
                    onChange={(e) => setSponsorInfo({...sponsorInfo, contactName: e.target.value})}
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="contact@company.com"
                    value={sponsorInfo.email}
                    onChange={(e) => setSponsorInfo({...sponsorInfo, email: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    placeholder="(555) 123-4567"
                    value={sponsorInfo.phone}
                    onChange={(e) => setSponsorInfo({...sponsorInfo, phone: e.target.value})}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  placeholder="https://yourcompany.com"
                  value={sponsorInfo.website}
                  onChange={(e) => setSponsorInfo({...sponsorInfo, website: e.target.value})}
                />
              </div>

              <div>
                <Label htmlFor="description">Company Description</Label>
                <Textarea
                  id="description"
                  placeholder="Tell us about your company and why you want to sponsor MarketPace..."
                  value={sponsorInfo.description}
                  onChange={(e) => setSponsorInfo({...sponsorInfo, description: e.target.value})}
                />
              </div>

              <div>
                <Label htmlFor="logo">Company Logo</Label>
                <div className="mt-2">
                  <Input
                    id="logo"
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                  <Button
                    variant="outline"
                    onClick={() => document.getElementById('logo')?.click()}
                    className="w-full"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    {sponsorInfo.logo ? sponsorInfo.logo.name : 'Upload Logo'}
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  PNG, JPG, or SVG. Max 5MB. High resolution recommended.
                </p>
              </div>

              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="flex justify-between items-center text-lg font-semibold">
                  <span>Sponsorship Investment:</span>
                  <span className="text-purple-600">${selectedTierData?.price.toLocaleString()}</span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  One-time payment for 12 months of benefits and promotional opportunities
                </p>
              </div>

              <Button 
                className="w-full bg-purple-600 hover:bg-purple-700 text-lg py-6"
                onClick={handleSubmitSponsorship}
                disabled={isProcessing || !sponsorInfo.companyName || !sponsorInfo.contactName || !sponsorInfo.email}
              >
                {isProcessing ? (
                  <div className="flex items-center gap-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                    Processing...
                  </div>
                ) : (
                  <>
                    <Crown className="h-5 w-5 mr-2" />
                    Become a Sponsor - ${selectedTierData?.price.toLocaleString()}
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}