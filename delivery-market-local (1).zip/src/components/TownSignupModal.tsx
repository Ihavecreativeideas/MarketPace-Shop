import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { MapPin, Trophy } from 'lucide-react';
import { useLaunch } from '@/contexts/LaunchContext';

interface TownSignupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSignup: (townName: string, userName: string) => void;
}

const TownSignupModal: React.FC<TownSignupModalProps> = ({ isOpen, onClose, onSignup }) => {
  const [selectedTown, setSelectedTown] = useState('');
  const [userName, setUserName] = useState('');
  const [customTown, setCustomTown] = useState('');
  const [showCustomTown, setShowCustomTown] = useState(false);
  const { townData } = useLaunch();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const townName = showCustomTown ? customTown : selectedTown;
    if (townName && userName) {
      onSignup(townName, userName);
      onClose();
      setSelectedTown('');
      setUserName('');
      setCustomTown('');
      setShowCustomTown(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            <span>Join the Town Race!</span>
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="userName">Your Name</Label>
            <Input
              id="userName"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              placeholder="Enter your name"
              required
            />
          </div>
          
          <div>
            <Label htmlFor="town">Select Your Town</Label>
            <Select value={selectedTown} onValueChange={setSelectedTown}>
              <SelectTrigger>
                <SelectValue placeholder="Choose your town" />
              </SelectTrigger>
              <SelectContent>
                {townData.map((town) => (
                  <SelectItem key={town.name} value={town.name}>
                    <div className="flex items-center justify-between w-full">
                      <span>{town.name}</span>
                      <span className="text-sm text-gray-500 ml-2">({town.members} members)</span>
                    </div>
                  </SelectItem>
                ))}
                <SelectItem value="custom" onClick={() => setShowCustomTown(true)}>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4" />
                    <span>Add New Town</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {(showCustomTown || selectedTown === 'custom') && (
            <div>
              <Label htmlFor="customTown">Town Name</Label>
              <Input
                id="customTown"
                value={customTown}
                onChange={(e) => setCustomTown(e.target.value)}
                placeholder="Enter your town name"
                required={showCustomTown}
              />
            </div>
          )}
          
          <div className="bg-blue-50 p-3 rounded-lg">
            <p className="text-sm text-blue-800">
              <Trophy className="w-4 h-4 inline mr-1" />
              Join your town's race to launch! The leading town gets special perks when we go live.
            </p>
          </div>
          
          <div className="flex space-x-2">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1">
              Join Race
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TownSignupModal;