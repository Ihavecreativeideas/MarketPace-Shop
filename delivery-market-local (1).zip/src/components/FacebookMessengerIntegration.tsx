import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageCircle, CheckCircle } from 'lucide-react';

export const FacebookMessengerIntegration: React.FC = () => {
  useEffect(() => {
    // Initialize Facebook Messenger integration
    if (typeof window !== 'undefined' && !window.FB) {
      const script = document.createElement('script');
      script.src = 'https://connect.facebook.net/en_US/sdk.js';
      script.async = true;
      script.defer = true;
      document.head.appendChild(script);

      window.fbAsyncInit = function() {
        window.FB.init({
          appId: process.env.REACT_APP_FACEBOOK_APP_ID || 'your-app-id',
          cookie: true,
          xfbml: true,
          version: 'v18.0'
        });
      };
    }
  }, []);

  const handleSetupMessenger = () => {
    // This would typically redirect to Facebook Business Suite
    // or open a setup wizard for Messenger integration
    window.open('https://business.facebook.com/settings/pages', '_blank');
  };

  return (
    <Card className="bg-white/10 backdrop-blur-sm border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <MessageCircle className="w-5 h-5" />
          Facebook Messenger Auto-Reply
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-blue-500/20 p-4 rounded-lg border border-blue-400/30">
          <h3 className="text-white font-semibold mb-2">Auto-Reply Setup</h3>
          <p className="text-gray-300 text-sm mb-3">
            When someone asks "Is this still available?" on your Facebook Marketplace posts, 
            we'll automatically reply:
          </p>
          <div className="bg-white/10 p-3 rounded border-l-4 border-green-400">
            <p className="text-white text-sm">
              "✅ Yes! Deliver now with MarketPace – download the app and we'll bring it to your door! 📦"
            </p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm text-gray-300">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span>Automatic response to availability inquiries</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-300">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span>Drives traffic to MarketPace app</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-300">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span>24/7 automated customer service</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-300">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span>Complies with Facebook's messaging policies</span>
          </div>
        </div>

        <Button 
          onClick={handleSetupMessenger}
          className="w-full bg-blue-600 hover:bg-blue-700"
        >
          Setup Messenger Integration
        </Button>

        <div className="text-xs text-gray-400 space-y-1">
          <p>• Requires Facebook Business Page</p>
          <p>• Must have pages_messaging permission</p>
          <p>• Auto-responder follows 24-hour messaging policy</p>
        </div>
      </CardContent>
    </Card>
  );
};

// Backend webhook handler (for reference - would be implemented server-side)
export const messengerWebhookHandler = `
// Example Node.js webhook handler
app.post('/webhook/messenger', (req, res) => {
  const entry = req.body.entry;
  
  for (const event of entry) {
    const messaging = event.messaging;
    
    for (const msg of messaging) {
      const text = msg.message?.text?.toLowerCase();
      
      if (text?.includes('is this still available')) {
        sendAutoReply(msg.sender.id);
      }
    }
  }
  
  res.sendStatus(200);
});

function sendAutoReply(recipientId) {
  const messageData = {
    recipient: { id: recipientId },
    message: {
      text: "✅ Yes! Deliver now with MarketPace – download the app and we'll bring it to your door! 📦 https://marketpace.app"
    }
  };

  fetch('https://graph.facebook.com/v18.0/me/messages?access_token=YOUR_PAGE_ACCESS_TOKEN', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(messageData)
  });
}
`;