import React from 'react';
import { Button } from './ui/button';
import { Building2, Car, Users, TrendingUp, MapPin, Heart, Globe, Share2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import TownLaunchMeter from './TownLaunchMeter';

interface RecruitTownFlyerProps {
  onJoinCampaign?: () => void;
  onShare: () => void;
}

const RecruitTownFlyer: React.FC<RecruitTownFlyerProps> = ({ onJoinCampaign, onShare }) => {
  const navigate = useNavigate();
  
  const handleApplyToDrive = () => {
    navigate('/driver-job');
  };

  return (
    <div className="bg-gradient-to-br from-slate-800 via-slate-700 to-slate-900 p-8 rounded-3xl text-white shadow-2xl max-w-lg mx-auto border border-slate-600">
      {/* Town Launch Meter */}
      <div className="mb-6">
        <TownLaunchMeter 
          townName="Your Town"
          members={247}
          shops={18}
          entertainers={12}
          drivers={31}
          services={9}
          targetMembers={1000}
        />
      </div>

      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold mb-2 text-white drop-shadow-lg">
          "Launching Campaign" to recruit your town!
        </h1>
        <p className="text-lg font-semibold text-cyan-300">
          MarketPace needs YOU!
        </p>
      </div>

      {/* Main Message */}
      <div className="bg-slate-800/60 backdrop-blur-sm rounded-2xl p-6 mb-6 border border-slate-600">
        <p className="text-sm leading-relaxed mb-4 text-gray-100">
          MarketPace needs <span className="font-semibold text-yellow-400">members, shops, services, entertainers, and drivers</span> from your town!
        </p>
        <p className="text-sm leading-relaxed mb-4 text-gray-100">
          <span className="font-semibold text-green-400">Early members will receive lifetime benefits.</span> In the trial era there is no upcharge, no added fees, you simply pay the driver.
        </p>
        <p className="text-sm leading-relaxed text-gray-100">
          Early subscribers will also get to benefit from testing out all of the features that <span className="font-semibold text-cyan-400">MarketPace Pro</span> will provide, including the ease of web integration for shops, services, and entertainers.
        </p>
      </div>

      {/* Mission Statement */}
      <div className="bg-gradient-to-r from-cyan-900/50 to-purple-900/50 rounded-xl p-4 mb-6 border border-cyan-500/30">
        <p className="text-center font-bold text-white mb-2">
          "You set the pace, we make it happen!"
        </p>
        <p className="text-center text-cyan-300 text-sm">
          Buy, sell, rent, and hire locally!
        </p>
      </div>

      {/* Benefits Grid */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="text-center bg-slate-800/60 rounded-xl p-3 border border-slate-600">
          <Users className="h-6 w-6 mx-auto mb-2 text-yellow-400" />
          <p className="text-xs font-semibold text-gray-100">Local Opportunities</p>
        </div>
        <div className="text-center bg-slate-800/60 rounded-xl p-3 border border-slate-600">
          <Globe className="h-6 w-6 mx-auto mb-2 text-green-400" />
          <p className="text-xs font-semibold text-gray-100">Web Integration</p>
        </div>
        <div className="text-center bg-slate-800/60 rounded-xl p-3 border border-slate-600">
          <Building2 className="h-6 w-6 mx-auto mb-2 text-cyan-400" />
          <p className="text-xs font-semibold text-gray-100">Local Communities</p>
        </div>
        <div className="text-center bg-slate-800/60 rounded-xl p-3 border border-slate-600">
          <Heart className="h-6 w-6 mx-auto mb-2 text-pink-400" />
          <p className="text-xs font-semibold text-gray-100">Lifetime Benefits</p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button 
          onClick={onJoinCampaign || (() => {})}
          className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white hover:from-green-600 hover:to-blue-600 font-bold py-3 text-lg shadow-lg"
        >
          Join Launch Campaign
        </Button>
        <Button 
          onClick={handleApplyToDrive}
          className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 text-white hover:from-yellow-600 hover:to-orange-600 font-bold py-3 text-lg shadow-lg"
        >
          Become a Driver
        </Button>
      </div>
    </div>
  );
};

export default RecruitTownFlyer;