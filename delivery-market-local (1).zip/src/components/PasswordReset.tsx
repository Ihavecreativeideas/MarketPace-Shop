import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { KeyRound, RefreshCw, CheckCircle } from 'lucide-react';

export default function PasswordReset() {
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [step, setStep] = useState<'email' | 'verify' | 'reset' | 'success'>('email');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const sendResetCode = async () => {
    setLoading(true);
    setError('');
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setStep('verify');
    } catch (err) {
      setError('Failed to send reset code');
    } finally {
      setLoading(false);
    }
  };

  const verifyResetCode = async () => {
    setLoading(true);
    setError('');
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      if (code === '123456') {
        setStep('reset');
      } else {
        setError('Invalid reset code');
      }
    } catch (err) {
      setError('Verification failed');
    } finally {
      setLoading(false);
    }
  };

  const resetPassword = async () => {
    if (newPassword !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setStep('success');
    } catch (err) {
      setError('Failed to reset password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto border-black">
      <CardHeader className="bg-black">
        <CardTitle className="flex items-center gap-2 text-purple-400">
          <KeyRound className="h-5 w-5" />
          Reset Password
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 pt-6">
        {step === 'email' && (
          <>
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="border-gray-300 focus:border-purple-500"
            />
            <Button 
              onClick={sendResetCode} 
              disabled={!email || loading}
              className="w-full bg-black text-purple-400 hover:bg-gray-800"
            >
              {loading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
              Send Reset Code
            </Button>
          </>
        )}
        
        {step === 'verify' && (
          <>
            <p className="text-sm text-black">
              Enter the reset code sent to <span className="text-purple-600 font-medium">{email}</span>
            </p>
            <Input
              placeholder="Enter reset code"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="border-gray-300 focus:border-purple-500 text-center text-lg tracking-widest"
            />
            <Button 
              onClick={verifyResetCode} 
              disabled={!code || loading}
              className="w-full bg-black text-purple-400 hover:bg-gray-800"
            >
              {loading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
              Verify Code
            </Button>
          </>
        )}
        
        {step === 'reset' && (
          <>
            <Input
              type="password"
              placeholder="New password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="border-gray-300 focus:border-purple-500"
            />
            <Input
              type="password"
              placeholder="Confirm password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="border-gray-300 focus:border-purple-500"
            />
            <Button 
              onClick={resetPassword} 
              disabled={!newPassword || !confirmPassword || loading}
              className="w-full bg-black text-purple-400 hover:bg-gray-800"
            >
              {loading && <RefreshCw className="mr-2 h-4 w-4 animate-spin" />}
              Reset Password
            </Button>
          </>
        )}
        
        {step === 'success' && (
          <Alert className="border-purple-200 bg-purple-50">
            <CheckCircle className="h-4 w-4 text-purple-600" />
            <AlertDescription className="text-black">
              Password reset successfully!
            </AlertDescription>
          </Alert>
        )}
        
        {error && (
          <Alert variant="destructive" className="border-red-200 bg-red-50">
            <AlertDescription className="text-black">{error}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}