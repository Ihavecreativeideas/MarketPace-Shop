import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Plus, Image, Video, Calendar, Briefcase, Music, MessageSquare, BarChart3 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface PostData {
  type: string;
  title: string;
  content: string;
  location: string;
  eventDate?: string;
  price?: string;
  category?: string;
}

const CommunityPostModal: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [postData, setPostData] = useState<PostData>({
    type: '',
    title: '',
    content: '',
    location: ''
  });

  const postTypes = [
    { value: 'livestream', label: 'Live Stream', icon: Video, color: 'text-red-500' },
    { value: 'event', label: 'Event', icon: Calendar, color: 'text-purple-500' },
    { value: 'thought', label: 'Thought/Concern', icon: MessageSquare, color: 'text-blue-500' },
    { value: 'sale', label: 'For Sale', icon: BarChart3, color: 'text-green-500' },
    { value: 'music', label: 'New Music', icon: Music, color: 'text-pink-500' },
    { value: 'hire', label: 'For Hire', icon: Briefcase, color: 'text-orange-500' },
    { value: 'job', label: 'Job Posting', icon: Briefcase, color: 'text-indigo-500' },
    { value: 'picture', label: 'Picture/Media', icon: Image, color: 'text-teal-500' }
  ];

  const handleSubmit = () => {
    if (!postData.type || !postData.title || !postData.content) {
      toast({ title: 'Error', description: 'Please fill in all required fields', variant: 'destructive' });
      return;
    }
    
    toast({ title: 'Success!', description: 'Your post has been shared with the community' });
    setIsOpen(false);
    setPostData({ type: '', title: '', content: '', location: '' });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="bg-black text-teal-400 hover:bg-gray-900 w-full mb-6">
          <Plus className="w-4 h-4 mr-2" />
          Share with Community
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-black">Create Community Post</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Post Type Selection */}
          <div>
            <Label className="text-black mb-3 block">What would you like to share?</Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {postTypes.map((type) => {
                const Icon = type.icon;
                return (
                  <Card 
                    key={type.value}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      postData.type === type.value ? 'ring-2 ring-teal-500 bg-teal-50' : ''
                    }`}
                    onClick={() => setPostData(prev => ({ ...prev, type: type.value }))}
                  >
                    <CardContent className="p-3 text-center">
                      <Icon className={`w-6 h-6 mx-auto mb-1 ${type.color}`} />
                      <div className="text-xs font-medium">{type.label}</div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Title */}
          <div>
            <Label htmlFor="title" className="text-black">Title *</Label>
            <Input
              id="title"
              value={postData.title}
              onChange={(e) => setPostData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="What's the title of your post?"
              className="mt-1"
            />
          </div>

          {/* Content */}
          <div>
            <Label htmlFor="content" className="text-black">Description *</Label>
            <Textarea
              id="content"
              value={postData.content}
              onChange={(e) => setPostData(prev => ({ ...prev, content: e.target.value }))}
              placeholder="Share details about your post..."
              className="mt-1 min-h-[100px]"
            />
          </div>

          {/* Location */}
          <div>
            <Label htmlFor="location" className="text-black">Location</Label>
            <Input
              id="location"
              value={postData.location}
              onChange={(e) => setPostData(prev => ({ ...prev, location: e.target.value }))}
              placeholder="Where is this happening?"
              className="mt-1"
            />
          </div>

          {/* Conditional Fields */}
          {(postData.type === 'event' || postData.type === 'livestream') && (
            <div>
              <Label htmlFor="eventDate" className="text-black">Date & Time</Label>
              <Input
                id="eventDate"
                type="datetime-local"
                value={postData.eventDate || ''}
                onChange={(e) => setPostData(prev => ({ ...prev, eventDate: e.target.value }))}
                className="mt-1"
              />
            </div>
          )}

          {postData.type === 'sale' && (
            <div>
              <Label htmlFor="price" className="text-black">Price</Label>
              <Input
                id="price"
                value={postData.price || ''}
                onChange={(e) => setPostData(prev => ({ ...prev, price: e.target.value }))}
                placeholder="$0.00"
                className="mt-1"
              />
            </div>
          )}

          {/* Submit Button */}
          <Button 
            onClick={handleSubmit}
            className="w-full bg-black text-teal-400 hover:bg-gray-900"
          >
            Share Post
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CommunityPostModal;