import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ShoppingCart, 
  Store, 
  UserPlus, 
  Gift,
  Crown,
  Sparkles,
  Heart
} from 'lucide-react';

interface GuestSignupModalProps {
  isOpen: boolean;
  onClose: () => void;
  action?: 'purchase' | 'sell';
  onSignUp: () => void;
}

export const GuestSignupModal: React.FC<GuestSignupModalProps> = ({
  isOpen,
  onClose,
  action = 'purchase',
  onSignUp
}) => {
  const actionConfig = {
    purchase: {
      icon: ShoppingCart,
      title: 'Sign Up to Purchase',
      description: 'Join our community to buy items and support local businesses'
    },
    sell: {
      icon: Store,
      title: 'Sign Up to Sell',
      description: 'Create your account to list items and start selling'
    }
  };

  const config = actionConfig[action];
  const Icon = config.icon;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-center">
            <Icon className="h-5 w-5 text-purple-600" />
            {config.title}
          </DialogTitle>
          <DialogDescription className="text-center">
            {config.description}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-4">
              <div className="text-center space-y-2">
                <div className="flex items-center justify-center gap-2">
                  <Gift className="h-5 w-5 text-green-600" />
                  <span className="font-bold text-green-800">It's FREE!</span>
                </div>
                <p className="text-sm text-green-700">
                  Join our startup community at no cost
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-purple-200 bg-purple-50">
            <CardContent className="p-4">
              <div className="text-center space-y-2">
                <div className="flex items-center justify-center gap-2">
                  <Crown className="h-5 w-5 text-purple-600" />
                  <span className="font-bold text-purple-800">Early Member Benefits</span>
                </div>
                <div className="space-y-1 text-sm text-purple-700">
                  <div className="flex items-center justify-center gap-1">
                    <Sparkles className="h-3 w-3" />
                    <span>Lifetime premium features</span>
                  </div>
                  <div className="flex items-center justify-center gap-1">
                    <Sparkles className="h-3 w-3" />
                    <span>No fees during trial era</span>
                  </div>
                  <div className="flex items-center justify-center gap-1">
                    <Sparkles className="h-3 w-3" />
                    <span>Priority support access</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="text-center p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center justify-center gap-2 mb-1">
              <Heart className="h-4 w-4 text-blue-600" />
              <span className="text-sm text-blue-700 font-medium">
                Thanks for supporting our startup!
              </span>
            </div>
            <p className="text-xs text-blue-600">
              Your early membership helps us grow the community
            </p>
          </div>
          
          <div className="flex gap-2">
            <Button onClick={onSignUp} className="flex-1 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600">
              <UserPlus className="h-4 w-4 mr-2" />
              Sign Up Now - FREE!
            </Button>
            <Button onClick={onClose} variant="outline">
              Maybe Later
            </Button>
          </div>
          
          <div className="text-center">
            <Badge variant="secondary" className="bg-green-50 text-green-700 border-green-200">
              <Gift className="w-3 h-3 mr-1" />
              Free Forever for Early Members
            </Badge>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};