import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { User, Building, Music, Wrench } from 'lucide-react';

interface ProfileSetupProps {
  user: any;
}

export function ProfileSetup({ user }: ProfileSetupProps) {
  const [showSetup, setShowSetup] = useState(false);
  const [profileType, setProfileType] = useState<string>('');
  const [profileData, setProfileData] = useState({
    displayName: '',
    bio: '',
    location: '',
    phone: '',
    businessName: '',
    businessType: '',
    services: [] as string[],
    pricingTier: '',
    isHiring: false
  });

  const businessTypes = [
    'Restaurant/Food Service', 'Retail Shop', 'Professional Service',
    'Entertainment/Music', 'Health & Wellness', 'Home Services',
    'Technology', 'Education', 'Other'
  ];

  const entertainmentServices = [
    'Live Music Performance', 'DJ Services', 'Sound Engineering',
    'Lighting Services', 'Event Planning', 'Photography',
    'Videography', 'Comedy', 'Dance Performance'
  ];

  const pricingTiers = ['$', '$$', '$$$', '$$$$'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would save to Supabase
    console.log('Profile data:', { profileType, ...profileData });
    alert('Profile updated successfully!');
    setShowSetup(false);
  };

  if (!user) return null;

  return (
    <div className="mt-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            Complete Your Profile
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!showSetup ? (
            <div className="text-center space-y-4">
              <p>Set up your profile to start connecting with your community!</p>
              <Button onClick={() => setShowSetup(true)} className="w-full">
                Set Up Profile
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Profile Type Selection */}
              <div>
                <Label>Profile Type</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <Button
                    type="button"
                    variant={profileType === 'personal' ? 'default' : 'outline'}
                    onClick={() => setProfileType('personal')}
                    className="h-20 flex flex-col"
                  >
                    <User className="w-6 h-6 mb-1" />
                    Personal
                  </Button>
                  <Button
                    type="button"
                    variant={profileType === 'business' ? 'default' : 'outline'}
                    onClick={() => setProfileType('business')}
                    className="h-20 flex flex-col"
                  >
                    <Building className="w-6 h-6 mb-1" />
                    Business
                  </Button>
                </div>
              </div>

              {/* Basic Info */}
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <Label htmlFor="displayName">Display Name</Label>
                  <Input
                    id="displayName"
                    value={profileData.displayName}
                    onChange={(e) => setProfileData(prev => ({ ...prev, displayName: e.target.value }))}
                    placeholder="How should people know you?"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    value={profileData.bio}
                    onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                    placeholder="Tell us about yourself..."
                    rows={3}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      value={profileData.location}
                      onChange={(e) => setProfileData(prev => ({ ...prev, location: e.target.value }))}
                      placeholder="City, State"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      value={profileData.phone}
                      onChange={(e) => setProfileData(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder="(555) 123-4567"
                    />
                  </div>
                </div>
              </div>

              {/* Business-specific fields */}
              {profileType === 'business' && (
                <div className="space-y-4 border-t pt-4">
                  <div>
                    <Label htmlFor="businessName">Business Name</Label>
                    <Input
                      id="businessName"
                      value={profileData.businessName}
                      onChange={(e) => setProfileData(prev => ({ ...prev, businessName: e.target.value }))}
                      placeholder="Your business name"
                    />
                  </div>
                  
                  <div>
                    <Label>Business Type</Label>
                    <Select onValueChange={(value) => setProfileData(prev => ({ ...prev, businessType: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select business type" />
                      </SelectTrigger>
                      <SelectContent>
                        {businessTypes.map(type => (
                          <SelectItem key={type} value={type}>{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {profileData.businessType === 'Entertainment/Music' && (
                    <div>
                      <Label>Services Offered</Label>
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        {entertainmentServices.map(service => (
                          <div key={service} className="flex items-center space-x-2">
                            <Checkbox
                              id={service}
                              checked={profileData.services.includes(service)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setProfileData(prev => ({
                                    ...prev,
                                    services: [...prev.services, service]
                                  }));
                                } else {
                                  setProfileData(prev => ({
                                    ...prev,
                                    services: prev.services.filter(s => s !== service)
                                  }));
                                }
                              }}
                            />
                            <Label htmlFor={service} className="text-sm">{service}</Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Pricing Tier</Label>
                      <Select onValueChange={(value) => setProfileData(prev => ({ ...prev, pricingTier: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select tier" />
                        </SelectTrigger>
                        <SelectContent>
                          {pricingTiers.map(tier => (
                            <SelectItem key={tier} value={tier}>{tier}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center space-x-2 mt-6">
                      <Checkbox
                        id="isHiring"
                        checked={profileData.isHiring}
                        onCheckedChange={(checked) => 
                          setProfileData(prev => ({ ...prev, isHiring: checked as boolean }))
                        }
                      />
                      <Label htmlFor="isHiring">Currently Hiring</Label>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="flex gap-2">
                <Button type="submit" className="flex-1">
                  Save Profile
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowSetup(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}