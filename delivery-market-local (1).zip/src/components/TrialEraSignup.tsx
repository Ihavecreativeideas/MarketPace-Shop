import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Sparkles, Gift, Users, Crown, Rocket, Globe, Clock } from 'lucide-react';
import MembershipSignup from './MembershipSignup';

const TrialEraSignup: React.FC = () => {
  const [showSignup, setShowSignup] = useState(false);

  if (showSignup) {
    return <MembershipSignup onClose={() => setShowSignup(false)} />;
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 border-2 border-purple-200">
        <CardHeader className="text-center">
          <div className="mb-4">
            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 text-lg">
              <Sparkles className="w-5 h-5 mr-2" />
              TRIAL ERA - Limited Time
            </Badge>
          </div>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Join MarketPace Today!
          </CardTitle>
          <p className="text-lg text-gray-700 mt-2">
            All Early Members Get Full Access During Trial Era
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-gradient-to-r from-orange-50 to-red-50 p-4 rounded-lg border-2 border-orange-200">
            <div className="flex items-center space-x-2 mb-3">
              <Clock className="w-5 h-5 text-orange-600" />
              <Badge className="bg-orange-500 text-white animate-pulse">
                LIMITED TIME OFFER
              </Badge>
            </div>
            <h3 className="font-bold text-orange-900 mb-2">
              🚀 FREE Website Integration During Trial Era!
            </h3>
            <p className="text-sm text-orange-800 mb-3">
              Connect your existing shop/website and sync ALL your products directly to your MarketPace profile. 
              Each product gets Facebook sharing with "Deliver Now" buttons!
            </p>
            <div className="flex items-center space-x-2">
              <Globe className="w-4 h-4 text-orange-600" />
              <span className="text-sm font-medium text-orange-800">
                Take advantage while it lasts - This feature will be premium after trial!
              </span>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-6 bg-white rounded-lg border border-blue-200 hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-3 mb-4">
                <Users className="w-8 h-8 text-blue-600" />
                <div>
                  <h3 className="text-xl font-bold text-blue-800">Basic Member</h3>
                  <p className="text-sm text-blue-600">Occasional Buyers/Sellers</p>
                </div>
              </div>
              <div className="space-y-3">
                <p className="text-gray-700">
                  Perfect for those who buy or sell occasionally. Access to core marketplace features.
                </p>
                <div className="space-y-2">
                  <Badge variant="outline" className="text-blue-600 border-blue-200">
                    <Gift className="w-4 h-4 mr-1" />
                    Trial Era: Full Access
                  </Badge>
                  <Badge variant="outline" className="text-orange-600 border-orange-200">
                    <Globe className="w-4 h-4 mr-1" />
                    FREE Web Integration
                  </Badge>
                </div>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Buy and sell items</li>
                  <li>• Basic messaging</li>
                  <li>• Standard delivery options</li>
                  <li>• Community access</li>
                  <li>• Website integration (Trial Era)</li>
                </ul>
              </div>
            </div>

            <div className="p-6 bg-gradient-to-br from-purple-100 to-pink-100 rounded-lg border-2 border-purple-300 hover:shadow-lg transition-shadow">
              <div className="flex items-center space-x-3 mb-4">
                <Crown className="w-8 h-8 text-purple-600" />
                <div>
                  <h3 className="text-xl font-bold text-purple-800">Premium Partner</h3>
                  <p className="text-sm text-purple-600">Subscribers with Lifetime Benefits</p>
                </div>
              </div>
              <div className="space-y-3">
                <p className="text-gray-700">
                  For shops, services, frequent buyers/sellers, and musicians. Premium features & benefits.
                </p>
                <div className="space-y-2">
                  <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                    <Sparkles className="w-4 h-4 mr-1" />
                    Lifetime Benefits
                  </Badge>
                  <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                    <Gift className="w-4 h-4 mr-1" />
                    Trial Era: FREE
                  </Badge>
                  <Badge className="bg-gradient-to-r from-green-400 to-blue-500 text-white">
                    <Globe className="w-4 h-4 mr-1" />
                    Advanced Integration
                  </Badge>
                </div>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• All basic features PLUS:</li>
                  <li>• Advanced analytics</li>
                  <li>• Full web integration tools</li>
                  <li>• Facebook Marketplace sync</li>
                  <li>• Priority delivery options</li>
                  <li>• Promotional advantages</li>
                  <li>• Business spotlight eligibility</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg border border-blue-200">
            <h4 className="font-bold text-blue-900 mb-3 flex items-center space-x-2">
              <Rocket className="w-5 h-5" />
              <span>Why Join During Trial Era?</span>
            </h4>
            <div className="grid md:grid-cols-2 gap-4 text-sm text-blue-800">
              <div className="space-y-2">
                <p>• <strong>All early members</strong> get full access to ALL features during trial</p>
                <p>• <strong>FREE website integration</strong> - sync your products instantly</p>
                <p>• <strong>Facebook sharing</strong> with "Deliver Now" buttons on every item</p>
              </div>
              <div className="space-y-2">
                <p>• <strong>Premium Partners</strong> lock in lifetime subscriber benefits</p>
                <p>• Be part of MarketPace's founding community</p>
                <p>• Get grandfathered into the best pricing</p>
              </div>
            </div>
          </div>

          <div className="text-center">
            <Button 
              onClick={() => setShowSignup(true)}
              className="bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 hover:from-purple-700 hover:via-pink-700 hover:to-orange-700 text-white px-8 py-4 text-lg font-bold rounded-lg"
            >
              <Rocket className="w-5 h-5 mr-2" />
              Join MarketPace Now!
            </Button>
            <p className="text-xs text-gray-500 mt-2">
              No credit card required • Choose your membership level • Full trial access
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TrialEraSignup;