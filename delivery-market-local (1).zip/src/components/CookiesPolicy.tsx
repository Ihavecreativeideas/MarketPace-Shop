import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Cookie, Settings, Shield, BarChart } from 'lucide-react';

const CookiesPolicy = () => {
  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cookie className="w-6 h-6" />
            Cookies Policy
          </CardTitle>
          <CardDescription>
            Learn about how we use cookies and similar technologies to improve your experience
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600">
            Last updated: {new Date().toLocaleDateString()}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>What Are Cookies?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm">
            Cookies are small text files that are stored on your device when you visit our website. 
            They help us provide you with a better experience by remembering your preferences and 
            understanding how you use our platform.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Types of Cookies We Use</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-5 h-5 text-green-500" />
                  <h3 className="font-semibold">Essential Cookies</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Required for the website to function properly. These cannot be disabled.
                </p>
                <ul className="text-xs text-gray-500 mt-2 space-y-1">
                  <li>• Authentication and security</li>
                  <li>• Shopping cart functionality</li>
                  <li>• Form submissions</li>
                </ul>
              </div>
              <Switch checked disabled />
            </div>

            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <BarChart className="w-5 h-5 text-blue-500" />
                  <h3 className="font-semibold">Analytics Cookies</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Help us understand how visitors interact with our website.
                </p>
                <ul className="text-xs text-gray-500 mt-2 space-y-1">
                  <li>• Page views and user behavior</li>
                  <li>• Performance monitoring</li>
                  <li>• Error tracking</li>
                </ul>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Settings className="w-5 h-5 text-purple-500" />
                  <h3 className="font-semibold">Functional Cookies</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Remember your preferences and provide enhanced features.
                </p>
                <ul className="text-xs text-gray-500 mt-2 space-y-1">
                  <li>• Language preferences</li>
                  <li>• Theme settings</li>
                  <li>• Location data</li>
                </ul>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <BarChart className="w-5 h-5 text-orange-500" />
                  <h3 className="font-semibold">Marketing Cookies</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Used to deliver personalized advertisements and track campaign effectiveness.
                </p>
                <ul className="text-xs text-gray-500 mt-2 space-y-1">
                  <li>• Targeted advertising</li>
                  <li>• Social media integration</li>
                  <li>• Campaign tracking</li>
                </ul>
              </div>
              <Switch />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Managing Your Cookie Preferences</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm">
            You can control and manage cookies in several ways:
          </p>
          
          <div className="space-y-3">
            <div>
              <h4 className="font-semibold text-sm">Browser Settings</h4>
              <p className="text-sm text-gray-600">
                Most browsers allow you to view, manage, and delete cookies through their settings.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-sm">Opt-Out Tools</h4>
              <p className="text-sm text-gray-600">
                You can opt out of targeted advertising through industry opt-out pages.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-sm">Platform Settings</h4>
              <p className="text-sm text-gray-600">
                Use the switches above to control cookie categories on our platform.
              </p>
            </div>
          </div>
          
          <div className="flex gap-2 pt-4">
            <Button>Save Preferences</Button>
            <Button variant="outline">Accept All</Button>
            <Button variant="outline">Reject All</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Third-Party Cookies</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm">
            We may use third-party services that set their own cookies:
          </p>
          
          <ul className="text-sm space-y-2">
            <li>• <strong>Google Analytics:</strong> Website analytics and performance monitoring</li>
            <li>• <strong>Facebook Pixel:</strong> Social media integration and advertising</li>
            <li>• <strong>Stripe:</strong> Payment processing and fraud prevention</li>
            <li>• <strong>PayPal:</strong> Alternative payment processing</li>
          </ul>
          
          <p className="text-sm text-gray-600">
            These third parties have their own privacy policies and cookie practices.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Contact Us</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm">
            If you have questions about our use of cookies, please contact us at:
          </p>
          <div className="mt-2 text-sm">
            <p>Email: privacy@marketpace.com</p>
            <p>Phone: 1-800-MARKET-1</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CookiesPolicy;