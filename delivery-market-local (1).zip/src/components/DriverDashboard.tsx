import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Truck, DollarSign, MapPin, Clock, Package, Star, Navigation, Phone, CheckCircle, AlertCircle } from 'lucide-react';

interface DeliveryJob {
  id: string;
  type: 'pickup' | 'delivery' | 'large-item';
  status: 'available' | 'accepted' | 'in-progress' | 'completed';
  pickup: string;
  dropoff: string;
  distance: number;
  estimatedPay: number;
  urgentBonus?: number;
  customerName: string;
  items: string;
  timeEstimate: string;
  specialRequirements?: string;
}

const DriverDashboard: React.FC = () => {
  const [activeJobs, setActiveJobs] = useState<DeliveryJob[]>([]);
  const [availableJobs] = useState<DeliveryJob[]>([
    {
      id: '1',
      type: 'pickup',
      status: 'available',
      pickup: 'Best Buy - Downtown',
      dropoff: '123 Oak Street',
      distance: 3.2,
      estimatedPay: 7.60,
      customerName: 'John Smith',
      items: 'Electronics - TV',
      timeEstimate: '25 min'
    },
    {
      id: '2',
      type: 'large-item',
      status: 'available',
      pickup: 'Furniture Store',
      dropoff: '456 Pine Avenue',
      distance: 8.5,
      estimatedPay: 44.25,
      customerName: 'Sarah Johnson',
      items: 'Large Sofa',
      timeEstimate: '45 min',
      specialRequirements: 'Truck/trailer required'
    }
  ]);

  const [driverStats] = useState({
    todayEarnings: 127.50,
    weeklyEarnings: 892.30,
    completedDeliveries: 23,
    rating: 4.8,
    totalTips: 45.20
  });

  const acceptJob = (jobId: string) => {
    const job = availableJobs.find(j => j.id === jobId);
    if (job) {
      const acceptedJob = { ...job, status: 'accepted' as const };
      setActiveJobs(prev => [...prev, acceptedJob]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <header className="text-center space-y-2 py-6">
          <h1 className="text-3xl font-bold text-white">Driver Dashboard</h1>
          <p className="text-gray-300">$4 pickup • $2 drop-off • $0.50/mile • $40+ large items • 100% tips</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-white/10 border-white/20">
            <CardContent className="p-4 text-center">
              <DollarSign className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">${driverStats.todayEarnings}</div>
              <div className="text-sm text-gray-300">Today's Earnings</div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/10 border-white/20">
            <CardContent className="p-4 text-center">
              <Package className="w-8 h-8 text-purple-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{driverStats.completedDeliveries}</div>
              <div className="text-sm text-gray-300">Completed</div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/10 border-white/20">
            <CardContent className="p-4 text-center">
              <Star className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{driverStats.rating}</div>
              <div className="text-sm text-gray-300">Rating</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-green-900/50 to-emerald-900/50 border-green-500/30">
            <CardContent className="p-4 text-center">
              <DollarSign className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <div className="text-xl font-bold text-green-400">100% Tips</div>
              <div className="text-sm text-green-300">${driverStats.totalTips} this week</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {availableJobs.map(job => (
            <Card key={job.id} className="bg-white/10 border-white/20">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-white flex items-center gap-2">
                    {job.type === 'large-item' ? <Truck className="w-5 h-5" /> : <Package className="w-5 h-5" />}
                    {job.type === 'large-item' ? 'Large Item' : 'Standard Delivery'}
                  </CardTitle>
                  <div className="text-2xl font-bold text-cyan-400">
                    ${job.estimatedPay.toFixed(2)}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-300">
                    <MapPin className="w-4 h-4 text-green-400" />
                    <span>From: {job.pickup}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-300">
                    <MapPin className="w-4 h-4 text-red-400" />
                    <span>To: {job.dropoff}</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm text-gray-300">
                  <div><span className="font-medium">Distance:</span> {job.distance} mi</div>
                  <div><span className="font-medium">Time:</span> {job.timeEstimate}</div>
                  <div><span className="font-medium">Customer:</span> {job.customerName}</div>
                  <div><span className="font-medium">Items:</span> {job.items}</div>
                </div>
                
                {job.specialRequirements && (
                  <div className="bg-yellow-900/30 border border-yellow-600/30 rounded-lg p-3">
                    <div className="flex items-center gap-2 text-yellow-400 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      <span>{job.specialRequirements}</span>
                    </div>
                  </div>
                )}
                
                <Button 
                  onClick={() => acceptJob(job.id)}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Accept Job - ${job.estimatedPay.toFixed(2)}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DriverDashboard;