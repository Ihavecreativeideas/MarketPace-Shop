import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { BarChart3, Plus, X } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface PollOption {
  id: string;
  text: string;
}

interface PollData {
  question: string;
  options: PollOption[];
  duration: string;
}

const CommunityPollModal: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [pollData, setPollData] = useState<PollData>({
    question: '',
    options: [{ id: '1', text: '' }, { id: '2', text: '' }],
    duration: '24'
  });

  const addOption = () => {
    if (pollData.options.length < 6) {
      setPollData(prev => ({
        ...prev,
        options: [...prev.options, { id: Date.now().toString(), text: '' }]
      }));
    }
  };

  const removeOption = (id: string) => {
    if (pollData.options.length > 2) {
      setPollData(prev => ({
        ...prev,
        options: prev.options.filter(opt => opt.id !== id)
      }));
    }
  };

  const updateOption = (id: string, text: string) => {
    setPollData(prev => ({
      ...prev,
      options: prev.options.map(opt => opt.id === id ? { ...opt, text } : opt)
    }));
  };

  const handleSubmit = () => {
    if (!pollData.question.trim()) {
      toast({ title: 'Error', description: 'Please enter a poll question', variant: 'destructive' });
      return;
    }
    
    const validOptions = pollData.options.filter(opt => opt.text.trim());
    if (validOptions.length < 2) {
      toast({ title: 'Error', description: 'Please provide at least 2 poll options', variant: 'destructive' });
      return;
    }
    
    toast({ title: 'Success!', description: 'Your poll has been created and shared with the community' });
    setIsOpen(false);
    setPollData({ question: '', options: [{ id: '1', text: '' }, { id: '2', text: '' }], duration: '24' });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="border-purple-500 text-purple-600 hover:bg-purple-50">
          <BarChart3 className="w-4 h-4 mr-2" />
          Create Poll
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-black flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-purple-500" />
            Create Community Poll
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Poll Question */}
          <div>
            <Label htmlFor="question" className="text-black">Poll Question *</Label>
            <Input
              id="question"
              value={pollData.question}
              onChange={(e) => setPollData(prev => ({ ...prev, question: e.target.value }))}
              placeholder="What would you like to ask the community?"
              className="mt-1"
            />
          </div>

          {/* Poll Options */}
          <div>
            <Label className="text-black mb-3 block">Poll Options *</Label>
            <div className="space-y-3">
              {pollData.options.map((option, index) => (
                <div key={option.id} className="flex items-center gap-2">
                  <div className="flex-1">
                    <Input
                      value={option.text}
                      onChange={(e) => updateOption(option.id, e.target.value)}
                      placeholder={`Option ${index + 1}`}
                    />
                  </div>
                  {pollData.options.length > 2 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeOption(option.id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
            
            {pollData.options.length < 6 && (
              <Button
                variant="ghost"
                onClick={addOption}
                className="mt-2 text-purple-600 hover:text-purple-700 hover:bg-purple-50"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Option
              </Button>
            )}
          </div>

          {/* Poll Duration */}
          <div>
            <Label htmlFor="duration" className="text-black">Poll Duration (hours)</Label>
            <select
              id="duration"
              value={pollData.duration}
              onChange={(e) => setPollData(prev => ({ ...prev, duration: e.target.value }))}
              className="mt-1 w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              <option value="1">1 hour</option>
              <option value="6">6 hours</option>
              <option value="12">12 hours</option>
              <option value="24">24 hours</option>
              <option value="48">2 days</option>
              <option value="168">1 week</option>
            </select>
          </div>

          {/* Preview */}
          {pollData.question && (
            <Card className="bg-purple-50 border-purple-200">
              <CardContent className="p-4">
                <div className="text-sm text-purple-600 mb-2">Preview:</div>
                <div className="font-medium text-black mb-3">{pollData.question}</div>
                <div className="space-y-2">
                  {pollData.options.filter(opt => opt.text.trim()).map((option, index) => (
                    <div key={option.id} className="flex items-center gap-2 text-sm">
                      <div className="w-4 h-4 border border-purple-300 rounded" />
                      <span>{option.text}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Submit Button */}
          <Button 
            onClick={handleSubmit}
            className="w-full bg-purple-600 text-white hover:bg-purple-700"
          >
            Create Poll
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CommunityPollModal;