import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, Star, ShoppingBag, MapPin, Tag } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface PersonalizedForYouSectionProps {
  userId?: string;
}

interface LocalItem {
  id: string;
  title: string;
  description: string;
  price: string;
  rating: number;
  image: string;
  location: string;
  distance: string;
  category: string;
  tags?: string[];
}

export const PersonalizedForYouSection: React.FC<PersonalizedForYouSectionProps> = ({ userId }) => {
  const [items, setItems] = useState<LocalItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [userTags, setUserTags] = useState<string[]>([]);

  useEffect(() => {
    fetchUserData();
  }, [userId]);

  const fetchUserData = async () => {
    try {
      if (userId) {
        // Fetch user tags from enhanced_user_profiles
        const { data: profile } = await supabase
          .from('enhanced_user_profiles')
          .select('tags')
          .eq('user_id', userId)
          .single();
        
        if (profile?.tags && profile.tags.length > 0) {
          setUserTags(profile.tags);
          await fetchPersonalizedItems(profile.tags);
        } else {
          loadDemoItems();
        }
      } else {
        loadDemoItems();
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
      loadDemoItems();
    } finally {
      setLoading(false);
    }
  };

  const fetchPersonalizedItems = async (tags: string[]) => {
    try {
      const { data: marketplaceItems } = await supabase
        .from('marketplace_products')
        .select('*')
        .in('category', tags)
        .eq('status', 'active')
        .limit(9);

      if (marketplaceItems && marketplaceItems.length > 0) {
        const formattedItems = marketplaceItems.map(item => ({
          id: item.id,
          title: item.name,
          description: item.description || 'No description available',
          price: `$${item.price}`,
          rating: 4.5,
          image: item.image_url || '/placeholder.svg',
          location: 'Local Area',
          distance: '1.5 mi',
          category: item.category,
          tags: [item.category]
        }));
        setItems(formattedItems);
      } else {
        loadDemoItems();
      }
    } catch (error) {
      console.error('Error fetching items:', error);
      loadDemoItems();
    }
  };

  const loadDemoItems = () => {
    const demoItems: LocalItem[] = [
      {
        id: '1',
        title: 'Premium Coffee Blend',
        description: 'Artisan roasted coffee beans from local roastery',
        price: '$24.99',
        rating: 4.8,
        image: '/placeholder.svg',
        location: 'Downtown Coffee Shop',
        distance: '1.2 mi',
        category: 'Food & Beverage',
        tags: ['coffee', 'artisan', 'local']
      },
      {
        id: '2',
        title: 'Handcrafted Ceramic Mug',
        description: 'Beautiful handmade ceramic mug by local artist',
        price: '$18.50',
        rating: 4.9,
        image: '/placeholder.svg',
        location: 'Arts District',
        distance: '0.8 mi',
        category: 'Home & Garden',
        tags: ['handmade', 'ceramic', 'art']
      },
      {
        id: '3',
        title: 'Fresh Organic Vegetables',
        description: 'Farm-fresh organic produce from local farms',
        price: '$25.00',
        rating: 4.7,
        image: '/placeholder.svg',
        location: 'Farmers Market',
        distance: '1.5 mi',
        category: 'Food & Beverage',
        tags: ['organic', 'fresh', 'local']
      },
      {
        id: '4',
        title: 'Yoga Class Package',
        description: 'Beginner-friendly yoga sessions with certified instructor',
        price: '$80.00',
        rating: 4.6,
        image: '/placeholder.svg',
        location: 'Wellness Center',
        distance: '0.9 mi',
        category: 'Health & Fitness',
        tags: ['yoga', 'wellness', 'fitness']
      },
      {
        id: '5',
        title: 'Custom Portrait Art',
        description: 'Personalized portrait paintings by local artist',
        price: '$150.00',
        rating: 4.9,
        image: '/placeholder.svg',
        location: 'Art Studio',
        distance: '1.1 mi',
        category: 'Art & Crafts',
        tags: ['custom', 'portrait', 'art']
      },
      {
        id: '6',
        title: 'Guitar Lessons',
        description: 'Learn guitar from experienced local musician',
        price: '$50.00',
        rating: 4.8,
        image: '/placeholder.svg',
        location: 'Music Studio',
        distance: '2.0 mi',
        category: 'Education',
        tags: ['music', 'guitar', 'lessons']
      }
    ];
    setItems(demoItems);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">
          Just for <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">You</span>
        </h2>
        <p className="text-gray-300">Local items matching your interests within 30 miles</p>
        {userTags.length > 0 && (
          <div className="flex flex-wrap justify-center gap-2 mt-2">
            {userTags.map((tag) => (
              <span key={tag} className="bg-cyan-500/20 text-cyan-400 px-2 py-1 rounded-full text-xs flex items-center gap-1">
                <Tag className="w-3 h-3" />
                #{tag}
              </span>
            ))}
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((item) => (
          <Card key={item.id} className="bg-white/5 backdrop-blur-lg border-white/10 hover:bg-white/10 transition-all duration-300">
            <div className="relative">
              <img 
                src={item.image} 
                alt={item.title}
                className="w-full h-48 object-cover rounded-t-lg"
              />
              <Button
                size="sm"
                variant="ghost"
                className="absolute top-2 right-2 p-2 bg-white/20 backdrop-blur-sm rounded-full text-white hover:text-red-400"
              >
                <Heart className="w-4 h-4" />
              </Button>
              <div className="absolute bottom-2 left-2 bg-black/50 backdrop-blur-sm rounded-full px-2 py-1">
                <span className="text-xs text-white">{item.distance}</span>
              </div>
            </div>
            
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold text-lg text-white">{item.title}</h3>
                <span className="text-xs bg-cyan-500/20 text-cyan-400 px-2 py-1 rounded">
                  {item.category}
                </span>
              </div>
              <p className="text-gray-300 text-sm mb-2">{item.description}</p>
              <p className="text-xs text-gray-400 mb-3">
                <MapPin className="inline w-3 h-3 mr-1" />
                {item.location}
              </p>
              
              {item.tags && (
                <div className="flex flex-wrap gap-1 mb-3">
                  {item.tags.slice(0, 3).map((tag) => (
                    <span key={tag} className="text-xs bg-purple-500/20 text-purple-400 px-2 py-1 rounded">
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
              
              <div className="flex items-center justify-between mb-4">
                <span className="text-xl font-bold text-cyan-400">{item.price}</span>
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="text-sm text-gray-300">{item.rating}</span>
                </div>
              </div>
              
              <Button className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white">
                <ShoppingBag className="w-4 h-4 mr-2" />
                View Details
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};