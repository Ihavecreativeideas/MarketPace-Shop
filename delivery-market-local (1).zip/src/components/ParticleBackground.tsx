import React from 'react';

const ParticleBackground = () => {
  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {/* Animated particles */}
      <div className="absolute top-10 left-10 w-2 h-2 bg-purple-300 rounded-full opacity-60 animate-bounce"></div>
      <div className="absolute top-20 right-16 w-1 h-1 bg-purple-200 rounded-full opacity-40 animate-pulse"></div>
      <div className="absolute top-32 left-1/4 w-3 h-3 bg-purple-400 rounded-full opacity-30 animate-ping"></div>
      <div className="absolute top-48 right-1/3 w-2 h-2 bg-purple-300 rounded-full opacity-50 animate-bounce"></div>
      <div className="absolute top-64 left-1/2 w-1 h-1 bg-purple-200 rounded-full opacity-60 animate-pulse"></div>
      <div className="absolute top-80 right-10 w-2 h-2 bg-purple-400 rounded-full opacity-40 animate-ping"></div>
      <div className="absolute bottom-32 left-8 w-3 h-3 bg-purple-300 rounded-full opacity-50 animate-bounce"></div>
      <div className="absolute bottom-48 right-1/4 w-1 h-1 bg-purple-200 rounded-full opacity-30 animate-pulse"></div>
      <div className="absolute bottom-64 left-1/3 w-2 h-2 bg-purple-400 rounded-full opacity-60 animate-ping"></div>
      <div className="absolute bottom-80 right-12 w-2 h-2 bg-purple-300 rounded-full opacity-40 animate-bounce"></div>
      
      {/* Larger floating elements */}
      <div className="absolute top-1/4 left-1/5 w-8 h-8 bg-gradient-to-br from-purple-400 to-purple-600 rounded-lg opacity-20 animate-pulse"></div>
      <div className="absolute top-1/3 right-1/5 w-6 h-6 bg-gradient-to-br from-purple-300 to-purple-500 rounded-lg opacity-15 animate-bounce"></div>
      <div className="absolute bottom-1/4 left-1/3 w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-700 rounded-lg opacity-10 animate-ping"></div>
      
      {/* Additional floating particles */}
      <div className="absolute top-1/5 left-2/3 w-1 h-1 bg-purple-200 rounded-full opacity-50 animate-pulse"></div>
      <div className="absolute top-2/3 right-1/4 w-2 h-2 bg-purple-300 rounded-full opacity-40 animate-bounce"></div>
      <div className="absolute bottom-1/5 left-1/6 w-1 h-1 bg-purple-400 rounded-full opacity-60 animate-ping"></div>
      <div className="absolute top-3/4 right-2/5 w-3 h-3 bg-purple-300 rounded-full opacity-30 animate-pulse"></div>
      <div className="absolute bottom-1/3 right-1/6 w-2 h-2 bg-purple-200 rounded-full opacity-50 animate-bounce"></div>
    </div>
  );
};

export default ParticleBackground;