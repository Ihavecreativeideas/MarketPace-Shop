import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Target, Plus, Play, Pause, BarChart3, DollarSign, Eye, Users } from 'lucide-react';

const AdsManager = () => {
  const [campaigns] = useState([
    {
      id: 1,
      name: 'Vintage Guitar Promotion',
      status: 'Active',
      budget: '$50/day',
      spent: '$347',
      impressions: '12,450',
      clicks: '234',
      conversions: '12'
    },
    {
      id: 2,
      name: 'Electronics Sale',
      status: 'Paused',
      budget: '$30/day',
      spent: '$156',
      impressions: '8,920',
      clicks: '167',
      conversions: '8'
    }
  ]);

  const adMetrics = [
    { title: 'Total Spend', value: '$503', icon: DollarSign },
    { title: 'Impressions', value: '21,370', icon: Eye },
    { title: 'Clicks', value: '401', icon: Users },
    { title: 'Conversions', value: '20', icon: Target }
  ];

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Ads Manager</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Create and manage your advertising campaigns
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        {adMetrics.map((metric, index) => {
          const IconComponent = metric.icon;
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{metric.title}</p>
                    <p className="text-2xl font-bold">{metric.value}</p>
                  </div>
                  <IconComponent className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="campaigns" className="space-y-6">
        <TabsList>
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
          <TabsTrigger value="create">Create Ad</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="campaigns">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Active Campaigns
                </span>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Campaign
                </Button>
              </CardTitle>
              <CardDescription>
                Manage your advertising campaigns and performance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {campaigns.map((campaign) => (
                  <div key={campaign.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <h3 className="font-medium">{campaign.name}</h3>
                        <Badge variant={campaign.status === 'Active' ? 'default' : 'secondary'}>
                          {campaign.status}
                        </Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          {campaign.status === 'Active' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                        <Button size="sm" variant="outline">Edit</Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500">Budget</p>
                        <p className="font-medium">{campaign.budget}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Spent</p>
                        <p className="font-medium">{campaign.spent}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Impressions</p>
                        <p className="font-medium">{campaign.impressions}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Clicks</p>
                        <p className="font-medium">{campaign.clicks}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Conversions</p>
                        <p className="font-medium">{campaign.conversions}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="create">
          <Card>
            <CardHeader>
              <CardTitle>Create New Ad Campaign</CardTitle>
              <CardDescription>
                Set up a new advertising campaign for your listings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="campaignName">Campaign Name</Label>
                    <Input id="campaignName" placeholder="Enter campaign name" />
                  </div>
                  <div>
                    <Label htmlFor="dailyBudget">Daily Budget</Label>
                    <Input id="dailyBudget" placeholder="$0.00" type="number" />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="targetAudience">Target Audience</Label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
                    <div>
                      <Label htmlFor="ageRange">Age Range</Label>
                      <select id="ageRange" className="w-full p-2 border rounded-md">
                        <option>18-65+</option>
                        <option>18-24</option>
                        <option>25-34</option>
                        <option>35-44</option>
                        <option>45-54</option>
                        <option>55-65+</option>
                      </select>
                    </div>
                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input id="location" placeholder="Enter location" />
                    </div>
                    <div>
                      <Label htmlFor="interests">Interests</Label>
                      <Input id="interests" placeholder="Enter interests" />
                    </div>
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="adObjective">Campaign Objective</Label>
                  <select id="adObjective" className="w-full mt-1 p-2 border rounded-md">
                    <option>Increase Listing Views</option>
                    <option>Generate Inquiries</option>
                    <option>Drive Sales</option>
                    <option>Build Brand Awareness</option>
                  </select>
                </div>
                
                <div className="flex gap-2">
                  <Button className="flex-1">Create Campaign</Button>
                  <Button variant="outline">Save as Draft</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Campaign Analytics
              </CardTitle>
              <CardDescription>
                Detailed performance metrics for your campaigns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="h-64 flex items-center justify-center bg-gray-50 dark:bg-gray-800 rounded">
                  <p className="text-gray-500">Performance charts would appear here</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-medium mb-3">Top Performing Ads</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded">
                        <span>Vintage Guitar Ad</span>
                        <span className="text-green-600">+15% CTR</span>
                      </div>
                      <div className="flex justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded">
                        <span>Electronics Sale</span>
                        <span className="text-green-600">+8% CTR</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-3">Optimization Tips</h3>
                    <div className="space-y-2 text-sm">
                      <div className="p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                        <p className="text-blue-800 dark:text-blue-200">Consider increasing budget for high-performing campaigns</p>
                      </div>
                      <div className="p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded">
                        <p className="text-yellow-800 dark:text-yellow-200">Update ad creative for better engagement</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdsManager;