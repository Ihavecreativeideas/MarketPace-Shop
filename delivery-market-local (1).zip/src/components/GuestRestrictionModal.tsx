import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ShoppingCart, 
  CreditCard, 
  Store, 
  UserPlus, 
  Eye, 
  Lock,
  Shield
} from 'lucide-react';

interface GuestRestrictionModalProps {
  isOpen: boolean;
  onClose: () => void;
  action?: 'purchase' | 'sell' | 'checkout' | 'profile';
}

export const GuestRestrictionModal: React.FC<GuestRestrictionModalProps> = ({
  isOpen,
  onClose,
  action = 'purchase'
}) => {
  const actionConfig = {
    purchase: {
      icon: ShoppingCart,
      title: 'Purchase Items',
      description: 'To make purchases and manage orders'
    },
    sell: {
      icon: Store,
      title: 'Sell Items',
      description: 'To list items and manage your store'
    },
    checkout: {
      icon: CreditCard,
      title: 'Complete Checkout',
      description: 'To process payments securely'
    },
    profile: {
      icon: UserPlus,
      title: 'Access Profile',
      description: 'To manage your account and preferences'
    }
  };

  const config = actionConfig[action];
  const Icon = config.icon;

  const handleSignUp = () => {
    onClose();
    // Trigger auth flow - in a real app, this would open the auth modal
    window.location.reload();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5 text-purple-600" />
            Guest Mode Active
          </DialogTitle>
          <DialogDescription>
            You're currently browsing as a guest. Sign up to unlock full features.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Icon className="h-5 w-5 text-orange-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-orange-900">
                    Sign Up Required: {config.title}
                  </h4>
                  <p className="text-sm text-orange-700 mt-1">
                    {config.description}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="space-y-3">
            <h4 className="font-medium text-gray-900">What you get with an account:</h4>
            <div className="grid grid-cols-1 gap-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <ShoppingCart className="h-4 w-4 text-green-600" />
                <span>Make purchases and track orders</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Store className="h-4 w-4 text-blue-600" />
                <span>List and sell your items</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Shield className="h-4 w-4 text-purple-600" />
                <span>HIPAA-compliant secure payments</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Lock className="h-4 w-4 text-red-600" />
                <span>End-to-end encrypted data protection</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-center gap-2 p-3 bg-green-50 rounded-lg border border-green-200">
            <Shield className="h-4 w-4 text-green-600" />
            <span className="text-sm text-green-700 font-medium">
              100% Secure & HIPAA Compliant
            </span>
          </div>
          
          <div className="flex gap-2">
            <Button onClick={handleSignUp} className="flex-1">
              <UserPlus className="h-4 w-4 mr-2" />
              Sign Up Now
            </Button>
            <Button onClick={onClose} variant="outline">
              Continue Browsing
            </Button>
          </div>
          
          <div className="text-center">
            <Badge variant="secondary" className="bg-purple-50 text-purple-700 border-purple-200">
              <Eye className="w-3 h-3 mr-1" />
              Guest Mode: Browse Only
            </Badge>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};