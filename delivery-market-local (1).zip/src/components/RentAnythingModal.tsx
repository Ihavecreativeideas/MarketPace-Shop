import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { VisuallyHidden } from '@/components/ui/visually-hidden';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Clock, DollarSign, Package } from 'lucide-react';

interface RentAnythingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  type: 'list' | 'request';
}

const RentAnythingModal: React.FC<RentAnythingModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  type
}) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    pricePerHour: '',
    pricePerDay: '',
    location: '',
    availability: '',
    deliveryOptions: 'both'
  });

  const categories = [
    'Outdoor Equipment',
    'Electronics',
    'Tools & Equipment',
    'Baby & Kids',
    'Sports Equipment',
    'Party Supplies',
    'Camping Gear',
    'Musical Instruments',
    'Other'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            {type === 'list' ? 'List Item for Rent' : 'Request Item (ISO)'}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="title">Item Name</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              placeholder={type === 'list' ? 'Beach Chair' : 'Looking for: Beach Chair'}
              required
            />
          </div>
          
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder={type === 'list' ? 'Comfortable folding beach chair...' : 'Need for weekend beach trip...'}
              required
            />
          </div>
          
          <div>
            <Label htmlFor="category">Category</Label>
            <Select onValueChange={(value) => setFormData({...formData, category: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(cat => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {type === 'list' && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="pricePerHour">Price/Hour</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                  <Input
                    id="pricePerHour"
                    type="number"
                    step="0.01"
                    value={formData.pricePerHour}
                    onChange={(e) => setFormData({...formData, pricePerHour: e.target.value})}
                    className="pl-10"
                    placeholder="5.00"
                    required
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="pricePerDay">Price/Day</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                  <Input
                    id="pricePerDay"
                    type="number"
                    step="0.01"
                    value={formData.pricePerDay}
                    onChange={(e) => setFormData({...formData, pricePerDay: e.target.value})}
                    className="pl-10"
                    placeholder="25.00"
                    required
                  />
                </div>
              </div>
            </div>
          )}
          
          <div>
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              value={formData.location}
              onChange={(e) => setFormData({...formData, location: e.target.value})}
              placeholder="Your neighborhood/area"
              required
            />
          </div>
          
          <div>
            <Label htmlFor="availability">Availability</Label>
            <Input
              id="availability"
              value={formData.availability}
              onChange={(e) => setFormData({...formData, availability: e.target.value})}
              placeholder="Weekends, Evenings, etc."
              required
            />
          </div>
          
          <div className="bg-blue-50 p-3 rounded-lg text-sm">
            <p className="font-medium text-blue-800 mb-1">📦 Delivery Options:</p>
            <p className="text-blue-700">
              • Regular route delivery (scheduled times)
              • Rush delivery (+$5 fee for urgent needs)
            </p>
          </div>
          
          <div className="bg-yellow-50 p-3 rounded-lg text-sm">
            <p className="font-medium text-yellow-800 mb-1">⚠️ Important:</p>
            <p className="text-yellow-700">
              MarketPace is not responsible for lost, stolen, or damaged items. 
              Negotiate terms directly with the renter.
            </p>
          </div>
          
          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1">
              {type === 'list' ? 'List Item' : 'Post Request'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default RentAnythingModal;