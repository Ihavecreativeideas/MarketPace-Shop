import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from './ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';
import { Badge } from './ui/badge';
import { Menu, Home, Store, Music, Users, Truck, Calendar, Settings, Search, Heart, User, Bell, Zap, Hammer, Building2, ChevronDown } from 'lucide-react';
import { useAuth } from './AuthProvider';
import { useCart } from './CartContext';

const Navigation: React.FC = () => {
  const location = useLocation();
  const { user, logout } = useAuth();
  const { items } = useCart();
  const [isOpen, setIsOpen] = useState(false);

  const homeItems = [
    { path: '/', label: 'Home', icon: Home },
    { path: '/marketplace', label: 'Market', icon: Store, badge: items.length > 0 ? items.length : null },
    { path: '/wishlist', label: 'Wishlist', icon: Heart },
    { path: '/profile', label: 'Profile', icon: User },
  ];

  const navItems = [
    { path: '/shops', label: 'Shops', icon: Building2 },
    { path: '/services', label: 'Services', icon: Settings },
    { path: '/handcrafted', label: 'Handcrafted', icon: Hammer },
    { path: '/rent-anything', label: 'Rent', icon: Calendar },
    { path: '/entertainment-hub', label: 'The Hub', icon: Music },
    { path: '/community', label: 'Community', icon: Users },
    { path: '/driver-dashboard', label: 'Driver Hub', icon: Truck, badge: 'Hiring' },
  ];

  const isActive = (path: string) => location.pathname === path;

  const NavLink = ({ item, mobile = false }: { item: any; mobile?: boolean }) => {
    const Icon = item.icon;
    const active = isActive(item.path);
    
    return (
      <Link
        to={item.path}
        onClick={() => mobile && setIsOpen(false)}
        className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
          active 
            ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' 
            : 'text-gray-300 hover:text-white hover:bg-white/10'
        }`}
      >
        <Icon className="w-4 h-4" />
        <span className={mobile ? 'text-base' : 'text-sm'}>{item.label}</span>
        {item.badge && (
          <Badge className="bg-green-600 text-white text-xs">
            {typeof item.badge === 'number' ? item.badge : item.badge}
          </Badge>
        )}
      </Link>
    );
  };

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden lg:flex items-center justify-between bg-black/20 backdrop-blur-lg border-b border-white/10 px-6 py-4">
        <div className="flex items-center space-x-8">
          <Link to="/" className="flex items-center space-x-2">
            <Zap className="w-8 h-8 text-cyan-400" />
            <span className="text-2xl font-bold text-white">MarketPace</span>
          </Link>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="text-gray-300 hover:text-white hover:bg-white/10">
                <span className="text-sm">Home</span>
                <ChevronDown className="w-4 h-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-slate-900 border-slate-700 text-white">
              {homeItems.map((item) => {
                const Icon = item.icon;
                return (
                  <DropdownMenuItem key={item.path} asChild>
                    <Link to={item.path} className="flex items-center gap-2 px-3 py-2 text-gray-300 hover:text-white">
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                      {item.badge && (
                        <Badge className="bg-green-600 text-white text-xs ml-auto">
                          {typeof item.badge === 'number' ? item.badge : item.badge}
                        </Badge>
                      )}
                    </Link>
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>
            
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="text-gray-300 hover:text-white hover:bg-white/10">
                <span className="text-sm">More</span>
                <ChevronDown className="w-4 h-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-slate-900 border-slate-700 text-white">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <DropdownMenuItem key={item.path} asChild>
                    <Link to={item.path} className="flex items-center gap-2 px-3 py-2 text-gray-300 hover:text-white">
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                      {item.badge && (
                        <Badge className="bg-green-600 text-white text-xs ml-auto">
                          {typeof item.badge === 'number' ? item.badge : item.badge}
                        </Badge>
                      )}
                    </Link>
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex items-center space-x-4">
          <Button variant="outline" size="sm" className="border-white/20 text-white hover:bg-white/10">
            <Bell className="w-4 h-4" />
          </Button>
        </div>
      </nav>

      {/* Mobile Navigation - Simplified */}
      <nav className="lg:hidden flex items-center justify-between bg-black/20 backdrop-blur-lg border-b border-white/10 px-4 py-3">
        <Link to="/" className="flex items-center space-x-2">
          <Zap className="w-6 h-6 text-cyan-400" />
          <span className="text-xl font-bold text-white">MarketPace</span>
        </Link>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="text-white">
              <Menu className="w-5 h-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-slate-900 border-slate-700 text-white w-56">
            {[...homeItems, ...navItems].map((item) => {
              const Icon = item.icon;
              return (
                <DropdownMenuItem key={item.path} asChild>
                  <Link to={item.path} className="flex items-center gap-2 px-3 py-2 text-gray-300 hover:text-white">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                    {item.badge && (
                      <Badge className="bg-green-600 text-white text-xs ml-auto">
                        {typeof item.badge === 'number' ? item.badge : item.badge}
                      </Badge>
                    )}
                  </Link>
                </DropdownMenuItem>
              );
            })}
          </DropdownMenuContent>
        </DropdownMenu>
      </nav>
    </>
  );
};

export default Navigation;