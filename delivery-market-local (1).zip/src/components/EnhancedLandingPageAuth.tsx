import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Truck, Package, MapPin, Star, Clock } from 'lucide-react';

const EnhancedLandingPageAuth = () => {
  const [email, setEmail] = useState('');
  const [showSignup, setShowSignup] = useState(false);

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-md mx-auto space-y-6">
        {/* Hero Section */}
        <div className="text-center text-white mb-8">
          <h2 className="text-3xl font-bold mb-2">Welcome to MarketPace</h2>
          <p className="text-teal-100 text-lg">Smart delivery for your local marketplace</p>
        </div>

        {/* Features Cards */}
        <div className="grid gap-4">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-teal-500 rounded-lg flex items-center justify-center">
                  <Truck className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-white">Smart Routing</h3>
                  <p className="text-sm text-teal-100">AI-optimized delivery routes</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-teal-500 rounded-lg flex items-center justify-center">
                  <Package className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-white">Live Tracking</h3>
                  <p className="text-sm text-teal-100">Real-time delivery updates</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-teal-500 rounded-lg flex items-center justify-center">
                  <Star className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-white">Tip & Rate</h3>
                  <p className="text-sm text-teal-100">Rate drivers and sellers</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Auth Section */}
        <Card className="bg-white/95 backdrop-blur-lg">
          <CardHeader>
            <CardTitle className="text-center">
              {showSignup ? 'Join MarketPace' : 'Sign In'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full"
            />
            {showSignup && (
              <Input
                type="password"
                placeholder="Create password"
                className="w-full"
              />
            )}
            <Button className="w-full bg-teal-600 hover:bg-teal-700">
              {showSignup ? 'Sign Up' : 'Sign In'}
            </Button>
            <p className="text-center text-sm text-gray-600">
              {showSignup ? 'Already have an account?' : "Don't have an account?"}
              <button
                onClick={() => setShowSignup(!showSignup)}
                className="text-teal-600 hover:text-teal-700 ml-1 font-medium"
              >
                {showSignup ? 'Sign In' : 'Sign Up'}
              </button>
            </p>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="text-white">
            <div className="text-2xl font-bold text-teal-300">15mi</div>
            <div className="text-sm text-teal-100">Delivery Range</div>
          </div>
          <div className="text-white">
            <div className="text-2xl font-bold text-teal-300">12</div>
            <div className="text-sm text-teal-100">Stops per Route</div>
          </div>
          <div className="text-white">
            <div className="text-2xl font-bold text-teal-300">9-9</div>
            <div className="text-sm text-teal-100">Daily Hours</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnhancedLandingPageAuth;