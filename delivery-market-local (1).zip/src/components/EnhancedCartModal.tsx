import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, ShoppingCart, Trash2, Calculator } from 'lucide-react';
import { useCart } from './CartContext';

interface EnhancedCartItem {
  id: string;
  name: string;
  price: number;
  image: string;
  quantity: number;
  offerStatus?: 'none' | 'pending' | 'accepted' | 'declined';
  counterOfferPrice?: number;
}

interface EnhancedCartModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const EnhancedCartModal: React.FC<EnhancedCartModalProps> = ({ isOpen, onClose }) => {
  const { cartItems, removeFromCart, clearCart } = useCart();
  const [enhancedItems, setEnhancedItems] = useState<EnhancedCartItem[]>(
    cartItems.map(item => ({ ...item, offerStatus: 'none' }))
  );
  const [selectedDiscounts, setSelectedDiscounts] = useState<{ [key: string]: number }>({});

  const discountOptions = [15, 25, 35, 50];

  const handleOfferSubmit = async (itemId: string) => {
    const discount = selectedDiscounts[itemId];
    if (!discount) return;

    const item = enhancedItems.find(i => i.id === itemId);
    if (!item) return;

    const discountedPrice = item.price * (1 - discount / 100);
    
    setEnhancedItems(prev => prev.map(i => 
      i.id === itemId 
        ? { ...i, offerStatus: 'pending', counterOfferPrice: discountedPrice }
        : i
    ));

    // Simulate seller response
    setTimeout(() => {
      const accepted = Math.random() > 0.3;
      setEnhancedItems(prev => prev.map(i => 
        i.id === itemId 
          ? { ...i, offerStatus: accepted ? 'accepted' : 'declined' }
          : i
      ));
    }, 2000);
  };

  const handleOfferAccept = (itemId: string) => {
    const item = enhancedItems.find(i => i.id === itemId);
    if (!item || !item.counterOfferPrice) return;
    
    alert(`Order locked for ${item.name} at $${item.counterOfferPrice.toFixed(2)}`);
    setEnhancedItems(prev => prev.filter(i => i.id !== itemId));
  };

  const getTotal = () => {
    return enhancedItems.reduce((total, item) => {
      const price = item.offerStatus === 'accepted' && item.counterOfferPrice 
        ? item.counterOfferPrice 
        : item.price;
      return total + (price * item.quantity);
    }, 0);
  };

  const canProceedToCheckout = enhancedItems.some(item => 
    item.offerStatus === 'none' || item.offerStatus === 'accepted'
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5" />
              Cart ({enhancedItems.length})
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        {enhancedItems.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">Your cart is empty</p>
          </div>
        ) : (
          <div className="space-y-4">
            {enhancedItems.map((item) => (
              <div key={item.id} className="border rounded-lg p-4">
                <div className="flex gap-4">
                  <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded" />
                  <div className="flex-1">
                    <h4 className="font-medium">{item.name}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-lg font-bold">
                        ${item.offerStatus === 'accepted' && item.counterOfferPrice 
                          ? item.counterOfferPrice.toFixed(2)
                          : item.price.toFixed(2)}
                      </span>
                      {item.offerStatus === 'accepted' && (
                        <Badge className="bg-green-100 text-green-800">Offer Accepted</Badge>
                      )}
                      {item.offerStatus === 'pending' && (
                        <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
                      )}
                      {item.offerStatus === 'declined' && (
                        <Badge className="bg-red-100 text-red-800">Declined</Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => {
                    removeFromCart(item.id);
                    setEnhancedItems(prev => prev.filter(i => i.id !== item.id));
                  }}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                
                {item.offerStatus === 'none' && (
                  <div className="mt-3 space-y-2">
                    <p className="text-sm font-medium">Make Counter Offer:</p>
                    <div className="grid grid-cols-2 gap-2">
                      {discountOptions.map((discount) => {
                        const discountedPrice = item.price * (1 - discount / 100);
                        return (
                          <div key={discount} className={`p-2 border rounded cursor-pointer text-center ${
                            selectedDiscounts[item.id] === discount
                              ? 'border-orange-500 bg-orange-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`} onClick={() => setSelectedDiscounts(prev => ({ ...prev, [item.id]: discount }))}>
                            <Badge variant="outline" className="text-xs">{discount}% off</Badge>
                            <p className="text-sm font-bold mt-1">${discountedPrice.toFixed(2)}</p>
                          </div>
                        );
                      })}
                    </div>
                    <Button onClick={() => handleOfferSubmit(item.id)} disabled={!selectedDiscounts[item.id]} className="w-full bg-orange-600 hover:bg-orange-700">
                      <Calculator className="w-4 h-4 mr-2" />Submit Offer
                    </Button>
                  </div>
                )}
                
                {item.offerStatus === 'accepted' && (
                  <div className="mt-3">
                    <Button onClick={() => handleOfferAccept(item.id)} className="w-full bg-green-600 hover:bg-green-700">
                      Accept & Lock Order
                    </Button>
                  </div>
                )}
              </div>
            ))}

            <div className="border-t pt-4">
              <div className="flex justify-between items-center mb-4">
                <span className="text-lg font-bold">Total: ${getTotal().toFixed(2)}</span>
                <Button variant="outline" onClick={() => {
                  clearCart();
                  setEnhancedItems([]);
                }}>Clear Cart</Button>
              </div>
              
              <Button className="w-full bg-green-600 hover:bg-green-700" disabled={!canProceedToCheckout} onClick={() => {
                alert('Proceeding to checkout...');
                onClose();
              }}>
                Proceed to Checkout
              </Button>
              
              {!canProceedToCheckout && (
                <p className="text-sm text-gray-500 mt-2 text-center">
                  Accept offers or remove pending items to checkout
                </p>
              )}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default EnhancedCartModal;