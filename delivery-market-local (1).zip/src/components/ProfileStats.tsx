import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Package, Star, Users } from 'lucide-react';

interface ProfileStatsProps {
  membershipType: string;
  stats: {
    totalOrders?: number;
    completedDeliveries?: number;
    rating?: number;
    totalEarnings?: number;
    activeListings?: number;
    followers?: number;
    gigs?: number;
    reviews?: number;
  };
}

export const ProfileStats: React.FC<ProfileStatsProps> = ({ membershipType, stats }) => {
  const getStatsForMembership = () => {
    switch (membershipType.toLowerCase()) {
      case 'driver':
        return [
          { label: 'Deliveries', value: stats.completedDeliveries || 0, icon: Package, color: 'text-green-400' },
          { label: 'Rating', value: `${(stats.rating || 0).toFixed(1)}★`, icon: Star, color: 'text-yellow-400' },
          { label: 'Earnings', value: `$${stats.totalEarnings || 0}`, icon: TrendingUp, color: 'text-blue-400' },
          { label: 'Reviews', value: stats.reviews || 0, icon: Users, color: 'text-purple-400' }
        ];
      
      case 'business':
        return [
          { label: 'Active Listings', value: stats.activeListings || 0, icon: Package, color: 'text-blue-400' },
          { label: 'Total Orders', value: stats.totalOrders || 0, icon: TrendingUp, color: 'text-green-400' },
          { label: 'Rating', value: `${(stats.rating || 0).toFixed(1)}★`, icon: Star, color: 'text-yellow-400' },
          { label: 'Followers', value: stats.followers || 0, icon: Users, color: 'text-purple-400' }
        ];
      
      case 'musician':
        return [
          { label: 'Gigs Played', value: stats.gigs || 0, icon: Star, color: 'text-purple-400' },
          { label: 'Followers', value: stats.followers || 0, icon: Users, color: 'text-blue-400' },
          { label: 'Rating', value: `${(stats.rating || 0).toFixed(1)}★`, icon: Star, color: 'text-yellow-400' },
          { label: 'Earnings', value: `$${stats.totalEarnings || 0}`, icon: TrendingUp, color: 'text-green-400' }
        ];
      
      default:
        return [
          { label: 'Orders', value: stats.totalOrders || 0, icon: Package, color: 'text-blue-400' },
          { label: 'Rating', value: `${(stats.rating || 0).toFixed(1)}★`, icon: Star, color: 'text-yellow-400' },
          { label: 'Reviews', value: stats.reviews || 0, icon: Users, color: 'text-purple-400' },
          { label: 'Activity', value: '0', icon: TrendingUp, color: 'text-green-400' }
        ];
    }
  };

  const membershipStats = getStatsForMembership();

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {membershipStats.map((stat, index) => {
        const IconComponent = stat.icon;
        return (
          <Card key={index} className="bg-slate-800 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm font-medium">{stat.label}</p>
                  <p className="text-2xl font-bold text-white">{stat.value}</p>
                </div>
                <IconComponent className={`w-8 h-8 ${stat.color}`} />
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};