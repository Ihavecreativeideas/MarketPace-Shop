import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Bot, CheckCircle, Circle, ArrowRight, Code, Globe, Zap } from 'lucide-react';

interface AIIntegrationAssistantProps {
  partnerTier: 'silver' | 'gold' | 'platinum';
  onStepComplete: (step: string) => void;
}

const AIIntegrationAssistant: React.FC<AIIntegrationAssistantProps> = ({ 
  partnerTier, 
  onStepComplete 
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [showBenefits, setShowBenefits] = useState(false);

  const tierBenefits = {
    silver: {
      color: 'bg-gray-400',
      features: [
        'Advanced API Integration',
        'Priority Search Placement',
        'Enhanced Analytics',
        'Custom Branding Options',
        'Dedicated Support Channel'
      ]
    },
    gold: {
      color: 'bg-yellow-500',
      features: [
        'All Silver Benefits',
        'White-label Solutions',
        'Advanced Webhook Support',
        'Custom Domain Integration',
        'Premium Marketing Tools',
        'Real-time Inventory Sync'
      ]
    },
    platinum: {
      color: 'bg-purple-600',
      features: [
        'All Gold Benefits',
        'Enterprise API Access',
        'Custom Feature Development',
        'Dedicated Account Manager',
        'Priority Feature Requests',
        'Advanced Security Features'
      ]
    }
  };

  const integrationSteps = [
    {
      id: 'setup',
      title: 'Initial Setup',
      description: 'Configure your account and API credentials',
      details: 'We\'ll help you set up your API keys and configure your account settings for seamless integration.'
    },
    {
      id: 'api',
      title: 'API Integration',
      description: 'Connect your website to our platform',
      details: 'Step-by-step guidance to integrate our APIs into your existing website or e-commerce platform.'
    },
    {
      id: 'customize',
      title: 'Customize Features',
      description: 'Configure your specific business needs',
      details: 'Tailor the integration to match your brand and business requirements with our customization tools.'
    },
    {
      id: 'test',
      title: 'Testing & Validation',
      description: 'Ensure everything works perfectly',
      details: 'Comprehensive testing to make sure all features work correctly before going live.'
    },
    {
      id: 'launch',
      title: 'Go Live',
      description: 'Launch your integrated solution',
      details: 'Final deployment and monitoring to ensure a smooth launch of your integrated platform.'
    }
  ];

  const handleStepComplete = (stepId: string) => {
    if (!completedSteps.includes(stepId)) {
      const newCompleted = [...completedSteps, stepId];
      setCompletedSteps(newCompleted);
      onStepComplete(stepId);
      
      if (currentStep < integrationSteps.length - 1) {
        setCurrentStep(currentStep + 1);
      }
    }
  };

  const progress = (completedSteps.length / integrationSteps.length) * 100;

  return (
    <div className="max-w-4xl mx-auto space-y-6 p-6">
      <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Bot className="h-8 w-8 text-blue-600" />
            <div>
              <h2 className="text-2xl font-bold text-blue-800">
                AI Integration Assistant
              </h2>
              <Badge className={`${tierBenefits[partnerTier].color} text-white mt-2`}>
                {partnerTier.toUpperCase()} PARTNER
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Integration Progress</span>
              <span className="text-sm text-gray-600">{Math.round(progress)}% Complete</span>
            </div>
            <Progress value={progress} className="h-3" />
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Code className="h-5 w-5" />
              Integration Steps
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {integrationSteps.map((step, index) => {
              const isCompleted = completedSteps.includes(step.id);
              const isCurrent = index === currentStep;
              
              return (
                <div key={step.id} className={`p-4 rounded-lg border ${
                  isCurrent ? 'border-blue-300 bg-blue-50' : 
                  isCompleted ? 'border-green-300 bg-green-50' : 'border-gray-200'
                }`}>
                  <div className="flex items-start gap-3">
                    {isCompleted ? (
                      <CheckCircle className="h-6 w-6 text-green-600 mt-0.5" />
                    ) : (
                      <Circle className={`h-6 w-6 mt-0.5 ${
                        isCurrent ? 'text-blue-600' : 'text-gray-400'
                      }`} />
                    )}
                    <div className="flex-1">
                      <h3 className="font-semibold">{step.title}</h3>
                      <p className="text-sm text-gray-600 mb-2">{step.description}</p>
                      {isCurrent && (
                        <div className="space-y-2">
                          <p className="text-sm">{step.details}</p>
                          <Button 
                            size="sm" 
                            onClick={() => handleStepComplete(step.id)}
                            className="flex items-center gap-2"
                          >
                            Complete Step <ArrowRight className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              Your {partnerTier.toUpperCase()} Benefits
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {tierBenefits[partnerTier].features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-sm">{feature}</span>
                </div>
              ))}
            </div>
            
            <Button 
              variant="outline" 
              className="w-full mt-4"
              onClick={() => setShowBenefits(!showBenefits)}
            >
              <Globe className="h-4 w-4 mr-2" />
              View Integration Guide
            </Button>
            
            {showBenefits && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold mb-2">Quick Start Guide:</h4>
                <ol className="text-sm space-y-1 list-decimal list-inside">
                  <li>Copy your API credentials from the dashboard</li>
                  <li>Install our SDK or use direct API calls</li>
                  <li>Configure webhook endpoints</li>
                  <li>Test the integration in sandbox mode</li>
                  <li>Deploy to production</li>
                </ol>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AIIntegrationAssistant;