import React, { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Facebook, Truck, ExternalLink } from 'lucide-react';

interface ProductFacebookShareProps {
  product: {
    id: string;
    name: string;
    price: number;
    image: string;
    description: string;
  };
}

const ProductFacebookShare: React.FC<ProductFacebookShareProps> = ({ product }) => {
  const [isSharing, setIsSharing] = useState(false);

  const handleFacebookShare = async () => {
    setIsSharing(true);
    
    const shareUrl = `${window.location.origin}/product/${product.id}`;
    const shareText = `Check out this ${product.name} for $${product.price} on MarketPace! Available for immediate delivery.`;
    
    // Facebook Share Dialog
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
    
    window.open(facebookUrl, 'facebook-share', 'width=580,height=296');
    
    setTimeout(() => setIsSharing(false), 1000);
  };

  const handleDeliverNow = () => {
    // Navigate to delivery options
    window.location.href = `/deliver-now/${product.id}`;
  };

  return (
    <div className="flex flex-col space-y-2 mt-3">
      <div className="flex space-x-2">
        <Button
          onClick={handleFacebookShare}
          disabled={isSharing}
          variant="outline"
          size="sm"
          className="flex-1 border-blue-200 hover:bg-blue-50"
        >
          <Facebook className="w-4 h-4 mr-2 text-blue-600" />
          {isSharing ? 'Sharing...' : 'Share to Facebook'}
        </Button>
        
        <Button
          onClick={handleDeliverNow}
          size="sm"
          className="bg-green-600 hover:bg-green-700 text-white"
        >
          <Truck className="w-4 h-4 mr-2" />
          Deliver Now
        </Button>
      </div>
      
      <Badge variant="outline" className="text-xs text-center border-green-200 text-green-700">
        <Truck className="w-3 h-3 mr-1" />
        Same-day delivery available
      </Badge>
    </div>
  );
};

export default ProductFacebookShare;