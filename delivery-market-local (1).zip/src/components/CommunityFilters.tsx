import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Video, Calendar, MessageSquare, BarChart3, Music, Briefcase, Image, MapPin, Search, Filter } from 'lucide-react';

interface FilterProps {
  onFilterChange: (filters: FilterState) => void;
}

interface FilterState {
  type: string;
  location: string;
  sortBy: string;
  searchTerm: string;
}

const CommunityFilters: React.FC<FilterProps> = ({ onFilterChange }) => {
  const [filters, setFilters] = useState<FilterState>({
    type: 'all',
    location: 'all',
    sortBy: 'recent',
    searchTerm: ''
  });

  const [showFilters, setShowFilters] = useState(false);

  const postTypes = [
    { value: 'all', label: 'All Posts', icon: null, count: 156 },
    { value: 'livestream', label: 'Live Streams', icon: Video, count: 3 },
    { value: 'event', label: 'Events', icon: Calendar, count: 12 },
    { value: 'thought', label: 'Thoughts', icon: MessageSquare, count: 45 },
    { value: 'sale', label: 'For Sale', icon: BarChart3, count: 23 },
    { value: 'music', label: 'New Music', icon: Music, count: 18 },
    { value: 'hire', label: 'For Hire', icon: Briefcase, count: 15 },
    { value: 'job', label: 'Jobs', icon: Briefcase, count: 8 },
    { value: 'picture', label: 'Pictures', icon: Image, count: 32 }
  ];

  const locations = [
    { value: 'all', label: 'All Locations' },
    { value: 'springfield', label: 'Springfield' },
    { value: 'downtown', label: 'Downtown' },
    { value: 'northside', label: 'Northside' },
    { value: 'southside', label: 'Southside' }
  ];

  const sortOptions = [
    { value: 'recent', label: 'Most Recent' },
    { value: 'popular', label: 'Most Popular' },
    { value: 'trending', label: 'Trending' },
    { value: 'nearby', label: 'Nearby' }
  ];

  const updateFilter = (key: keyof FilterState, value: string) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Search community posts..."
          value={filters.searchTerm}
          onChange={(e) => updateFilter('searchTerm', e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Quick Filter Buttons */}
      <div className="flex flex-wrap gap-2">
        {postTypes.slice(0, 6).map((type) => {
          const Icon = type.icon;
          const isActive = filters.type === type.value;
          return (
            <Button
              key={type.value}
              variant={isActive ? "default" : "outline"}
              size="sm"
              onClick={() => updateFilter('type', type.value)}
              className={`flex items-center gap-1 ${
                isActive 
                  ? 'bg-black text-teal-400 hover:bg-gray-900' 
                  : 'border-gray-300 text-gray-600 hover:bg-gray-50'
              }`}
            >
              {Icon && <Icon className="w-3 h-3" />}
              <span>{type.label}</span>
              <Badge variant="secondary" className="ml-1 text-xs">
                {type.count}
              </Badge>
            </Button>
          );
        })}
        
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowFilters(!showFilters)}
          className="border-gray-300 text-gray-600 hover:bg-gray-50"
        >
          <Filter className="w-3 h-3 mr-1" />
          More Filters
        </Button>
      </div>

      {/* Advanced Filters */}
      {showFilters && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
          {/* Post Type Dropdown */}
          <div>
            <label className="text-sm font-medium text-black mb-2 block">Post Type</label>
            <Select value={filters.type} onValueChange={(value) => updateFilter('type', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {postTypes.map((type) => {
                  const Icon = type.icon;
                  return (
                    <SelectItem key={type.value} value={type.value}>
                      <div className="flex items-center gap-2">
                        {Icon && <Icon className="w-4 h-4" />}
                        <span>{type.label}</span>
                        <Badge variant="secondary" className="ml-auto">
                          {type.count}
                        </Badge>
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {/* Location Filter */}
          <div>
            <label className="text-sm font-medium text-black mb-2 block">Location</label>
            <Select value={filters.location} onValueChange={(value) => updateFilter('location', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {locations.map((location) => (
                  <SelectItem key={location.value} value={location.value}>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span>{location.label}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Sort By */}
          <div>
            <label className="text-sm font-medium text-black mb-2 block">Sort By</label>
            <Select value={filters.sortBy} onValueChange={(value) => updateFilter('sortBy', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {sortOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      )}

      {/* Active Filters Display */}
      {(filters.type !== 'all' || filters.location !== 'all' || filters.searchTerm) && (
        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-sm text-gray-600">Active filters:</span>
          
          {filters.type !== 'all' && (
            <Badge variant="secondary" className="bg-teal-100 text-teal-800">
              {postTypes.find(t => t.value === filters.type)?.label}
              <button 
                onClick={() => updateFilter('type', 'all')}
                className="ml-1 hover:text-teal-900"
              >
                ×
              </button>
            </Badge>
          )}
          
          {filters.location !== 'all' && (
            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
              {locations.find(l => l.value === filters.location)?.label}
              <button 
                onClick={() => updateFilter('location', 'all')}
                className="ml-1 hover:text-purple-900"
              >
                ×
              </button>
            </Badge>
          )}
          
          {filters.searchTerm && (
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              "{filters.searchTerm}"
              <button 
                onClick={() => updateFilter('searchTerm', '')}
                className="ml-1 hover:text-blue-900"
              >
                ×
              </button>
            </Badge>
          )}
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              const resetFilters = { type: 'all', location: 'all', sortBy: 'recent', searchTerm: '' };
              setFilters(resetFilters);
              onFilterChange(resetFilters);
            }}
            className="text-gray-500 hover:text-gray-700"
          >
            Clear all
          </Button>
        </div>
      )}
    </div>
  );
};

export default CommunityFilters;