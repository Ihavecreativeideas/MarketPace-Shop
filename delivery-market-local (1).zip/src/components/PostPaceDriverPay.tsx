import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { DollarSign, MapPin, Package, Clock, Zap } from 'lucide-react';
import { Badge } from './ui/badge';

const PostPaceDriverPay: React.FC = () => {
  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-orange-600">
          <DollarSign className="w-5 h-5" />
          PostPace Driver Pay
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
            <div className="flex items-center gap-2">
              <Package className="w-4 h-4 text-green-600" />
              <span className="font-medium">Pickup Fee</span>
            </div>
            <span className="font-bold text-green-600">$4.00</span>
          </div>
          
          <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-blue-600" />
              <span className="font-medium">Drop-off Fee</span>
            </div>
            <span className="font-bold text-blue-600">$2.00</span>
          </div>
          
          <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-purple-600" />
              <span className="font-medium">Per Mile</span>
            </div>
            <span className="font-bold text-purple-600">$0.50</span>
          </div>
          
          <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-red-600" />
              <span className="font-medium">Urgent Bonus</span>
            </div>
            <Badge className="bg-red-600 text-white">+35%</Badge>
          </div>
          
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-semibold text-gray-900 mb-2">Example Delivery (8 miles)</h4>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>Pickup:</span>
                <span>$4.00</span>
              </div>
              <div className="flex justify-between">
                <span>Drop-off:</span>
                <span>$2.00</span>
              </div>
              <div className="flex justify-between">
                <span>Miles (8 × $0.50):</span>
                <span>$4.00</span>
              </div>
              <hr className="my-2" />
              <div className="flex justify-between font-bold">
                <span>Total:</span>
                <span>$10.00</span>
              </div>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-yellow-50 rounded-lg">
            <h4 className="font-semibold text-yellow-800 mb-2">Urgent Package Example</h4>
            <div className="space-y-1 text-sm text-yellow-700">
              <div className="flex justify-between">
                <span>Base pay (8 miles):</span>
                <span>$10.00</span>
              </div>
              <div className="flex justify-between">
                <span>Urgent bonus (+35%):</span>
                <span>$3.50</span>
              </div>
              <hr className="my-2" />
              <div className="flex justify-between font-bold">
                <span>Total:</span>
                <span>$13.50</span>
              </div>
            </div>
          </div>
          
          <div className="mt-4 p-3 bg-orange-50 rounded-lg">
            <p className="text-xs text-orange-700">
              <strong>Fair Rates:</strong> No peak time multipliers - consistent pay for all postal deliveries.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PostPaceDriverPay;