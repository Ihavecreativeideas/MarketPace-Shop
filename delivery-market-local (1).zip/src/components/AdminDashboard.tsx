import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LogOut, RefreshCw, Users, TrendingUp, MapPin, MessageSquare, Settings, Edit, Activity, BarChart3, Zap, Monitor, Wrench } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import LiveStatsPanel from '@/components/LiveStatsPanel';
import CampaignTracker from '@/components/CampaignTracker';
import StatusChartsPanel from '@/components/StatusChartsPanel';

interface AdminDashboardProps {
  onLogout: () => void;
}

export default function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const navigate = useNavigate();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [globalStats, setGlobalStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    totalTowns: 0,
    totalDrivers: 0,
    totalBusinesses: 0,
    totalDeliveries: 0
  });

  useEffect(() => {
    loadGlobalStats();
    const interval = setInterval(loadGlobalStats, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadGlobalStats = async () => {
    try {
      const [users, drivers, businesses, deliveries] = await Promise.all([
        supabase.from('users').select('*', { count: 'exact' }),
        supabase.from('driver_profiles').select('*', { count: 'exact' }),
        supabase.from('business_profiles').select('*', { count: 'exact' }),
        supabase.from('deliveries').select('*', { count: 'exact' })
      ]);

      setGlobalStats({
        totalUsers: users.count || 0,
        activeUsers: Math.floor((users.count || 0) * 0.7),
        totalTowns: 12,
        totalDrivers: drivers.count || 0,
        totalBusinesses: businesses.count || 0,
        totalDeliveries: deliveries.count || 0
      });
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadGlobalStats();
    setIsRefreshing(false);
    setLastUpdated(new Date());
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="border-b bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-teal-600 to-blue-600 bg-clip-text text-transparent">
                MarketPace Admin Command Center
              </h1>
              <p className="text-muted-foreground flex items-center gap-2">
                <Activity className="h-4 w-4 text-green-500" />
                Live Dashboard • Last updated: {lastUpdated.toLocaleTimeString()}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button onClick={() => navigate('/admin/ai-app-editor')} className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
                <Wrench className="h-4 w-4 mr-2" />
                App
              </Button>
              <Button onClick={() => navigate('/admin/analytics')} className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-0">
                <BarChart3 className="h-4 w-4 mr-2" />
                Analytics
              </Button>
              <Button onClick={() => navigate('/admin/drivers')} className="bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0">
                <MapPin className="h-4 w-4 mr-2" />
                Drivers
              </Button>
              <Button onClick={() => navigate('/admin/businesses')} className="bg-gradient-to-r from-orange-500 to-red-500 text-white border-0">
                <MessageSquare className="h-4 w-4 mr-2" />
                Businesses
              </Button>
              <Button onClick={() => navigate('/admin/routes')} className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-0">
                <TrendingUp className="h-4 w-4 mr-2" />
                Routes
              </Button>
              <Button onClick={() => navigate('/admin/sales')} className="bg-gradient-to-r from-pink-500 to-rose-500 text-white border-0">
                <Users className="h-4 w-4 mr-2" />
                Sales
              </Button>
              <Button variant="outline" onClick={handleRefresh} disabled={isRefreshing}>
                <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Button variant="outline" onClick={onLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Live Stats Panel */}
        <LiveStatsPanel stats={globalStats} />
        
        {/* Campaign Tracker */}
        <CampaignTracker />
        
        {/* Status Charts Panel */}
        <StatusChartsPanel />
      </div>
    </div>
  );
}