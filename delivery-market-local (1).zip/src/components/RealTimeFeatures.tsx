import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, Activity, TrendingUp, Zap, Bell, MapPin } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface LiveActivity {
  id: string;
  type: 'purchase' | 'booking' | 'join' | 'review';
  user: string;
  item: string;
  location: string;
  timestamp: Date;
}

const RealTimeFeatures = () => {
  const [liveUsers, setLiveUsers] = useState(1247);
  const [activities, setActivities] = useState<LiveActivity[]>([]);
  const [trendingItems, setTrendingItems] = useState<string[]>([]);

  const mockActivities: LiveActivity[] = [
    {
      id: '1',
      type: 'purchase',
      user: 'Sarah M.',
      item: 'Handmade Jewelry Set',
      location: 'New York',
      timestamp: new Date()
    },
    {
      id: '2',
      type: 'booking',
      user: 'Mike R.',
      item: 'Guitar Lessons',
      location: 'Los Angeles',
      timestamp: new Date(Date.now() - 30000)
    },
    {
      id: '3',
      type: 'join',
      user: 'Emma K.',
      item: 'MarketPace Pro',
      location: 'Chicago',
      timestamp: new Date(Date.now() - 60000)
    }
  ];

  useEffect(() => {
    // Simulate live user count updates
    const userInterval = setInterval(() => {
      setLiveUsers(prev => prev + Math.floor(Math.random() * 10) - 5);
    }, 3000);

    // Simulate new activities
    const activityInterval = setInterval(() => {
      const newActivity: LiveActivity = {
        id: Date.now().toString(),
        type: ['purchase', 'booking', 'join', 'review'][Math.floor(Math.random() * 4)] as any,
        user: ['Alex T.', 'Jordan P.', 'Casey L.', 'Taylor M.'][Math.floor(Math.random() * 4)],
        item: ['Coffee Beans', 'Music Lesson', 'Art Print', 'Web Design'][Math.floor(Math.random() * 4)],
        location: ['Seattle', 'Austin', 'Miami', 'Denver'][Math.floor(Math.random() * 4)],
        timestamp: new Date()
      };
      
      setActivities(prev => [newActivity, ...prev.slice(0, 4)]);
    }, 5000);

    // Initialize with mock data
    setActivities(mockActivities);
    setTrendingItems(['Guitar Lessons', 'Coffee Beans', 'Art Prints']);

    return () => {
      clearInterval(userInterval);
      clearInterval(activityInterval);
    };
  }, []);

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'purchase': return '🛒';
      case 'booking': return '📅';
      case 'join': return '👋';
      case 'review': return '⭐';
      default: return '💫';
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'purchase': return 'from-green-500 to-emerald-500';
      case 'booking': return 'from-blue-500 to-cyan-500';
      case 'join': return 'from-purple-500 to-pink-500';
      case 'review': return 'from-yellow-500 to-orange-500';
      default: return 'from-gray-500 to-slate-500';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      {/* Live Users Counter */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border-cyan-500/30 backdrop-blur-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-300 mb-1">Live Users</p>
                <motion.p 
                  className="text-3xl font-bold text-cyan-400"
                  key={liveUsers}
                  initial={{ scale: 1.2 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.3 }}
                >
                  {liveUsers.toLocaleString()}
                </motion.p>
              </div>
              <div className="relative">
                <Users className="w-8 h-8 text-cyan-400" />
                <motion.div
                  className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Trending Now */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-purple-500/30 backdrop-blur-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-purple-400" />
                <p className="text-sm text-gray-300">Trending Now</p>
              </div>
              <Zap className="w-5 h-5 text-yellow-400" />
            </div>
            <div className="space-y-2">
              {trendingItems.map((item, index) => (
                <motion.div
                  key={item}
                  className="flex items-center space-x-2"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <Badge variant="outline" className="text-xs border-purple-400/50 text-purple-300">
                    #{index + 1}
                  </Badge>
                  <span className="text-sm text-white">{item}</span>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Live Activity Feed */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 border-green-500/30 backdrop-blur-lg">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Activity className="w-5 h-5 text-green-400" />
              <p className="text-sm text-gray-300">Live Activity</p>
              <motion.div
                className="w-2 h-2 bg-green-400 rounded-full"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
            </div>
            
            <div className="space-y-3 max-h-32 overflow-hidden">
              <AnimatePresence>
                {activities.map((activity, index) => (
                  <motion.div
                    key={activity.id}
                    initial={{ opacity: 0, y: -20, scale: 0.9 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 20, scale: 0.9 }}
                    transition={{ duration: 0.3 }}
                    className={`p-2 rounded-lg bg-gradient-to-r ${getActivityColor(activity.type)}/10 border border-white/10`}
                  >
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{getActivityIcon(activity.type)}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-white truncate">
                          <span className="font-medium">{activity.user}</span> {activity.type === 'purchase' ? 'bought' : activity.type === 'booking' ? 'booked' : activity.type === 'join' ? 'joined' : 'reviewed'} {activity.item}
                        </p>
                        <div className="flex items-center space-x-1 text-xs text-gray-400">
                          <MapPin className="w-3 h-3" />
                          <span>{activity.location}</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default RealTimeFeatures;