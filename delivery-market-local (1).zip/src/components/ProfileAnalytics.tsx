import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { BarChart3, TrendingUp, Users, Package, DollarSign, Eye, ShoppingCart } from 'lucide-react';

interface AnalyticsData {
  profileViews: number;
  productViews: number;
  totalSales: number;
  conversionRate: number;
  topProducts: Array<{
    name: string;
    sales: number;
    revenue: number;
  }>;
  salesTrend: Array<{
    date: string;
    sales: number;
    revenue: number;
  }>;
  customerInsights: {
    totalCustomers: number;
    returningCustomers: number;
    averageOrderValue: number;
  };
}

const ProfileAnalytics: React.FC = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('7d');

  useEffect(() => {
    loadAnalytics();
  }, [timeRange]);

  const loadAnalytics = async () => {
    const mockData: AnalyticsData = {
      profileViews: 1247,
      productViews: 3892,
      totalSales: 156,
      conversionRate: 4.2,
      topProducts: [
        { name: 'Premium Coffee Blend', sales: 45, revenue: 1124.55 },
        { name: 'Handcrafted Mug', sales: 32, revenue: 592.00 },
        { name: 'Coffee Grinder', sales: 18, revenue: 1619.82 }
      ],
      salesTrend: [
        { date: '2024-01-01', sales: 12, revenue: 298.50 },
        { date: '2024-01-02', sales: 18, revenue: 445.20 },
        { date: '2024-01-03', sales: 25, revenue: 612.75 },
        { date: '2024-01-04', sales: 22, revenue: 534.60 },
        { date: '2024-01-05', sales: 31, revenue: 756.25 },
        { date: '2024-01-06', sales: 28, revenue: 689.40 },
        { date: '2024-01-07', sales: 35, revenue: 842.50 }
      ],
      customerInsights: {
        totalCustomers: 89,
        returningCustomers: 34,
        averageOrderValue: 24.85
      }
    };

    setTimeout(() => {
      setAnalytics(mockData);
      setLoading(false);
    }, 1000);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500"></div>
      </div>
    );
  }

  if (!analytics) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No analytics data available</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-4 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Analytics Dashboard</h1>
        <div className="flex gap-2">
          {['7d', '30d', '90d'].map((range) => (
            <Badge
              key={range}
              variant={timeRange === range ? 'default' : 'secondary'}
              className={`cursor-pointer ${
                timeRange === range ? 'bg-cyan-600' : 'bg-slate-600 hover:bg-slate-500'
              }`}
              onClick={() => setTimeRange(range)}
            >
              {range === '7d' ? 'Last 7 days' : range === '30d' ? 'Last 30 days' : 'Last 90 days'}
            </Badge>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800 border-cyan-500/30 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-cyan-300">Profile Views</p>
                <p className="text-2xl font-bold">{analytics.profileViews.toLocaleString()}</p>
                <p className="text-xs text-green-400 flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +12.5% vs last period
                </p>
              </div>
              <Eye className="h-8 w-8 text-cyan-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-cyan-500/30 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-cyan-300">Total Sales</p>
                <p className="text-2xl font-bold">{analytics.totalSales}</p>
                <p className="text-xs text-green-400 flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +8.3% vs last period
                </p>
              </div>
              <ShoppingCart className="h-8 w-8 text-cyan-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-cyan-500/30 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-cyan-300">Revenue</p>
                <p className="text-2xl font-bold">
                  ${analytics.salesTrend.reduce((sum, day) => sum + day.revenue, 0).toFixed(0)}
                </p>
                <p className="text-xs text-green-400 flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +15.2% vs last period
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-cyan-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-cyan-500/30 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-cyan-300">Conversion Rate</p>
                <p className="text-2xl font-bold">{analytics.conversionRate}%</p>
                <p className="text-xs text-green-400 flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +2.1% vs last period
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-cyan-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3 bg-slate-800">
          <TabsTrigger value="overview" className="text-white">Overview</TabsTrigger>
          <TabsTrigger value="products" className="text-white">Products</TabsTrigger>
          <TabsTrigger value="customers" className="text-white">Customers</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-slate-800 border-cyan-500/30 text-white">
              <CardHeader>
                <CardTitle className="text-cyan-300">Sales Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analytics.salesTrend.map((day, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-sm text-cyan-200">
                        {new Date(day.date).toLocaleDateString()}
                      </span>
                      <div className="text-right">
                        <p className="font-semibold">{day.sales} sales</p>
                        <p className="text-sm text-green-400">${day.revenue.toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-cyan-500/30 text-white">
              <CardHeader>
                <CardTitle className="text-cyan-300">Top Products</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analytics.topProducts.map((product, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{product.name}</span>
                        <span className="text-green-400">${product.revenue.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-cyan-300">{product.sales} sales</span>
                        <Progress value={(product.sales / 50) * 100} className="w-20 h-2" />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="products">
          <Card className="bg-slate-800 border-cyan-500/30 text-white">
            <CardHeader>
              <CardTitle className="text-cyan-300">Product Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-cyan-400">{analytics.productViews.toLocaleString()}</p>
                  <p className="text-sm text-cyan-300">Total Product Views</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-cyan-400">12</p>
                  <p className="text-sm text-cyan-300">Active Products</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-cyan-400">${analytics.customerInsights.averageOrderValue}</p>
                  <p className="text-sm text-cyan-300">Avg Order Value</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customers">
          <Card className="bg-slate-800 border-cyan-500/30 text-white">
            <CardHeader>
              <CardTitle className="text-cyan-300">Customer Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <Users className="h-12 w-12 text-cyan-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold">{analytics.customerInsights.totalCustomers}</p>
                  <p className="text-sm text-cyan-300">Total Customers</p>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">
                    {((analytics.customerInsights.returningCustomers / analytics.customerInsights.totalCustomers) * 100).toFixed(1)}%
                  </div>
                  <p className="text-sm text-cyan-300">Returning Customers</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-cyan-400">${analytics.customerInsights.averageOrderValue}</p>
                  <p className="text-sm text-cyan-300">Average Order Value</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProfileAnalytics;