import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ArrowLeft, Search, Music, Star, MapPin, Calendar, Heart } from 'lucide-react';
import TealSquareLogo from './TealSquareLogo';

const Musicians: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');

  const mockMusicians = [
    { id: 1, name: 'Jazz Quartet', genre: 'Jazz', rating: 4.8, price: 150, location: 'Downtown', image: '/placeholder.svg', description: 'Professional jazz ensemble for events' },
    { id: 2, name: 'Rock Band Alpha', genre: 'Rock', rating: 4.6, price: 200, location: 'Midtown', image: '/placeholder.svg', description: 'High-energy rock performances' },
    { id: 3, name: 'Acoustic Duo', genre: 'Folk', rating: 4.9, price: 100, location: 'Uptown', image: '/placeholder.svg', description: 'Intimate acoustic performances' },
    { id: 4, name: 'DJ Mixer', genre: 'Electronic', rating: 4.7, price: 120, location: 'Downtown', image: '/placeholder.svg', description: 'Professional DJ for parties' },
    { id: 5, name: 'Classical Trio', genre: 'Classical', rating: 4.9, price: 180, location: 'Arts District', image: '/placeholder.svg', description: 'Elegant classical music' },
    { id: 6, name: 'Blues Brothers', genre: 'Blues', rating: 4.5, price: 140, location: 'Old Town', image: '/placeholder.svg', description: 'Authentic blues experience' }
  ];

  const genres = ['all', 'Jazz', 'Rock', 'Folk', 'Electronic', 'Classical', 'Blues'];

  const handleBack = () => navigate('/');
  const handleBooking = (musicianId: number) => {
    console.log('Booking musician:', musicianId);
    // In a real app, this would open a booking modal or navigate to booking page
  };

  const filteredMusicians = mockMusicians.filter(musician => {
    const matchesSearch = musician.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         musician.genre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         musician.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGenre = selectedGenre === 'all' || musician.genre === selectedGenre;
    return matchesSearch && matchesGenre;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-white/10 backdrop-blur-lg border-b border-slate-200/20 text-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBack}
                className="text-slate-400 hover:text-white"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center space-x-3">
                <TealSquareLogo size={32} />
                <div className="text-xl font-bold text-teal-400">
                  Musicians
                </div>
              </div>
            </div>
            <Button
              onClick={() => navigate('/profile')}
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-white"
            >
              Profile
            </Button>
          </div>
        </div>
      </header>

      {/* Search and Filters */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search musicians, genres, or locations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
            />
          </div>
        </div>

        {/* Genre Filter */}
        <div className="flex flex-wrap gap-2 mb-6">
          {genres.map((genre) => (
            <Button
              key={genre}
              variant={selectedGenre === genre ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedGenre(genre)}
              className={`${
                selectedGenre === genre
                  ? 'bg-teal-500 hover:bg-teal-600'
                  : 'bg-slate-700 hover:bg-slate-600 border-slate-600 text-white'
              }`}
            >
              {genre === 'all' ? 'All Genres' : genre}
            </Button>
          ))}
        </div>

        {/* Musicians Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMusicians.map((musician) => (
            <Card key={musician.id} className="bg-slate-800/40 border-slate-600/30 hover:shadow-lg transition-all duration-300 hover:bg-slate-700/40 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <div className="aspect-square bg-slate-700 rounded-lg mb-3 flex items-center justify-center relative">
                  <img
                    src={musician.image}
                    alt={musician.name}
                    className="w-full h-full object-cover rounded-lg opacity-50"
                  />
                  <Music className="absolute inset-0 m-auto h-12 w-12 text-slate-400" />
                </div>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg text-white">{musician.name}</CardTitle>
                    <div className="flex items-center gap-2 mt-1">
                      <MapPin className="h-4 w-4 text-slate-400" />
                      <span className="text-sm text-slate-400">{musician.location}</span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-slate-400 hover:text-red-400 p-1"
                  >
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-slate-300 mb-3">{musician.description}</p>
                <div className="flex justify-between items-center mb-3">
                  <Badge variant="secondary" className="bg-slate-700 text-slate-300">
                    {musician.genre}
                  </Badge>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm text-slate-300">{musician.rating}</span>
                  </div>
                </div>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-xl font-bold text-teal-400">
                    ${musician.price}/hr
                  </span>
                </div>
                <Button
                  onClick={() => handleBooking(musician.id)}
                  className="w-full bg-teal-500 hover:bg-teal-600"
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  Book Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredMusicians.length === 0 && (
          <div className="text-center py-12">
            <Music className="h-16 w-16 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-400 text-lg">No musicians found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Musicians;
export { Musicians };