import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Alert, AlertDescription } from './ui/alert';
import { Heart, MapPin, AlertTriangle, Clock, Zap } from 'lucide-react';
import ShippingStoreLocator from './ShippingStoreLocator';

const MedPaceDeliveryForm: React.FC = () => {
  const [formData, setFormData] = useState({
    pickupAddress: '',
    dropoffAddress: '',
    prescriptionInfo: '',
    urgency: 'grow-routes',
    distance: 0
  });
  const [cost, setCost] = useState(0);
  const [errors, setErrors] = useState<string[]>([]);

  const prohibitedItems = [
    'alcohol', 'beer', 'wine', 'liquor', 'spirits',
    'hazardous', 'flammable', 'explosive', 'toxic',
    'chemical', 'battery', 'lithium', 'gas', 'fuel'
  ];

  const calculateCost = (miles: number) => {
    const baseCost = 14; // $14 for first 8 miles
    const extraMiles = Math.max(0, miles - 8);
    const extraCost = extraMiles * 1.25;
    return baseCost + extraCost;
  };

  const validateItems = (description: string) => {
    const newErrors: string[] = [];
    const lowerDesc = description.toLowerCase();
    
    prohibitedItems.forEach(item => {
      if (lowerDesc.includes(item)) {
        newErrors.push(`${item.charAt(0).toUpperCase() + item.slice(1)} items cannot be shipped`);
      }
    });
    
    setErrors(newErrors);
    return newErrors.length === 0;
  };

  const handlePrescriptionChange = (value: string) => {
    setFormData(prev => ({ ...prev, prescriptionInfo: value }));
    validateItems(value);
  };

  const handleDistanceChange = (value: string) => {
    const miles = parseFloat(value) || 0;
    setFormData(prev => ({ ...prev, distance: miles }));
    setCost(calculateCost(miles));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (errors.length > 0) {
      alert('Please remove prohibited items before submitting.');
      return;
    }
    if (!formData.pickupAddress || !formData.dropoffAddress) {
      alert('Please verify both pickup and dropoff addresses are correct.');
      return;
    }
    console.log('MedPace pickup job submitted:', formData);
    alert(`MedPace pickup job submitted! Total cost: $${cost.toFixed(2)}`);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-blue-600" />
            MedPace Prescription Delivery
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="pickup">Pharmacy Address *</Label>
                <Input
                  id="pickup"
                  placeholder="Enter pharmacy address"
                  value={formData.pickupAddress}
                  onChange={(e) => setFormData(prev => ({ ...prev, pickupAddress: e.target.value }))}
                  required
                />
              </div>
              <div>
                <Label htmlFor="dropoff">Delivery Address *</Label>
                <Input
                  id="dropoff"
                  placeholder="Enter delivery address"
                  value={formData.dropoffAddress}
                  onChange={(e) => setFormData(prev => ({ ...prev, dropoffAddress: e.target.value }))}
                  required
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="distance">Distance (miles) *</Label>
                <Input
                  id="distance"
                  type="number"
                  step="0.1"
                  placeholder="Enter distance"
                  onChange={(e) => handleDistanceChange(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="urgency">Delivery Priority</Label>
                <Select value={formData.urgency} onValueChange={(value) => setFormData(prev => ({ ...prev, urgency: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="urgent">
                      <div className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-red-500" />
                        Urgent
                      </div>
                    </SelectItem>
                    <SelectItem value="grow-routes">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-green-500" />
                        Grow Routes
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="prescription">Prescription Information *</Label>
              <Textarea
                id="prescription"
                placeholder="Patient name, pickup code, or prescription details"
                value={formData.prescriptionInfo}
                onChange={(e) => handlePrescriptionChange(e.target.value)}
                required
              />
            </div>

            {errors.length > 0 && (
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="w-4 h-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  <ul className="list-disc list-inside">
                    {errors.map((error, index) => (
                      <li key={index}>{error}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            <Alert>
              <MapPin className="w-4 h-4" />
              <AlertDescription>
                Please double-check that your addresses are correct before submitting.
              </AlertDescription>
            </Alert>

            {cost > 0 && (
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-semibold text-blue-900 mb-2">Delivery Cost</h3>
                <div className="text-blue-800">
                  <p>Base cost (8 miles): $14.00</p>
                  {formData.distance > 8 && (
                    <p>Extra miles ({(formData.distance - 8).toFixed(1)}): ${((formData.distance - 8) * 1.25).toFixed(2)}</p>
                  )}
                  <p className="font-bold text-lg">Total: ${cost.toFixed(2)}</p>
                </div>
              </div>
            )}

            <Button type="submit" className="w-full" disabled={errors.length > 0}>
              Submit MedPace Pickup Job
            </Button>
          </form>
        </CardContent>
      </Card>

      <ShippingStoreLocator />
    </div>
  );
};

export default MedPaceDeliveryForm;