import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Users, Building, Music, Wrench, MapPin } from 'lucide-react';

interface LaunchMeterProps {
  members?: number;
  towns?: number;
  shops?: number;
  services?: number;
  entertainers?: number;
}

export const LaunchMeter: React.FC<LaunchMeterProps> = ({
  members = 1247,
  towns = 8,
  shops = 156,
  services = 89,
  entertainers = 234
}) => {
  const totalGoal = 5000;
  const currentTotal = members;
  const progress = Math.min((currentTotal / totalGoal) * 100, 100);

  return (
    <Card className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white border-0 shadow-2xl">
      <CardHeader className="text-center pb-4">
        <CardTitle className="text-2xl font-bold mb-2">🚀 Campaign Launch Meter</CardTitle>
        <p className="text-lg italic opacity-90">"You set the pace, we make it happen."</p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Launch Progress</span>
            <span>{currentTotal.toLocaleString()} / {totalGoal.toLocaleString()}</span>
          </div>
          <Progress value={progress} className="h-3 bg-white/20" />
          <p className="text-center text-sm opacity-80">{progress.toFixed(1)}% to launch!</p>
        </div>

        {/* Live Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div className="text-center p-3 bg-white/10 rounded-lg backdrop-blur-sm">
            <Users className="w-6 h-6 mx-auto mb-2" />
            <div className="text-xl font-bold">{members.toLocaleString()}</div>
            <div className="text-xs opacity-80">Members</div>
          </div>
          
          <div className="text-center p-3 bg-white/10 rounded-lg backdrop-blur-sm">
            <MapPin className="w-6 h-6 mx-auto mb-2" />
            <div className="text-xl font-bold">{towns}</div>
            <div className="text-xs opacity-80">Towns</div>
          </div>
          
          <div className="text-center p-3 bg-white/10 rounded-lg backdrop-blur-sm">
            <Building className="w-6 h-6 mx-auto mb-2" />
            <div className="text-xl font-bold">{shops}</div>
            <div className="text-xs opacity-80">Shops</div>
          </div>
          
          <div className="text-center p-3 bg-white/10 rounded-lg backdrop-blur-sm">
            <Wrench className="w-6 h-6 mx-auto mb-2" />
            <div className="text-xl font-bold">{services}</div>
            <div className="text-xs opacity-80">Services</div>
          </div>
          
          <div className="text-center p-3 bg-white/10 rounded-lg backdrop-blur-sm">
            <Music className="w-6 h-6 mx-auto mb-2" />
            <div className="text-xl font-bold">{entertainers}</div>
            <div className="text-xs opacity-80">Entertainers</div>
          </div>
        </div>

        {/* Donation CTA */}
        <div className="text-center pt-4 border-t border-white/20">
          <Button 
            className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold px-6 py-2 rounded-full shadow-lg transform hover:scale-105 transition-all"
            size="lg"
          >
            💝 Donate to Support Our Launch
          </Button>
          <p className="text-xs mt-2 opacity-70">Help us build the future of local commerce</p>
        </div>
      </CardContent>
    </Card>
  );
};