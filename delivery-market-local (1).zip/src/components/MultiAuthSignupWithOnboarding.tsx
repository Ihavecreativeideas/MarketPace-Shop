import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { Facebook, Mail, User, Linkedin, UserCheck } from 'lucide-react';
import { useToast } from './ui/use-toast';
import OnboardingFlow from './OnboardingFlow';

interface MultiAuthSignupWithOnboardingProps {
  onClose?: () => void;
  onComplete?: () => void;
}

const MultiAuthSignupWithOnboarding: React.FC<MultiAuthSignupWithOnboardingProps> = ({ onClose, onComplete }) => {
  const [currentView, setCurrentView] = useState<'signup' | 'onboarding' | 'complete'>('signup');
  const [isLogin, setIsLogin] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    setTimeout(() => {
      if (isLogin) {
        toast({
          title: "Welcome back!",
          description: "You've successfully signed in."
        });
        onComplete?.();
      } else {
        toast({
          title: "Account Created!",
          description: "Let's personalize your MarketPace experience."
        });
        setCurrentView('onboarding');
      }
      setLoading(false);
    }, 1000);
  };

  const handleSocialAuth = (provider: string) => {
    setLoading(true);
    setTimeout(() => {
      toast({
        title: `${provider} Sign Up Complete!`,
        description: "Let's set up your MarketPace profile."
      });
      setLoading(false);
      setCurrentView('onboarding');
    }, 1500);
  };

  const handleGuestAccess = () => {
    toast({
      title: "Guest Access",
      description: "Browsing as guest. Sign up to unlock all features!"
    });
    onComplete?.();
  };

  const handleOnboardingComplete = () => {
    toast({
      title: "Welcome to MarketPace!",
      description: "Your profile has been set up successfully."
    });
    onComplete?.();
  };

  if (currentView === 'onboarding') {
    return <OnboardingFlow onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className="max-w-md mx-auto p-4">
      <Card className="bg-gradient-to-br from-slate-900 via-cyan-900 to-purple-900 border-cyan-500/30 text-white">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            Join MarketPace
          </CardTitle>
          <p className="text-cyan-300">
            Choose your preferred sign-in method
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Social Auth Buttons */}
          <Button 
            onClick={() => handleSocialAuth('Facebook')}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            size="lg"
            disabled={loading}
          >
            <Facebook className="h-5 w-5 mr-2" />
            Continue with Facebook
          </Button>

          <Button 
            onClick={() => handleSocialAuth('Google')}
            className="w-full bg-red-600 hover:bg-red-700 text-white"
            size="lg"
            disabled={loading}
          >
            <Mail className="h-5 w-5 mr-2" />
            Continue with Google
          </Button>

          <Button 
            onClick={() => handleSocialAuth('LinkedIn')}
            className="w-full bg-blue-800 hover:bg-blue-900 text-white"
            size="lg"
            disabled={loading}
          >
            <Linkedin className="h-5 w-5 mr-2" />
            Continue with LinkedIn
          </Button>

          <div className="relative">
            <Separator className="bg-cyan-500/30" />
            <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-slate-900 px-2 text-sm text-cyan-300">
              or
            </span>
          </div>

          {/* Email Form */}
          <form onSubmit={handleEmailAuth} className="space-y-4">
            {!isLogin && (
              <div>
                <Label htmlFor="name" className="text-cyan-300">Full Name</Label>
                <Input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                />
              </div>
            )}
            
            <div>
              <Label htmlFor="email" className="text-cyan-300">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
              />
            </div>
            
            <div>
              <Label htmlFor="password" className="text-cyan-300">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
              />
            </div>

            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
              disabled={loading}
            >
              <User className="h-4 w-4 mr-2" />
              {loading ? 'Processing...' : (isLogin ? 'Sign In' : 'Sign Up with Email')}
            </Button>
          </form>

          <div className="text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-sm text-cyan-400 hover:underline"
            >
              {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
            </button>
          </div>

          <Separator className="bg-cyan-500/30" />

          {/* Guest Access */}
          <Button 
            onClick={handleGuestAccess}
            variant="outline"
            className="w-full border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/10"
          >
            <UserCheck className="h-4 w-4 mr-2" />
            Continue as Guest
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default MultiAuthSignupWithOnboarding;