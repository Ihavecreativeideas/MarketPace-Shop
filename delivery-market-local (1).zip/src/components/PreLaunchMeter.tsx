import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Rocket, Users, Music, Store, Truck } from 'lucide-react';
import { useLaunch } from '@/contexts/LaunchContext';
import TownRaceBar from './TownRaceBar';

const PreLaunchMeter: React.FC = () => {
  const { launchProgress, totalSignups, isLaunched, townData } = useLaunch();

  const getColor = () => {
    if (launchProgress < 33) return 'bg-red-500';
    if (launchProgress < 66) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getGlow = () => {
    if (launchProgress < 33) return 'shadow-red-500/50';
    if (launchProgress < 66) return 'shadow-yellow-500/50';
    return 'shadow-green-500/50';
  };

  if (isLaunched) {
    return (
      <Card className="bg-gradient-to-r from-green-500 to-blue-500 text-white mb-3 sm:mb-4 mx-2 sm:mx-0">
        <CardContent className="p-3 sm:p-4">
          <div className="flex items-center justify-center space-x-2">
            <Rocket className="w-5 h-5 sm:w-6 sm:h-6" />
            <span className="font-bold text-sm sm:text-lg text-center">🚀 LAUNCHED! Welcome to the full experience!</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="mx-2 sm:mx-0">
      <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white mb-3 sm:mb-4">
        <CardHeader className="pb-2 px-3 sm:px-6 pt-3 sm:pt-6">
          <CardTitle className="text-center flex items-center justify-center space-x-2 text-base sm:text-lg">
            <Rocket className="w-5 h-5 sm:w-6 sm:h-6" />
            <span>Preparing to Launch</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0 px-3 sm:px-6 pb-3 sm:pb-6">
          <div className="mb-3">
            <div className="w-full bg-white/20 rounded-full h-3 sm:h-4 relative overflow-hidden">
              <div 
                className={`h-full ${getColor()} transition-all duration-1000 ease-out rounded-full ${getGlow()} shadow-lg`}
                style={{ width: `${launchProgress}%` }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse"></div>
              </div>
            </div>
            <div className="flex justify-between text-xs sm:text-sm mt-1">
              <span>{totalSignups} members joined</span>
              <span>{Math.round(launchProgress)}% to launch</span>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:flex sm:justify-center gap-2 sm:gap-4 text-xs">
            <div className="flex items-center justify-center sm:justify-start space-x-1">
              <Users className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Members</span>
            </div>
            <div className="flex items-center justify-center sm:justify-start space-x-1">
              <Music className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Musicians</span>
            </div>
            <div className="flex items-center justify-center sm:justify-start space-x-1">
              <Store className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Vendors</span>
            </div>
            <div className="flex items-center justify-center sm:justify-start space-x-1">
              <Truck className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Drivers</span>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <TownRaceBar towns={townData} totalMembers={totalSignups} />
    </div>
  );
};

export default PreLaunchMeter;