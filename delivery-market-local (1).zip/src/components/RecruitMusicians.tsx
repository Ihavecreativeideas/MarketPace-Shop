import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Music, Guitar, Mic, Headphones, Share2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import MusicianShareFlyer from './MusicianShareFlyer';

const RecruitMusicians: React.FC = () => {
  const [showFlyer, setShowFlyer] = useState(false);
  const navigate = useNavigate();

  const handleShareWithMusicians = () => {
    setShowFlyer(true);
  };

  const handleJoinNow = () => {
    navigate('/musicians');
  };

  const handleShare = () => {
    const shareText = encodeURIComponent(
      "🎵 Join MarketPace Musicians! Rent/buy/sell equipment, hire talent, post events, and grow your local fan base! Upgrade to Pro for social media integration and merch sales. #Musicians #LocalMusic #MarketPace"
    );
    const shareUrl = encodeURIComponent(`${window.location.origin}/musicians`);
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}&quote=${shareText}`;
    window.open(facebookUrl, '_blank', 'width=600,height=400');
  };

  return (
    <>
      <div className="mt-8">
        <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="bg-white/20 rounded-full p-3">
                <Music className="h-8 w-8" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold">Recruit Musicians</CardTitle>
            <p className="text-white/90">
              Build a community of local artists and music enthusiasts
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-white/10 rounded-lg p-3">
                <Guitar className="h-6 w-6 mx-auto mb-2" />
                <p className="text-sm">Equipment</p>
              </div>
              <div className="bg-white/10 rounded-lg p-3">
                <Mic className="h-6 w-6 mx-auto mb-2" />
                <p className="text-sm">Gigs</p>
              </div>
              <div className="bg-white/10 rounded-lg p-3">
                <Headphones className="h-6 w-6 mx-auto mb-2" />
                <p className="text-sm">Community</p>
              </div>
            </div>
            <Button 
              onClick={handleShareWithMusicians}
              className="w-full bg-white text-purple-600 hover:bg-gray-100 font-semibold"
              size="lg"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Share with Musicians
            </Button>
          </CardContent>
        </Card>
      </div>

      <Dialog open={showFlyer} onOpenChange={setShowFlyer}>
        <DialogContent className="p-0 border-0 bg-transparent shadow-none max-w-md">
          <DialogHeader className="sr-only">
            <DialogTitle>Musician Recruitment Flyer</DialogTitle>
          </DialogHeader>
          <MusicianShareFlyer 
            onJoinNow={handleJoinNow}
            onShare={handleShare}
          />
        </DialogContent>
      </Dialog>
    </>
  );
};

export default RecruitMusicians;