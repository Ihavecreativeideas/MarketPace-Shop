import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Package, ArrowLeft, CheckCircle, Users } from 'lucide-react';
import DeliveryAcceptanceModal from './DeliveryAcceptanceModal';
import TipDriverModal from './TipDriverModal';
import RouteManager from './RouteManager';

interface DeliveryStop {
  id: string;
  type: 'pickup' | 'dropoff' | 'return';
  address: string;
  itemName: string;
  orderId: string;
  distance?: number;
}

interface Route {
  id: string;
  stops: DeliveryStop[];
  totalDistance: number;
  earnings: number;
}

const ReturnProcessingDemo = () => {
  const [showAcceptanceModal, setShowAcceptanceModal] = useState(false);
  const [showTipModal, setShowTipModal] = useState(false);
  const [currentAction, setCurrentAction] = useState<'accepted' | 'returned' | null>(null);
  const [isPartnerItem, setIsPartnerItem] = useState(false);
  const [routes, setRoutes] = useState<Route[]>([
    {
      id: 'route-1',
      stops: [
        { id: '1', type: 'pickup', address: '123 Store St', itemName: 'Wireless Headphones', orderId: 'ORD-001', distance: 2 },
        { id: '2', type: 'dropoff', address: '456 Home Ave', itemName: 'Wireless Headphones', orderId: 'ORD-001', distance: 3 }
      ],
      totalDistance: 5,
      earnings: 15.5
    }
  ]);
  const [returnFees, setReturnFees] = useState({ buyerFee: 0, driverEarnings: 0, isPartnerReturn: false });

  const handleAccept = () => {
    setCurrentAction('accepted');
    setShowTipModal(true);
  };

  const handleReturn = async (fees: { buyerFee: number; driverEarnings: number; isPartnerReturn: boolean }) => {
    setReturnFees(fees);
    setCurrentAction('returned');
    
    // Process return through backend
    try {
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/e89bc3b3-3a60-4932-b7a2-4f88a3a0dae4',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            orderId: 'ORD-001',
            buyerId: 'buyer-123',
            sellerId: 'seller-456',
            itemName: 'Wireless Headphones',
            pickupAddress: '456 Home Ave',
            returnAddress: '123 Store St',
            distance: 3,
            buyerFee: fees.buyerFee,
            driverEarnings: fees.driverEarnings,
            isPartnerReturn: fees.isPartnerReturn,
            returnReason: 'Not as expected'
          })
        }
      );
      
      const result = await response.json();
      
      if (result.success) {
        // Add return to route
        const returnStop: DeliveryStop = {
          id: result.returnId,
          type: 'return',
          address: '456 Home Ave → 123 Store St',
          itemName: `Wireless Headphones (${fees.isPartnerReturn ? 'Partner Return' : 'Return'})`,
          orderId: 'ORD-001',
          distance: 3
        };
        
        const updatedRoutes = routes.map(route => {
          if (route.id === 'route-1') {
            return {
              ...route,
              stops: [...route.stops, returnStop],
              totalDistance: route.totalDistance + 3,
              earnings: route.earnings + fees.driverEarnings
            };
          }
          return route;
        });
        
        setRoutes(updatedRoutes);
      }
    } catch (error) {
      console.error('Return processing failed:', error);
    }
    
    setShowTipModal(true);
  };

  const handleTipComplete = () => {
    setShowTipModal(false);
  };

  const handleRouteUpdate = (updatedRoutes: Route[]) => {
    setRoutes(updatedRoutes);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-bold">Return Processing Demo</h1>
        <p className="text-gray-600">
          Demonstrates return fee calculation with partner discounts and automatic route integration
        </p>
      </div>
      
      {/* Partner Item Toggle */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Demo Settings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <Switch
              id="partner-item"
              checked={isPartnerItem}
              onCheckedChange={setIsPartnerItem}
            />
            <Label htmlFor="partner-item">
              Simulate Partner Item (Special return pricing)
            </Label>
          </div>
          {isPartnerItem && (
            <p className="text-sm text-purple-600 mt-2">
              ✨ Partner items get free returns or 50% off, but drivers still receive full payment
            </p>
          )}
        </CardContent>
      </Card>
      
      {/* Delivery Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            Order Status
            {isPartnerItem && (
              <Badge className="bg-purple-100 text-purple-800">
                <Users className="w-3 h-3 mr-1" />
                Partner Item
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-green-50 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Order #ORD-001</h3>
                <p className="text-sm text-gray-600">Wireless Headphones</p>
                <p className="text-sm text-gray-500">Delivered to: 456 Home Ave</p>
                {isPartnerItem && (
                  <p className="text-sm text-purple-600 font-medium">Partner Store Item</p>
                )}
              </div>
              <Badge className="bg-green-600">
                <CheckCircle className="w-3 h-3 mr-1" />
                Delivered
              </Badge>
            </div>
          </div>
          
          {!currentAction && (
            <Button 
              onClick={() => setShowAcceptanceModal(true)}
              className="w-full"
            >
              Choose Accept or Return
            </Button>
          )}
          
          {currentAction === 'accepted' && (
            <div className="bg-blue-50 p-3 rounded-lg">
              <p className="text-blue-800 font-medium">✅ Item Accepted</p>
              <p className="text-sm text-blue-600">Thank you for your purchase!</p>
            </div>
          )}
          
          {currentAction === 'returned' && (
            <div className="bg-orange-50 p-3 rounded-lg">
              <p className="text-orange-800 font-medium">↩️ Return Requested</p>
              <div className="text-sm text-orange-600 space-y-1">
                <p>Buyer fee: ${returnFees.buyerFee.toFixed(2)}</p>
                <p>Driver earnings: ${returnFees.driverEarnings.toFixed(2)}</p>
                {returnFees.isPartnerReturn && (
                  <p className="text-purple-700 font-medium">
                    ✨ Partner return discount applied - Driver still gets full pay!
                  </p>
                )}
              </div>
              <p className="text-xs text-orange-500 mt-1">
                Return has been automatically added to delivery route
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Route Management */}
      <RouteManager 
        routes={routes}
        onRouteUpdate={handleRouteUpdate}
        maxPickupsPerRoute={5}
      />
      
      {/* Return Processing Rules */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ArrowLeft className="w-5 h-5" />
            Return Processing Rules
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium">Standard Returns</h4>
              <ul className="text-sm space-y-1">
                <li>• Base return fee: $3.00</li>
                <li>• Distance fee: $1.00 per mile</li>
                <li>• Buyer pays full cost</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-purple-700">Partner Returns</h4>
              <ul className="text-sm space-y-1">
                <li>• Free return option</li>
                <li>• 50% off return option</li>
                <li>• Driver still gets full pay</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium">Driver Earnings</h4>
              <ul className="text-sm space-y-1">
                <li>• Base pay: $2.00</li>
                <li>• Mileage: $0.75 per mile</li>
                <li>• Max 5 pickups per route</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Modals */}
      <DeliveryAcceptanceModal
        isOpen={showAcceptanceModal}
        onClose={() => setShowAcceptanceModal(false)}
        onAccept={handleAccept}
        onReturn={handleReturn}
        itemName="Wireless Headphones"
        orderId="ORD-001"
        deliveryDistance={3}
        isPartnerItem={isPartnerItem}
      />
      
      <TipDriverModal
        isOpen={showTipModal}
        onClose={handleTipComplete}
        driverName="Mike Johnson"
        orderTotal={29.99}
        userType="buyer"
      />
    </div>
  );
};

export default ReturnProcessingDemo;