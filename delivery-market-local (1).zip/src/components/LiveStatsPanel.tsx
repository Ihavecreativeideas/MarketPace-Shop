import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Users, MapPin, MessageSquare, TrendingUp, Activity, Zap, Globe, ShoppingCart } from 'lucide-react';

interface LiveStatsPanelProps {
  stats: {
    totalUsers: number;
    activeUsers: number;
    totalTowns: number;
    totalDrivers: number;
    totalBusinesses: number;
    totalDeliveries: number;
  };
}

export default function LiveStatsPanel({ stats }: LiveStatsPanelProps) {
  const [liveData, setLiveData] = useState({
    onlineUsers: 0,
    activeDeliveries: 0,
    systemHealth: 98,
    serverLoad: 45,
    responseTime: 120,
    ordersToday: 0
  });

  useEffect(() => {
    // Simulate real-time data updates
    const interval = setInterval(() => {
      setLiveData(prev => ({
        onlineUsers: Math.floor(Math.random() * 100) + 50,
        activeDeliveries: Math.floor(Math.random() * 25) + 5,
        systemHealth: Math.floor(Math.random() * 5) + 95,
        serverLoad: Math.floor(Math.random() * 30) + 30,
        responseTime: Math.floor(Math.random() * 50) + 100,
        ordersToday: Math.floor(Math.random() * 200) + 150
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="mb-6">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <Activity className="h-6 w-6 text-green-500" />
        Live Statistics
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
              <div className="flex items-center">
                <Users className="h-4 w-4 mr-2 text-green-500" />
                Total Users
              </div>
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                Live
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.totalUsers}</div>
            <div className="text-xs text-muted-foreground">Online: {liveData.onlineUsers}</div>
            <Progress value={(liveData.onlineUsers / stats.totalUsers) * 100} className="mt-2" />
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
              <div className="flex items-center">
                <MapPin className="h-4 w-4 mr-2 text-blue-500" />
                Drivers
              </div>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                Active
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.totalDrivers}</div>
            <div className="text-xs text-muted-foreground">Delivering: {liveData.activeDeliveries}</div>
            <Progress value={(liveData.activeDeliveries / stats.totalDrivers) * 100} className="mt-2" />
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
              <div className="flex items-center">
                <MessageSquare className="h-4 w-4 mr-2 text-purple-500" />
                Businesses
              </div>
              <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                Open
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{stats.totalBusinesses}</div>
            <div className="text-xs text-muted-foreground">Active: {Math.floor(stats.totalBusinesses * 0.8)}</div>
            <Progress value={80} className="mt-2" />
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
              <div className="flex items-center">
                <ShoppingCart className="h-4 w-4 mr-2 text-orange-500" />
                Orders Today
              </div>
              <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                Real-time
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{liveData.ordersToday}</div>
            <div className="text-xs text-muted-foreground">Total: {stats.totalDeliveries}</div>
            <Progress value={(liveData.ordersToday / stats.totalDeliveries) * 100} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* System Health */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-500" />
              System Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{liveData.systemHealth}%</div>
            <Progress value={liveData.systemHealth} className="mt-2" />
            <div className="text-xs text-muted-foreground mt-1">Excellent</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-blue-500" />
              Server Load
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{liveData.serverLoad}%</div>
            <Progress value={liveData.serverLoad} className="mt-2" />
            <div className="text-xs text-muted-foreground mt-1">Optimal</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-500" />
              Response Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{liveData.responseTime}ms</div>
            <Progress value={100 - (liveData.responseTime / 10)} className="mt-2" />
            <div className="text-xs text-muted-foreground mt-1">Fast</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}