import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { PurpleParticleBackground } from './PurpleParticleBackground';
import { FloatingBottomNavigation } from './FloatingBottomNavigation';
import { UniversalBackButton } from './UniversalBackButton';
import { BoxProductCard } from './BoxProductCard';
import { RentalCheckout } from './RentalCheckout';
import { BookingPage } from './BookingPage';
import { RentalRequestPage } from './RentalRequestPage';
import { FacebookInviteFixed } from './FacebookInviteFixed';

const UpdatedApp: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-indigo-900 to-purple-900 relative">
        <PurpleParticleBackground />
        
        <div className="relative z-10">
          <Routes>
            <Route path="/" element={
              <div className="p-4">
                <div className="max-w-7xl mx-auto">
                  <div className="mb-8">
                    <UniversalBackButton />
                    <h1 className="text-4xl font-bold text-white mt-4 mb-2">MarketPace</h1>
                    <p className="text-gray-300">Your local marketplace and community</p>
                  </div>
                  
                  <div className="mb-8">
                    <FacebookInviteFixed />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <BoxProductCard
                      id="1"
                      title="Professional Camera"
                      price={25}
                      location="Downtown"
                      isRental={true}
                      isAvailable={true}
                      rating={4.8}
                      onRent={() => console.log('Rent camera')}
                    />
                    
                    <BoxProductCard
                      id="2"
                      title="Vintage Guitar"
                      price={150}
                      location="Midtown"
                      isRental={false}
                      isAvailable={true}
                      rating={4.9}
                      onBuy={() => console.log('Buy guitar')}
                    />
                    
                    <BoxProductCard
                      id="3"
                      title="Power Drill Set"
                      price={15}
                      location="Suburbs"
                      isRental={true}
                      isAvailable={false}
                      rating={4.5}
                      onRent={() => console.log('Rent drill')}
                    />
                    
                    <BoxProductCard
                      id="4"
                      title="DJ Equipment"
                      price={75}
                      location="City Center"
                      isRental={true}
                      isAvailable={true}
                      rating={4.7}
                      onRent={() => console.log('Rent DJ equipment')}
                    />
                  </div>
                </div>
              </div>
            } />
            
            <Route path="/marketplace" element={
              <div className="p-4">
                <div className="max-w-7xl mx-auto">
                  <div className="mb-8">
                    <UniversalBackButton />
                    <h1 className="text-4xl font-bold text-white mt-4">Marketplace</h1>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <BoxProductCard
                      id="5"
                      title="Laptop Stand"
                      price={45}
                      location="Tech District"
                      isRental={false}
                      isAvailable={true}
                      rating={4.6}
                      onBuy={() => console.log('Buy laptop stand')}
                    />
                    
                    <BoxProductCard
                      id="6"
                      title="Wedding Decorations"
                      price={30}
                      location="Wedding District"
                      isRental={true}
                      isAvailable={true}
                      rating={4.9}
                      onRent={() => console.log('Rent decorations')}
                    />
                  </div>
                </div>
              </div>
            } />
            
            <Route path="/entertainment" element={
              <div className="p-4">
                <div className="max-w-7xl mx-auto">
                  <div className="mb-8">
                    <UniversalBackButton />
                    <h1 className="text-4xl font-bold text-white mt-4">Entertainment</h1>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl rounded-lg p-6">
                      <h3 className="text-white font-semibold text-xl mb-2">Live DJ Services</h3>
                      <p className="text-gray-300 mb-4">Professional DJ for your events</p>
                      <div className="flex justify-between items-center">
                        <span className="text-green-400 font-bold text-lg">$200/event</span>
                        <button 
                          onClick={() => console.log('Book DJ')}
                          className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-4 py-2 rounded-lg"
                        >
                          Book Now
                        </button>
                      </div>
                    </div>
                    
                    <div className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl rounded-lg p-6">
                      <h3 className="text-white font-semibold text-xl mb-2">Wedding Photography</h3>
                      <p className="text-gray-300 mb-4">Capture your special moments</p>
                      <div className="flex justify-between items-center">
                        <span className="text-green-400 font-bold text-lg">$500/day</span>
                        <button 
                          onClick={() => console.log('Book photographer')}
                          className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-4 py-2 rounded-lg"
                        >
                          Book Now
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            } />
            
            <Route path="/community" element={
              <div className="p-4">
                <div className="max-w-4xl mx-auto">
                  <div className="mb-8">
                    <UniversalBackButton />
                    <h1 className="text-4xl font-bold text-white mt-4">Community</h1>
                  </div>
                  
                  <div className="space-y-6">
                    <div className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl rounded-lg p-6">
                      <h3 className="text-white font-semibold text-lg mb-2">Welcome to MarketPace Community!</h3>
                      <p className="text-gray-300">Connect with your neighbors, share resources, and build stronger local connections.</p>
                    </div>
                    
                    <div className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl rounded-lg p-6">
                      <h3 className="text-white font-semibold text-lg mb-2">Local Events</h3>
                      <p className="text-gray-300">Stay updated on community events and gatherings in your area.</p>
                    </div>
                  </div>
                </div>
              </div>
            } />
            
            <Route path="/search" element={
              <div className="p-4">
                <div className="max-w-4xl mx-auto">
                  <div className="mb-8">
                    <UniversalBackButton />
                    <h1 className="text-4xl font-bold text-white mt-4">Search</h1>
                  </div>
                  
                  <div className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl rounded-lg p-6">
                    <input 
                      type="text" 
                      placeholder="Search for items, services, or people..."
                      className="w-full bg-white/10 border-white/20 text-white placeholder:text-gray-400 rounded-lg px-4 py-3"
                    />
                  </div>
                </div>
              </div>
            } />
            
            <Route path="/events" element={
              <div className="p-4">
                <div className="max-w-4xl mx-auto">
                  <div className="mb-8">
                    <UniversalBackButton />
                    <h1 className="text-4xl font-bold text-white mt-4">Events</h1>
                  </div>
                  
                  <div className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl rounded-lg p-6">
                    <p className="text-gray-300">Discover local events and activities in your community.</p>
                  </div>
                </div>
              </div>
            } />
            
            <Route path="/delivery" element={
              <div className="p-4">
                <div className="max-w-4xl mx-auto">
                  <div className="mb-8">
                    <UniversalBackButton />
                    <h1 className="text-4xl font-bold text-white mt-4">Delivery</h1>
                  </div>
                  
                  <div className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl rounded-lg p-6">
                    <p className="text-gray-300">Track your deliveries and manage pickup options.</p>
                  </div>
                </div>
              </div>
            } />
            
            <Route path="/profile" element={
              <div className="p-4">
                <div className="max-w-4xl mx-auto">
                  <div className="mb-8">
                    <UniversalBackButton />
                    <h1 className="text-4xl font-bold text-white mt-4">Profile</h1>
                  </div>
                  
                  <div className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl rounded-lg p-6">
                    <p className="text-gray-300">Manage your profile, listings, and account settings.</p>
                  </div>
                </div>
              </div>
            } />
          </Routes>
        </div>
        
        <FloatingBottomNavigation />
      </div>
    </Router>
  );
};

export default UpdatedApp;
export { UpdatedApp };