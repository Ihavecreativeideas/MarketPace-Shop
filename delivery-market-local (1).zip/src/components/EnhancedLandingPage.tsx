import React from 'react';
import { LaunchMeter } from './LaunchMeter';
import { DualProfileSignup } from './DualProfileSignup';
import { FacebookInvite } from './FacebookInvite';
import { FloatingNavBar } from './FloatingNavBar';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, Store, Music, Wrench, Truck, Star, Shield, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

export const EnhancedLandingPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Hero Section with Launch Meter */}
      <div className="pt-8 pb-12 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Main Header */}
          <div className="text-center mb-8">
            <h1 className="text-6xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              MarketPace
            </h1>
            <p className="text-2xl text-gray-300 mb-6">
              "You set the pace, we make it happen."
            </p>
            <p className="text-lg text-gray-400">
              Your local marketplace for everything - buy, sell, rent, hire, and connect with your community
            </p>
          </div>

          {/* Launch Meter */}
          <div className="mb-8">
            <LaunchMeter />
          </div>

          {/* Facebook Invite Section */}
          <div className="mb-8">
            <FacebookInvite />
          </div>
        </div>
      </div>

      {/* Signup Section */}
      <div className="px-4 pb-12">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          {/* Signup Form */}
          <div>
            <DualProfileSignup />
          </div>

          {/* Features Highlight */}
          <div className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-white mb-4">🎭 Entertainment Industry Hub</h3>
                <ul className="text-gray-300 space-y-2 text-sm">
                  <li>• Musicians, DJs, bands, comedians, theater performers</li>
                  <li>• Upload music, sell tracks, rent equipment</li>
                  <li>• List services with pricing tiers ($-$$$$)</li>
                  <li>• Event calendar and booking system</li>
                  <li>• Direct messaging for gigs and collaborations</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-white mb-4">🛻 Smart Delivery System</h3>
                <ul className="text-gray-300 space-y-2 text-sm">
                  <li>• Routes every 3 hours (9am-9pm daily)</li>
                  <li>• $4 pickup + $2 dropoff + $0.50/mile</li>
                  <li>• Urgent delivery: +$5 fee, +$3 driver bonus</li>
                  <li>• Color-coded mission map for drivers</li>
                  <li>• Ship anywhere via UPS handoff</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-white mb-4">🏪 Business Integration</h3>
                <ul className="text-gray-300 space-y-2 text-sm">
                  <li>• Import products from Shopify, WooCommerce</li>
                  <li>• Facebook Marketplace auto-reply integration</li>
                  <li>• Community-first, no hidden fees during launch</li>
                  <li>• Professional service listings and hiring</li>
                  <li>• "Rent Anything" with contract uploads</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Quick Access Cards */}
      <div className="px-4 pb-12">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-white mb-8">Explore MarketPace</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Link to="/shops">
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all cursor-pointer h-full">
                <CardContent className="p-6 text-center">
                  <Store className="w-12 h-12 mx-auto mb-4 text-blue-400" />
                  <h3 className="text-lg font-semibold text-white mb-2">Local Shops</h3>
                  <p className="text-gray-300 text-sm">Discover local businesses and products</p>
                </CardContent>
              </Card>
            </Link>
            
            <Link to="/entertainment">
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all cursor-pointer h-full">
                <CardContent className="p-6 text-center">
                  <Music className="w-12 h-12 mx-auto mb-4 text-purple-400" />
                  <h3 className="text-lg font-semibold text-white mb-2">Entertainment</h3>
                  <p className="text-gray-300 text-sm">Musicians, DJs, performers for hire</p>
                </CardContent>
              </Card>
            </Link>
            
            <Link to="/services">
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all cursor-pointer h-full">
                <CardContent className="p-6 text-center">
                  <Wrench className="w-12 h-12 mx-auto mb-4 text-green-400" />
                  <h3 className="text-lg font-semibold text-white mb-2">Services</h3>
                  <p className="text-gray-300 text-sm">Hire local professionals</p>
                </CardContent>
              </Card>
            </Link>
            
            <Link to="/driver-application">
              <Card className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all cursor-pointer h-full">
                <CardContent className="p-6 text-center">
                  <Truck className="w-12 h-12 mx-auto mb-4 text-orange-400" />
                  <h3 className="text-lg font-semibold text-white mb-2">Drive for Us</h3>
                  <p className="text-gray-300 text-sm">Earn money with flexible delivery</p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </div>

      {/* Community Promise */}
      <div className="bg-white/5 backdrop-blur-sm py-12">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl font-bold text-white mb-6">Community First. Always.</h2>
          <p className="text-lg text-gray-300 mb-8">
            MarketPace is committed to creating jobs and growing local economies. 
            During our launch campaign, all features are free. Members only pay drivers. 
            No hidden fees. No upcharges.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <Star className="w-8 h-8 mx-auto mb-3 text-yellow-400" />
              <h3 className="font-semibold text-white mb-2">Quality First</h3>
              <p className="text-sm text-gray-300">Vetted drivers and verified businesses</p>
            </div>
            <div className="text-center">
              <Shield className="w-8 h-8 mx-auto mb-3 text-green-400" />
              <h3 className="font-semibold text-white mb-2">Secure & Safe</h3>
              <p className="text-sm text-gray-300">Protected transactions and privacy</p>
            </div>
            <div className="text-center">
              <Clock className="w-8 h-8 mx-auto mb-3 text-blue-400" />
              <h3 className="font-semibold text-white mb-2">Fast Delivery</h3>
              <p className="text-sm text-gray-300">Same-day local delivery service</p>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Navigation */}
      <FloatingNavBar />
    </div>
  );
};