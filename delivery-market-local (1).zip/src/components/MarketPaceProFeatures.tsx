import { Badge } from '@/components/ui/badge';
import { Check, Crown, Star } from 'lucide-react';

interface FeatureItemProps {
  feature: string;
  isPro?: boolean;
}

const FeatureItem: React.FC<FeatureItemProps> = ({ feature, isPro }) => (
  <div className="flex items-start gap-2">
    <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
    <span className={`text-sm ${isPro ? 'font-medium' : ''}`}>
      {feature}
      {isPro && (
        <Badge className="ml-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs px-2 py-0.5">
          <Crown className="w-3 h-3 mr-1" />
          Pro
        </Badge>
      )}
    </span>
  </div>
);

const MarketPaceProFeatures: React.FC = () => {
  const features = [
    { text: 'Website integration included', pro: true },
    { text: 'Platform to promote your business', pro: false },
    { text: 'Multiple delivery options', pro: true },
    { text: 'Social media integration tools', pro: false },
    { text: 'Analytics and performance insights', pro: true },
    { text: 'Customer messaging system', pro: false },
    { text: 'Inventory management tools', pro: false },
    { text: 'Promotional advantages & marketing tools', pro: true },
    { text: 'Discounted delivery fees', pro: true },
    { text: 'Priority delivery day shipping', pro: true },
    { text: 'Business of the month spotlight eligibility', pro: true },
    { text: 'Ability to set your own S&H fees', pro: true },
    { text: 'Free returns processing', pro: true },
    { text: 'Priority customer support', pro: false },
    { text: 'Mobile app access for business management', pro: false }
  ];

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div>
        <h4 className="font-semibold mb-4 flex items-center gap-2">
          <Check className="w-5 h-5 text-green-600" />
          Standard Features:
        </h4>
        <div className="space-y-3">
          {features.filter(f => !f.pro).map((feature, index) => (
            <FeatureItem key={index} feature={feature.text} isPro={false} />
          ))}
        </div>
      </div>
      
      <div>
        <h4 className="font-semibold mb-4 flex items-center gap-2">
          <Star className="w-5 h-5 text-purple-600" />
          MarketPace Pro Features:
        </h4>
        <div className="space-y-3">
          {features.filter(f => f.pro).map((feature, index) => (
            <FeatureItem key={index} feature={feature.text} isPro={true} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default MarketPaceProFeatures;