import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Package, DollarSign, Shield, CheckCircle, XCircle, Star, Heart } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

const MarketplaceOrderDemo: React.FC = () => {
  const [orderStatus, setOrderStatus] = useState<'delivered' | 'accepted' | 'returned'>('delivered');
  const [showAcceptModal, setShowAcceptModal] = useState(false);
  const [showTipModal, setShowTipModal] = useState(false);
  const [selectedAction, setSelectedAction] = useState<'accept' | 'return' | null>(null);
  const [tip, setTip] = useState('');
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [userType, setUserType] = useState<'buyer' | 'seller'>('buyer');

  const handleAccept = () => {
    setOrderStatus('accepted');
    setSelectedAction('accept');
    setShowAcceptModal(false);
    setTimeout(() => setShowTipModal(true), 500);
  };

  const handleReturn = () => {
    setOrderStatus('returned');
    setSelectedAction('return');
    setShowAcceptModal(false);
    setTimeout(() => setShowTipModal(true), 500);
  };

  const handleTipSubmit = () => {
    console.log('Tip submitted:', { tip, rating, review, userType, action: selectedAction });
    setShowTipModal(false);
    setTip('');
    setRating(0);
    setReview('');
  };

  const resetDemo = () => {
    setOrderStatus('delivered');
    setSelectedAction(null);
    setShowAcceptModal(false);
    setShowTipModal(false);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 p-4">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold">MarketPace Delivery Flow Demo</h2>
        <p className="text-gray-600">Experience the new accept/return and tipping system</p>
        <div className="flex gap-2 justify-center">
          <Button 
            variant={userType === 'buyer' ? 'default' : 'outline'}
            onClick={() => setUserType('buyer')}
            size="sm"
          >
            View as Buyer
          </Button>
          <Button 
            variant={userType === 'seller' ? 'default' : 'outline'}
            onClick={() => setUserType('seller')}
            size="sm"
          >
            View as Seller
          </Button>
          <Button onClick={resetDemo} variant="outline" size="sm">
            Reset Demo
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            Handcrafted Ceramic Mug
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Item Price:</span>
              <p className="font-semibold">$24.99</p>
            </div>
            <div>
              <span className="text-gray-600">Delivery Fee:</span>
              <p className="font-semibold">$8.00</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-2">
            <h4 className="font-medium flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Delivery Cost Split
            </h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className={`p-2 rounded ${userType === 'buyer' ? 'bg-blue-50' : 'bg-gray-50'}`}>
                <span className="text-gray-600">Buyer Pays:</span>
                <p className="font-semibold">$4.00</p>
              </div>
              <div className={`p-2 rounded ${userType === 'seller' ? 'bg-green-50' : 'bg-gray-50'}`}>
                <span className="text-gray-600">Seller Pays:</span>
                <p className="font-semibold">$4.00</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-blue-600 bg-blue-50 p-2 rounded">
            <Shield className="w-4 h-4" />
            <span>MarketPace covers all return costs</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg">Order #MP-12345</CardTitle>
            <Badge className={orderStatus === 'delivered' ? 'border-orange-500 text-orange-600' : orderStatus === 'accepted' ? 'bg-green-500' : 'bg-red-500'}>
              {orderStatus === 'delivered' ? 'Delivered - Action Required' : orderStatus === 'accepted' ? 'Accepted' : 'Returned'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {orderStatus === 'delivered' && userType === 'buyer' && (
            <div className="space-y-4">
              <p className="text-sm text-gray-600">
                Your item has been delivered. Please choose an action:
              </p>
              <Button onClick={() => setShowAcceptModal(true)} className="w-full">
                <Package className="w-4 h-4 mr-2" />
                Review Delivery
              </Button>
            </div>
          )}
          
          {orderStatus === 'delivered' && userType === 'seller' && (
            <div className="space-y-2">
              <p className="text-sm text-gray-600">
                Your item has been delivered to the buyer.
              </p>
              <Button onClick={() => setShowTipModal(true)} variant="outline" className="w-full">
                <Star className="w-4 h-4 mr-2" />
                Tip Driver
              </Button>
            </div>
          )}
          
          {(orderStatus === 'accepted' || orderStatus === 'returned') && (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                {orderStatus === 'accepted' ? (
                  <CheckCircle className="w-4 h-4 text-green-600" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-600" />
                )}
                <span className="text-sm">
                  {orderStatus === 'accepted' ? 'Item accepted successfully!' : 'Item returned successfully!'}
                </span>
              </div>
              <Button onClick={() => setShowTipModal(true)} variant="outline" size="sm">
                <Star className="w-4 h-4 mr-2" />
                Tip Driver
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Accept/Return Modal */}
      <Dialog open={showAcceptModal} onOpenChange={setShowAcceptModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="w-5 h-5" />
              Item Delivered - Action Required
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-green-50 p-3 rounded-lg">
              <p className="text-sm text-green-800"><strong>Order #MP-12345</strong></p>
              <p className="text-sm text-green-700 mt-1">Handcrafted Ceramic Mug</p>
              <Badge className="bg-green-600 mt-2">Delivered Successfully</Badge>
            </div>
            
            <div className="space-y-3">
              <p className="text-sm text-gray-600">Please choose whether to accept or return this item:</p>
              
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start" onClick={handleAccept}>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Accept Item - I'm satisfied with my order
                </Button>
                
                <Button variant="outline" className="w-full justify-start" onClick={handleReturn}>
                  <XCircle className="w-4 h-4 mr-2" />
                  Return Item - Not as expected
                </Button>
              </div>
            </div>
            
            <div className="bg-yellow-50 p-3 rounded-lg">
              <p className="text-xs text-yellow-800">
                <strong>Note:</strong> After making your choice, you'll have the option to tip your driver.
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Tip Modal */}
      <Dialog open={showTipModal} onOpenChange={setShowTipModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-red-500" />
              Tip Your Driver
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-blue-50 p-3 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-4 h-4 text-blue-600" />
                <span className="font-medium text-blue-900">Show Your Appreciation</span>
              </div>
              <p className="text-sm text-blue-800">
                {userType === 'buyer' 
                  ? selectedAction === 'return' 
                    ? 'Your driver handled the delivery professionally, even though you returned the item.'
                    : 'Your driver successfully delivered your item!'
                  : 'Your driver successfully delivered your item to the buyer!'}
              </p>
              <p className="text-xs text-blue-700 mt-1">Tips go 100% to your driver!</p>
            </div>
            
            <div>
              <Label className="text-sm font-medium">Tip Amount (Optional)</Label>
              <div className="flex gap-2 mt-2">
                {[2, 3, 5, 8].map((amount) => (
                  <Button
                    key={amount}
                    variant={tip === amount.toString() ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setTip(amount.toString())}
                  >
                    ${amount}
                  </Button>
                ))}
              </div>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-sm">$</span>
                <Input
                  type="number"
                  placeholder="Custom amount"
                  value={tip}
                  onChange={(e) => setTip(e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
            
            <div>
              <Label className="text-sm font-medium">Rate Your Driver (Optional)</Label>
              <div className="flex gap-1 mt-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setRating(star)}
                    className="p-1"
                  >
                    <Star
                      className={`w-6 h-6 ${
                        star <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <Label htmlFor="review" className="text-sm font-medium">Review (Optional)</Label>
              <Textarea
                id="review"
                placeholder="Share your experience..."
                value={review}
                onChange={(e) => setReview(e.target.value)}
                className="mt-2"
                rows={3}
              />
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowTipModal(false)} className="flex-1">
                Skip for Now
              </Button>
              <Button onClick={handleTipSubmit} className="flex-1">
                {tip || rating || review ? 'Submit' : 'No Tip'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MarketplaceOrderDemo;