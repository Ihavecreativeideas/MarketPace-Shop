import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Package, Truck, MapPin, Clock, DollarSign, CheckCircle } from 'lucide-react';
import { useState } from 'react';
import PostPaceScheduler from './PostPaceScheduler';
import PostPaceNonLocalPurchase from './PostPaceNonLocalPurchase';

const PostPace: React.FC = () => {
  const [activeTab, setActiveTab] = useState('local');

  const handleSchedulePickup = (data: any) => {
    console.log('Scheduled pickup:', data);
    // Handle local pickup scheduling
  };

  const handleNonLocalPurchase = (data: any) => {
    console.log('Non-local purchase:', data);
    // Handle non-local purchase request
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-orange-100 rounded-full mb-6">
            <Package className="w-10 h-10 text-orange-600" />
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">PostPace</h1>
          <p className="text-xl text-gray-600 mb-6">
            Package pickup and drop-off service for all your shipping needs
          </p>
          <div className="mt-4 p-4 bg-orange-50 rounded-lg">
            <p className="text-orange-800 font-semibold">Same delivery charge as regular marketplace items</p>
          </div>
        </div>

        {/* How It Works */}
        <Card className="mb-8 shadow-lg">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              How PostPace Works
            </h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-4">
                <Package className="w-12 h-12 text-orange-600 mx-auto mb-4" />
                <h4 className="font-semibold text-gray-900 mb-2">1. Schedule Pickup</h4>
                <p className="text-gray-600 text-sm">Schedule a pickup time and choose your preferred drop-off service (FedEx, UPS, USPS).</p>
              </div>
              <div className="text-center p-4">
                <Truck className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                <h4 className="font-semibold text-gray-900 mb-2">2. Driver Pickup</h4>
                <p className="text-gray-600 text-sm">Our verified driver picks up your package from your location or seller's address.</p>
              </div>
              <div className="text-center p-4">
                <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h4 className="font-semibold text-gray-900 mb-2">3. Drop-off Complete</h4>
                <p className="text-gray-600 text-sm">Package is dropped off at your chosen shipping service for final delivery.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Service Options */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="local">Local Package Pickup</TabsTrigger>
            <TabsTrigger value="nonlocal">Non-Local Item Purchase</TabsTrigger>
          </TabsList>
          
          <TabsContent value="local" className="mt-6">
            <PostPaceScheduler onSchedule={handleSchedulePickup} />
          </TabsContent>
          
          <TabsContent value="nonlocal" className="mt-6">
            <PostPaceNonLocalPurchase onPurchase={handleNonLocalPurchase} />
          </TabsContent>
        </Tabs>

        {/* Pricing Info */}
        <Card className="mb-8 shadow-lg">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              Pricing Information
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-blue-50 p-6 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-3 flex items-center">
                  <MapPin className="w-5 h-5 mr-2" />
                  Local Pickup & Drop-off
                </h4>
                <p className="text-blue-800 mb-2">Same as regular marketplace delivery charge</p>
                <ul className="text-blue-700 text-sm space-y-1">
                  <li>• Pick up from your location</li>
                  <li>• Drop off at FedEx, UPS, or USPS</li>
                  <li>• Real-time tracking</li>
                </ul>
              </div>
              
              <div className="bg-green-50 p-6 rounded-lg">
                <h4 className="font-semibold text-green-900 mb-3 flex items-center">
                  <Truck className="w-5 h-5 mr-2" />
                  Non-Local Purchase
                </h4>
                <p className="text-green-800 mb-2">Delivery fee + shipping cost</p>
                <ul className="text-green-700 text-sm space-y-1">
                  <li>• Pick up from seller in other towns</li>
                  <li>• Drop off at shipping service</li>
                  <li>• Includes postal service shipping</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <p className="text-gray-600 mb-4">Connecting your packages to the world</p>
          <div className="inline-flex items-center space-x-2 text-orange-600">
            <Package className="w-5 h-5" />
            <span className="font-medium">Fast, reliable package delivery service</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostPace;