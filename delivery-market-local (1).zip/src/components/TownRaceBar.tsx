import React from 'react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Trophy, Users } from 'lucide-react';

interface TownData {
  name: string;
  members: number;
  color: string;
  position: number;
}

interface TownRaceBarProps {
  towns: TownData[];
  totalMembers: number;
}

const TownRaceBar: React.FC<TownRaceBarProps> = ({ towns, totalMembers }) => {
  const maxMembers = Math.max(...towns.map(t => t.members));
  const sortedTowns = [...towns].sort((a, b) => b.members - a.members);

  return (
    <Card className="bg-gradient-to-r from-blue-500 to-purple-500 text-white mb-4">
      <CardContent className="p-4">
        <div className="flex items-center justify-center mb-3">
          <Trophy className="w-5 h-5 mr-2" />
          <h3 className="font-bold text-lg">Town Race to Launch</h3>
        </div>
        
        <div className="space-y-2">
          {sortedTowns.map((town, index) => {
            const percentage = maxMembers > 0 ? (town.members / maxMembers) * 100 : 0;
            const isLeader = index === 0;
            
            return (
              <div key={town.name} className="relative">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center space-x-2">
                    <Badge 
                      variant={isLeader ? "default" : "secondary"}
                      className={`${isLeader ? 'bg-yellow-500 text-black' : 'bg-white/20'} text-xs`}
                    >
                      #{index + 1}
                    </Badge>
                    <span className="font-medium text-sm">{town.name}</span>
                    {isLeader && <Trophy className="w-4 h-4 text-yellow-300" />}
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="w-3 h-3" />
                    <span className="text-sm font-bold">{town.members}</span>
                  </div>
                </div>
                
                <div className="w-full bg-white/20 rounded-full h-2 relative overflow-hidden">
                  <div 
                    className={`h-full ${town.color} transition-all duration-500 ease-out rounded-full`}
                    style={{ width: `${percentage}%` }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse"></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-3 text-center text-sm opacity-90">
          <span className="font-medium">{totalMembers} total members</span> • 
          <span>Leading town gets special launch perks!</span>
        </div>
      </CardContent>
    </Card>
  );
};

export default TownRaceBar;