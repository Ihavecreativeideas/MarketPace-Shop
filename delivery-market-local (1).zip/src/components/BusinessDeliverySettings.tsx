import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Truck, DollarSign, Settings, Users, Clock } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function BusinessDeliverySettings() {
  const [useOwnDelivery, setUseOwnDelivery] = useState(false);
  const [deliveryFeeStructure, setDeliveryFeeStructure] = useState('split');
  const [shippingFee, setShippingFee] = useState('5.99');
  const [handlingFee, setHandlingFee] = useState('2.99');
  const [additionalFees, setAdditionalFees] = useState('');
  const [deliveryRadius, setDeliveryRadius] = useState('10');
  const [deliveryTimes, setDeliveryTimes] = useState({
    sameDay: true,
    nextDay: true,
    scheduled: true
  });

  const handleSaveSettings = () => {
    const settings = {
      useOwnDelivery,
      deliveryFeeStructure,
      shippingFee: parseFloat(shippingFee),
      handlingFee: parseFloat(handlingFee),
      additionalFees,
      deliveryRadius: parseInt(deliveryRadius),
      deliveryTimes
    };
    
    // Save to backend
    console.log('Saving delivery settings:', settings);
    toast({ title: "Delivery settings saved successfully!" });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck className="h-5 w-5" />
            Delivery Service Configuration
          </CardTitle>
          <CardDescription>
            Configure your delivery options and integrate with existing services
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Delivery Service Choice */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-base font-medium">Use Your Own Delivery Service</Label>
                <p className="text-sm text-gray-600">
                  Connect your existing delivery infrastructure
                </p>
              </div>
              <Switch
                checked={useOwnDelivery}
                onCheckedChange={setUseOwnDelivery}
              />
            </div>

            {useOwnDelivery && (
              <div className="bg-blue-50 p-4 rounded-lg space-y-3">
                <h4 className="font-medium text-blue-800">Delivery Service Integration</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>API Endpoint</Label>
                    <Input placeholder="https://api.yourdelivery.com" />
                  </div>
                  <div>
                    <Label>API Key</Label>
                    <Input type="password" placeholder="Your API key" />
                  </div>
                </div>
                <p className="text-sm text-blue-700">
                  We'll integrate with your existing delivery system while providing a unified local platform experience.
                </p>
              </div>
            )}
          </div>

          {/* Fee Structure */}
          <div className="space-y-4">
            <Label className="text-base font-medium">Delivery Fee Structure</Label>
            <RadioGroup value={deliveryFeeStructure} onValueChange={setDeliveryFeeStructure}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="split" id="split" />
                <Label htmlFor="split">Split delivery fee with buyer (50/50)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="seller-pays" id="seller-pays" />
                <Label htmlFor="seller-pays">Pass entire delivery fee to seller</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="business-absorb" id="business-absorb" />
                <Label htmlFor="business-absorb">Business absorbs delivery costs</Label>
              </div>
            </RadioGroup>
            
            {deliveryFeeStructure === 'split' && (
              <div className="bg-gray-50 p-3 rounded text-sm">
                <Users className="h-4 w-4 inline mr-1" />
                Regular marketplace members automatically split fees 50/50 between buyer and seller
              </div>
            )}
          </div>

          {/* Shipping & Handling Fees */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Base Shipping Fee ($)</Label>
              <Input
                type="number"
                step="0.01"
                value={shippingFee}
                onChange={(e) => setShippingFee(e.target.value)}
                placeholder="5.99"
              />
            </div>
            <div>
              <Label>Handling Fee ($)</Label>
              <Input
                type="number"
                step="0.01"
                value={handlingFee}
                onChange={(e) => setHandlingFee(e.target.value)}
                placeholder="2.99"
              />
            </div>
            <div>
              <Label>Additional Fees ($)</Label>
              <Input
                type="number"
                step="0.01"
                value={additionalFees}
                onChange={(e) => setAdditionalFees(e.target.value)}
                placeholder="0.00"
              />
            </div>
          </div>

          {/* Delivery Options */}
          <div className="space-y-4">
            <Label className="text-base font-medium">Delivery Options</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Delivery Radius (miles)</Label>
                <Select value={deliveryRadius} onValueChange={setDeliveryRadius}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 miles</SelectItem>
                    <SelectItem value="10">10 miles</SelectItem>
                    <SelectItem value="15">15 miles</SelectItem>
                    <SelectItem value="25">25 miles</SelectItem>
                    <SelectItem value="50">50 miles</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Available Delivery Times</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={deliveryTimes.sameDay}
                      onCheckedChange={(checked) => setDeliveryTimes({...deliveryTimes, sameDay: checked})}
                    />
                    <Label>Same Day Delivery</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={deliveryTimes.nextDay}
                      onCheckedChange={(checked) => setDeliveryTimes({...deliveryTimes, nextDay: checked})}
                    />
                    <Label>Next Day Delivery</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={deliveryTimes.scheduled}
                      onCheckedChange={(checked) => setDeliveryTimes({...deliveryTimes, scheduled: checked})}
                    />
                    <Label>Scheduled Delivery</Label>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Pricing Summary */}
          <Card className="bg-gray-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <DollarSign className="h-5 w-5" />
                Pricing Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Base Shipping:</span>
                  <span>${shippingFee}</span>
                </div>
                <div className="flex justify-between">
                  <span>Handling Fee:</span>
                  <span>${handlingFee}</span>
                </div>
                {additionalFees && (
                  <div className="flex justify-between">
                    <span>Additional Fees:</span>
                    <span>${additionalFees}</span>
                  </div>
                )}
                <div className="border-t pt-2 flex justify-between font-semibold">
                  <span>Total Customer Sees:</span>
                  <span>${(parseFloat(shippingFee) + parseFloat(handlingFee) + parseFloat(additionalFees || '0')).toFixed(2)}</span>
                </div>
                <p className="text-sm text-gray-600">
                  {deliveryFeeStructure === 'split' && 'Customer pays 50% of delivery fee'}
                  {deliveryFeeStructure === 'seller-pays' && 'Seller pays full delivery fee'}
                  {deliveryFeeStructure === 'business-absorb' && 'Business absorbs all delivery costs'}
                </p>
              </div>
            </CardContent>
          </Card>

          <Button onClick={handleSaveSettings} className="w-full">
            <Settings className="h-4 w-4 mr-2" />
            Save Delivery Settings
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}