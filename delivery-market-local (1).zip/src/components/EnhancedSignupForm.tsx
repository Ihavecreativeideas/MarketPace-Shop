import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import ProfileTypeSelector from '@/components/ProfileTypeSelector';
import { Loader2 } from 'lucide-react';

interface SignupData {
  name: string;
  email: string;
  password: string;
  phone: string;
  zipCode: string;
  city: string;
  acceptTerms: boolean;
}

const EnhancedSignupForm: React.FC = () => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [signupData, setSignupData] = useState<SignupData>({
    name: '',
    email: '',
    password: '',
    phone: '',
    zipCode: '',
    city: '',
    acceptTerms: false
  });
  const [selectedProfileTypes, setSelectedProfileTypes] = useState<string[]>(['regular']);
  const { user } = useAuth();

  const handleInputChange = (field: keyof SignupData, value: string | boolean) => {
    setSignupData(prev => ({ ...prev, [field]: value }));
  };

  const handleStep1Submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupData.acceptTerms) {
      alert('Please accept the terms and conditions');
      return;
    }
    
    setLoading(true);
    try {
      const { error } = await supabase.auth.signUp({
        email: signupData.email,
        password: signupData.password
      });
      
      if (error) throw error;
      setStep(2);
    } catch (error) {
      console.error('Signup error:', error);
      alert('Signup failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleStep2Submit = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        // Create user profile
        const { error } = await supabase.from('enhanced_user_profiles').insert({
          user_id: user.id,
          name: signupData.name,
          email: signupData.email,
          phone: signupData.phone || null,
          zip_code: signupData.zipCode || null,
          city: signupData.city || null,
          profile_types: selectedProfileTypes
        });
        
        if (error) throw error;
        
        // Create business profiles for non-regular types
        const businessTypes = selectedProfileTypes.filter(type => type !== 'regular');
        if (businessTypes.length > 0) {
          const businessProfiles = businessTypes.map(type => ({
            user_id: user.id,
            profile_type: type,
            business_name: `${signupData.name}'s ${type.charAt(0).toUpperCase() + type.slice(1)}`,
            direct_messaging_enabled: type === 'service' || type === 'entertainment'
          }));
          
          await supabase.from('business_profiles').insert(businessProfiles);
        }
      }
      
      alert('Profile created successfully!');
    } catch (error) {
      console.error('Profile creation error:', error);
      alert('Profile creation failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (step === 1) {
    return (
      <Card className="w-full max-w-md mx-auto bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-2xl text-center text-white">Join MarketPace</CardTitle>
          <CardDescription className="text-center text-gray-300">
            Create your account to get started
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleStep1Submit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-white">Full Name *</Label>
              <Input
                id="name"
                type="text"
                value={signupData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                required
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white">Email *</Label>
              <Input
                id="email"
                type="email"
                value={signupData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                required
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="text-white">Password *</Label>
              <Input
                id="password"
                type="password"
                value={signupData.password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                required
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phone" className="text-white">Phone (Optional)</Label>
              <Input
                id="phone"
                type="tel"
                value={signupData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="zipCode" className="text-white">Zip Code</Label>
                <Input
                  id="zipCode"
                  type="text"
                  value={signupData.zipCode}
                  onChange={(e) => handleInputChange('zipCode', e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="city" className="text-white">City</Label>
                <Input
                  id="city"
                  type="text"
                  value={signupData.city}
                  onChange={(e) => handleInputChange('city', e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="terms"
                checked={signupData.acceptTerms}
                onCheckedChange={(checked) => handleInputChange('acceptTerms', checked as boolean)}
                className="data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
              />
              <Label htmlFor="terms" className="text-sm text-gray-300">
                I accept the terms and conditions *
              </Label>
            </div>
            
            <Button 
              type="submit" 
              className="w-full bg-purple-600 hover:bg-purple-700"
              disabled={loading}
            >
              {loading ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating Account...</>
              ) : (
                'Create Account'
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto">
      <ProfileTypeSelector
        selectedTypes={selectedProfileTypes}
        onTypeChange={setSelectedProfileTypes}
      />
      <div className="mt-6 text-center">
        <Button 
          onClick={handleStep2Submit}
          className="bg-purple-600 hover:bg-purple-700 px-8"
          disabled={loading}
        >
          {loading ? (
            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Setting up Profile...</>
          ) : (
            'Complete Setup'
          )}
        </Button>
      </div>
    </div>
  );
};

export default EnhancedSignupForm;