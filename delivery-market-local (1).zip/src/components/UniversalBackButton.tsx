import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

interface UniversalBackButtonProps {
  customAction?: () => void;
  label?: string;
  className?: string;
}

const UniversalBackButton: React.FC<UniversalBackButtonProps> = ({
  customAction,
  label = 'Back',
  className = ''
}) => {
  const navigate = useNavigate();

  const handleBack = () => {
    if (customAction) {
      customAction();
    } else {
      navigate(-1);
    }
  };

  return (
    <Button
      variant="ghost"
      onClick={handleBack}
      className={`
        text-white hover:bg-white/10 transition-all duration-200
        flex items-center gap-2 px-3 py-2 rounded-lg
        backdrop-blur-sm bg-white/5 border border-white/10
        hover:border-white/20 hover:shadow-lg
        ${className}
      `}
    >
      <ArrowLeft className="w-4 h-4" />
      <span className="text-sm font-medium">{label}</span>
    </Button>
  );
};

export default UniversalBackButton;
export { UniversalBackButton };