import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Zap, DollarSign, Clock, MapPin, Truck, Route, KeyRound } from 'lucide-react';
import { useState, useEffect } from 'react';
import LargeItemDeliveryPay from './LargeItemDeliveryPay';
import GreenRouteOptimizer from './GreenRouteOptimizer';
import ForgotPasswordModal from './ForgotPasswordModal';
import DriverPortalRoutes from './DriverPortalRoutes';

interface Delivery {
  id: string;
  pickup: string;
  dropoff: string;
  distance: number;
  status: 'pending' | 'in_progress' | 'completed';
  basePay: number;
  tip: number;
  type: 'standard' | 'large_item' | 'pharmacy';
  service: 'MedPace' | 'PostPace';
}

const DriverPortal: React.FC = () => {
  const [deliveries, setDeliveries] = useState<Delivery[]>([
    {
      id: 'DEL001',
      pickup: '123 Main St',
      dropoff: '456 Oak Ave',
      distance: 5.2,
      status: 'completed',
      basePay: 14.00,
      tip: 5.00,
      type: 'standard',
      service: 'PostPace'
    },
    {
      id: 'PH001',
      pickup: 'CVS Pharmacy',
      dropoff: '789 Pine Rd',
      distance: 3.2,
      status: 'completed',
      basePay: 14.00,
      tip: 0.00,
      type: 'pharmacy',
      service: 'MedPace'
    },
    {
      id: 'DEL002',
      pickup: '789 Pine Rd',
      dropoff: '321 Elm St',
      distance: 15.8,
      status: 'completed',
      basePay: 40.00,
      tip: 15.00,
      type: 'large_item',
      service: 'PostPace'
    }
  ]);

  const [paymentStatus, setPaymentStatus] = useState<{[key: string]: 'pending' | 'processing' | 'paid'}>({});
  const [activeTab, setActiveTab] = useState<'dashboard' | 'large_items' | 'green_routes' | 'delivery_routes'>('dashboard');
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  const processInstantPayment = async (deliveryId: string, amount: number) => {
    setPaymentStatus(prev => ({ ...prev, [deliveryId]: 'processing' }));
    
    try {
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/4f9b62c2-db04-4293-88fb-fce001aa326c',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            deliveryId,
            driverPay: amount,
            tipAmount: deliveries.find(d => d.id === deliveryId)?.tip || 0,
            driverId: 'driver-123',
            bankAccount: 'xxxx-1234'
          })
        }
      );
      
      const result = await response.json();
      
      if (result.success) {
        setPaymentStatus(prev => ({ ...prev, [deliveryId]: 'paid' }));
      }
    } catch (error) {
      console.error('Payment failed:', error);
    }
  };

  const totalEarnings = deliveries
    .filter(d => d.status === 'completed')
    .reduce((sum, d) => sum + d.basePay + d.tip, 0);

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex gap-4">
          <Button 
            variant={activeTab === 'dashboard' ? 'default' : 'outline'}
            onClick={() => setActiveTab('dashboard')}
          >
            Dashboard
          </Button>
          <Button 
            variant={activeTab === 'delivery_routes' ? 'default' : 'outline'}
            onClick={() => setActiveTab('delivery_routes')}
            className="flex items-center gap-2"
          >
            <Route className="w-4 h-4" />
            Delivery Routes
          </Button>
          <Button 
            variant={activeTab === 'green_routes' ? 'default' : 'outline'}
            onClick={() => setActiveTab('green_routes')}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white"
          >
            <Route className="w-4 h-4" />
            Green Routes
          </Button>
          <Button 
            variant={activeTab === 'large_items' ? 'default' : 'outline'}
            onClick={() => setActiveTab('large_items')}
            className="flex items-center gap-2"
          >
            <Truck className="w-4 h-4" />
            Large Items
          </Button>
        </div>
        
        <Button 
          variant="outline"
          onClick={() => setShowForgotPassword(true)}
          className="flex items-center gap-2 border-blue-600 text-blue-600 hover:bg-blue-50"
        >
          <KeyRound className="w-4 h-4" />
          Forgot My Password
        </Button>
      </div>

      {activeTab === 'delivery_routes' && <DriverPortalRoutes />}
      {activeTab === 'green_routes' && <GreenRouteOptimizer />}
      {activeTab === 'large_items' && <LargeItemDeliveryPay />}
      
      {activeTab === 'dashboard' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-500" />
              Driver Dashboard - Instant Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-green-50 p-4 rounded-lg mb-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold">Total Earnings Today:</span>
                <span className="text-2xl font-bold text-green-600">${totalEarnings.toFixed(2)}</span>
              </div>
            </div>
            
            <div className="space-y-4">
              {deliveries.map((delivery) => {
                const totalPayout = delivery.basePay + delivery.tip;
                const status = paymentStatus[delivery.id] || 'pending';
                
                return (
                  <div key={delivery.id} className={`border rounded-lg p-4 ${
                    delivery.type === 'large_item' ? 'border-green-300 bg-green-50' : 
                    delivery.type === 'pharmacy' ? 'border-blue-300 bg-blue-50' : ''
                  }`}>
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-semibold flex items-center gap-2">
                          Delivery #{delivery.id}
                          <Badge className="bg-purple-600 text-white">
                            {delivery.service}
                          </Badge>
                          {delivery.type === 'large_item' && (
                            <Badge className="bg-green-600 text-white">
                              <Truck className="w-3 h-3 mr-1" />
                              Large Item
                            </Badge>
                          )}
                          {delivery.type === 'pharmacy' && (
                            <Badge className="bg-blue-600 text-white">
                              Pharmacy
                            </Badge>
                          )}
                        </h3>
                        <div className="text-sm text-gray-600 space-y-1">
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            <span>{delivery.pickup} → {delivery.dropoff}</span>
                          </div>
                          <div>{delivery.distance} miles</div>
                        </div>
                      </div>
                      <Badge variant={delivery.status === 'completed' ? 'default' : 'secondary'}>
                        {delivery.status}
                      </Badge>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-lg mb-3">
                      <div className="text-sm font-semibold mb-2">Pay Breakdown:</div>
                      <div className="text-sm space-y-1">
                        {delivery.type === 'large_item' ? (
                          <>
                            <div className="flex justify-between">
                              <span>Large Item Base (up to 20 mi):</span>
                              <span>$40.00</span>
                            </div>
                            {delivery.distance > 20 && (
                              <div className="flex justify-between">
                                <span>Overage ({(delivery.distance - 20).toFixed(1)} mi × $0.75):</span>
                                <span>${((delivery.distance - 20) * 0.75).toFixed(2)}</span>
                              </div>
                            )}
                          </>
                        ) : (
                          <>
                            <div className="flex justify-between">
                              <span>{delivery.service} Base (up to 8 mi):</span>
                              <span>$14.00</span>
                            </div>
                            {delivery.distance > 8 && (
                              <div className="flex justify-between">
                                <span>Overage ({(delivery.distance - 8).toFixed(1)} mi × $0.75):</span>
                                <span>${((delivery.distance - 8) * 0.75).toFixed(2)}</span>
                              </div>
                            )}
                          </>
                        )}
                        <div className="border-t pt-1 flex justify-between font-semibold">
                          <span>Base Pay:</span>
                          <span>${delivery.basePay.toFixed(2)}</span>
                        </div>
                        {delivery.tip > 0 && (
                          <div className="flex justify-between text-green-600">
                            <span>Tips (100%):</span>
                            <span>+${delivery.tip.toFixed(2)}</span>
                          </div>
                        )}
                        <div className="border-t pt-1 flex justify-between font-bold text-lg">
                          <span>Total:</span>
                          <span>${totalPayout.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                    
                    {delivery.status === 'completed' && (
                      <div>
                        {status === 'pending' && (
                          <Button 
                            onClick={() => processInstantPayment(delivery.id, delivery.basePay)}
                            className="w-full bg-green-600 hover:bg-green-700"
                          >
                            <CreditCard className="w-4 h-4 mr-2" />
                            Get Paid Instantly - ${totalPayout.toFixed(2)}
                          </Button>
                        )}
                        
                        {status === 'processing' && (
                          <div className="text-center py-2">
                            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-green-600 mx-auto mb-1"></div>
                            <p className="text-sm">Processing payment...</p>
                          </div>
                        )}
                        
                        {status === 'paid' && (
                          <div className="bg-green-100 p-3 rounded-lg">
                            <div className="flex items-center gap-2 text-green-800">
                              <DollarSign className="w-4 h-4" />
                              <span className="font-medium">Paid ${totalPayout.toFixed(2)} - In your account now!</span>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
      
      <ForgotPasswordModal 
        isOpen={showForgotPassword} 
        onClose={() => setShowForgotPassword(false)} 
      />
    </div>
  );
};

export default DriverPortal;