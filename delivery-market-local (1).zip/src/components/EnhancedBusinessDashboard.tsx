import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, BarChart3, MessageSquare, Settings, Zap, Crown, Users, TrendingUp, Globe, Truck } from 'lucide-react';
import POSIntegration from './POSIntegration';
import VendorReviews from './VendorReviews';
import VendorAnalytics from './VendorAnalytics';
import VendorPartnershipTiers from './VendorPartnershipTiers';
import PlatformDropdown from './PlatformDropdown';
import TrialWebIntegrationBanner from './TrialWebIntegrationBanner';
import WebsiteIntegrationWizard from './WebsiteIntegrationWizard';
import BusinessDeliverySettings from './BusinessDeliverySettings';
import BusinessAIAnalytics from './BusinessAIAnalytics';
import FacebookMarketplaceIntegration from './FacebookMarketplaceIntegration';

export default function EnhancedBusinessDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [showWebWizard, setShowWebWizard] = useState(false);
  const businessId = 'business-123';

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <Building2 className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold">Business Dashboard</h1>
                <p className="text-gray-600">Manage your dual business account</p>
              </div>
            </div>
            <PlatformDropdown />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <TrialWebIntegrationBanner onStartIntegration={() => setShowWebWizard(true)} />
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="integration" className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              Website
            </TabsTrigger>
            <TabsTrigger value="delivery" className="flex items-center gap-2">
              <Truck className="h-4 w-4" />
              Delivery
            </TabsTrigger>
            <TabsTrigger value="ai-analytics" className="flex items-center gap-2">
              <Crown className="h-4 w-4" />
              AI Analytics
            </TabsTrigger>
            <TabsTrigger value="pos" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              POS
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="reviews" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Reviews
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Today's Stats
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Orders:</span>
                      <span className="font-semibold">23</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Revenue:</span>
                      <span className="font-semibold">$1,245</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Rating:</span>
                      <span className="font-semibold">4.6 ★</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="h-5 w-5" />
                    Website Sync
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Products:</span>
                      <span className="font-semibold">156</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Synced:</span>
                      <span className="font-semibold text-green-600">154</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <span className="font-semibold text-green-600">Active</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Truck className="h-5 w-5" />
                    Delivery
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Active:</span>
                      <span className="font-semibold">8</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Completed:</span>
                      <span className="font-semibold">45</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Avg Time:</span>
                      <span className="font-semibold">32 min</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="h-5 w-5" />
                    AI Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Growth:</span>
                      <span className="font-semibold text-green-600">+12%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Recommendations:</span>
                      <span className="font-semibold">3</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Promotions:</span>
                      <span className="font-semibold">2 Active</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Website Orders</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div>
                        <p className="font-medium">Order #WEB-1234</p>
                        <p className="text-sm text-gray-600">Synced from website</p>
                      </div>
                      <span className="font-semibold">$45.99</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div>
                        <p className="font-medium">Order #WEB-1235</p>
                        <p className="text-sm text-gray-600">Synced from website</p>
                      </div>
                      <span className="font-semibold">$78.50</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Delivery Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span>On-time Rate:</span>
                      <span className="font-semibold text-green-600">94%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Customer Satisfaction:</span>
                      <span className="font-semibold">4.8/5</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Delivery Fees Collected:</span>
                      <span className="font-semibold">$234.50</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="integration">
            <div className="space-y-6">
              <FacebookMarketplaceIntegration />
              <Card>
                <CardHeader>
                  <CardTitle>Website Integration</CardTitle>
                  <CardDescription>Connect your existing website to mirror products perfectly</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={() => setShowWebWizard(true)}>
                    <Globe className="w-4 h-4 mr-2" />
                    Start Integration Wizard
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="delivery">
            <BusinessDeliverySettings />
          </TabsContent>

          <TabsContent value="ai-analytics">
            <BusinessAIAnalytics />
          </TabsContent>

          <TabsContent value="pos">
            <POSIntegration />
          </TabsContent>

          <TabsContent value="analytics">
            <VendorAnalytics vendorId={businessId} />
          </TabsContent>

          <TabsContent value="reviews">
            <VendorReviews vendorId={businessId} />
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Business Settings</CardTitle>
                <CardDescription>Manage your dual business account preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Business Information</h3>
                    <p className="text-sm text-gray-600">Update your business details and contact information</p>
                    <Button variant="outline" className="mt-2">Edit Details</Button>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Website Integration</h3>
                    <p className="text-sm text-gray-600">Manage your website connection and sync settings</p>
                    <Button variant="outline" className="mt-2">Manage Integration</Button>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Delivery Settings</h3>
                    <p className="text-sm text-gray-600">Configure delivery options and fee structures</p>
                    <Button variant="outline" className="mt-2">Configure Delivery</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        {showWebWizard && (
          <WebsiteIntegrationWizard onClose={() => setShowWebWizard(false)} />
        )}
      </div>
    </div>
  );
}