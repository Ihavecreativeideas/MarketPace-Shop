import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Crown, Star, CheckCircle, Clock, Gift, Zap, Users, TrendingUp } from 'lucide-react';
import { useState } from 'react';
import { toast } from '@/hooks/use-toast';

interface MusicianStartupCampaignProps {
  onSignup: () => void;
}

const MusicianStartupCampaign: React.FC<MusicianStartupCampaignProps> = ({ onSignup }) => {
  const [isSigningUp, setIsSigningUp] = useState(false);

  const handleFreeSignup = async () => {
    setIsSigningUp(true);
    // Simulate signup process
    setTimeout(() => {
      toast({
        title: "Welcome to MarketPace!",
        description: "You're now part of our exclusive startup campaign with lifetime MarketPace Musician Pro benefits!"
      });
      setIsSigningUp(false);
      onSignup();
    }, 2000);
  };

  const campaignBenefits = [
    { icon: Crown, title: "Professional Profile", description: "Complete biography, photos, and showcase" },
    { icon: Star, title: "Venue History & Reviews", description: "Build credibility with past performance records" },
    { icon: CheckCircle, title: "AI Contract Generator", description: "Automated booking contracts and agreements" },
    { icon: Zap, title: "Instant Booking System", description: "Direct bookings with secure payment processing" },
    { icon: Users, title: "Fan Engagement Tools", description: "Connect with followers and build your audience" },
    { icon: TrendingUp, title: "Performance Analytics", description: "Track your growth and booking success" }
  ];

  return (
    <Card className="bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 border-2 border-purple-200 shadow-xl">
      <CardHeader className="text-center pb-4">
        <div className="flex justify-center mb-4">
          <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 text-lg font-bold animate-pulse">
            <Gift className="w-5 h-5 mr-2" />
            STARTUP CAMPAIGN
          </Badge>
        </div>
        <CardTitle className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          FREE ACCESS FOR MUSICIANS
        </CardTitle>
        <p className="text-lg text-gray-700 mt-2">
          Join our <span className="font-bold text-purple-600">"Startup Campaign"</span> and get lifetime benefits!
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Limited Time Alert */}
        <div className="bg-gradient-to-r from-red-100 to-orange-100 border-l-4 border-red-500 p-4 rounded-lg">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-red-600" />
            <span className="font-bold text-red-800">LIMITED TIME ONLY!</span>
          </div>
          <p className="text-red-700 mt-1">
            All MarketPace Musician Pro features are <span className="font-bold">completely FREE</span> during our startup campaign.
            Early members get <span className="font-bold underline">LIFETIME ACCESS</span> to all Pro benefits!
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {campaignBenefits.map((benefit, index) => {
            const IconComponent = benefit.icon;
            return (
              <div key={index} className="flex items-start gap-3 p-3 bg-white/70 rounded-lg border border-purple-100">
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-2 rounded-lg">
                  <IconComponent className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800">{benefit.title}</h4>
                  <p className="text-sm text-gray-600">{benefit.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Value Proposition */}
        <div className="bg-gradient-to-r from-green-100 to-blue-100 p-4 rounded-lg border border-green-200">
          <h4 className="font-bold text-green-800 mb-2">MarketPace Musician Pro Benefits (Normally $50/month):</h4>
          <ul className="text-sm text-green-700 space-y-1">
            <li>✓ Professional musician profile with unlimited photos</li>
            <li>✓ Direct booking system with secure payments</li>
            <li>✓ AI-powered contract generation</li>
            <li>✓ Performance analytics and insights</li>
            <li>✓ Fan engagement and marketing tools</li>
            <li>✓ Priority support and feature access</li>
          </ul>
        </div>

        {/* Lifetime Benefits Alert */}
        <div className="bg-gradient-to-r from-yellow-100 to-orange-100 p-4 rounded-lg border-2 border-yellow-400">
          <div className="flex items-center gap-2 mb-2">
            <Crown className="w-6 h-6 text-yellow-600" />
            <span className="font-bold text-yellow-800 text-lg">EARLY MEMBER EXCLUSIVE</span>
          </div>
          <p className="text-yellow-800">
            Sign up now and keep all MarketPace Musician Pro features <span className="font-bold">FOR LIFE</span> - 
            even after our campaign ends and we start charging new members!
          </p>
        </div>

        {/* CTA Button */}
        <div className="text-center pt-4">
          <Button 
            onClick={handleFreeSignup}
            disabled={isSigningUp}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-4 text-lg font-bold rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200"
            size="lg"
          >
            {isSigningUp ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                Joining Campaign...
              </>
            ) : (
              <>
                <Gift className="w-6 h-6 mr-2" />
                JOIN FREE STARTUP CAMPAIGN
              </>
            )}
          </Button>
          <p className="text-sm text-gray-600 mt-2">
            No credit card required • Instant access • Lifetime Pro benefits for early members
          </p>
        </div>

        {/* Urgency Footer */}
        <div className="text-center text-sm text-gray-500 border-t pt-4">
          <p>
            ⚡ Campaign ends when we reach 1,000 musicians or launch officially
          </p>
          <p className="font-semibold text-purple-600">
            Join now to secure your lifetime MarketPace Musician Pro access!
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default MusicianStartupCampaign;