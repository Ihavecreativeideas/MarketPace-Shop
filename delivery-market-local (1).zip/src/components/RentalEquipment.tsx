import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Mic, Speaker, Camera, Lightbulb, ShoppingCart, Star, MapPin, Calendar } from 'lucide-react';
import { useState } from 'react';

interface RentalEquipmentProps {
  onRentEquipment?: (equipment: any) => void;
}

const RentalEquipment: React.FC<RentalEquipmentProps> = ({ onRentEquipment }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const equipmentCategories = [
    { value: 'all', label: 'All Equipment' },
    { value: 'audio', label: 'Audio Equipment' },
    { value: 'lighting', label: 'Lighting' },
    { value: 'video', label: 'Video/Camera' },
    { value: 'instruments', label: 'Instruments' },
    { value: 'staging', label: 'Staging' }
  ];

  const rentalEquipment = [
    {
      id: 1,
      name: 'Professional PA System',
      category: 'audio',
      brand: 'JBL PRX815W',
      dailyRate: '$150',
      weeklyRate: '$750',
      location: 'Downtown',
      rating: 4.8,
      availability: 'Available',
      image: '/placeholder.svg',
      description: 'Powered 15" speaker with wireless connectivity',
      includes: ['Wireless mics', 'Cables', 'Stand'],
      deposit: '$500'
    },
    {
      id: 2,
      name: 'LED Stage Lighting Kit',
      category: 'lighting',
      brand: 'Chauvet DJ',
      dailyRate: '$120',
      weeklyRate: '$600',
      location: 'Arts District',
      rating: 4.9,
      availability: 'Available',
      image: '/placeholder.svg',
      description: 'Complete RGB LED wash lighting system',
      includes: ['4 LED pars', 'Controller', 'Cables', 'Stands'],
      deposit: '$400'
    },
    {
      id: 3,
      name: '4K Video Camera Setup',
      category: 'video',
      brand: 'Sony FX6',
      dailyRate: '$300',
      weeklyRate: '$1500',
      location: 'Uptown',
      rating: 4.7,
      availability: 'Booked until Dec 20',
      image: '/placeholder.svg',
      description: 'Professional cinema camera with full accessories',
      includes: ['Tripod', 'Extra batteries', 'Memory cards', 'Lenses'],
      deposit: '$1000'
    },
    {
      id: 4,
      name: 'Digital Piano Keyboard',
      category: 'instruments',
      brand: 'Yamaha P-515',
      dailyRate: '$75',
      weeklyRate: '$375',
      location: 'Music District',
      rating: 4.6,
      availability: 'Available',
      image: '/placeholder.svg',
      description: '88-key weighted digital piano',
      includes: ['Stand', 'Pedal', 'Power adapter'],
      deposit: '$300'
    },
    {
      id: 5,
      name: 'Portable Stage Platform',
      category: 'staging',
      brand: 'IntelliStage',
      dailyRate: '$200',
      weeklyRate: '$1000',
      location: 'Industrial District',
      rating: 4.5,
      availability: 'Available',
      image: '/placeholder.svg',
      description: '8x8 ft modular stage platform',
      includes: ['Platform sections', 'Legs', 'Skirting', 'Steps'],
      deposit: '$600'
    }
  ];

  const filteredEquipment = selectedCategory === 'all' 
    ? rentalEquipment 
    : rentalEquipment.filter(item => item.category === selectedCategory);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'audio': return <Speaker className="w-4 h-4" />;
      case 'lighting': return <Lightbulb className="w-4 h-4" />;
      case 'video': return <Camera className="w-4 h-4" />;
      case 'instruments': return <Mic className="w-4 h-4" />;
      default: return <ShoppingCart className="w-4 h-4" />;
    }
  };

  const handleRentNow = (equipment: any) => {
    if (onRentEquipment) {
      onRentEquipment(equipment);
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Equipment Rental</h2>
        <p className="text-gray-600">Professional audio, lighting, video, and staging equipment for rent</p>
      </div>

      <div className="flex justify-center">
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Equipment Category" />
          </SelectTrigger>
          <SelectContent>
            {equipmentCategories.map(category => (
              <SelectItem key={category.value} value={category.value}>
                {category.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredEquipment.map((equipment) => (
          <Card key={equipment.id} className="hover:shadow-lg transition-all">
            <CardHeader className="p-0 relative">
              <img 
                src={equipment.image} 
                alt={equipment.name} 
                className="w-full h-32 object-cover rounded-t-lg" 
              />
              <div className="absolute top-2 right-2">
                <Badge 
                  variant={equipment.availability === 'Available' ? 'default' : 'secondary'}
                  className={equipment.availability === 'Available' ? 'bg-green-600' : 'bg-red-600'}
                >
                  {equipment.availability}
                </Badge>
              </div>
              <div className="absolute bottom-2 left-2">
                <Badge variant="secondary" className="flex items-center gap-1">
                  {getCategoryIcon(equipment.category)}
                  {equipment.category}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="p-4 space-y-3">
              <div>
                <CardTitle className="text-lg">{equipment.name}</CardTitle>
                <p className="text-sm text-gray-600">{equipment.brand}</p>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <MapPin className="w-3 h-3" />
                  <span>{equipment.location}</span>
                  <span>•</span>
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <span>{equipment.rating}</span>
                </div>
              </div>

              <p className="text-sm text-gray-600">{equipment.description}</p>

              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Daily Rate:</span>
                  <span className="font-medium text-green-600">{equipment.dailyRate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Weekly Rate:</span>
                  <span className="font-medium text-green-600">{equipment.weeklyRate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Deposit:</span>
                  <span className="text-orange-600">{equipment.deposit}</span>
                </div>
              </div>

              <div>
                <p className="text-xs text-gray-500 mb-1">Includes:</p>
                <div className="flex flex-wrap gap-1">
                  {equipment.includes.slice(0, 3).map((item, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs">
                      {item}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <Button 
                  size="sm" 
                  className="flex-1"
                  disabled={equipment.availability !== 'Available'}
                  onClick={() => handleRentNow(equipment)}
                >
                  <ShoppingCart className="w-4 h-4 mr-1" />
                  {equipment.availability === 'Available' ? 'Rent Now' : 'Unavailable'}
                </Button>
                <Button size="sm" variant="outline">
                  Details
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default RentalEquipment;