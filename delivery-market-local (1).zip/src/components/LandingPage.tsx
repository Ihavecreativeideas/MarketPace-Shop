import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { ShoppingCart, Truck, Users, Music, Store, Wrench, MapPin, Clock, Star, ArrowRight } from 'lucide-react';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const [isLaunching, setIsLaunching] = useState(false);

  const handleJoinLaunch = () => {
    setIsLaunching(true);
    setTimeout(() => {
      navigate('/auth');
    }, 500);
  };

  const features = [
    {
      icon: <ShoppingCart className="h-6 w-6" />,
      title: "Local Marketplace",
      description: "Buy and sell with neighbors in your area"
    },
    {
      icon: <Truck className="h-6 w-6" />,
      title: "Fast Delivery",
      description: "Get items delivered within hours"
    },
    {
      icon: <Music className="h-6 w-6" />,
      title: "Entertainment Hub",
      description: "Book local musicians, DJs, and performers"
    },
    {
      icon: <Store className="h-6 w-6" />,
      title: "Local Shops",
      description: "Support local businesses in your community"
    },
    {
      icon: <Wrench className="h-6 w-6" />,
      title: "Services",
      description: "Find trusted local service providers"
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Community",
      description: "Connect with your local community"
    }
  ];

  const stats = [
    { label: "Active Users", value: "10K+" },
    { label: "Local Shops", value: "500+" },
    { label: "Deliveries", value: "25K+" },
    { label: "Cities", value: "50+" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="relative z-10 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-teal-500 rounded-lg flex items-center justify-center">
              <Store className="h-5 w-5 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">MarketPace</span>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <button 
              onClick={() => navigate('/marketplace')}
              className="text-slate-300 hover:text-white transition-colors"
            >
              Marketplace
            </button>
            <button 
              onClick={() => navigate('/rent')}
              className="text-slate-300 hover:text-white transition-colors"
            >
              Rent
            </button>
            <button 
              onClick={() => navigate('/musicians')}
              className="text-slate-300 hover:text-white transition-colors"
            >
              Entertainment
            </button>
            <button 
              onClick={() => navigate('/shops')}
              className="text-slate-300 hover:text-white transition-colors"
            >
              Services
            </button>
          </nav>
          <Button 
            onClick={handleJoinLaunch}
            className="bg-teal-500 hover:bg-teal-600 text-white"
            disabled={isLaunching}
          >
            {isLaunching ? 'Launching...' : 'Get Started'}
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative px-6 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <Badge className="mb-6 bg-teal-500/20 text-teal-400 border-teal-500/30">
            🚀 Now Live in Your Area
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Your Local
            <span className="text-teal-400"> MarketPace</span>
          </h1>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            Connect with your community. Buy, sell, rent, and discover local services and entertainment - all in one place.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={handleJoinLaunch}
              size="lg"
              className="bg-teal-500 hover:bg-teal-600 text-white px-8 py-4 text-lg"
              disabled={isLaunching}
            >
              {isLaunching ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Launching...
                </div>
              ) : (
                <>
                  Join MarketPace
                  <ArrowRight className="ml-2 h-5 w-5" />
                </>
              )}
            </Button>
            <Button 
              onClick={() => navigate('/marketplace')}
              variant="outline"
              size="lg"
              className="border-slate-600 text-slate-300 hover:bg-slate-800 px-8 py-4 text-lg"
            >
              Browse Marketplace
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="px-6 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <Card key={index} className="bg-slate-800/50 border-slate-700">
                <CardContent className="p-6 text-center">
                  <div className="text-2xl font-bold text-teal-400 mb-2">{stat.value}</div>
                  <div className="text-slate-400 text-sm">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="px-6 py-20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Everything Your Community Needs
            </h2>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto">
              From shopping to services, entertainment to rentals - MarketPace brings your local community together.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-colors">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-teal-500/20 rounded-lg flex items-center justify-center text-teal-400">
                      {feature.icon}
                    </div>
                    <h3 className="text-xl font-semibold text-white">{feature.title}</h3>
                  </div>
                  <p className="text-slate-400">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-6 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <Card className="bg-gradient-to-r from-teal-500/20 to-blue-500/20 border-teal-500/30">
            <CardContent className="p-12">
              <h2 className="text-3xl font-bold text-white mb-4">
                Ready to Join Your Local MarketPace?
              </h2>
              <p className="text-slate-300 mb-8 text-lg">
                Get started today and discover what your community has to offer.
              </p>
              <Button 
                onClick={handleJoinLaunch}
                size="lg"
                className="bg-teal-500 hover:bg-teal-600 text-white px-8 py-4 text-lg"
                disabled={isLaunching}
              >
                {isLaunching ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Launching...
                  </div>
                ) : (
                  <>
                    Get Started Now
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-12 border-t border-slate-800">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-teal-500 rounded-lg flex items-center justify-center">
                  <Store className="h-5 w-5 text-white" />
                </div>
                <span className="text-xl font-bold text-white">MarketPace</span>
              </div>
              <p className="text-slate-400 text-sm">
                Connecting communities through local commerce and services.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Marketplace</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><button onClick={() => navigate('/marketplace')}>Browse Items</button></li>
                <li><button onClick={() => navigate('/rent')}>Rent Anything</button></li>
                <li>Sell Items</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><button onClick={() => navigate('/shops')}>Local Shops</button></li>
                <li><button onClick={() => navigate('/musicians')}>Entertainment</button></li>
                <li>Professional Services</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>Help Center</li>
                <li>Contact Us</li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400 text-sm">
            <p>&copy; 2024 MarketPace. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;