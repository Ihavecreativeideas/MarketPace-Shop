import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { MapPin, Navigation, Clock } from 'lucide-react';
import { Badge } from './ui/badge';

interface PostOffice {
  id: string;
  name: string;
  address: string;
  distance: number;
  type: 'usps' | 'fedex' | 'ups';
  hours: string;
  services: string[];
}

interface PostOfficeSelectorProps {
  onSelect: (office: PostOffice) => void;
  selectedOffice?: PostOffice;
}

const PostOfficeSelector: React.FC<PostOfficeSelectorProps> = ({ onSelect, selectedOffice }) => {
  const [userLocation, setUserLocation] = useState<string>('');
  const [nearbyOffices, setNearbyOffices] = useState<PostOffice[]>([
    {
      id: '1',
      name: 'USPS Downtown',
      address: '123 Main St, Downtown',
      distance: 0.8,
      type: 'usps',
      hours: '9:00 AM - 5:00 PM',
      services: ['Priority Mail', 'Express Mail', 'Ground']
    },
    {
      id: '2', 
      name: 'FedEx Office Center',
      address: '456 Oak Ave, Midtown',
      distance: 1.2,
      type: 'fedex',
      hours: '8:00 AM - 8:00 PM',
      services: ['Overnight', '2-Day', 'Ground']
    },
    {
      id: '3',
      name: 'UPS Store',
      address: '789 Pine St, Uptown', 
      distance: 1.5,
      type: 'ups',
      hours: '9:00 AM - 7:00 PM',
      services: ['Next Day Air', 'Ground', '3-Day Select']
    },
    {
      id: '4',
      name: 'USPS Northside',
      address: '321 Elm St, Northside',
      distance: 2.1,
      type: 'usps',
      hours: '9:00 AM - 5:00 PM',
      services: ['Priority Mail', 'Media Mail', 'Ground']
    }
  ]);

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'usps': return 'bg-blue-100 text-blue-800';
      case 'fedex': return 'bg-purple-100 text-purple-800';
      case 'ups': return 'bg-amber-100 text-amber-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeName = (type: string) => {
    switch (type) {
      case 'usps': return 'USPS';
      case 'fedex': return 'FedEx';
      case 'ups': return 'UPS';
      default: return type.toUpperCase();
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5" />
          Select Drop-off Location
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {nearbyOffices.map((office) => (
            <div
              key={office.id}
              className={`p-4 border rounded-lg cursor-pointer transition-all ${
                selectedOffice?.id === office.id
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => onSelect(office)}
            >
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-semibold text-gray-900">{office.name}</h3>
                  <p className="text-sm text-gray-600">{office.address}</p>
                </div>
                <div className="text-right">
                  <Badge className={getTypeColor(office.type)}>
                    {getTypeName(office.type)}
                  </Badge>
                  <p className="text-sm text-gray-500 mt-1">{office.distance} mi</p>
                </div>
              </div>
              
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {office.hours}
                </div>
              </div>
              
              <div className="mt-2">
                <div className="flex flex-wrap gap-1">
                  {office.services.map((service, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {service}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default PostOfficeSelector;