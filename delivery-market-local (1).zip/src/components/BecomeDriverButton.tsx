import React from 'react';
import { Button } from '@/components/ui/button';
import { Truck, Star } from 'lucide-react';
import { Link } from 'react-router-dom';

const BecomeDriverButton = () => {
  return (
    <Link to="/driver-application">
      <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
        <Truck className="h-5 w-5 mr-2" />
        <span className="font-semibold">Become a Driver</span>
        <Star className="h-4 w-4 ml-2 text-yellow-300" />
      </Button>
    </Link>
  );
};

export default BecomeDriverButton;