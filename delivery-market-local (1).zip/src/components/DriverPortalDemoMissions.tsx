import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Clock, DollarSign, Package, Star, Navigation } from 'lucide-react';

interface Mission {
  id: string;
  title: string;
  pickup: string;
  dropoff: string;
  distance: string;
  estimatedTime: string;
  payout: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  tips: number;
  description: string;
  priority: 'Low' | 'Medium' | 'High';
}

const demoMissions: Mission[] = [
  {
    id: '001',
    title: 'Downtown Electronics Delivery',
    pickup: 'Best Buy - Main St',
    dropoff: '1234 Oak Avenue',
    distance: '3.2 miles',
    estimatedTime: '25 min',
    payout: 18.50,
    difficulty: 'Easy',
    tips: 5.00,
    description: 'Laptop delivery to residential area',
    priority: 'High'
  },
  {
    id: '002',
    title: 'Pharmacy Rush Order',
    pickup: 'CVS Pharmacy - 5th St',
    dropoff: 'Sunset Retirement Home',
    distance: '1.8 miles',
    estimatedTime: '15 min',
    payout: 12.00,
    difficulty: 'Easy',
    tips: 3.00,
    description: 'Prescription medication - Handle with care',
    priority: 'High'
  },
  {
    id: '003',
    title: 'Furniture Assembly Delivery',
    pickup: 'IKEA Warehouse',
    dropoff: '789 Pine Street Apt 4B',
    distance: '7.5 miles',
    estimatedTime: '45 min',
    payout: 35.00,
    difficulty: 'Hard',
    tips: 10.00,
    description: 'Large furniture items - Requires assembly',
    priority: 'Medium'
  }
];

export default function DriverPortalDemoMissions() {
  const [selectedMission, setSelectedMission] = useState<Mission | null>(null);
  const [acceptedMissions, setAcceptedMissions] = useState<string[]>([]);

  const handleAcceptMission = (missionId: string) => {
    setAcceptedMissions([...acceptedMissions, missionId]);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-500';
      case 'Medium': return 'bg-yellow-500';
      case 'Hard': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'border-red-400 bg-red-50';
      case 'Medium': return 'border-yellow-400 bg-yellow-50';
      case 'Low': return 'border-green-400 bg-green-50';
      default: return 'border-gray-400 bg-gray-50';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Available Missions
        </h1>
        <p className="text-gray-600 mt-2">Select and accept delivery missions in your area</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {demoMissions.map((mission) => (
          <Card 
            key={mission.id} 
            className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
              getPriorityColor(mission.priority)
            } ${selectedMission?.id === mission.id ? 'ring-2 ring-blue-500' : ''}`}
            onClick={() => setSelectedMission(mission)}
          >
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg font-semibold">{mission.title}</CardTitle>
                <Badge className={`${getDifficultyColor(mission.difficulty)} text-white`}>
                  {mission.difficulty}
                </Badge>
              </div>
              <Badge variant="outline" className="w-fit">
                {mission.priority} Priority
              </Badge>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-green-600" />
                  <span className="font-medium">Pickup:</span> {mission.pickup}
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Navigation className="w-4 h-4 text-red-600" />
                  <span className="font-medium">Dropoff:</span> {mission.dropoff}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4 text-blue-600" />
                  <span>{mission.estimatedTime}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Package className="w-4 h-4 text-purple-600" />
                  <span>{mission.distance}</span>
                </div>
              </div>

              <div className="flex justify-between items-center pt-2 border-t">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-green-600" />
                  <span className="font-bold text-lg">${mission.payout.toFixed(2)}</span>
                  {mission.tips > 0 && (
                    <div className="flex items-center gap-1 text-sm text-yellow-600">
                      <Star className="w-3 h-3" />
                      <span>+${mission.tips.toFixed(2)}</span>
                    </div>
                  )}
                </div>
                
                {acceptedMissions.includes(mission.id) ? (
                  <Badge className="bg-green-500 text-white">Accepted</Badge>
                ) : (
                  <Button 
                    size="sm" 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAcceptMission(mission.id);
                    }}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Accept
                  </Button>
                )}
              </div>

              <p className="text-xs text-gray-600 mt-2">{mission.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedMission && (
        <Card className="mt-6 border-2 border-blue-500">
          <CardHeader>
            <CardTitle className="text-xl">Mission Details: {selectedMission.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-semibold text-lg">Route Information</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-green-600" />
                    <span><strong>Pickup:</strong> {selectedMission.pickup}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Navigation className="w-4 h-4 text-red-600" />
                    <span><strong>Dropoff:</strong> {selectedMission.dropoff}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-purple-600" />
                    <span><strong>Distance:</strong> {selectedMission.distance}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span><strong>Est. Time:</strong> {selectedMission.estimatedTime}</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-semibold text-lg">Payment Details</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Base Payout:</span>
                    <span className="font-semibold">${selectedMission.payout.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Expected Tips:</span>
                    <span className="font-semibold text-yellow-600">+${selectedMission.tips.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between border-t pt-2">
                    <span className="font-bold">Total Potential:</span>
                    <span className="font-bold text-green-600">
                      ${(selectedMission.payout + selectedMission.tips).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <p className="text-sm"><strong>Description:</strong> {selectedMission.description}</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}