import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DollarSign, TrendingUp, ShoppingCart, Users, Search, Calendar, Package } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface SaleRecord {
  id: string;
  orderNumber: string;
  customerName: string;
  businessName: string;
  amount: number;
  status: 'completed' | 'pending' | 'refunded' | 'cancelled';
  paymentMethod: string;
  category: string;
  date: string;
  commission: number;
  deliveryFee: number;
}

export default function SalesPanel() {
  const [sales, setSales] = useState<SaleRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSales();
  }, []);

  const loadSales = async () => {
    try {
      const { data, error } = await supabase
        .from('marketplace_orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Mock additional data for demo
      const mockSales: SaleRecord[] = [
        {
          id: '1',
          orderNumber: 'ORD-2024-001',
          customerName: 'John Doe',
          businessName: 'Pizza Palace',
          amount: 45.99,
          status: 'completed',
          paymentMethod: 'Credit Card',
          category: 'Food',
          date: '2024-01-15T14:30:00Z',
          commission: 4.60,
          deliveryFee: 5.99
        },
        {
          id: '2',
          orderNumber: 'ORD-2024-002',
          customerName: 'Jane Smith',
          businessName: 'Fresh Grocers',
          amount: 89.50,
          status: 'pending',
          paymentMethod: 'PayPal',
          category: 'Grocery',
          date: '2024-01-15T13:15:00Z',
          commission: 8.95,
          deliveryFee: 7.99
        },
        {
          id: '3',
          orderNumber: 'ORD-2024-003',
          customerName: 'Mike Johnson',
          businessName: 'Tech Repair Shop',
          amount: 199.99,
          status: 'completed',
          paymentMethod: 'Credit Card',
          category: 'Electronics',
          date: '2024-01-15T12:00:00Z',
          commission: 20.00,
          deliveryFee: 9.99
        },
        {
          id: '4',
          orderNumber: 'ORD-2024-004',
          customerName: 'Sarah Wilson',
          businessName: 'Flower Garden',
          amount: 65.00,
          status: 'refunded',
          paymentMethod: 'Credit Card',
          category: 'Retail',
          date: '2024-01-15T11:30:00Z',
          commission: 6.50,
          deliveryFee: 4.99
        },
        {
          id: '5',
          orderNumber: 'ORD-2024-005',
          customerName: 'David Brown',
          businessName: 'Coffee Corner',
          amount: 12.50,
          status: 'cancelled',
          paymentMethod: 'Cash',
          category: 'Food',
          date: '2024-01-15T10:45:00Z',
          commission: 1.25,
          deliveryFee: 2.99
        }
      ];

      setSales(mockSales);
    } catch (error) {
      console.error('Error loading sales:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: SaleRecord['status']) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'refunded': return 'bg-blue-100 text-blue-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredSales = sales.filter(sale => {
    const matchesSearch = 
      sale.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.businessName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.category.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || sale.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const totalRevenue = sales.reduce((sum, sale) => sum + sale.amount, 0);
  const totalCommission = sales.reduce((sum, sale) => sum + sale.commission, 0);
  const completedSales = sales.filter(s => s.status === 'completed').length;
  const pendingSales = sales.filter(s => s.status === 'pending').length;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
        <div className="text-center">Loading sales data...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Sales Management</h1>
          <p className="text-gray-600">Monitor and analyze sales performance</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-green-600">${totalRevenue.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Total Revenue</div>
                </div>
                <DollarSign className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-blue-600">${totalCommission.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Commission Earned</div>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-purple-600">{completedSales}</div>
                  <div className="text-sm text-muted-foreground">Completed Orders</div>
                </div>
                <ShoppingCart className="h-8 w-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-orange-600">{pendingSales}</div>
                  <div className="text-sm text-muted-foreground">Pending Orders</div>
                </div>
                <Package className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by order number, customer, business, or category..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="refunded">Refunded</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Sales List */}
        <div className="space-y-4">
          {filteredSales.map((sale) => (
            <Card key={sale.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-4">
                <div className="grid grid-cols-1 md:grid-cols-6 gap-4 items-center">
                  <div>
                    <div className="font-semibold">{sale.orderNumber}</div>
                    <div className="text-sm text-muted-foreground">{sale.customerName}</div>
                  </div>
                  
                  <div>
                    <div className="font-medium">{sale.businessName}</div>
                    <div className="text-sm text-muted-foreground">{sale.category}</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-lg font-bold text-green-600">${sale.amount.toFixed(2)}</div>
                    <div className="text-xs text-muted-foreground">Amount</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-sm font-medium">${sale.commission.toFixed(2)}</div>
                    <div className="text-xs text-muted-foreground">Commission</div>
                  </div>
                  
                  <div className="text-center">
                    <Badge className={getStatusColor(sale.status)}>
                      {sale.status}
                    </Badge>
                    <div className="text-xs text-muted-foreground mt-1">
                      {new Date(sale.date).toLocaleDateString()}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      View Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredSales.length === 0 && (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No sales found matching your criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
}