import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import { LaunchProvider } from '@/contexts/LaunchContext';
import { CartProvider } from '@/components/CartContext';
import { AuthProvider } from '@/components/AuthProvider';
import { PWAInstaller, NotificationManager, OfflineIndicator } from '@/components/PWAFeatures';
import Navigation from '@/components/Navigation';
import PreLaunchMeter from '@/components/PreLaunchMeter';
import Index from '@/pages/Index';
import MarketplacePage from '@/pages/MarketplacePage';
import MusiciansPage from '@/pages/MusiciansPage';
import MedPaceEnhanced from '@/components/MedPaceEnhanced';
import DriverPortalEnhanced from '@/components/DriverPortalEnhanced';
import PharmacyPickupNotification from '@/components/PharmacyPickupNotification';
import DriverApplication from '@/components/DriverApplication';
import CampaignSignup from '@/components/CampaignSignup';
import DriverJobDescription from '@/components/DriverJobDescription';
import PostPace from '@/components/PostPace';
import VendorPartnershipTiers from '@/components/VendorPartnershipTiers';
import PartnerSubscriptionPlans from '@/components/PartnerSubscriptionPlans';
import PartnerAIDashboard from '@/components/PartnerAIDashboard';
import { UserProfile } from '@/components/UserProfile';
import { RealTimeTracking } from '@/components/RealTimeTracking';
import { OrderHistory } from '@/components/OrderHistory';
import { AnalyticsDashboard } from '@/components/AnalyticsDashboard';
import './App.css';

function EnhancedApp() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="vite-ui-theme">
      <AuthProvider>
        <LaunchProvider>
          <CartProvider>
            <Router>
              <div className="min-h-screen bg-background">
                <OfflineIndicator />
                <Navigation />
                <div className="container mx-auto px-2 sm:px-4 pt-2 sm:pt-4">
                  <PWAInstaller />
                  <PreLaunchMeter />
                </div>
                <main className="pb-4">
                  <Routes>
                    <Route path="/" element={<Index />} />
                    <Route path="/marketplace" element={<MarketplacePage />} />
                    <Route path="/musicians" element={<MusiciansPage />} />
                    <Route path="/medpace" element={<MedPaceEnhanced />} />
                    <Route path="/postpace" element={<PostPace />} />
                    <Route path="/driver-portal" element={<DriverPortalEnhanced />} />
                    <Route path="/pharmacy-tracking" element={<PharmacyPickupNotification />} />
                    <Route path="/driver-application" element={<DriverApplication />} />
                    <Route path="/driver-job" element={<DriverJobDescription />} />
                    <Route path="/campaign-signup" element={<CampaignSignup />} />
                    <Route path="/vendor-partnership" element={<VendorPartnershipTiers />} />
                    <Route path="/partner-plans" element={<PartnerSubscriptionPlans />} />
                    <Route path="/profile" element={<UserProfile />} />
                    <Route path="/orders" element={<OrderHistory />} />
                    <Route path="/tracking/:orderId" element={
                      <RealTimeTracking orderId={window.location.pathname.split('/')[2]} />
                    } />
                    <Route path="/analytics" element={<AnalyticsDashboard isAdmin={true} />} />
                    <Route path="/vendor-analytics/:vendorId" element={
                      <AnalyticsDashboard vendorId={window.location.pathname.split('/')[2]} />
                    } />
                    <Route path="/notifications" element={<NotificationManager />} />
                    <Route path="/ai-assistant/:tier" element={
                      <PartnerAIDashboard 
                        partnerTier={window.location.pathname.split('/')[2] as 'silver' | 'gold' | 'platinum'}
                        userId="user-123"
                      />
                    } />
                    <Route path="*" element={<Index />} />
                  </Routes>
                </main>
                <Toaster />
              </div>
            </Router>
          </CartProvider>
        </LaunchProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default EnhancedApp;