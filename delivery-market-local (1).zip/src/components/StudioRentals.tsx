import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Music, Mic, Camera, Clock, Star, MapPin, Calendar, Users, Wifi } from 'lucide-react';
import { useState } from 'react';

interface StudioRentalsProps {
  onBookStudio?: (studio: any) => void;
}

const StudioRentals: React.FC<StudioRentalsProps> = ({ onBookStudio }) => {
  const [selectedType, setSelectedType] = useState('all');

  const studioTypes = [
    { value: 'all', label: 'All Studios' },
    { value: 'recording', label: 'Recording Studios' },
    { value: 'rehearsal', label: 'Rehearsal Spaces' },
    { value: 'video', label: 'Video Production' },
    { value: 'photography', label: 'Photography Studios' },
    { value: 'podcast', label: 'Podcast Studios' }
  ];

  const studios = [
    {
      id: 1,
      name: 'Soundwave Recording Studio',
      type: 'recording',
      location: 'Music District',
      hourlyRate: '$85',
      dailyRate: '$600',
      rating: 4.9,
      capacity: '8 people',
      size: '500 sq ft',
      availability: 'Available today',
      image: '/placeholder.svg',
      description: 'Professional recording studio with vintage and modern equipment',
      amenities: ['Pro Tools', 'SSL Console', 'Vintage Mics', 'Piano', 'Isolation Booth'],
      features: ['Air Conditioning', 'WiFi', 'Parking', 'Kitchen', '24/7 Access']
    },
    {
      id: 2,
      name: 'Band Jam Rehearsal Space',
      type: 'rehearsal',
      location: 'Industrial District',
      hourlyRate: '$35',
      dailyRate: '$250',
      rating: 4.6,
      capacity: '6 people',
      size: '400 sq ft',
      availability: 'Available weekends',
      image: '/placeholder.svg',
      description: 'Loud-friendly rehearsal space with full backline',
      amenities: ['Drum Kit', 'Guitar Amps', 'Bass Amp', 'PA System', 'Mics'],
      features: ['Sound Isolation', 'WiFi', 'Storage Lockers', 'Parking']
    },
    {
      id: 3,
      name: 'Creative Video Studio',
      type: 'video',
      location: 'Arts District',
      hourlyRate: '$120',
      dailyRate: '$850',
      rating: 4.8,
      capacity: '12 people',
      size: '800 sq ft',
      availability: 'Booked until Dec 22',
      image: '/placeholder.svg',
      description: 'Full-service video production studio with green screen',
      amenities: ['4K Cameras', 'Green Screen', 'Lighting Kit', 'Teleprompter', 'Editing Suite'],
      features: ['Climate Control', 'WiFi', 'Makeup Room', 'Client Lounge', 'Catering']
    },
    {
      id: 4,
      name: 'Portrait Photography Studio',
      type: 'photography',
      location: 'Downtown',
      hourlyRate: '$75',
      dailyRate: '$500',
      rating: 4.7,
      capacity: '4 people',
      size: '300 sq ft',
      availability: 'Available',
      image: '/placeholder.svg',
      description: 'Natural light photography studio with professional equipment',
      amenities: ['Strobes', 'Softboxes', 'Backdrops', 'Props', 'Changing Room'],
      features: ['Natural Light', 'WiFi', 'Makeup Station', 'Client Area']
    },
    {
      id: 5,
      name: 'Podcast Production Hub',
      type: 'podcast',
      location: 'Tech District',
      hourlyRate: '$60',
      dailyRate: '$400',
      rating: 4.5,
      capacity: '4 people',
      size: '200 sq ft',
      availability: 'Available',
      image: '/placeholder.svg',
      description: 'Acoustic-treated podcast studio with professional audio setup',
      amenities: ['Podcast Mics', 'Audio Interface', 'Headphones', 'Recording Software'],
      features: ['Sound Treatment', 'WiFi', 'Live Streaming Setup', 'Coffee/Tea']
    }
  ];

  const filteredStudios = selectedType === 'all' 
    ? studios 
    : studios.filter(studio => studio.type === selectedType);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'recording': return <Music className="w-4 h-4" />;
      case 'rehearsal': return <Users className="w-4 h-4" />;
      case 'video': return <Camera className="w-4 h-4" />;
      case 'photography': return <Camera className="w-4 h-4" />;
      case 'podcast': return <Mic className="w-4 h-4" />;
      default: return <Music className="w-4 h-4" />;
    }
  };

  const handleBookStudio = (studio: any) => {
    if (onBookStudio) {
      onBookStudio(studio);
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Studio Rentals</h2>
        <p className="text-gray-600">Professional recording, rehearsal, video, and photography studios</p>
      </div>

      <div className="flex justify-center">
        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Studio Type" />
          </SelectTrigger>
          <SelectContent>
            {studioTypes.map(type => (
              <SelectItem key={type.value} value={type.value}>
                {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredStudios.map((studio) => (
          <Card key={studio.id} className="hover:shadow-lg transition-all">
            <CardHeader className="p-0 relative">
              <img 
                src={studio.image} 
                alt={studio.name} 
                className="w-full h-32 object-cover rounded-t-lg" 
              />
              <div className="absolute top-2 right-2">
                <Badge 
                  variant={studio.availability.includes('Available') ? 'default' : 'secondary'}
                  className={studio.availability.includes('Available') ? 'bg-green-600' : 'bg-red-600'}
                >
                  {studio.availability.includes('Available') ? 'Available' : 'Booked'}
                </Badge>
              </div>
              <div className="absolute bottom-2 left-2">
                <Badge variant="secondary" className="flex items-center gap-1">
                  {getTypeIcon(studio.type)}
                  {studio.type}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="p-4 space-y-3">
              <div>
                <CardTitle className="text-lg">{studio.name}</CardTitle>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <MapPin className="w-3 h-3" />
                  <span>{studio.location}</span>
                  <span>•</span>
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <span>{studio.rating}</span>
                </div>
              </div>

              <p className="text-sm text-gray-600">{studio.description}</p>

              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{studio.hourlyRate}/hr</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  <span>{studio.dailyRate}/day</span>
                </div>
                <div className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  <span>{studio.capacity}</span>
                </div>
                <div className="text-gray-500">
                  <span>{studio.size}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Calendar className="w-4 h-4" />
                <span>{studio.availability}</span>
              </div>

              <div>
                <p className="text-xs text-gray-500 mb-1">Key Equipment:</p>
                <div className="flex flex-wrap gap-1">
                  {studio.amenities.slice(0, 3).map((amenity, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs">
                      {amenity}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-xs text-gray-500 mb-1">Features:</p>
                <div className="flex flex-wrap gap-1">
                  {studio.features.slice(0, 3).map((feature, idx) => (
                    <Badge key={idx} variant="secondary" className="text-xs">
                      {feature === 'WiFi' && <Wifi className="w-2 h-2 mr-1" />}
                      {feature}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <Button 
                  size="sm" 
                  className="flex-1"
                  disabled={!studio.availability.includes('Available')}
                  onClick={() => handleBookStudio(studio)}
                >
                  {studio.availability.includes('Available') ? 'Book Studio' : 'Unavailable'}
                </Button>
                <Button size="sm" variant="outline">
                  Tour
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default StudioRentals;