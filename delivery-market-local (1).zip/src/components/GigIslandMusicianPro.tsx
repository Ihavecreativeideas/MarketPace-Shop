import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Music, MapPin, Calendar, Star, Users, Award, Play, ExternalLink } from 'lucide-react';
import BookingModal from './BookingModal';
import AvailabilityCalendar from './AvailabilityCalendar';

interface Venue {
  name: string;
  location: string;
  date: string;
  type: string;
}

interface MusicianProfile {
  id: string;
  name: string;
  genre: string;
  location: string;
  rating: number;
  totalGigs: number;
  profileImage: string;
  biography: string;
  venues: Venue[];
  socialLinks: {
    spotify?: string;
    instagram?: string;
    youtube?: string;
    website?: string;
  };
  equipment: string[];
  priceRange: string;
  availability: string[];
}

const GigIslandMusicianPro: React.FC = () => {
  const [selectedMusician, setSelectedMusician] = useState<MusicianProfile | null>(null);
  const [showBooking, setShowBooking] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);

  const musicians: MusicianProfile[] = [
    {
      id: '1',
      name: 'Alex Rivera',
      genre: 'Jazz/Blues',
      location: 'Downtown',
      rating: 4.9,
      totalGigs: 127,
      profileImage: '/placeholder.svg',
      biography: 'Professional jazz guitarist with 10+ years of experience. Specializing in smooth jazz, blues, and contemporary fusion. Available for weddings, corporate events, and intimate venues.',
      venues: [
        { name: 'Blue Note Cafe', location: 'Downtown', date: '2024-01-15', type: 'Jazz Club' },
        { name: 'Grand Hotel Ballroom', location: 'Midtown', date: '2024-02-03', type: 'Wedding' },
        { name: 'Corporate Center', location: 'Business District', date: '2024-02-20', type: 'Corporate Event' }
      ],
      socialLinks: {
        spotify: 'https://spotify.com/alexrivera',
        instagram: '@alexriveramusic',
        youtube: 'AlexRiveraJazz'
      },
      equipment: ['Electric Guitar', 'Acoustic Guitar', 'Amplifier', 'Microphone'],
      priceRange: '$200-500/hour',
      availability: ['2024-03-15', '2024-03-22', '2024-03-29']
    }
  ];

  const handleBookNow = (musician: MusicianProfile) => {
    setSelectedMusician(musician);
    setShowBooking(true);
  };

  const handleViewAvailability = (musician: MusicianProfile) => {
    setSelectedMusician(musician);
    setShowCalendar(true);
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          MarketPace Musician Pro
        </h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Connect with professional musicians in your area. Book talent for your events with confidence.
        </p>
      </div>

      <div className="grid gap-6">
        {musicians.map((musician) => (
          <Card key={musician.id} className="overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
              <div className="flex items-start gap-4">
                <Avatar className="w-20 h-20">
                  <AvatarImage src={musician.profileImage} alt={musician.name} />
                  <AvatarFallback>{musician.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <CardTitle className="text-2xl">{musician.name}</CardTitle>
                    <Badge variant="secondary">{musician.genre}</Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {musician.location}
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      {musician.rating} ({musician.totalGigs} gigs)
                    </div>
                  </div>
                  <p className="text-gray-700">{musician.priceRange}</p>
                </div>
                <div className="flex gap-2">
                  <Button onClick={() => handleViewAvailability(musician)} variant="outline">
                    <Calendar className="w-4 h-4 mr-2" />
                    Check Availability
                  </Button>
                  <Button onClick={() => handleBookNow(musician)} className="bg-gradient-to-r from-purple-600 to-pink-600">
                    <Music className="w-4 h-4 mr-2" />
                    Book Now
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="p-6">
              <Tabs defaultValue="biography" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="biography">Biography</TabsTrigger>
                  <TabsTrigger value="venues">Venues</TabsTrigger>
                  <TabsTrigger value="equipment">Equipment</TabsTrigger>
                  <TabsTrigger value="social">Links</TabsTrigger>
                </TabsList>
                
                <TabsContent value="biography" className="mt-4">
                  <p className="text-gray-700 leading-relaxed">{musician.biography}</p>
                </TabsContent>
                
                <TabsContent value="venues" className="mt-4">
                  <div className="space-y-3">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Award className="w-4 h-4" />
                      Performance History
                    </h4>
                    {musician.venues.map((venue, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium">{venue.name}</p>
                          <p className="text-sm text-gray-600">{venue.location} • {venue.type}</p>
                        </div>
                        <Badge variant="outline">{venue.date}</Badge>
                      </div>
                    ))}
                  </div>
                </TabsContent>
                
                <TabsContent value="equipment" className="mt-4">
                  <div className="space-y-3">
                    <h4 className="font-semibold">Available Equipment</h4>
                    <div className="flex flex-wrap gap-2">
                      {musician.equipment.map((item, index) => (
                        <Badge key={index} variant="secondary">{item}</Badge>
                      ))}
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="social" className="mt-4">
                  <div className="space-y-3">
                    <h4 className="font-semibold">Social Media & Links</h4>
                    <div className="flex flex-wrap gap-3">
                      {musician.socialLinks.spotify && (
                        <Button variant="outline" size="sm" asChild>
                          <a href={musician.socialLinks.spotify} target="_blank" rel="noopener noreferrer">
                            <Play className="w-4 h-4 mr-2" />
                            Spotify
                          </a>
                        </Button>
                      )}
                      {musician.socialLinks.instagram && (
                        <Button variant="outline" size="sm" asChild>
                          <a href={`https://instagram.com/${musician.socialLinks.instagram.replace('@', '')}`} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="w-4 h-4 mr-2" />
                            Instagram
                          </a>
                        </Button>
                      )}
                      {musician.socialLinks.youtube && (
                        <Button variant="outline" size="sm" asChild>
                          <a href={`https://youtube.com/@${musician.socialLinks.youtube}`} target="_blank" rel="noopener noreferrer">
                            <Play className="w-4 h-4 mr-2" />
                            YouTube
                          </a>
                        </Button>
                      )}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedMusician && (
        <>
          <BookingModal
            isOpen={showBooking}
            onClose={() => setShowBooking(false)}
            musician={selectedMusician}
          />
          <AvailabilityCalendar
            isOpen={showCalendar}
            onClose={() => setShowCalendar(false)}
            musician={selectedMusician}
          />
        </>
      )}
    </div>
  );
};

export default GigIslandMusicianPro;