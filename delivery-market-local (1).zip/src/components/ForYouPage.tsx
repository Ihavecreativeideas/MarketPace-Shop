import React from 'react';
import { ForYouSection } from './ForYouSection';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Settings, Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ForYouPageProps {
  userId?: string;
}

const ForYouPage: React.FC<ForYouPageProps> = ({ userId = 'demo-user' }) => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-purple-900 p-4">
      {/* Header */}
      <div className="max-w-6xl mx-auto mb-8">
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back
          </Button>
          
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              className="text-white hover:bg-white/10"
            >
              <Search className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              className="text-white hover:bg-white/10"
            >
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        {/* Welcome Message */}
        <Card className="bg-white/5 backdrop-blur-lg border-white/10 mb-8">
          <CardContent className="p-6">
            <h1 className="text-2xl font-bold text-white mb-2">
              Welcome to your personalized feed!
            </h1>
            <p className="text-gray-300">
              Based on your profile and interests, here are some recommendations just for you.
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* For You Section */}
      <div className="max-w-6xl mx-auto">
        <ForYouSection userId={userId} />
      </div>
    </div>
  );
};

export default ForYouPage;