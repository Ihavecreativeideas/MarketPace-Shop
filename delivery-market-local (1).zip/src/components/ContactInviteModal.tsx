import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Users, Mail, Phone, Facebook, Copy } from 'lucide-react';

interface ContactInviteModalProps {
  children: React.ReactNode;
}

export const ContactInviteModal: React.FC<ContactInviteModalProps> = ({ children }) => {
  const { toast } = useToast();
  const [emails, setEmails] = useState('');
  const [phones, setPhones] = useState('');
  const [isInviting, setIsInviting] = useState(false);
  const [open, setOpen] = useState(false);

  const inviteUrl = window.location.origin;
  const inviteMessage = "Join me on MarketPace - the local marketplace that supports our community! Shop local, support families, and discover amazing deals.";

  const handleEmailInvites = async () => {
    if (!emails.trim()) {
      toast({ title: 'Email Required', description: 'Please enter at least one email address' });
      return;
    }

    setIsInviting(true);
    try {
      const emailList = emails.split(',').map(e => e.trim()).filter(e => e);
      
      // Simulate sending invites
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: 'Invites Sent!',
        description: `Sent ${emailList.length} email invitation(s)`
      });
      setEmails('');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send invitations',
        variant: 'destructive'
      });
    } finally {
      setIsInviting(false);
    }
  };

  const handleSMSInvites = async () => {
    if (!phones.trim()) {
      toast({ title: 'Phone Required', description: 'Please enter at least one phone number' });
      return;
    }

    setIsInviting(true);
    try {
      const phoneList = phones.split(',').map(p => p.trim()).filter(p => p);
      
      // Simulate sending SMS invites
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: 'SMS Invites Sent!',
        description: `Sent ${phoneList.length} SMS invitation(s)`
      });
      setPhones('');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send SMS invitations',
        variant: 'destructive'
      });
    } finally {
      setIsInviting(false);
    }
  };

  const handleFacebookInvite = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(inviteUrl)}&quote=${encodeURIComponent(inviteMessage)}`;
    window.open(url, '_blank', 'width=600,height=400');
    toast({ title: 'Opening Facebook', description: 'Redirecting to Facebook to invite friends' });
  };

  const copyInviteLink = async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl);
      toast({ title: 'Link Copied!', description: 'Invite link copied to clipboard' });
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to copy link', variant: 'destructive' });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Invite Contacts & Friends
          </DialogTitle>
        </DialogHeader>
        
        <Tabs defaultValue="email" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="email">Email</TabsTrigger>
            <TabsTrigger value="sms">SMS</TabsTrigger>
            <TabsTrigger value="social">Social</TabsTrigger>
          </TabsList>
          
          <TabsContent value="email" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="emails">Email Addresses</Label>
              <textarea
                id="emails"
                placeholder="Enter email addresses separated by commas"
                value={emails}
                onChange={(e) => setEmails(e.target.value)}
                className="w-full p-2 border rounded-md resize-none h-20"
              />
              <p className="text-xs text-muted-foreground">
                Separate multiple emails with commas
              </p>
            </div>
            <Button 
              onClick={handleEmailInvites} 
              disabled={isInviting}
              className="w-full"
            >
              <Mail className="h-4 w-4 mr-2" />
              {isInviting ? 'Sending...' : 'Send Email Invites'}
            </Button>
          </TabsContent>
          
          <TabsContent value="sms" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="phones">Phone Numbers</Label>
              <textarea
                id="phones"
                placeholder="Enter phone numbers separated by commas"
                value={phones}
                onChange={(e) => setPhones(e.target.value)}
                className="w-full p-2 border rounded-md resize-none h-20"
              />
              <p className="text-xs text-muted-foreground">
                Include country code (e.g., +1 555-123-4567)
              </p>
            </div>
            <Button 
              onClick={handleSMSInvites} 
              disabled={isInviting}
              className="w-full"
            >
              <Phone className="h-4 w-4 mr-2" />
              {isInviting ? 'Sending...' : 'Send SMS Invites'}
            </Button>
          </TabsContent>
          
          <TabsContent value="social" className="space-y-4">
            <Button 
              onClick={handleFacebookInvite}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              <Facebook className="h-4 w-4 mr-2" />
              Invite Facebook Friends
            </Button>
            
            <div className="space-y-2">
              <Label>Share Invite Link</Label>
              <div className="flex gap-2">
                <Input value={inviteUrl} readOnly className="text-xs" />
                <Button size="sm" variant="outline" onClick={copyInviteLink}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};