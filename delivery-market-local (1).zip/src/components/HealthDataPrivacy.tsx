import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, Heart, Lock, FileText, Users, Database } from 'lucide-react';

const HealthDataPrivacy = () => {
  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-red-500" />
            Consumer Health Data Privacy Policy
          </CardTitle>
          <CardDescription>
            How we protect and handle your health-related information
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              Your health data is subject to the highest level of protection under federal and state privacy laws.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            What Health Data We Collect
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Prescription Delivery Services:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Prescription information (medication names, dosages, quantities)</li>
              <li>• Pharmacy information and prescription numbers</li>
              <li>• Delivery addresses for medical supplies</li>
              <li>• Insurance information (when provided)</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2">Medical Equipment Marketplace:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Medical device purchases and rentals</li>
              <li>• Health-related product searches</li>
              <li>• Medical supply delivery preferences</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2">We DO NOT Collect:</h3>
            <ul className="space-y-1 text-sm text-red-600">
              <li>• Medical diagnoses or health conditions</li>
              <li>• Doctor's notes or medical records</li>
              <li>• Genetic information</li>
              <li>• Mental health information</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5" />
            How We Protect Your Health Data
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Technical Safeguards:</h3>
            <ul className="space-y-1 text-sm">
              <li>• End-to-end encryption for all health data transmission</li>
              <li>• Secure, HIPAA-compliant data storage</li>
              <li>• Multi-factor authentication for access</li>
              <li>• Regular security audits and penetration testing</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2">Administrative Safeguards:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Limited access on a need-to-know basis</li>
              <li>• Employee training on health data privacy</li>
              <li>• Background checks for staff handling health data</li>
              <li>• Incident response procedures</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2">Physical Safeguards:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Secure data centers with restricted access</li>
              <li>• Biometric access controls</li>
              <li>• 24/7 monitoring and surveillance</li>
              <li>• Secure disposal of physical media</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Who Has Access to Your Health Data
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Authorized Personnel Only:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Licensed pharmacists (for prescription deliveries)</li>
              <li>• Delivery drivers (limited to delivery information only)</li>
              <li>• Customer service representatives (with your consent)</li>
              <li>• IT security staff (for system maintenance only)</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2">We Never Share With:</h3>
            <ul className="space-y-1 text-sm text-red-600">
              <li>• Advertisers or marketing companies</li>
              <li>• Insurance companies (unless required by law)</li>
              <li>• Employers or potential employers</li>
              <li>• Social media platforms</li>
              <li>• Data brokers or analytics companies</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            Your Rights Regarding Health Data
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">You Have the Right To:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Access your health data we have collected</li>
              <li>• Request corrections to inaccurate health data</li>
              <li>• Delete your health data (with some exceptions)</li>
              <li>• Restrict how we use your health data</li>
              <li>• Receive a copy of your health data</li>
              <li>• File a complaint with regulatory authorities</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2">Data Retention:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Prescription data: Retained for 7 years (legal requirement)</li>
              <li>• Medical device purchases: Retained for 3 years</li>
              <li>• Delivery records: Retained for 1 year</li>
              <li>• Account closure: Health data deleted within 30 days</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Legal Compliance</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-sm space-y-2">
            <p><strong>HIPAA Compliance:</strong> We comply with the Health Insurance Portability and Accountability Act</p>
            <p><strong>State Privacy Laws:</strong> We adhere to applicable state health privacy regulations</p>
            <p><strong>FDA Regulations:</strong> Medical device sales comply with FDA requirements</p>
            <p><strong>DEA Regulations:</strong> Prescription deliveries follow DEA guidelines</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Data Breach Notification</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm">
            In the unlikely event of a data breach involving your health information, we will:
          </p>
          <ul className="space-y-1 text-sm">
            <li>• Notify you within 60 days of discovery</li>
            <li>• Report to relevant authorities within 72 hours</li>
            <li>• Provide details about what information was involved</li>
            <li>• Explain steps we're taking to address the breach</li>
            <li>• Offer credit monitoring services if applicable</li>
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Contact Our Privacy Officer</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm mb-4">
            For questions about your health data privacy or to exercise your rights:
          </p>
          <div className="text-sm space-y-1">
            <p><strong>Privacy Officer:</strong> Dr. Sarah Johnson, CIPP/US</p>
            <p><strong>Email:</strong> healthprivacy@marketpace.com</p>
            <p><strong>Phone:</strong> 1-800-HEALTH-1 (1-800-432-5841)</p>
            <p><strong>Mail:</strong> MarketPace Health Privacy Office, 123 Privacy Lane, Secure City, SC 12345</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HealthDataPrivacy;