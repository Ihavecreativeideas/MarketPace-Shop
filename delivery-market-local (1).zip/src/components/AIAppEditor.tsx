import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Wand2, Palette, Layout, Code, Sparkles, Eye, Save, RefreshCw } from 'lucide-react';

export default function AIAppEditor() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedTheme, setSelectedTheme] = useState('modern');
  const [aiPrompt, setAiPrompt] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  
  const themes = [
    { id: 'modern', name: 'Modern', colors: ['#0F172A', '#1E293B', '#334155'] },
    { id: 'vibrant', name: 'Vibrant', colors: ['#7C3AED', '#EC4899', '#F59E0B'] },
    { id: 'nature', name: 'Nature', colors: ['#059669', '#0D9488', '#84CC16'] },
    { id: 'sunset', name: 'Sunset', colors: ['#DC2626', '#EA580C', '#F59E0B'] }
  ];

  const handleAIGenerate = async () => {
    setIsGenerating(true);
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setGeneratedCode(`
// AI Generated Component
import React from 'react';
import { Card } from '@/components/ui/card';

export default function AIGeneratedComponent() {
  return (
    <Card className="p-6 bg-gradient-to-r from-purple-500 to-pink-500">
      <h2 className="text-2xl font-bold text-white mb-4">
        AI Enhanced Feature
      </h2>
      <p className="text-white/90">
        This component was generated based on your prompt: "${aiPrompt}"
      </p>
    </Card>
  );
}
    `.trim());
    
    setIsGenerating(false);
  };

  const layoutTemplates = [
    { id: 'dashboard', name: 'Dashboard Layout', preview: '📊 Dashboard' },
    { id: 'ecommerce', name: 'E-commerce Layout', preview: '🛒 Shop' },
    { id: 'social', name: 'Social Media Layout', preview: '👥 Social' },
    { id: 'landing', name: 'Landing Page Layout', preview: '🚀 Landing' }
  ];

  return (
    <div className="space-y-6">
      {/* AI Assistant Header */}
      <Card className="border-l-4 border-l-purple-500 bg-gradient-to-r from-purple-50 to-pink-50">
        <CardHeader>
          <CardTitle className="flex items-center text-purple-600">
            <Sparkles className="h-5 w-5 mr-2" />
            AI App Editor Assistant
            <Badge className="ml-2 bg-purple-500">Powered by AI</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            Describe what you want to create or modify, and I'll help you build it with advanced coding assistance.
          </p>
          <div className="flex gap-2">
            <Textarea
              placeholder="Describe your app changes... (e.g., 'Create a modern dashboard with dark theme and animated charts')"
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              className="flex-1"
            />
            <Button 
              onClick={handleAIGenerate} 
              disabled={isGenerating || !aiPrompt}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              {isGenerating ? (
                <RefreshCw className="h-4 w-4 animate-spin" />
              ) : (
                <Wand2 className="h-4 w-4" />
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="themes" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="themes" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            Themes
          </TabsTrigger>
          <TabsTrigger value="layouts" className="flex items-center gap-2">
            <Layout className="h-4 w-4" />
            Layouts
          </TabsTrigger>
          <TabsTrigger value="code" className="flex items-center gap-2">
            <Code className="h-4 w-4" />
            Code Editor
          </TabsTrigger>
          <TabsTrigger value="preview" className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            Preview
          </TabsTrigger>
        </TabsList>

        <TabsContent value="themes">
          <Card>
            <CardHeader>
              <CardTitle>Color Themes & Styling</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {themes.map((theme) => (
                  <div
                    key={theme.id}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedTheme === theme.id ? 'border-purple-500 bg-purple-50' : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedTheme(theme.id)}
                  >
                    <div className="flex gap-1 mb-2">
                      {theme.colors.map((color, index) => (
                        <div
                          key={index}
                          className="w-6 h-6 rounded-full"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                    <div className="font-medium">{theme.name}</div>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <h4 className="font-medium mb-2">AI Theme Suggestions</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="cursor-pointer hover:bg-purple-50">
                    Generate Dark Mode
                  </Badge>
                  <Badge variant="outline" className="cursor-pointer hover:bg-purple-50">
                    Create Gradient Theme
                  </Badge>
                  <Badge variant="outline" className="cursor-pointer hover:bg-purple-50">
                    Brand Color Palette
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="layouts">
          <Card>
            <CardHeader>
              <CardTitle>Layout Templates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {layoutTemplates.map((template) => (
                  <div
                    key={template.id}
                    className="p-6 border-2 border-dashed border-gray-300 rounded-lg hover:border-purple-500 hover:bg-purple-50 cursor-pointer transition-all text-center"
                  >
                    <div className="text-4xl mb-2">{template.preview}</div>
                    <div className="font-medium">{template.name}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="code">
          <Card>
            <CardHeader>
              <CardTitle>AI Code Generator</CardTitle>
            </CardHeader>
            <CardContent>
              {generatedCode ? (
                <div className="space-y-4">
                  <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                    <pre>{generatedCode}</pre>
                  </div>
                  <div className="flex gap-2">
                    <Button className="bg-green-600 hover:bg-green-700">
                      <Save className="h-4 w-4 mr-2" />
                      Apply Changes
                    </Button>
                    <Button variant="outline">
                      <Eye className="h-4 w-4 mr-2" />
                      Preview
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Code className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Use the AI prompt above to generate code</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preview">
          <Card>
            <CardHeader>
              <CardTitle>Live Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <div className="text-6xl mb-4">🎨</div>
                <h3 className="text-xl font-bold mb-2">Preview Mode</h3>
                <p className="text-muted-foreground">
                  Your AI-generated changes will appear here in real-time
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}