import React from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { CheckCircle } from 'lucide-react'

const TestComponent = () => {
  return (
    <Card className="bg-green-500/20 border-green-400/30 backdrop-blur-lg">
      <CardContent className="p-4">
        <div className="flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-green-400" />
          <span className="font-semibold text-green-300">App Status</span>
        </div>
        <p className="text-sm text-green-200">All components loaded successfully</p>
      </CardContent>
    </Card>
  )
}

export default TestComponent