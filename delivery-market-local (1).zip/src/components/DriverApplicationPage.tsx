import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Car, DollarSign, Clock, Shield, FileText, CheckCircle, AlertTriangle } from 'lucide-react';
import { useToast } from './ui/use-toast';

interface DriverApplicationPageProps {
  onClose?: () => void;
}

const DriverApplicationPage: React.FC<DriverApplicationPageProps> = ({ onClose }) => {
  const { toast } = useToast();

  const handleApply = () => {
    toast({
      title: "Application Started!",
      description: "Redirecting to full application form..."
    });
    // Navigate to full driver application
  };

  const payStructure = [
    { type: 'Local Delivery', rate: '$3-8 per delivery', time: '15-30 min' },
    { type: 'Pharmacy Run', rate: '$5-12 per delivery', time: '20-45 min' },
    { type: 'Large Items', rate: '$15-50 per delivery', time: '45-90 min' },
    { type: 'Rush Orders', rate: '+50% bonus', time: 'Priority' }
  ];

  const requirements = [
    'Valid Driver License (required)',
    'Valid Auto Insurance (required)',
    'Background Check (self-provided)',
    'Pass Background Check Verification',
    'Own Vehicle (car, truck, or motorcycle)',
    'Smartphone with GPS capability'
  ];

  const benefits = [
    'Flexible Schedule - Work When You Want',
    'Keep 100% of Tips',
    'Weekly Direct Deposit',
    'Fuel Reimbursement Program',
    'Driver Support 24/7',
    'Performance Bonuses'
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <Card className="bg-gradient-to-br from-slate-900 via-green-900 to-blue-900 border-green-500/30 text-white">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <Car className="w-8 h-8 mr-3 text-green-400" />
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
              Drive with MarketPace
            </CardTitle>
          </div>
          <p className="text-green-300 text-lg">
            Join our delivery network as an Independent Contractor
          </p>
          <Badge className="bg-green-500/20 text-green-300 border-green-500/30 mx-auto">
            Now Hiring in Your Area
          </Badge>
        </CardHeader>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Job Description */}
        <Card className="bg-slate-800 border-green-500/30">
          <CardHeader>
            <CardTitle className="text-green-400 flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              Job Description
            </CardTitle>
          </CardHeader>
          <CardContent className="text-white space-y-4">
            <p className="text-gray-300">
              As a MarketPace delivery driver, you'll help connect local businesses with customers by providing fast, reliable delivery services.
            </p>
            <div>
              <h4 className="font-semibold text-green-400 mb-2">Your Responsibilities:</h4>
              <ul className="space-y-1 text-sm text-gray-300">
                <li>• Pick up orders from local businesses</li>
                <li>• Deliver items safely to customers</li>
                <li>• Provide excellent customer service</li>
                <li>• Use our driver app for navigation and updates</li>
                <li>• Handle payments through the app</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-green-400 mb-2">Benefits:</h4>
              <ul className="space-y-1 text-sm text-gray-300">
                {benefits.map((benefit, index) => (
                  <li key={index} className="flex items-center">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-400" />
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Payment Structure */}
        <Card className="bg-slate-800 border-green-500/30">
          <CardHeader>
            <CardTitle className="text-green-400 flex items-center">
              <DollarSign className="w-5 h-5 mr-2" />
              Payment Structure
            </CardTitle>
          </CardHeader>
          <CardContent className="text-white space-y-4">
            <div className="space-y-3">
              {payStructure.map((pay, index) => (
                <div key={index} className="bg-slate-700 rounded-lg p-3">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-green-400">{pay.type}</span>
                    <Badge className="bg-green-500/20 text-green-300">{pay.rate}</Badge>
                  </div>
                  <div className="flex items-center mt-1">
                    <Clock className="w-4 h-4 mr-1 text-gray-400" />
                    <span className="text-sm text-gray-400">{pay.time}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="bg-blue-900/30 rounded-lg p-3 border border-blue-500/30">
              <h4 className="font-semibold text-blue-400 mb-2">Earning Potential:</h4>
              <p className="text-sm text-blue-300">
                Active drivers typically earn $15-25/hour during peak times. Earnings vary based on location, time, and demand.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Requirements & Important Info */}
      <Card className="bg-slate-800 border-yellow-500/30">
        <CardHeader>
          <CardTitle className="text-yellow-400 flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2" />
            Requirements & Important Information
          </CardTitle>
        </CardHeader>
        <CardContent className="text-white space-y-4">
          <div className="bg-yellow-900/20 rounded-lg p-4 border border-yellow-500/30">
            <h4 className="font-semibold text-yellow-400 mb-2 flex items-center">
              <Shield className="w-4 h-4 mr-2" />
              Independent Contractor Status
            </h4>
            <p className="text-sm text-yellow-200 mb-3">
              You will be hired as an Independent Contractor, not an employee. This means:
            </p>
            <ul className="text-sm text-yellow-200 space-y-1">
              <li>• You are responsible for your own taxes</li>
              <li>• You set your own schedule and work when you want</li>
              <li>• You use your own vehicle and cover your own expenses</li>
              <li>• You are your own boss with the freedom to work multiple platforms</li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-green-400 mb-3">Requirements Checklist:</h4>
            <div className="grid md:grid-cols-2 gap-2">
              {requirements.map((req, index) => (
                <div key={index} className="flex items-center text-sm">
                  <CheckCircle className="w-4 h-4 mr-2 text-green-400" />
                  <span className="text-gray-300">{req}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-red-900/20 rounded-lg p-4 border border-red-500/30">
            <h4 className="font-semibold text-red-400 mb-2">Background Check Requirements:</h4>
            <p className="text-sm text-red-200">
              You must provide and pass your own background check from an approved provider. 
              We will verify the results but you are responsible for obtaining and paying for the background check.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Apply Button */}
      <div className="text-center">
        <Button 
          onClick={handleApply}
          size="lg"
          className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white px-8 py-3 text-lg"
        >
          <Car className="w-5 h-5 mr-2" />
          Start Application Process
        </Button>
        <p className="text-sm text-gray-400 mt-2">
          Application takes 5-10 minutes to complete
        </p>
      </div>
    </div>
  );
};

export default DriverApplicationPage;