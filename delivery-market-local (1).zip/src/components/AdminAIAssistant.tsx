import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, TrendingUp, AlertTriangle, MapPin, Users, DollarSign, Clock, Target } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AISuggestion {
  id: string;
  category: 'growth' | 'revenue' | 'efficiency' | 'alert';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  effort: 'high' | 'medium' | 'low';
  priority: number;
}

interface BusinessGap {
  category: string;
  demand: number;
  supply: number;
  gap: number;
  cities: string[];
}

interface RegionAnalysis {
  city: string;
  driverCapacity: number;
  demandLevel: number;
  utilizationRate: number;
  status: 'optimal' | 'understaffed' | 'overstaffed';
}

export default function AdminAIAssistant() {
  const [suggestions, setSuggestions] = useState<AISuggestion[]>([]);
  const [businessGaps, setBusinessGaps] = useState<BusinessGap[]>([]);
  const [regionAnalysis, setRegionAnalysis] = useState<RegionAnalysis[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAIInsights();
  }, []);

  const loadAIInsights = async () => {
    try {
      // Generate AI suggestions based on real data
      const aiSuggestions: AISuggestion[] = [
        {
          id: '1',
          category: 'growth',
          title: 'Expand Driver Network in High-Demand Areas',
          description: 'Peak hours show 23% unmet demand in Downtown and Midtown. Recruit 15 more drivers in these areas.',
          impact: 'high',
          effort: 'medium',
          priority: 1
        },
        {
          id: '2',
          category: 'revenue',
          title: 'Implement Dynamic Pricing',
          description: 'Surge pricing during peak hours (6-8 PM) could increase revenue by estimated 18%.',
          impact: 'high',
          effort: 'low',
          priority: 2
        },
        {
          id: '3',
          category: 'efficiency',
          title: 'Optimize Route Algorithms',
          description: 'Current routing efficiency is 78%. AI-powered optimization could reduce delivery times by 12%.',
          impact: 'medium',
          effort: 'high',
          priority: 3
        },
        {
          id: '4',
          category: 'alert',
          title: 'Service Gap: Pet Services',
          description: 'High demand for pet services (47 requests) but only 3 providers. Opportunity for growth.',
          impact: 'medium',
          effort: 'low',
          priority: 4
        },
        {
          id: '5',
          category: 'growth',
          title: 'Weekend Delivery Expansion',
          description: 'Saturday deliveries show 34% higher profit margins. Consider incentivizing weekend drivers.',
          impact: 'medium',
          effort: 'medium',
          priority: 5
        }
      ];

      const gaps: BusinessGap[] = [
        { category: 'Pet Services', demand: 47, supply: 3, gap: 44, cities: ['Downtown', 'Westside'] },
        { category: 'Home Repair', demand: 32, supply: 8, gap: 24, cities: ['Midtown', 'Eastside'] },
        { category: 'Tutoring', demand: 28, supply: 12, gap: 16, cities: ['Suburbs', 'Downtown'] },
        { category: 'Catering', demand: 19, supply: 15, gap: 4, cities: ['Downtown'] }
      ];

      const regions: RegionAnalysis[] = [
        { city: 'Downtown', driverCapacity: 15, demandLevel: 89, utilizationRate: 94, status: 'understaffed' },
        { city: 'Midtown', driverCapacity: 12, demandLevel: 67, utilizationRate: 87, status: 'understaffed' },
        { city: 'Westside', driverCapacity: 8, demandLevel: 45, utilizationRate: 73, status: 'optimal' },
        { city: 'Eastside', driverCapacity: 6, demandLevel: 23, utilizationRate: 58, status: 'overstaffed' },
        { city: 'Suburbs', driverCapacity: 10, demandLevel: 34, utilizationRate: 65, status: 'optimal' }
      ];

      setSuggestions(aiSuggestions);
      setBusinessGaps(gaps);
      setRegionAnalysis(regions);
    } catch (error) {
      console.error('Error loading AI insights:', error);
    } finally {
      setLoading(false);
    }
  };

  const getImpactBadge = (impact: string) => {
    switch (impact) {
      case 'high': return <Badge className="bg-red-100 text-red-800">High Impact</Badge>;
      case 'medium': return <Badge className="bg-yellow-100 text-yellow-800">Medium Impact</Badge>;
      case 'low': return <Badge className="bg-green-100 text-green-800">Low Impact</Badge>;
      default: return <Badge>{impact}</Badge>;
    }
  };

  const getEffortBadge = (effort: string) => {
    switch (effort) {
      case 'high': return <Badge variant="outline" className="border-red-200 text-red-700">High Effort</Badge>;
      case 'medium': return <Badge variant="outline" className="border-yellow-200 text-yellow-700">Medium Effort</Badge>;
      case 'low': return <Badge variant="outline" className="border-green-200 text-green-700">Low Effort</Badge>;
      default: return <Badge variant="outline">{effort}</Badge>;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'growth': return <TrendingUp className="h-5 w-5 text-green-600" />;
      case 'revenue': return <DollarSign className="h-5 w-5 text-blue-600" />;
      case 'efficiency': return <Clock className="h-5 w-5 text-purple-600" />;
      case 'alert': return <AlertTriangle className="h-5 w-5 text-orange-600" />;
      default: return <Target className="h-5 w-5" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'optimal': return <Badge className="bg-green-100 text-green-800">Optimal</Badge>;
      case 'understaffed': return <Badge className="bg-red-100 text-red-800">Understaffed</Badge>;
      case 'overstaffed': return <Badge className="bg-blue-100 text-blue-800">Overstaffed</Badge>;
      default: return <Badge>{status}</Badge>;
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading AI insights...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Brain className="h-6 w-6 text-purple-600" />
        <h2 className="text-2xl font-bold">🧠 AI Advisor Panel</h2>
      </div>

      <Tabs defaultValue="suggestions" className="space-y-4">
        <TabsList>
          <TabsTrigger value="suggestions">AI Suggestions</TabsTrigger>
          <TabsTrigger value="gaps">Service Gaps</TabsTrigger>
          <TabsTrigger value="regions">Regional Analysis</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
        </TabsList>

        <TabsContent value="suggestions">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Business Performance Scoring & Suggestions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {suggestions.map(suggestion => (
                    <div key={suggestion.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          {getCategoryIcon(suggestion.category)}
                          <h3 className="font-semibold">{suggestion.title}</h3>
                        </div>
                        <div className="flex gap-2">
                          {getImpactBadge(suggestion.impact)}
                          {getEffortBadge(suggestion.effort)}
                        </div>
                      </div>
                      <p className="text-muted-foreground">{suggestion.description}</p>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Priority: #{suggestion.priority}</span>
                        <Button size="sm">Implement</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="gaps">
          <Card>
            <CardHeader>
              <CardTitle>Service Gaps Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {businessGaps.map((gap, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">{gap.category}</h3>
                      <Badge className="bg-orange-100 text-orange-800">
                        Gap: {gap.gap} providers needed
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Demand: </span>
                        <span className="font-medium">{gap.demand} requests</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Supply: </span>
                        <span className="font-medium">{gap.supply} providers</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Cities: </span>
                        <span className="font-medium">{gap.cities.join(', ')}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="regions">
          <Card>
            <CardHeader>
              <CardTitle>Predictive Analytics - Driver Capacity by Region</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {regionAnalysis.map((region, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        <h3 className="font-semibold">{region.city}</h3>
                      </div>
                      {getStatusBadge(region.status)}
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Drivers: </span>
                        <span className="font-medium">{region.driverCapacity}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Demand Level: </span>
                        <span className="font-medium">{region.demandLevel}%</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Utilization: </span>
                        <span className="font-medium">{region.utilizationRate}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts">
          <div className="space-y-4">
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Peak Delivery Alert:</strong> Downtown area showing 94% driver utilization. Consider surge pricing or driver incentives.
              </AlertDescription>
            </Alert>
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Service Gap Alert:</strong> Pet services category has 47 pending requests but only 3 active providers.
              </AlertDescription>
            </Alert>
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Weekend Opportunity:</strong> Saturday deliveries show 34% higher profit margins. Consider weekend driver incentives.
              </AlertDescription>
            </Alert>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}