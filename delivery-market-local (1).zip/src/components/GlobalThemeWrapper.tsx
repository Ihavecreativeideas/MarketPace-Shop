import React from 'react';

interface GlobalThemeWrapperProps {
  children: React.ReactNode;
}

const GlobalThemeWrapper: React.FC<GlobalThemeWrapperProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-cyan-900 via-indigo-900 to-purple-900">
      <div className="min-h-screen backdrop-blur-sm">
        {children}
      </div>
      
      {/* Global style overrides */}
      <style jsx global>{`
        /* Force futuristic theme on all elements */
        * {
          scrollbar-width: thin;
          scrollbar-color: #06b6d4 #1e293b;
        }
        
        *::-webkit-scrollbar {
          width: 8px;
        }
        
        *::-webkit-scrollbar-track {
          background: #1e293b;
          border-radius: 4px;
        }
        
        *::-webkit-scrollbar-thumb {
          background: linear-gradient(135deg, #06b6d4, #8b5cf6);
          border-radius: 4px;
        }
        
        *::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(135deg, #0891b2, #7c3aed);
        }
        
        /* Override any remaining white backgrounds */
        .bg-white, .bg-gray-50, .bg-gray-100 {
          background: rgba(15, 23, 42, 0.9) !important;
          color: rgb(248, 250, 252) !important;
        }
        
        /* Ensure text is visible */
        .text-black, .text-gray-900 {
          color: rgb(248, 250, 252) !important;
        }
        
        /* Style form elements */
        input, textarea, select {
          background: rgba(15, 23, 42, 0.8) !important;
          border: 1px solid rgba(6, 182, 212, 0.3) !important;
          color: rgb(248, 250, 252) !important;
          border-radius: 8px !important;
        }
        
        input::placeholder, textarea::placeholder {
          color: rgb(148, 163, 184) !important;
        }
        
        /* Style modals and dropdowns */
        .modal, .dropdown, .popover {
          background: rgba(15, 23, 42, 0.95) !important;
          border: 1px solid rgba(6, 182, 212, 0.4) !important;
          backdrop-filter: blur(20px) !important;
        }
      `}</style>
    </div>
  );
};

export default GlobalThemeWrapper;