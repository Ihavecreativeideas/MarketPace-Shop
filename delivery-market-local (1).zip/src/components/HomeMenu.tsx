import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthProvider';
import { 
  User, 
  BarChart3, 
  MessageSquare, 
  Bell, 
  Heart, 
  Store, 
  Wrench, 
  Music, 
  Shield, 
  Calendar, 
  Bookmark, 
  HelpCircle,
  X,
  Package
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface HomeMenuProps {
  onClose: () => void;
}

const HomeMenu: React.FC<HomeMenuProps> = ({ onClose }) => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const menuItems = [
    { icon: User, label: 'Profile', path: '/profile' },
    { icon: BarChart3, label: 'Analysis', path: '/analysis' },
    { icon: MessageSquare, label: 'Messages', path: '/messages' },
    { icon: Bell, label: 'Notifications', path: '/notifications' },
    { icon: Heart, label: 'Favorites', path: '/favorites' },
    { icon: Store, label: 'Shops', path: '/shops' },
    { icon: Wrench, label: 'Services', path: '/services' },
    { icon: Music, label: 'Entertainment Hub', path: '/entertainment' },
    { icon: Package, label: 'Rent Anything', path: '/rent-anything' },
    { icon: Shield, label: 'Privacy Policy', path: '/privacy' },
    { icon: Calendar, label: 'Events', path: '/events' },
    { icon: Bookmark, label: 'Saved', path: '/saved' },
    { icon: HelpCircle, label: 'Contact Support', path: '/support' }
  ];

  const handleNavigation = (path: string) => {
    navigate(path);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <div className="w-full max-w-md mx-auto bg-white rounded-t-3xl p-6 max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold">Menu</h2>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {user && (
          <div className="flex items-center gap-3 mb-6 p-3 bg-blue-50 rounded-lg">
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
              <User className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="font-medium">{user.email}</p>
              <p className="text-sm text-gray-600">Member</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Card 
                key={item.path} 
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => handleNavigation(item.path)}
              >
                <CardContent className="p-4 flex flex-col items-center text-center">
                  <Icon className="h-6 w-6 text-blue-600 mb-2" />
                  <span className="text-sm font-medium">{item.label}</span>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-6 pt-6 border-t">
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => handleNavigation('/support')}
          >
            <HelpCircle className="h-4 w-4 mr-2" />
            Need Help? Contact AI Assistant
          </Button>
        </div>
      </div>
    </div>
  );
};

export default HomeMenu;