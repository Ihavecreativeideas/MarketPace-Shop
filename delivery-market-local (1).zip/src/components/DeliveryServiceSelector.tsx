import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Truck, Package, Clock, DollarSign } from 'lucide-react';

interface DeliveryService {
  id: string;
  name: string;
  logo: string;
  baseRate: number;
  estimatedTime: string;
  description: string;
  features: string[];
}

interface DeliveryServiceSelectorProps {
  onServiceSelect: (services: string[], customRates: Record<string, number>) => void;
}

const DeliveryServiceSelector: React.FC<DeliveryServiceSelectorProps> = ({ onServiceSelect }) => {
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [customRates, setCustomRates] = useState<Record<string, number>>({});

  const deliveryServices: DeliveryService[] = [
    {
      id: 'marketpace',
      name: 'MarketPace Delivery',
      logo: '🚚',
      baseRate: 5.99,
      estimatedTime: '30-60 min',
      description: 'Fast local delivery by MarketPace drivers',
      features: ['Real-time tracking', 'Local drivers', 'Same-day delivery']
    },
    {
      id: 'ups',
      name: 'UPS',
      logo: '📦',
      baseRate: 8.99,
      estimatedTime: '1-3 days',
      description: 'Reliable nationwide shipping',
      features: ['Package tracking', 'Insurance included', 'Signature required']
    },
    {
      id: 'fedex',
      name: 'FedEx',
      logo: '✈️',
      baseRate: 9.99,
      estimatedTime: '1-2 days',
      description: 'Express shipping nationwide',
      features: ['Overnight available', 'Package tracking', 'Delivery confirmation']
    },
    {
      id: 'doordash',
      name: 'DoorDash',
      logo: '🏃',
      baseRate: 4.99,
      estimatedTime: '20-45 min',
      description: 'Quick local delivery',
      features: ['Fast delivery', 'Real-time tracking', 'Local coverage']
    },
    {
      id: 'ubereats',
      name: 'Uber Eats',
      logo: '🚗',
      baseRate: 4.99,
      estimatedTime: '25-40 min',
      description: 'On-demand delivery service',
      features: ['Quick delivery', 'Live tracking', 'Flexible scheduling']
    },
    {
      id: 'shipt',
      name: 'Shipt',
      logo: '🛍️',
      baseRate: 7.99,
      estimatedTime: '1-2 hours',
      description: 'Personal shopping and delivery',
      features: ['Personal shopper', 'Same-day delivery', 'Special requests']
    }
  ];

  const handleServiceToggle = (serviceId: string) => {
    setSelectedServices(prev => {
      const newSelected = prev.includes(serviceId)
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId];
      
      return newSelected;
    });
  };

  const handleCustomRateChange = (serviceId: string, rate: number) => {
    setCustomRates(prev => ({
      ...prev,
      [serviceId]: rate
    }));
  };

  const handleSave = () => {
    onServiceSelect(selectedServices, customRates);
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <Card className="bg-gradient-to-br from-slate-900 via-cyan-900 to-purple-900 border-cyan-500/30 text-white">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-cyan-300 flex items-center gap-2">
            <Truck className="h-6 w-6" />
            Choose Your Delivery Services
          </CardTitle>
          <p className="text-cyan-200">
            Select which delivery services you want to offer and set your custom shipping rates
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {deliveryServices.map((service) => {
              const isSelected = selectedServices.includes(service.id);
              const customRate = customRates[service.id] || service.baseRate;
              
              return (
                <Card key={service.id} className={`bg-slate-800 border-2 transition-all cursor-pointer ${
                  isSelected ? 'border-cyan-400 bg-slate-700' : 'border-slate-600 hover:border-cyan-500/50'
                }`}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="text-2xl">{service.logo}</div>
                        <div>
                          <h3 className="font-semibold text-white">{service.name}</h3>
                          <p className="text-sm text-cyan-300 flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {service.estimatedTime}
                          </p>
                        </div>
                      </div>
                      <Checkbox
                        checked={isSelected}
                        onCheckedChange={() => handleServiceToggle(service.id)}
                        className="border-cyan-400"
                      />
                    </div>
                    
                    <p className="text-sm text-cyan-200 mb-3">{service.description}</p>
                    
                    <div className="flex flex-wrap gap-1 mb-3">
                      {service.features.map((feature) => (
                        <Badge key={feature} variant="secondary" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-cyan-300">Base Rate:</span>
                        <span className="font-semibold text-green-400">${service.baseRate}</span>
                      </div>
                      
                      {isSelected && (
                        <div className="space-y-2">
                          <Label htmlFor={`rate-${service.id}`} className="text-sm text-cyan-300">
                            Your Custom Rate:
                          </Label>
                          <div className="flex items-center gap-2">
                            <DollarSign className="h-4 w-4 text-cyan-400" />
                            <Input
                              id={`rate-${service.id}`}
                              type="number"
                              step="0.01"
                              min="0"
                              value={customRate}
                              onChange={(e) => handleCustomRateChange(service.id, parseFloat(e.target.value) || 0)}
                              className="bg-slate-700 border-cyan-500/30 text-white"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          
          {selectedServices.length > 0 && (
            <Card className="bg-slate-800 border-cyan-500/30">
              <CardHeader>
                <CardTitle className="text-lg text-cyan-300">Selected Services Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {selectedServices.map((serviceId) => {
                    const service = deliveryServices.find(s => s.id === serviceId);
                    const rate = customRates[serviceId] || service?.baseRate || 0;
                    
                    return (
                      <div key={serviceId} className="flex justify-between items-center">
                        <span className="text-white">{service?.name}</span>
                        <span className="text-green-400 font-semibold">${rate.toFixed(2)}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
          
          <div className="flex justify-end gap-3">
            <Button variant="outline" className="border-cyan-500 text-cyan-300">
              Cancel
            </Button>
            <Button 
              onClick={handleSave}
              className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
              disabled={selectedServices.length === 0}
            >
              Save Delivery Options
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DeliveryServiceSelector;