import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { User, MapPin, Star, Package, Users, Award, Store, Globe, Settings, Edit, Camera } from 'lucide-react';

const ProfileOverview: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  
  const profileData = {
    name: 'John Doe',
    bio: 'Local entrepreneur passionate about connecting communities through commerce.',
    address: '123 Main St, Springfield, IL',
    radius: 15,
    interests: ['Electronics', 'Music', 'Home & Garden'],
    accountType: 'dual' as 'personal' | 'dual',
    businessType: 'shops' as 'shops' | 'services' | 'entertainment',
    websiteUrl: 'https://johnselectronics.com',
    verified: true,
    rating: 4.9,
    reviewCount: 47
  };

  const userStats = [
    { label: 'Listings', value: 24, icon: Package, color: 'text-blue-500' },
    { label: 'Reviews', value: 47, icon: Star, color: 'text-yellow-500' },
    { label: 'Followers', value: 312, icon: Users, color: 'text-green-500' },
    { label: 'Sales', value: 89, icon: Award, color: 'text-purple-500' }
  ];

  const businessMetrics = [
    { label: 'Monthly Revenue', value: '$2,450', change: '+12%' },
    { label: 'Conversion Rate', value: '3.2%', change: '+0.8%' },
    { label: 'Website Visits', value: '1,234', change: '+24%' },
    { label: 'Avg. Order Value', value: '$67', change: '+5%' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Profile Header */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center gap-6">
              <div className="relative">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <User className="w-10 h-10 text-white" />
                </div>
                <Button size="sm" className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full p-0">
                  <Camera className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-2xl font-bold">{profileData.name}</h1>
                  {profileData.verified && (
                    <Badge className="bg-green-100 text-green-800">Verified</Badge>
                  )}
                  {profileData.accountType === 'dual' && (
                    <Badge className="bg-blue-100 text-blue-800">Business</Badge>
                  )}
                </div>
                <div className="flex items-center gap-2 text-gray-600 mb-2">
                  <MapPin className="w-4 h-4" />
                  <span>{profileData.address}</span>
                </div>
                <p className="text-gray-700 mb-3">{profileData.bio}</p>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span className="font-medium">{profileData.rating}</span>
                    <span className="text-gray-500">({profileData.reviewCount} reviews)</span>
                  </div>
                  <div className="text-sm text-gray-500">
                    Delivery radius: {profileData.radius} miles
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
                <Button variant="outline">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {userStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index}>
                <CardContent className="p-4 text-center">
                  <Icon className={`w-6 h-6 mx-auto mb-2 ${stat.color}`} />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="personal">Personal</TabsTrigger>
            <TabsTrigger value="business">Business</TabsTrigger>
            <TabsTrigger value="interests">Interests</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Account Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Account Type:</span>
                      <Badge variant={profileData.accountType === 'dual' ? 'default' : 'secondary'}>
                        {profileData.accountType === 'dual' ? 'Dual Account' : 'Personal'}
                      </Badge>
                    </div>
                    {profileData.accountType === 'dual' && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Business Type:</span>
                        <Badge variant="outline" className="capitalize">
                          {profileData.businessType}
                        </Badge>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-gray-600">Member Since:</span>
                      <span>January 2024</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Verification:</span>
                      <Badge className="bg-green-100 text-green-800">Verified</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Button className="w-full justify-start">
                      <Package className="w-4 h-4 mr-2" />
                      Add New Listing
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Globe className="w-4 h-4 mr-2" />
                      Website Integration
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Settings className="w-4 h-4 mr-2" />
                      Account Settings
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="personal" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700">Full Name</label>
                      <p className="mt-1 text-sm text-gray-900">{profileData.name}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Address</label>
                      <p className="mt-1 text-sm text-gray-900">{profileData.address}</p>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Bio</label>
                    <p className="mt-1 text-sm text-gray-900">{profileData.bio}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Delivery Radius</label>
                    <p className="mt-1 text-sm text-gray-900">{profileData.radius} miles</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="business" className="mt-6">
            {profileData.accountType === 'dual' ? (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {businessMetrics.map((metric, index) => (
                    <Card key={index}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-gray-600">{metric.label}</p>
                            <p className="text-2xl font-bold">{metric.value}</p>
                          </div>
                          <div className="text-sm font-medium text-green-500">
                            {metric.change}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <Card>
                  <CardHeader>
                    <CardTitle>Website Integration</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Website URL:</span>
                        <a href={profileData.websiteUrl} className="text-blue-500 hover:underline text-sm">
                          {profileData.websiteUrl}
                        </a>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Products Synced:</span>
                        <Badge className="bg-green-100 text-green-800">24 Active</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Last Sync:</span>
                        <span className="text-sm text-gray-500">2 hours ago</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <Store className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Upgrade to Business Account</h3>
                  <p className="text-gray-600 mb-4">Access advanced business features, analytics, and website integration.</p>
                  <Button>Upgrade Account</Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="interests" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Your Interests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {profileData.interests.map((interest) => (
                    <Badge key={interest} variant="secondary" className="text-sm">
                      {interest}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ProfileOverview;