import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, TrendingUp, Target, Users, DollarSign, Clock, Zap, Crown } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function BusinessAIAnalytics() {
  const [isPro, setIsPro] = useState(false);
  const [analysisData, setAnalysisData] = useState({
    customerInsights: {
      totalCustomers: 1247,
      avgOrderValue: 45.67,
      repeatCustomerRate: 68,
      topDemographics: ['25-34 years', 'Local residents', 'Weekend shoppers']
    },
    salesTrends: {
      weeklyGrowth: 12.5,
      monthlyRevenue: 15420,
      bestSellingHours: ['2-4 PM', '6-8 PM'],
      seasonalTrends: 'Summer peak approaching'
    },
    recommendations: [
      { type: 'pricing', suggestion: 'Increase weekend prices by 8%', impact: '+$340/week' },
      { type: 'inventory', suggestion: 'Stock more summer items', impact: '+15% sales' },
      { type: 'marketing', suggestion: 'Target 25-34 age group', impact: '+22% reach' }
    ]
  });

  const handleUpgradeToPro = () => {
    setIsPro(true);
    toast({ title: "Upgraded to Business Pro!", description: "Advanced AI analytics now available" });
  };

  const handlePromoteProduct = (productId: string) => {
    toast({ title: "Product promotion started!", description: "Your product will be featured for 7 days" });
  };

  if (!isPro) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AI Analytics & Promotion
            <Badge variant="secondary">Pro Feature</Badge>
          </CardTitle>
          <CardDescription>
            Unlock advanced AI-powered insights and product promotion tools
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg">
            <div className="flex items-center gap-3 mb-4">
              <Crown className="h-8 w-8 text-purple-600" />
              <div>
                <h3 className="text-xl font-semibold">Business Pro Analytics</h3>
                <p className="text-gray-600">Advanced AI insights for your business</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="bg-white p-4 rounded-lg">
                <h4 className="font-medium mb-2">Customer Intelligence</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Detailed customer demographics</li>
                  <li>• Purchase behavior analysis</li>
                  <li>• Retention predictions</li>
                </ul>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <h4 className="font-medium mb-2">Sales Optimization</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Dynamic pricing recommendations</li>
                  <li>• Inventory forecasting</li>
                  <li>• Revenue optimization</li>
                </ul>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <h4 className="font-medium mb-2">Marketing Insights</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Target audience analysis</li>
                  <li>• Campaign performance</li>
                  <li>• Competitor benchmarking</li>
                </ul>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <h4 className="font-medium mb-2">Product Promotion</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Featured product placement</li>
                  <li>• Targeted advertising</li>
                  <li>• Performance tracking</li>
                </ul>
              </div>
            </div>
            
            <div className="text-center">
              <Button onClick={handleUpgradeToPro} size="lg" className="bg-purple-600 hover:bg-purple-700">
                <Crown className="h-4 w-4 mr-2" />
                Upgrade to Business Pro - $29/month
              </Button>
              <p className="text-sm text-gray-600 mt-2">7-day free trial included</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AI Analytics Dashboard
            <Badge className="bg-purple-600">Pro</Badge>
          </CardTitle>
          <CardDescription>
            Advanced AI-powered insights for your business
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="insights" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="insights">Customer Insights</TabsTrigger>
          <TabsTrigger value="sales">Sales Analytics</TabsTrigger>
          <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
          <TabsTrigger value="promotion">Product Promotion</TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Total Customers
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analysisData.customerInsights.totalCustomers}</div>
                <p className="text-sm text-green-600">+12% this month</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Avg Order Value
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${analysisData.customerInsights.avgOrderValue}</div>
                <p className="text-sm text-green-600">+8% this month</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Repeat Rate
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analysisData.customerInsights.repeatCustomerRate}%</div>
                <p className="text-sm text-green-600">+5% this month</p>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Top Customer Demographics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {analysisData.customerInsights.topDemographics.map((demo, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span>{demo}</span>
                    <Badge variant="outline">{Math.floor(Math.random() * 30) + 20}%</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sales" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Sales Growth
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">+{analysisData.salesTrends.weeklyGrowth}%</div>
                <p className="text-sm text-gray-600">Weekly growth rate</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Monthly Revenue
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${analysisData.salesTrends.monthlyRevenue.toLocaleString()}</div>
                <p className="text-sm text-gray-600">This month</p>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Peak Sales Hours
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {analysisData.salesTrends.bestSellingHours.map((hour, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-blue-50 rounded">
                    <span>{hour}</span>
                    <Badge>High Activity</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4">
          <div className="space-y-4">
            {analysisData.recommendations.map((rec, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    AI Recommendation
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{rec.suggestion}</p>
                      <p className="text-sm text-gray-600">Potential impact: {rec.impact}</p>
                    </div>
                    <Button size="sm">Apply</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="promotion" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Product Promotion Center</CardTitle>
              <CardDescription>Pay to promote your products and increase visibility</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2">Featured Placement</h4>
                  <p className="text-sm text-gray-600 mb-3">Show your product at the top of search results</p>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">$5/day</span>
                    <Button size="sm" onClick={() => handlePromoteProduct('featured')}>Promote</Button>
                  </div>
                </div>
                
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2">Category Spotlight</h4>
                  <p className="text-sm text-gray-600 mb-3">Highlight in your product category</p>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">$3/day</span>
                    <Button size="sm" onClick={() => handlePromoteProduct('category')}>Promote</Button>
                  </div>
                </div>
                
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2">Local Boost</h4>
                  <p className="text-sm text-gray-600 mb-3">Increase visibility in your local area</p>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">$2/day</span>
                    <Button size="sm" onClick={() => handlePromoteProduct('local')}>Promote</Button>
                  </div>
                </div>
                
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2">Premium Package</h4>
                  <p className="text-sm text-gray-600 mb-3">All promotion types included</p>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">$8/day</span>
                    <Button size="sm" onClick={() => handlePromoteProduct('premium')}>Promote</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}