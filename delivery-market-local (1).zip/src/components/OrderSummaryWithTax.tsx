import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { calculateTax } from '@/components/TaxCalculator';
import { Package, Truck, DollarSign, Users, Crown, Receipt, Info } from 'lucide-react';

interface CartItem {
  id: number;
  title: string;
  price: number;
  image: string;
  category: string;
  location: string;
  size: 'small' | 'medium' | 'large';
}

interface OrderSummaryWithTaxProps {
  items: CartItem[];
  productSubtotal: number;
  deliveryFee: number;
  serviceFee: number;
  tipAmount?: number;
  taxRate?: number;
  growRouteDiscount?: number;
  isPartnerShop?: boolean;
}

export const OrderSummaryWithTax: React.FC<OrderSummaryWithTaxProps> = ({
  items,
  productSubtotal,
  deliveryFee,
  serviceFee,
  tipAmount = 0,
  taxRate = 0.0925,
  growRouteDiscount = 0,
  isPartnerShop = false
}) => {
  const getSizeInfo = (size: string) => {
    switch (size) {
      case 'small':
        return { label: 'Small', color: 'bg-green-100 text-green-800' };
      case 'medium':
        return { label: 'Medium', color: 'bg-yellow-100 text-yellow-800' };
      case 'large':
        return { label: 'Large', color: 'bg-red-100 text-red-800' };
      default:
        return { label: 'Unknown', color: 'bg-gray-100 text-gray-800' };
    }
  };

  const hasLargeItems = items.some(item => item.size === 'large');
  const originalSubtotal = productSubtotal / (1 - growRouteDiscount / 100);
  const discountAmount = originalSubtotal - productSubtotal;
  
  // Calculate tax properly according to MarketPace policy
  const taxCalculation = calculateTax(productSubtotal, deliveryFee, serviceFee, tipAmount, taxRate);

  return (
    <Card className={isPartnerShop ? 'border-purple-200' : ''}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="w-5 h-5" />
          Order Summary
          {isPartnerShop && (
            <Badge className="bg-purple-600">
              <Crown className="w-3 h-3 mr-1" />
              Partner
            </Badge>
          )}
          {growRouteDiscount > 0 && (
            <Badge className="bg-green-100 text-green-700">
              <Users className="w-3 h-3 mr-1" />
              {growRouteDiscount}% OFF
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Items List */}
        <div className="space-y-3">
          {items.map((item) => {
            const sizeInfo = getSizeInfo(item.size);
            return (
              <div key={item.id} className="flex items-center gap-3">
                <img src={item.image} alt={item.title} className="w-12 h-12 object-cover rounded" />
                <div className="flex-1">
                  <h4 className="font-medium">{item.title}</h4>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge className={sizeInfo.color} variant="secondary">
                      {sizeInfo.label}
                    </Badge>
                    {item.size === 'large' && (
                      <div className="flex items-center gap-1">
                        <Truck className="w-3 h-3 text-red-600" />
                        <span className="text-xs text-red-600">Truck Required</span>
                      </div>
                    )}
                  </div>
                </div>
                <span className="font-medium">${item.price.toFixed(2)}</span>
              </div>
            );
          })}
        </div>
        
        <Separator />
        
        {/* Pricing Breakdown with Tax Policy */}
        <div className="space-y-2">
          {/* Grow Route Discount */}
          {growRouteDiscount > 0 && (
            <>
              <div className="flex justify-between text-gray-600">
                <span>Original Subtotal</span>
                <span>${originalSubtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-green-600">
                <span>Grow Route Discount ({growRouteDiscount}%)</span>
                <span>-${discountAmount.toFixed(2)}</span>
              </div>
            </>
          )}
          
          {/* Product Subtotal - Vendor Tax Responsibility */}
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <span>Product Subtotal</span>
              <Badge variant="outline" className="text-xs">
                Vendor Tax Responsibility
              </Badge>
            </div>
            <span>${taxCalculation.productSubtotal.toFixed(2)}</span>
          </div>
          
          <Separator />
          
          {/* MarketPace Taxable Fees */}
          <div className="bg-blue-50 p-3 rounded-lg space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium text-blue-800">
              <Receipt className="w-4 h-4" />
              MarketPace Platform Fees (Taxable)
            </div>
            
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span className="ml-4">Delivery Fee</span>
                <span>${taxCalculation.deliveryFee.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="ml-4">Service Fee</span>
                <span>${taxCalculation.serviceFee.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between border-t pt-1 font-medium">
                <span className="ml-4">Taxable Amount</span>
                <span>${taxCalculation.taxableAmount.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between text-blue-700">
                <span className="ml-4">Sales Tax ({(taxRate * 100).toFixed(2)}%)</span>
                <span>${taxCalculation.taxCollected.toFixed(2)}</span>
              </div>
            </div>
          </div>
          
          {/* Driver Tip - Tax Free */}
          {tipAmount > 0 && (
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                <span>Driver Tip</span>
                <Badge variant="outline" className="text-xs bg-green-50">
                  Tax-Free Gratuity
                </Badge>
              </div>
              <span>${tipAmount.toFixed(2)}</span>
            </div>
          )}
          
          <Separator className="border-2" />
          
          {/* Final Total */}
          <div className="flex justify-between text-lg font-bold">
            <span>Total Amount</span>
            <span>${taxCalculation.checkoutTotal.toFixed(2)}</span>
          </div>
        </div>
        
        {/* Tax Policy Information */}
        <div className="bg-gray-50 p-3 rounded-lg text-xs space-y-2">
          <div className="flex items-start gap-2">
            <Info className="w-4 h-4 text-gray-600 mt-0.5" />
            <div className="text-gray-700">
              <div className="font-medium mb-1">MarketPace Tax Policy:</div>
              <div className="space-y-1">
                <div>• Product prices: Vendors collect & remit sales tax</div>
                <div>• Platform fees: MarketPace collects & remits tax</div>
                <div>• Driver tips: Tax-free gratuities (100% to driver)</div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Partner Benefits */}
        {isPartnerShop && (
          <div className="bg-purple-50 p-3 rounded-lg text-sm border border-purple-200">
            <div className="font-medium text-purple-900 mb-1 flex items-center gap-1">
              <Crown className="w-4 h-4" />
              Partner Shop Benefits Applied
            </div>
            <div className="text-purple-800 space-y-1">
              <div>✓ Reduced platform fees</div>
              <div>✓ Enhanced marketplace placement</div>
              <div>✓ Priority customer support</div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};