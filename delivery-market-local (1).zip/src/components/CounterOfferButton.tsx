import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { DollarSign, MessageSquare } from 'lucide-react';

interface CounterOfferButtonProps {
  itemId: string;
  originalPrice: number;
  itemName: string;
  isGuest?: boolean;
  onAuthRequired?: () => void;
}

const CounterOfferButton: React.FC<CounterOfferButtonProps> = ({ 
  itemId, 
  originalPrice, 
  itemName,
  isGuest = false,
  onAuthRequired
}) => {
  const [offerPrice, setOfferPrice] = useState('');
  const [message, setMessage] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const handleClick = () => {
    if (isGuest) {
      onAuthRequired?.();
      return;
    }
    setIsOpen(true);
  };

  const handleSubmit = () => {
    console.log('Counter offer submitted:', {
      itemId,
      offerPrice: parseFloat(offerPrice),
      message,
      originalPrice
    });
    setIsOpen(false);
    setOfferPrice('');
    setMessage('');
  };

  return (
    <>
      <Button 
        onClick={handleClick}
        variant="outline" 
        className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
      >
        <DollarSign className="h-4 w-4 mr-1" />
        Make Offer
      </Button>
      
      {!isGuest && (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogContent className="bg-gray-900 border-gray-700">
            <DialogHeader>
              <DialogTitle className="text-white">
                Make Counter Offer for {itemName}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Original Price: ${originalPrice}</Label>
              </div>
              <div>
                <Label htmlFor="offer" className="text-gray-300">Your Offer ($)</Label>
                <Input
                  id="offer"
                  type="number"
                  step="0.01"
                  value={offerPrice}
                  onChange={(e) => setOfferPrice(e.target.value)}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Enter your offer"
                />
              </div>
              <div>
                <Label htmlFor="message" className="text-gray-300">Message (Optional)</Label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="bg-gray-800 border-gray-600 text-white"
                  placeholder="Add a message to the seller..."
                />
              </div>
              <Button 
                onClick={handleSubmit}
                disabled={!offerPrice || parseFloat(offerPrice) <= 0}
                className="w-full bg-gradient-to-r from-cyan-500 to-purple-500"
              >
                <MessageSquare className="h-4 w-4 mr-2" />
                Send Offer
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
};

export { CounterOfferButton };
export default CounterOfferButton;