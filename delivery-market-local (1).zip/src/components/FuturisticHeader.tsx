import React, { useState } from 'react';
import { Sparkles, Zap, Cpu, User, LogIn } from 'lucide-react';
import { Button } from './ui/button';
import AuthModal from './AuthModal';

const FuturisticHeader = () => {
  const [showAuthModal, setShowAuthModal] = useState(false);

  return (
    <>
      <div className="relative overflow-hidden bg-gradient-to-r from-slate-900 via-purple-900 to-slate-900 text-white py-20">
        {/* Top Navigation Bar */}
        <div className="absolute top-0 left-0 right-0 z-20 bg-black/20 backdrop-blur-lg border-b border-white/10">
          <div className="container mx-auto px-4 py-3">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <Cpu className="w-8 h-8 text-cyan-400" />
                <span className="text-xl font-bold">MarketPace</span>
              </div>
              
              <div className="flex items-center space-x-3">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowAuthModal(true)}
                  className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                >
                  <LogIn className="w-4 h-4 mr-2" />
                  Sign In
                </Button>
                <Button 
                  size="sm"
                  onClick={() => setShowAuthModal(true)}
                  className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
                >
                  <User className="w-4 h-4 mr-2" />
                  Sign Up
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Animated background particles */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-cyan-400 rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`
              }}
            />
          ))}
        </div>
        
        <div className="relative z-10 text-center pt-16">
          <div className="flex justify-center mb-6">
            <Cpu className="w-16 h-16 text-cyan-400 animate-spin" style={{animationDuration: '20s'}} />
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent animate-pulse">
            MarketPace
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 text-gray-300">
            Next-Gen Marketplace for the Digital Age
          </p>
          
          <div className="flex justify-center space-x-8 mb-8">
            <div className="flex items-center space-x-2 hover:scale-110 transition-transform">
              <Zap className="w-6 h-6 text-yellow-400" />
              <span>AI-Powered</span>
            </div>
            <div className="flex items-center space-x-2 hover:scale-110 transition-transform">
              <Sparkles className="w-6 h-6 text-pink-400" />
              <span>Real-Time</span>
            </div>
          </div>
          
          <Button 
            size="lg"
            onClick={() => setShowAuthModal(true)}
            className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-bold py-3 px-8 text-lg"
          >
            Get Started
          </Button>
        </div>
      </div>
      
      <AuthModal 
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
      />
    </>
  );
};

export default FuturisticHeader;