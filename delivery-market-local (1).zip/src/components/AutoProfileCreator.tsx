import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Globe, Package, CheckCircle, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AutoProfileCreatorProps {
  userId: string;
  website?: string;
  onComplete: () => void;
}

interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image?: string;
  category: string;
}

const AutoProfileCreator: React.FC<AutoProfileCreatorProps> = ({ userId, website, onComplete }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [profileCreated, setProfileCreated] = useState(false);

  const createProfile = async () => {
    if (!website) {
      onComplete();
      return;
    }

    setIsProcessing(true);
    setProgress(10);
    setCurrentStep('Analyzing website...');

    try {
      // Simulate website analysis
      await new Promise(resolve => setTimeout(resolve, 2000));
      setProgress(30);
      setCurrentStep('Extracting products...');

      // Mock product extraction
      const mockProducts: Product[] = [
        {
          id: '1',
          name: 'Premium Coffee Blend',
          price: 24.99,
          description: 'Artisan roasted coffee beans',
          category: 'Food & Beverage'
        },
        {
          id: '2',
          name: 'Handcrafted Mug',
          price: 18.50,
          description: 'Ceramic coffee mug',
          category: 'Home & Garden'
        }
      ];

      await new Promise(resolve => setTimeout(resolve, 1500));
      setProgress(60);
      setCurrentStep('Creating MarketPace products...');
      setProducts(mockProducts);

      // Save products to database
      for (const product of mockProducts) {
        await supabase.from('marketplace_products').insert({
          user_id: userId,
          name: product.name,
          price: product.price,
          description: product.description,
          category: product.category,
          source: 'website_import',
          original_url: website
        });
      }

      setProgress(80);
      setCurrentStep('Setting up profile...');
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Create enhanced profile
      await supabase.from('enhanced_user_profiles').upsert({
        user_id: userId,
        website_integrated: true,
        auto_import_enabled: true,
        products_imported: mockProducts.length,
        profile_completion: 100
      });

      setProgress(100);
      setCurrentStep('Profile created successfully!');
      setProfileCreated(true);

    } catch (error) {
      console.error('Error creating profile:', error);
      setCurrentStep('Error occurred. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  useEffect(() => {
    if (website) {
      createProfile();
    }
  }, [website]);

  if (!website) {
    return (
      <Card className="bg-gradient-to-br from-slate-900 via-cyan-900 to-purple-900 border-cyan-500/30 text-white">
        <CardHeader>
          <CardTitle className="text-xl text-cyan-300">Profile Setup Complete</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-cyan-200 mb-4">Your basic profile has been created.</p>
          <Button onClick={onComplete} className="bg-cyan-600 hover:bg-cyan-700">
            Continue to Dashboard
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-slate-900 via-cyan-900 to-purple-900 border-cyan-500/30 text-white">
      <CardHeader>
        <CardTitle className="text-xl text-cyan-300 flex items-center gap-2">
          <Globe className="h-5 w-5" />
          Auto Profile Creation
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-cyan-300">Progress</span>
            <span className="text-cyan-300">{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
          <p className="text-sm text-cyan-200 flex items-center gap-2">
            {isProcessing && <Loader2 className="h-4 w-4 animate-spin" />}
            {currentStep}
          </p>
        </div>

        {products.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-cyan-300 flex items-center gap-2">
              <Package className="h-5 w-5" />
              Imported Products
            </h3>
            <div className="space-y-2">
              {products.map((product) => (
                <div key={product.id} className="bg-slate-800 p-3 rounded-lg">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-white">{product.name}</h4>
                      <p className="text-sm text-cyan-200">{product.description}</p>
                      <Badge variant="secondary" className="mt-1 text-xs">
                        {product.category}
                      </Badge>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-400">${product.price}</p>
                      <CheckCircle className="h-4 w-4 text-green-400 mt-1" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {profileCreated && (
          <div className="text-center space-y-3">
            <CheckCircle className="h-12 w-12 text-green-400 mx-auto" />
            <h3 className="text-lg font-semibold text-green-400">Profile Created Successfully!</h3>
            <p className="text-cyan-200">
              Your website has been integrated and {products.length} products have been imported.
            </p>
            <Button onClick={onComplete} className="bg-green-600 hover:bg-green-700">
              Explore Your Profile
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AutoProfileCreator;