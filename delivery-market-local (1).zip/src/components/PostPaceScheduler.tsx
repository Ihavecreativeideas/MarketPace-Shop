import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Package, MapPin, Clock, Truck } from 'lucide-react';
import { useState } from 'react';

interface PostPaceSchedulerProps {
  onSchedule: (data: any) => void;
}

const PostPaceScheduler: React.FC<PostPaceSchedulerProps> = ({ onSchedule }) => {
  const [formData, setFormData] = useState({
    pickupAddress: '',
    dropoffService: '',
    packageSize: '',
    weight: '',
    description: '',
    scheduledTime: '',
    isNonLocal: false,
    sellerAddress: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSchedule(formData);
  };

  return (
    <Card className="shadow-lg">
      <CardContent className="p-6">
        <div className="flex items-center mb-6">
          <Package className="w-6 h-6 text-blue-600 mr-2" />
          <h3 className="text-xl font-bold">Schedule Package Pickup</h3>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="pickupAddress">Pickup Address</Label>
              <Input
                id="pickupAddress"
                value={formData.pickupAddress}
                onChange={(e) => setFormData({...formData, pickupAddress: e.target.value})}
                placeholder="Enter pickup address"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="dropoffService">Drop-off Service</Label>
              <Select onValueChange={(value) => setFormData({...formData, dropoffService: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select service" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fedex">FedEx</SelectItem>
                  <SelectItem value="ups">UPS</SelectItem>
                  <SelectItem value="usps">USPS</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="packageSize">Package Size</Label>
              <Select onValueChange={(value) => setFormData({...formData, packageSize: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select size" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="small">Small (under 12")</SelectItem>
                  <SelectItem value="medium">Medium (12"-24")</SelectItem>
                  <SelectItem value="large">Large (over 24")</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="weight">Weight (lbs)</Label>
              <Input
                id="weight"
                type="number"
                value={formData.weight}
                onChange={(e) => setFormData({...formData, weight: e.target.value})}
                placeholder="Package weight"
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="description">Package Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder="Describe your package contents"
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="scheduledTime">Preferred Pickup Time</Label>
            <Input
              id="scheduledTime"
              type="datetime-local"
              value={formData.scheduledTime}
              onChange={(e) => setFormData({...formData, scheduledTime: e.target.value})}
              required
            />
          </div>

          <Button type="submit" className="w-full">
            <Truck className="w-4 h-4 mr-2" />
            Schedule Pickup
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default PostPaceScheduler;