import React from 'react';
import { Button } from '@/components/ui/button';
import { Users } from 'lucide-react';

const FacebookInviteFixed: React.FC = () => {
  const handleFacebookInvite = () => {
    // Check if Facebook SDK is available
    if (typeof window !== 'undefined' && (window as any).FB) {
      (window as any).FB.ui({
        method: 'apprequests',
        message: 'Join me on MarketPace - the local marketplace and community platform!',
        title: 'Invite Friends to MarketPace'
      }, (response: any) => {
        if (response && response.request) {
          console.log('Invites sent successfully');
        }
      });
    } else {
      // Fallback to Facebook share URL
      const shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.origin)}&quote=${encodeURIComponent('Join me on MarketPace - the local marketplace and community platform!')}`;
      window.open(shareUrl, '_blank', 'width=600,height=400');
    }
  };

  return (
    <Button
      onClick={handleFacebookInvite}
      className="bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2"
    >
      <Users className="w-4 h-4" />
      Invite Friends on Facebook
    </Button>
  );
};

export default FacebookInviteFixed;
export { FacebookInviteFixed };