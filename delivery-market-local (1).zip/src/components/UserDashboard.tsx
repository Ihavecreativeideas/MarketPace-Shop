import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/components/EnhancedAuthProvider';
import { supabase } from '@/lib/supabase';
import { User, Store, Wrench, Music, Heart, Plus } from 'lucide-react';

interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  zip_code?: string;
  city?: string;
  profile_types: string[];
}

interface BusinessProfile {
  id: string;
  profile_type: string;
  business_name: string;
  category?: string;
  description?: string;
  is_pro: boolean;
}

const UserDashboard: React.FC = () => {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [businessProfiles, setBusinessProfiles] = useState<BusinessProfile[]>([]);
  const [favorites, setFavorites] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      loadUserData();
    }
  }, [user]);

  const loadUserData = async () => {
    try {
      // Load user profile
      const { data: profile, error: profileError } = await supabase
        .from('enhanced_user_profiles')
        .select('*')
        .eq('user_id', user?.id)
        .single();

      if (profileError && profileError.code !== 'PGRST116') {
        console.error('Error loading profile:', profileError);
      } else if (profile) {
        setUserProfile(profile);
      }

      // Load business profiles
      const { data: businessData, error: businessError } = await supabase
        .from('business_profiles')
        .select('*')
        .eq('user_id', user?.id);

      if (businessError) {
        console.error('Error loading business profiles:', businessError);
      } else {
        setBusinessProfiles(businessData || []);
      }

      // Load favorites
      const { data: favoritesData, error: favoritesError } = await supabase
        .from('favorites')
        .select('*')
        .eq('user_id', user?.id);

      if (favoritesError) {
        console.error('Error loading favorites:', favoritesError);
      } else {
        setFavorites(favoritesData || []);
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getProfileTypeIcon = (type: string) => {
    switch (type) {
      case 'shop': return Store;
      case 'service': return Wrench;
      case 'entertainment': return Music;
      default: return User;
    }
  };

  const getProfileTypeLabel = (type: string) => {
    switch (type) {
      case 'shop': return 'Shop/Business';
      case 'service': return 'Service Provider';
      case 'entertainment': return 'Entertainment Industry';
      default: return 'Regular Member';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="text-white">Loading dashboard...</div>
      </div>
    );
  }

  if (!userProfile) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="text-white">Please complete your profile setup</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Welcome, {userProfile.name}!</h1>
        <p className="text-gray-300">Manage your MarketPace profiles and favorites</p>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800">
          <TabsTrigger value="overview" className="text-white">Overview</TabsTrigger>
          <TabsTrigger value="profiles" className="text-white">My Profiles</TabsTrigger>
          <TabsTrigger value="favorites" className="text-white">Favorites</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <User className="mr-2 h-5 w-5" />
                  Profile Types
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {userProfile.profile_types.map((type) => (
                    <Badge key={type} variant="secondary">
                      {getProfileTypeLabel(type)}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Store className="mr-2 h-5 w-5" />
                  Business Profiles
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {businessProfiles.length}
                </div>
                <p className="text-gray-300 text-sm">Active business profiles</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Heart className="mr-2 h-5 w-5" />
                  Favorites
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {favorites.length}
                </div>
                <p className="text-gray-300 text-sm">Saved items</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="profiles" className="space-y-6">
          <div className="grid gap-4">
            {businessProfiles.map((profile) => {
              const Icon = getProfileTypeIcon(profile.profile_type);
              return (
                <Card key={profile.id} className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Icon className="h-6 w-6 text-purple-400" />
                        <div>
                          <CardTitle className="text-white">{profile.business_name}</CardTitle>
                          <CardDescription>
                            {getProfileTypeLabel(profile.profile_type)}
                            {profile.category && ` • ${profile.category}`}
                          </CardDescription>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {profile.is_pro && (
                          <Badge className="bg-purple-600">Pro</Badge>
                        )}
                        <Button size="sm" variant="outline">
                          Edit
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  {profile.description && (
                    <CardContent>
                      <p className="text-gray-300">{profile.description}</p>
                    </CardContent>
                  )}
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="favorites" className="space-y-6">
          <div className="grid gap-4">
            {favorites.length === 0 ? (
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="flex flex-col items-center justify-center p-8">
                  <Heart className="h-12 w-12 text-gray-400 mb-4" />
                  <p className="text-white text-lg mb-2">No favorites yet</p>
                  <p className="text-gray-300 text-center">
                    Start exploring and add items to your favorites using the heart icon
                  </p>
                </CardContent>
              </Card>
            ) : (
              favorites.map((favorite) => (
                <Card key={favorite.id} className="bg-gray-800 border-gray-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white font-medium">
                          {favorite.item_type.charAt(0).toUpperCase() + favorite.item_type.slice(1)}
                        </p>
                        <p className="text-gray-300 text-sm">ID: {favorite.item_id}</p>
                      </div>
                      <Button size="sm" variant="outline">
                        View
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default UserDashboard;