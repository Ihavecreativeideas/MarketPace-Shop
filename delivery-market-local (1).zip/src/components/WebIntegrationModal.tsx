import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Copy, Check, Globe, Code, Smartphone } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { VisuallyHidden } from '@/components/ui/visually-hidden';

interface WebIntegrationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function WebIntegrationModal({ isOpen, onClose }: WebIntegrationModalProps) {
  const [copied, setCopied] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const { toast } = useToast();

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    toast({ title: 'Copied to clipboard!' });
    setTimeout(() => setCopied(''), 2000);
  };

  const embedCode = `<iframe src="https://marketpace.app/embed" width="100%" height="600" frameborder="0"></iframe>`;
  const widgetCode = `<script src="https://marketpace.app/widget.js"></script>
<div id="marketpace-widget" data-theme="light"></div>`;
  const apiCode = `fetch('https://api.marketpace.app/products', {
  headers: { 'Authorization': 'Bearer YOUR_API_KEY' }
})`;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Website Integration
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="embed" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="embed">Embed</TabsTrigger>
            <TabsTrigger value="widget">Widget</TabsTrigger>
            <TabsTrigger value="api">API</TabsTrigger>
            <TabsTrigger value="mobile">Mobile</TabsTrigger>
          </TabsList>

          <TabsContent value="embed" className="space-y-4">
            <div className="space-y-2">
              <Label>Full Marketplace Embed</Label>
              <div className="relative">
                <pre className="bg-gray-100 p-3 rounded text-sm overflow-x-auto">{embedCode}</pre>
                <Button
                  size="sm"
                  variant="outline"
                  className="absolute top-2 right-2"
                  onClick={() => copyToClipboard(embedCode, 'embed')}
                >
                  {copied === 'embed' ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="website">Your Website URL</Label>
              <Input
                id="website"
                placeholder="https://yourwebsite.com"
                value={websiteUrl}
                onChange={(e) => setWebsiteUrl(e.target.value)}
              />
            </div>
            <Badge variant="secondary">Responsive • Mobile-friendly • Customizable</Badge>
          </TabsContent>

          <TabsContent value="widget" className="space-y-4">
            <div className="space-y-2">
              <Label>Marketplace Widget</Label>
              <div className="relative">
                <pre className="bg-gray-100 p-3 rounded text-sm overflow-x-auto">{widgetCode}</pre>
                <Button
                  size="sm"
                  variant="outline"
                  className="absolute top-2 right-2"
                  onClick={() => copyToClipboard(widgetCode, 'widget')}
                >
                  {copied === 'widget' ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <Badge variant="secondary">Lightweight • Customizable themes • Easy setup</Badge>
          </TabsContent>

          <TabsContent value="api" className="space-y-4">
            <div className="space-y-2">
              <Label>API Integration</Label>
              <div className="relative">
                <pre className="bg-gray-100 p-3 rounded text-sm overflow-x-auto">{apiCode}</pre>
                <Button
                  size="sm"
                  variant="outline"
                  className="absolute top-2 right-2"
                  onClick={() => copyToClipboard(apiCode, 'api')}
                >
                  {copied === 'api' ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <Badge variant="secondary">RESTful API • Real-time data • Full control</Badge>
          </TabsContent>

          <TabsContent value="mobile" className="space-y-4">
            <div className="text-center space-y-4">
              <Smartphone className="h-16 w-16 mx-auto text-blue-500" />
              <h3 className="text-lg font-semibold">Mobile App Integration</h3>
              <p className="text-sm text-gray-600">Coming Soon - Native iOS and Android SDKs</p>
              <Button variant="outline" disabled>Request Early Access</Button>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end space-x-2 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>Close</Button>
          <Button>Get API Key</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}