import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { Gift, Heart, Crown, Star, Zap, Users, Truck, ShoppingBag, MessageSquare, Music, Wrench, Shield } from 'lucide-react';

export default function LaunchCampaignPage() {
  const navigate = useNavigate();

  const features = [
    { icon: ShoppingBag, title: 'Marketplace Trading', description: 'Buy, sell, and trade with your community' },
    { icon: Truck, title: 'Local Delivery', description: 'Fast, reliable delivery from local drivers' },
    { icon: MessageSquare, title: 'Community Feed', description: 'Connect, share, and engage with neighbors' },
    { icon: Music, title: 'Musician Network', description: 'Book artists and discover local talent' },
    { icon: Wrench, title: 'Service Marketplace', description: 'Find and offer professional services' },
    { icon: Users, title: 'Business Integration', description: 'Connect your business to the community' },
    { icon: Shield, title: 'Secure Payments', description: 'Protected transactions and instant payouts' },
    { icon: Star, title: 'Rating System', description: 'Build trust through community reviews' }
  ];

  const lifetimeBenefits = [
    'No delivery fees for life',
    'Premium marketplace features',
    'Priority customer support',
    'Early access to new features',
    'Exclusive community events',
    'Enhanced business tools',
    'Advanced analytics dashboard',
    'Custom profile badges'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-blue-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-teal-600 to-blue-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center mb-4">
            <Gift className="h-12 w-12 mr-3" />
            <h1 className="text-4xl md:text-6xl font-bold">Launch Campaign</h1>
          </div>
          <p className="text-xl md:text-2xl mb-8 opacity-90">
            Join the Movement. Build Stronger Communities.
          </p>
          <Badge className="bg-yellow-500 text-yellow-900 text-lg px-6 py-2 mb-8">
            🎉 ALL FEATURES FREE DURING LAUNCH!
          </Badge>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-teal-600 hover:bg-gray-100 text-lg px-8 py-3"
              onClick={() => navigate('/donate')}
            >
              <Heart className="h-5 w-5 mr-2" />
              Support Our Launch
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-teal-600 text-lg px-8 py-3"
              onClick={() => navigate('/sponsorship')}
            >
              <Crown className="h-5 w-5 mr-2" />
              Become a Sponsor
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Campaign Promise */}
        <Card className="mb-12 border-2 border-teal-200">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl text-teal-600 mb-4">
              Our Launch Promise
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg mb-6">
                During our launch campaign, <strong>all features are completely free</strong> with no upcharges. 
                Members only pay drivers directly for their delivery services.
              </p>
              <div className="bg-teal-50 p-6 rounded-lg mb-6">
                <h3 className="text-xl font-bold text-teal-800 mb-3">Early Supporter Benefits</h3>
                <p className="text-teal-700">
                  As a thank you for your early support, you'll receive <strong>lifetime benefits</strong> 
                  that will continue even after our official launch.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Features Grid */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8">Powerful Features, All Free</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader className="text-center">
                  <feature.icon className="h-12 w-12 text-teal-600 mx-auto mb-3" />
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground text-center">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Lifetime Benefits */}
        <Card className="mb-12 bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-yellow-200">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl text-orange-600 mb-4">
              <Crown className="h-8 w-8 inline mr-3" />
              Lifetime Benefits for Early Supporters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
              {lifetimeBenefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-3">
                  <Zap className="h-5 w-5 text-yellow-600 flex-shrink-0" />
                  <span className="text-gray-700">{benefit}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Mission Statement */}
        <Card className="mb-12">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl text-teal-600 mb-4">
              Growing Stronger Communities
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="max-w-4xl mx-auto">
              <p className="text-lg mb-6">
                MarketPace isn't just an app – it's a movement to strengthen local communities 
                by connecting neighbors, supporting local businesses, and creating opportunities for everyone.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                <div className="text-center">
                  <Users className="h-12 w-12 text-teal-600 mx-auto mb-3" />
                  <h3 className="font-bold mb-2">Connect Communities</h3>
                  <p className="text-sm text-muted-foreground">
                    Bring neighbors together through shared commerce and communication
                  </p>
                </div>
                <div className="text-center">
                  <Truck className="h-12 w-12 text-teal-600 mx-auto mb-3" />
                  <h3 className="font-bold mb-2">Create Opportunities</h3>
                  <p className="text-sm text-muted-foreground">
                    Provide income opportunities for drivers and growth for local businesses
                  </p>
                </div>
                <div className="text-center">
                  <Heart className="h-12 w-12 text-teal-600 mx-auto mb-3" />
                  <h3 className="font-bold mb-2">Support Local</h3>
                  <p className="text-sm text-muted-foreground">
                    Keep money in the community while providing convenient services
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Call to Action */}
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-6">Be Part of Something Special</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Help us launch the future of community commerce. Your support today 
            builds stronger communities tomorrow.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-teal-600 hover:bg-teal-700 text-lg px-8 py-3"
              onClick={() => navigate('/donate')}
            >
              <Heart className="h-5 w-5 mr-2" />
              Donate to Support Launch
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-teal-600 text-teal-600 hover:bg-teal-50 text-lg px-8 py-3"
              onClick={() => navigate('/sponsorship')}
            >
              <Crown className="h-5 w-5 mr-2" />
              Explore Sponsorship
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}