import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from './ui/button';
import { Home, ShoppingCart, Package, Wrench, Users, Music, Store } from 'lucide-react';

const FloatingBottomNavigation: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    {
      icon: <Home className="h-5 w-5" />,
      label: 'Home',
      path: '/marketplace',
      active: location.pathname === '/marketplace'
    },
    {
      icon: <ShoppingCart className="h-5 w-5" />,
      label: 'Market',
      path: '/marketplace',
      active: location.pathname === '/marketplace'
    },
    {
      icon: <Package className="h-5 w-5" />,
      label: 'Rent',
      path: '/rent',
      active: location.pathname === '/rent'
    },
    {
      icon: <Wrench className="h-5 w-5" />,
      label: 'Services',
      path: '/shops',
      active: location.pathname === '/shops'
    },
    {
      icon: <Users className="h-5 w-5" />,
      label: 'Community',
      path: '/community',
      active: location.pathname === '/community'
    },
    {
      icon: <Music className="h-5 w-5" />,
      label: 'Hub',
      path: '/musicians',
      active: location.pathname === '/musicians'
    },
    {
      icon: <Store className="h-5 w-5" />,
      label: 'Profile',
      path: '/profile',
      active: location.pathname === '/profile'
    }
  ];

  // Don't show navigation on landing page or auth pages
  if (location.pathname === '/' || location.pathname === '/auth' || location.pathname === '/personalized-profile') {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-slate-900/95 backdrop-blur-sm border-t border-slate-700">
      <div className="max-w-md mx-auto px-4 py-2">
        <div className="flex items-center justify-between">
          {navItems.map((item, index) => (
            <Button
              key={index}
              variant="ghost"
              size="sm"
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center gap-1 h-auto py-2 px-2 ${
                item.active
                  ? 'text-teal-400 bg-teal-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {item.icon}
              <span className="text-xs font-medium">{item.label}</span>
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FloatingBottomNavigation;
export { FloatingBottomNavigation };