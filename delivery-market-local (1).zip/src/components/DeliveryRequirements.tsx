import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, Shield, Crown, Truck } from 'lucide-react';

interface DeliveryRequirementsProps {
  isPartner?: boolean;
  shopType?: 'etsy' | 'tiktok' | 'local' | 'other';
}

export function DeliveryRequirements({ isPartner = false, shopType = 'local' }: DeliveryRequirementsProps) {
  const platformNames = {
    etsy: 'Etsy',
    tiktok: 'TikTok Shop',
    local: 'Local Shop',
    other: 'External Platform'
  };

  return (
    <Card className="border-2 border-green-200 bg-green-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-green-800">
          <Shield className="h-5 w-5" />
          <Truck className="h-5 w-5" />
          MarketPace Safe Delivery Policy
        </CardTitle>
        <p className="text-sm text-green-600">We keep our customers safe with delivery-only services</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert className="border-green-200 bg-green-50">
          <Shield className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800 font-medium">
            <strong>SAFETY FIRST:</strong> {platformNames[shopType]} items must offer DELIVERY ONLY.
            No pickup required - we bring everything safely to your door!
          </AlertDescription>
        </Alert>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <span className="text-sm">Safe contactless delivery to your door</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <span className="text-sm">Convenient delivery within service area</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <span className="text-sm">Affordable shared delivery costs</span>
          </div>
          <div className="flex items-center gap-2">
            <XCircle className="h-4 w-4 text-red-600" />
            <span className="text-sm">No pickup required - for your safety</span>
          </div>
          <div className="flex items-center gap-2">
            <XCircle className="h-4 w-4 text-red-600" />
            <span className="text-sm">No links to external delivery platforms</span>
          </div>
        </div>

        {isPartner && (
          <Alert className="border-purple-200 bg-purple-50">
            <Crown className="h-4 w-4 text-purple-600" />
            <AlertDescription className="text-purple-800">
              <div className="flex items-center gap-2 mb-2">
                <Badge className="bg-purple-600">Partnership Perk</Badge>
              </div>
              <strong>As a MarketPace Partner:</strong> You get enhanced delivery options 
              with reduced fees and expanded service areas while maintaining our safety-first approach.
            </AlertDescription>
          </Alert>
        )}

        <div className="bg-green-100 p-3 rounded-lg">
          <div className="flex items-center gap-2 text-green-700 mb-2">
            <Shield className="w-4 h-4" />
            <span className="font-medium text-sm">Why Delivery Only?</span>
          </div>
          <ul className="text-xs text-green-600 space-y-1">
            <li>• Keeps customers safe at home</li>
            <li>• Convenient and contactless</li>
            <li>• Affordable shared delivery costs</li>
            <li>• Professional delivery service</li>
          </ul>
        </div>

        <div className="text-xs text-gray-600 mt-4">
          All items must support our safe delivery service. 
          Consider becoming a MarketPace Partner for enhanced delivery benefits.
        </div>
      </CardContent>
    </Card>
  );
}