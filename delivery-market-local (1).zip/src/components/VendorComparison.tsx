import { useState } from 'react';
import { Compare, Star, MapPin, Clock, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface Business {
  id: string;
  name: string;
  rating: number;
  deliveryTime: string;
  deliveryFee: number;
  minOrder: number;
  cuisine: string[];
  image: string;
  distance: string;
  features: string[];
}

interface BusinessComparisonProps {
  businesses: Business[];
}

export function BusinessComparison({ businesses }: BusinessComparisonProps) {
  const [selectedBusinesses, setSelectedBusinesses] = useState<Business[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  const addToComparison = (business: Business) => {
    if (selectedBusinesses.length >= 3) return;
    if (selectedBusinesses.find(v => v.id === business.id)) return;
    setSelectedBusinesses([...selectedBusinesses, business]);
  };

  const removeFromComparison = (businessId: string) => {
    setSelectedBusinesses(selectedBusinesses.filter(v => v.id !== businessId));
  };

  const ComparisonButton = ({ business }: { business: Business }) => {
    const isSelected = selectedBusinesses.find(v => v.id === business.id);
    const isFull = selectedBusinesses.length >= 3;

    return (
      <Button
        variant={isSelected ? "default" : "outline"}
        size="sm"
        onClick={() => isSelected ? removeFromComparison(business.id) : addToComparison(business)}
        disabled={!isSelected && isFull}
      >
        <Compare className="h-3 w-3 mr-1" />
        {isSelected ? 'Remove' : 'Compare'}
      </Button>
    );
  };

  return (
    <>
      {/* Comparison floating button */}
      {selectedBusinesses.length > 0 && (
        <div className="fixed bottom-4 right-4 z-50">
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-full shadow-lg">
                <Compare className="h-4 w-4 mr-2" />
                Compare ({selectedBusinesses.length})
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Business Comparison</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Business Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {selectedBusinesses.map((business) => (
                    <Card key={business.id}>
                      <CardHeader className="pb-2">
                        <img
                          src={business.image}
                          alt={business.name}
                          className="w-full h-32 object-cover rounded-lg mb-2"
                        />
                        <CardTitle className="text-lg">{business.name}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span className="font-medium">{business.rating}</span>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {business.cuisine.map((c) => (
                            <Badge key={c} variant="secondary" className="text-xs">
                              {c}
                            </Badge>
                          ))}
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeFromComparison(business.id)}
                          className="w-full"
                        >
                          Remove
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Comparison Table */}
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Feature</TableHead>
                      {selectedBusinesses.map((business) => (
                        <TableHead key={business.id}>{business.name}</TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">Rating</TableCell>
                      {selectedBusinesses.map((business) => (
                        <TableCell key={business.id}>
                          <div className="flex items-center space-x-1">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <span>{business.rating}</span>
                          </div>
                        </TableCell>
                      ))}
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Delivery Time</TableCell>
                      {selectedBusinesses.map((business) => (
                        <TableCell key={business.id}>
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>{business.deliveryTime}</span>
                          </div>
                        </TableCell>
                      ))}
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Delivery Fee</TableCell>
                      {selectedBusinesses.map((business) => (
                        <TableCell key={business.id}>
                          <div className="flex items-center space-x-1">
                            <DollarSign className="h-4 w-4" />
                            <span>${business.deliveryFee}</span>
                          </div>
                        </TableCell>
                      ))}
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Min Order</TableCell>
                      {selectedBusinesses.map((business) => (
                        <TableCell key={business.id}>${business.minOrder}</TableCell>
                      ))}
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Distance</TableCell>
                      {selectedBusinesses.map((business) => (
                        <TableCell key={business.id}>
                          <div className="flex items-center space-x-1">
                            <MapPin className="h-4 w-4" />
                            <span>{business.distance}</span>
                          </div>
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      )}

      {/* Export comparison button component */}
      <div className="hidden">
        <ComparisonButton business={businesses[0]} />
      </div>
    </>
  );
}

export { BusinessComparison as default, type Business };
export function ComparisonButton({ business, onAdd, onRemove, isSelected, disabled }: {
  business: Business;
  onAdd: (business: Business) => void;
  onRemove: (businessId: string) => void;
  isSelected: boolean;
  disabled: boolean;
}) {
  return (
    <Button
      variant={isSelected ? "default" : "outline"}
      size="sm"
      onClick={() => isSelected ? onRemove(business.id) : onAdd(business)}
      disabled={disabled}
    >
      <Compare className="h-3 w-3 mr-1" />
      {isSelected ? 'Remove' : 'Compare'}
    </Button>
  );
}