import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ArrowLeft, Search, Store, Star, MapPin, Clock, Phone } from 'lucide-react';
import TealSquareLogo from './TealSquareLogo';

const ShopsAndServices: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const mockShops = [
    { id: 1, name: 'Tony\'s Pizza', category: 'Food', rating: 4.8, location: 'Main St', hours: '11am-10pm', phone: '(555) 123-4567', image: '/placeholder.svg', description: 'Authentic Italian pizza' },
    { id: 2, name: 'Green Thumb Garden', category: 'Garden', rating: 4.6, location: 'Oak Ave', hours: '8am-6pm', phone: '(555) 234-5678', image: '/placeholder.svg', description: 'Plants and gardening supplies' },
    { id: 3, name: 'Fix-It Repair Shop', category: 'Repair', rating: 4.9, location: 'Elm St', hours: '9am-5pm', phone: '(555) 345-6789', image: '/placeholder.svg', description: 'Electronics and appliance repair' },
    { id: 4, name: 'Bella\'s Salon', category: 'Beauty', rating: 4.7, location: 'Pine St', hours: '10am-7pm', phone: '(555) 456-7890', image: '/placeholder.svg', description: 'Hair and beauty services' },
    { id: 5, name: 'Corner Pharmacy', category: 'Health', rating: 4.8, location: 'Maple Ave', hours: '8am-9pm', phone: '(555) 567-8901', image: '/placeholder.svg', description: 'Prescriptions and health products' },
    { id: 6, name: 'Auto Care Center', category: 'Automotive', rating: 4.5, location: 'Cedar St', hours: '7am-6pm', phone: '(555) 678-9012', image: '/placeholder.svg', description: 'Car maintenance and repair' }
  ];

  const categories = ['all', 'Food', 'Garden', 'Repair', 'Beauty', 'Health', 'Automotive'];

  const handleBack = () => navigate('/');
  const handleContact = (shopId: number) => {
    console.log('Contacting shop:', shopId);
    // In a real app, this would open contact modal or dial phone
  };

  const handleVisit = (shopId: number) => {
    console.log('Visiting shop:', shopId);
    // In a real app, this would show directions or shop details
  };

  const filteredShops = mockShops.filter(shop => {
    const matchesSearch = shop.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         shop.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         shop.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || shop.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-white/10 backdrop-blur-lg border-b border-slate-200/20 text-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBack}
                className="text-slate-400 hover:text-white"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center space-x-3">
                <TealSquareLogo size={32} />
                <div className="text-xl font-bold text-teal-400">
                  Shops & Services
                </div>
              </div>
            </div>
            <Button
              onClick={() => navigate('/profile')}
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-white"
            >
              Profile
            </Button>
          </div>
        </div>
      </header>

      {/* Search and Filters */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search shops, services, or locations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-800/50 border-slate-600 text-white placeholder-slate-400"
            />
          </div>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 mb-6">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className={`${
                selectedCategory === category
                  ? 'bg-teal-500 hover:bg-teal-600'
                  : 'bg-slate-700 hover:bg-slate-600 border-slate-600 text-white'
              }`}
            >
              {category === 'all' ? 'All Categories' : category}
            </Button>
          ))}
        </div>

        {/* Shops Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredShops.map((shop) => (
            <Card key={shop.id} className="bg-slate-800/40 border-slate-600/30 hover:shadow-lg transition-all duration-300 hover:bg-slate-700/40 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <div className="aspect-square bg-slate-700 rounded-lg mb-3 flex items-center justify-center relative">
                  <img
                    src={shop.image}
                    alt={shop.name}
                    className="w-full h-full object-cover rounded-lg opacity-50"
                  />
                  <Store className="absolute inset-0 m-auto h-12 w-12 text-slate-400" />
                </div>
                <div>
                  <CardTitle className="text-lg text-white">{shop.name}</CardTitle>
                  <div className="flex items-center gap-2 mt-1">
                    <MapPin className="h-4 w-4 text-slate-400" />
                    <span className="text-sm text-slate-400">{shop.location}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-slate-300 mb-3">{shop.description}</p>
                <div className="flex justify-between items-center mb-3">
                  <Badge variant="secondary" className="bg-slate-700 text-slate-300">
                    {shop.category}
                  </Badge>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm text-slate-300">{shop.rating}</span>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm text-slate-400">
                    <Clock className="h-4 w-4" />
                    <span>{shop.hours}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-400">
                    <Phone className="h-4 w-4" />
                    <span>{shop.phone}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => handleContact(shop.id)}
                    variant="outline"
                    size="sm"
                    className="flex-1 bg-slate-700 hover:bg-slate-600 border-slate-600 text-white"
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    Call
                  </Button>
                  <Button
                    onClick={() => handleVisit(shop.id)}
                    size="sm"
                    className="flex-1 bg-teal-500 hover:bg-teal-600"
                  >
                    <MapPin className="mr-2 h-4 w-4" />
                    Visit
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredShops.length === 0 && (
          <div className="text-center py-12">
            <Store className="h-16 w-16 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-400 text-lg">No shops found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ShopsAndServices;
export { ShopsAndServices };