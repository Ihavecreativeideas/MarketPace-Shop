import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, AlertTriangle, Ban, Users } from 'lucide-react';

const CommunityStandards = () => {
  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-6 h-6" />
            Community Standards
          </CardTitle>
          <CardDescription>
            Our guidelines help create a safe and respectful marketplace for everyone
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Violations of these standards may result in content removal, account restrictions, or permanent bans.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Ban className="w-5 h-5 text-red-500" />
            Prohibited Items & Services
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold text-red-600 mb-2">Strictly Prohibited:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Weapons, firearms, ammunition, or explosives</li>
              <li>• Illegal drugs, controlled substances, or drug paraphernalia</li>
              <li>• Adult content, services, or sexually explicit material</li>
              <li>• Stolen goods or items obtained illegally</li>
              <li>• Counterfeit or replica items</li>
              <li>• Human trafficking or exploitation services</li>
              <li>• Gambling or lottery services</li>
              <li>• Tobacco products or e-cigarettes</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-orange-600 mb-2">Restricted Items (Special Requirements):</h3>
            <ul className="space-y-1 text-sm">
              <li>• Alcohol (licensed sellers only)</li>
              <li>• Prescription medications (licensed pharmacies only)</li>
              <li>• Medical devices (certified sellers only)</li>
              <li>• Financial services (licensed providers only)</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Behavioral Standards
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Respectful Communication:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Treat all members with respect and courtesy</li>
              <li>• No harassment, bullying, or threatening behavior</li>
              <li>• No hate speech or discrimination based on race, religion, gender, etc.</li>
              <li>• Keep conversations relevant to transactions</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2">Honest Trading:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Provide accurate descriptions and photos of items</li>
              <li>• Honor agreed-upon prices and terms</li>
              <li>• No bait-and-switch tactics</li>
              <li>• Report items accurately (condition, authenticity, etc.)</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2">Account Integrity:</h3>
            <ul className="space-y-1 text-sm">
              <li>• One account per person</li>
              <li>• No impersonation of others</li>
              <li>• Use real, current contact information</li>
              <li>• No spam or excessive posting</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Safety Guidelines</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Meeting Safety:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Meet in public, well-lit locations</li>
              <li>• Bring a friend when possible</li>
              <li>• Trust your instincts - if something feels wrong, leave</li>
              <li>• Verify items before completing transactions</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2">Payment Security:</h3>
            <ul className="space-y-1 text-sm">
              <li>• Use secure payment methods when possible</li>
              <li>• Be cautious of overpayment scams</li>
              <li>• Never share personal financial information</li>
              <li>• Report suspicious payment requests</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Enforcement & Appeals</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-sm space-y-2">
            <p><strong>Warning:</strong> First-time minor violations may result in a warning</p>
            <p><strong>Content Removal:</strong> Prohibited content will be removed immediately</p>
            <p><strong>Account Restriction:</strong> Temporary limits on posting or messaging</p>
            <p><strong>Account Suspension:</strong> Temporary ban from the platform</p>
            <p><strong>Permanent Ban:</strong> Permanent removal from the platform for serious violations</p>
          </div>
          
          <div className="mt-4 p-4 bg-blue-50 rounded-lg">
            <h4 className="font-semibold mb-2">Appeals Process:</h4>
            <p className="text-sm">
              If you believe your content or account was restricted in error, you can appeal the decision 
              through our support system. Appeals are reviewed within 5-7 business days.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CommunityStandards;