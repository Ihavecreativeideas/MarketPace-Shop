import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ContactInviteModal } from '@/components/ContactInviteModal';
import { FacebookFriendsInvite } from '@/components/FacebookFriendsInvite';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/components/AuthProvider';
import { Users, Share2, Mail, Phone, Copy, Gift } from 'lucide-react';

export const EnhancedInviteFriends: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('contacts');

  const baseUrl = window.location.origin;
  const referralCode = user?.id?.slice(0, 8) || 'DEMO123';
  const inviteUrl = `${baseUrl}/join?ref=${referralCode}`;
  const inviteMessage = "Join me on MarketPace - the local marketplace that supports our community! Shop local, support families, and discover amazing deals.";

  const copyInviteLink = async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl);
      toast({ title: 'Link Copied!', description: 'Invite link copied to clipboard' });
    } catch (err) {
      toast({ title: 'Error', description: 'Failed to copy link', variant: 'destructive' });
    }
  };

  const shareNatively = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'MarketPace - Shop Local',
          text: inviteMessage,
          url: inviteUrl,
        });
      } catch (err) {
        console.log('Share cancelled');
      }
    } else {
      copyInviteLink();
    }
  };

  const openEmailClient = () => {
    const subject = 'Join MarketPace - Shop Local!';
    const body = `${inviteMessage}\n\n${inviteUrl}`;
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const openSMSClient = () => {
    const message = `${inviteMessage} ${inviteUrl}`;
    window.location.href = `sms:?body=${encodeURIComponent(message)}`;
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-6 w-6" />
            Invite Friends & Grow Our Community
          </CardTitle>
          <p className="text-muted-foreground">
            Help us build a stronger local marketplace by inviting your friends and contacts!
          </p>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="contacts">Contacts</TabsTrigger>
              <TabsTrigger value="facebook">Facebook</TabsTrigger>
              <TabsTrigger value="share">Quick Share</TabsTrigger>
            </TabsList>
            
            <TabsContent value="contacts" className="space-y-4">
              <div className="grid gap-4">
                <ContactInviteModal>
                  <Button className="w-full h-16 text-left justify-start">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Mail className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <div className="font-semibold">Invite via Email & SMS</div>
                        <div className="text-sm text-muted-foreground">
                          Send personalized invites to your contacts
                        </div>
                      </div>
                    </div>
                  </Button>
                </ContactInviteModal>
                
                <div className="grid grid-cols-2 gap-4">
                  <Button 
                    onClick={openEmailClient}
                    variant="outline"
                    className="h-12 flex items-center gap-2"
                  >
                    <Mail className="h-4 w-4" />
                    Open Email App
                  </Button>
                  <Button 
                    onClick={openSMSClient}
                    variant="outline"
                    className="h-12 flex items-center gap-2"
                  >
                    <Phone className="h-4 w-4" />
                    Open SMS App
                  </Button>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="facebook" className="space-y-4">
              <FacebookFriendsInvite />
            </TabsContent>
            
            <TabsContent value="share" className="space-y-4">
              <div className="space-y-4">
                <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
                  <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                    <Gift className="h-5 w-5" />
                    Your Referral Link
                  </h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Share this link and earn rewards when friends join!
                  </p>
                  <div className="flex gap-2">
                    <div className="flex-1 p-2 bg-white rounded border text-sm font-mono break-all">
                      {inviteUrl}
                    </div>
                    <Button size="sm" onClick={copyInviteLink}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 gap-3">
                  <Button 
                    onClick={shareNatively}
                    className="h-12 flex items-center gap-3"
                  >
                    <Share2 className="h-5 w-5" />
                    Share via Device
                  </Button>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <Button 
                      onClick={openEmailClient}
                      variant="outline"
                      className="h-12 flex items-center gap-2"
                    >
                      <Mail className="h-4 w-4" />
                      Email
                    </Button>
                    <Button 
                      onClick={openSMSClient}
                      variant="outline"
                      className="h-12 flex items-center gap-2"
                    >
                      <Phone className="h-4 w-4" />
                      SMS
                    </Button>
                  </div>
                </div>
                
                <div className="mt-6 p-4 bg-green-50 rounded-lg">
                  <h4 className="font-semibold text-green-800 mb-2">Referral Benefits:</h4>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• Earn $5 credit for each friend who joins</li>
                    <li>• Your friends get $5 welcome bonus</li>
                    <li>• Help grow our local community</li>
                    <li>• Support local businesses together</li>
                  </ul>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};