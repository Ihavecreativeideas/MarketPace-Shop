import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

interface LaunchFuelMeterProps {
  progress: number; // 0-100
}

const LaunchFuelMeter: React.FC<LaunchFuelMeterProps> = ({ progress }) => {
  const getColor = () => {
    if (progress < 33) return 'bg-red-500';
    if (progress < 66) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getGlow = () => {
    if (progress < 33) return 'shadow-red-500/50';
    if (progress < 66) return 'shadow-yellow-500/50';
    return 'shadow-green-500/50';
  };

  return (
    <Card className="bg-white text-gray-900">
      <CardHeader className="text-center">
        <CardTitle className="text-3xl font-bold text-orange-600 mb-4">
          Recruit Your Town!
        </CardTitle>
        <div className="mb-6">
          <div className="text-2xl font-bold text-gray-800 mb-2">Launch Fuel</div>
          <div className="w-full bg-gray-200 rounded-full h-8 relative overflow-hidden">
            <div 
              className={`h-full ${getColor()} transition-all duration-1000 ease-out rounded-full ${getGlow()} shadow-lg`}
              style={{ width: `${progress}%` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse"></div>
            </div>
          </div>
          <div className="mt-2 text-sm text-gray-600">
            Growing stronger as more people join our community!
          </div>
        </div>
        <p className="text-gray-600">
          Help us reach launch readiness in your town!
        </p>
      </CardHeader>
    </Card>
  );
};

export default LaunchFuelMeter;