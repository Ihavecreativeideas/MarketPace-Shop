import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/components/AuthProvider';
import { Users, Truck, Store, Share2, Copy, Mail } from 'lucide-react';

export const InviteFriends: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [isInviting, setIsInviting] = useState(false);

  const baseUrl = window.location.origin;
  const referralCode = user?.id?.slice(0, 8) || 'DEMO123';
  
  const inviteLinks = {
    general: `${baseUrl}/join?ref=${referralCode}`,
    driver: `${baseUrl}/join-driver?ref=${referralCode}`,
    shop: `${baseUrl}/join-shop?ref=${referralCode}`
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: 'Copied!',
      description: `${type} invite link copied to clipboard`
    });
  };

  const shareViaEmail = (link: string, type: string) => {
    const subject = encodeURIComponent(`Join our delivery platform as a ${type}`);
    const body = encodeURIComponent(
      `Hi! I'd like to invite you to join our delivery platform as a ${type}.\n\n` +
      `Click here to get started: ${link}\n\n` +
      `Best regards!`
    );
    window.open(`mailto:?subject=${subject}&body=${body}`);
  };

  const inviteViaFacebook = () => {
    const appUrl = window.location.origin;
    const message = encodeURIComponent('Join me on this amazing delivery platform!');
    const link = encodeURIComponent(inviteLinks.general);
    
    // Try to open Facebook app first, fallback to web
    const fbAppUrl = `fb://share?link=${link}&quote=${message}`;
    const fbWebUrl = `https://www.facebook.com/sharer/sharer.php?u=${link}&quote=${message}`;
    
    // Attempt to open Facebook app
    const iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    iframe.src = fbAppUrl;
    document.body.appendChild(iframe);
    
    // Fallback to web after a short delay
    setTimeout(() => {
      document.body.removeChild(iframe);
      window.open(fbWebUrl, '_blank', 'width=600,height=400');
    }, 500);
    
    toast({
      title: 'Opening Facebook',
      description: 'Redirecting to Facebook to invite friends'
    });
  };

  const sendInviteEmail = async () => {
    if (!email.trim()) {
      toast({
        title: 'Email Required',
        description: 'Please enter an email address'
      });
      return;
    }

    setIsInviting(true);
    try {
      console.log('Sending invite to:', email);
      
      toast({
        title: 'Invite Sent!',
        description: `Invitation sent to ${email}`
      });
      setEmail('');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send invitation',
        variant: 'destructive'
      });
    } finally {
      setIsInviting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-6 w-6" />
            Invite Friends & Grow Our Network
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="general" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="general">General Invite</TabsTrigger>
              <TabsTrigger value="drivers">Recruit Drivers</TabsTrigger>
              <TabsTrigger value="shops">Recruit Shops</TabsTrigger>
            </TabsList>
            
            <TabsContent value="general" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Share2 className="h-5 w-5" />
                    Invite Friends to Join
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button 
                    onClick={inviteViaFacebook}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                    </svg>
                    Invite Facebook Friends
                  </Button>
                  <div className="flex gap-2">
                    <Input 
                      value={inviteLinks.general}
                      readOnly
                      className="text-sm"
                    />
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={() => copyToClipboard(inviteLinks.general, 'General')}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <Input 
                      placeholder="Enter friend's email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      type="email"
                    />
                    <Button onClick={sendInviteEmail} disabled={isInviting}>
                      <Mail className="h-4 w-4 mr-2" />
                      {isInviting ? 'Sending...' : 'Send'}
                    </Button>
                  </div>
                  <Button 
                    variant="outline" 
                    onClick={() => shareViaEmail(inviteLinks.general, 'member')}
                    className="w-full"
                  >
                    Share via Email
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="drivers" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Truck className="h-5 w-5" />
                    Recruit Drivers
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Help us expand our delivery network by recruiting drivers. 
                    Drivers earn money on every delivery!
                  </p>
                  <div className="flex gap-2">
                    <Input 
                      value={inviteLinks.driver}
                      readOnly
                      className="text-sm"
                    />
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={() => copyToClipboard(inviteLinks.driver, 'Driver')}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <Button 
                    variant="outline" 
                    onClick={() => shareViaEmail(inviteLinks.driver, 'driver')}
                    className="w-full"
                  >
                    Share Driver Invite
                  </Button>
                  <div className="bg-green-50 p-3 rounded-lg">
                    <h4 className="font-semibold text-green-800">Driver Benefits:</h4>
                    <ul className="text-sm text-green-700 mt-1 space-y-1">
                      <li>• Flexible schedule</li>
                      <li>• Earn $15-25/hour</li>
                      <li>• Keep 100% of tips</li>
                      <li>• Weekly payouts</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="shops" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Store className="h-5 w-5" />
                    Recruit Local Shops
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Invite local businesses to join our platform and offer 
                    delivery services to their customers.
                  </p>
                  <div className="flex gap-2">
                    <Input 
                      value={inviteLinks.shop}
                      readOnly
                      className="text-sm"
                    />
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={() => copyToClipboard(inviteLinks.shop, 'Shop')}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <Button 
                    variant="outline" 
                    onClick={() => shareViaEmail(inviteLinks.shop, 'shop owner')}
                    className="w-full"
                  >
                    Share Shop Invite
                  </Button>
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <h4 className="font-semibold text-blue-800">Shop Benefits:</h4>
                    <ul className="text-sm text-blue-700 mt-1 space-y-1">
                      <li>• Increase sales reach</li>
                      <li>• No upfront costs</li>
                      <li>• Easy integration</li>
                      <li>• Customer analytics</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};