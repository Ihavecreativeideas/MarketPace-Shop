import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Check, Crown, Music, Store, Users, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import StripeCheckout from './StripeCheckout';
import { supabase } from '@/lib/supabase';

interface ProfileSubscriptionManagerProps {
  profileType: 'musician' | 'marketplace' | 'pacemaker';
  userId: string;
  onSubscriptionChange?: (subscription: any) => void;
}

const ProfileSubscriptionManager: React.FC<ProfileSubscriptionManagerProps> = ({
  profileType,
  userId,
  onSubscriptionChange
}) => {
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [currentSubscription, setCurrentSubscription] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const subscriptionPlans = {
    musician: [
      {
        id: 'musician-silver',
        name: 'Silver',
        price: 26.42,
        features: [
          'Social Media Integration',
          'Fan Notifications',
          'Event Promotion',
          'Basic Analytics',
          'Priority Support'
        ]
      },
      {
        id: 'musician-gold',
        name: 'Gold',
        price: 38.96,
        popular: true,
        features: [
          'Everything in Silver',
          'Advanced Analytics',
          'Verified Badge',
          'Featured Placement',
          'Custom Branding'
        ]
      },
      {
        id: 'musician-platinum',
        name: 'Platinum',
        price: 54.98,
        features: [
          'Everything in Gold',
          'API Access',
          'Dedicated Support',
          'Premium Features',
          'Marketing Tools'
        ]
      }
    ],
    marketplace: [
      {
        id: 'marketplace-silver',
        name: 'Silver',
        price: 26.42,
        features: [
          'Priority Listings',
          'Basic Analytics',
          'Extended Return Policy',
          'Customer Support'
        ]
      },
      {
        id: 'marketplace-gold',
        name: 'Gold',
        price: 38.96,
        popular: true,
        features: [
          'Everything in Silver',
          'Advanced Search Filters',
          'Featured Placement',
          'Seller Analytics',
          'Marketing Tools'
        ]
      },
      {
        id: 'marketplace-platinum',
        name: 'Platinum',
        price: 54.98,
        features: [
          'Everything in Gold',
          'API Integration',
          'Dedicated Support',
          'Custom Branding',
          'Premium Features'
        ]
      }
    ],
    pacemaker: [
      {
        id: 'pacemaker-silver',
        name: 'Silver',
        price: 26.42,
        features: [
          'Website Integration',
          'Social Media Tools',
          'Basic Analytics',
          'Customer Support',
          'Marketing Tools'
        ]
      },
      {
        id: 'pacemaker-gold',
        name: 'Gold',
        price: 38.96,
        popular: true,
        features: [
          'Everything in Silver',
          'Advanced SEO Tools',
          'Priority Support',
          'Featured Placement',
          'Custom Branding'
        ]
      },
      {
        id: 'pacemaker-platinum',
        name: 'Platinum',
        price: 54.98,
        features: [
          'Everything in Gold',
          'API Access',
          'Dedicated Support',
          'Premium Features',
          'Advanced Analytics'
        ]
      }
    ]
  };

  // Generate a valid UUID for the user if needed
  const generateValidUserId = () => {
    return crypto.randomUUID();
  };

  // Validate if string is a valid UUID
  const isValidUUID = (str: string) => {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return uuidRegex.test(str);
  };

  const fetchCurrentSubscription = async () => {
    try {
      setLoading(true);
      
      // Ensure we have a valid UUID
      let validUserId = userId;
      if (!isValidUUID(userId)) {
        validUserId = generateValidUserId();
        console.warn('Invalid UUID provided, generated new one:', validUserId);
      }
      
      const { data, error } = await supabase
        .from('profile_subscriptions')
        .select('*')
        .eq('user_id', validUserId)
        .eq('profile_type', profileType)
        .eq('status', 'active')
        .maybeSingle();

      if (error) {
        console.error('Error fetching subscription:', error);
        toast({
          title: 'Warning',
          description: 'Could not load subscription data. Using demo mode.',
          variant: 'default'
        });
        return;
      }

      setCurrentSubscription(data);
    } catch (error) {
      console.error('Error fetching subscription:', error);
      toast({
        title: 'Info',
        description: 'Running in demo mode - subscription features available for preview.',
        variant: 'default'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (userId) {
      fetchCurrentSubscription();
    }
  }, [userId, profileType]);

  const handleSubscribe = (plan: any) => {
    setSelectedPlan(plan);
    setShowCheckout(true);
  };

  const handlePaymentSuccess = async (subscriptionId: string) => {
    try {
      let validUserId = userId;
      if (!isValidUUID(userId)) {
        validUserId = generateValidUserId();
      }
      
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/5ca57993-e4b9-4419-a8bc-96cad232c309',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: validUserId,
            subscriptionId,
            planId: selectedPlan.id,
            planName: selectedPlan.name,
            profileType,
            action: 'activate'
          })
        }
      );

      if (!response.ok) {
        throw new Error('Payment processing failed');
      }

      const result = await response.json();
      
      if (result.success) {
        setCurrentSubscription(result.subscription);
        onSubscriptionChange?.(result.subscription);
        toast({
          title: 'Subscription Activated!',
          description: `Welcome to ${selectedPlan.name}! Your benefits are now active.`
        });
        await fetchCurrentSubscription();
      } else {
        throw new Error(result.error || 'Subscription activation failed');
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: 'Error',
        description: 'Failed to activate subscription. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setShowCheckout(false);
      setSelectedPlan(null);
    }
  };

  const getProfileIcon = () => {
    switch (profileType) {
      case 'musician': return <Music className="w-5 h-5" />;
      case 'marketplace': return <Store className="w-5 h-5" />;
      case 'pacemaker': return <Users className="w-5 h-5" />;
    }
  };

  const getProfileTitle = () => {
    switch (profileType) {
      case 'musician': return 'Musician Subscriptions';
      case 'marketplace': return 'Marketplace Subscriptions';
      case 'pacemaker': return 'PaceMaker Subscriptions';
    }
  };

  const plans = subscriptionPlans[profileType];

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <div className="flex items-center justify-center gap-2">
          {getProfileIcon()}
          <h2 className="text-2xl font-bold">{getProfileTitle()}</h2>
        </div>
        <p className="text-gray-600">
          Upgrade your {profileType} profile with premium features
        </p>
      </div>

      {currentSubscription && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-green-800">
                  Current Plan: {currentSubscription.plan_name}
                </h3>
                <p className="text-sm text-green-600">
                  Active until {new Date(currentSubscription.expires_at).toLocaleDateString()}
                </p>
              </div>
              <Badge className="bg-green-600">Active</Badge>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 md:grid-cols-3">
        {plans.map((plan) => (
          <Card key={plan.id} className={`relative ${
            plan.popular ? 'border-purple-300 bg-gradient-to-br from-purple-50 to-white shadow-lg' : 'border-gray-200'
          }`}>
            {plan.popular && (
              <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-purple-600">
                ⭐ Popular
              </Badge>
            )}
            
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                <Crown className="w-5 h-5" />
                {plan.name}
              </CardTitle>
              <div className="text-3xl font-bold text-green-600">
                ${plan.price}
                <span className="text-sm text-gray-500 font-normal">/month</span>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="space-y-2">
                {plan.features.map((feature: string, index: number) => (
                  <div key={index} className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
              
              <Button 
                className="w-full"
                onClick={() => handleSubscribe(plan)}
                variant={plan.popular ? 'default' : 'outline'}
                disabled={currentSubscription?.plan_id === plan.id}
              >
                {currentSubscription?.plan_id === plan.id ? 'Current Plan' : 'Subscribe Now'}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={showCheckout} onOpenChange={setShowCheckout}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              Subscribe to {selectedPlan?.name}
              <Button variant="ghost" size="sm" onClick={() => setShowCheckout(false)}>
                <X className="h-4 w-4" />
              </Button>
            </DialogTitle>
          </DialogHeader>
          {selectedPlan && (
            <StripeCheckout
              planId={selectedPlan.id}
              planName={selectedPlan.name}
              price={selectedPlan.price}
              onSuccess={handlePaymentSuccess}
              onCancel={() => setShowCheckout(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProfileSubscriptionManager;