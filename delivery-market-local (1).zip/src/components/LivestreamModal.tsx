import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Video, X, Users, Eye, Heart, MessageCircle } from 'lucide-react';

interface LivestreamModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const LivestreamModal: React.FC<LivestreamModalProps> = ({ isOpen, onClose }) => {
  const [isLive, setIsLive] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [viewers, setViewers] = useState(0);

  const startLivestream = () => {
    if (title.trim()) {
      setIsLive(true);
      setViewers(Math.floor(Math.random() * 50) + 1);
    }
  };

  const stopLivestream = () => {
    setIsLive(false);
    setViewers(0);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-slate-800 border-slate-700">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Video className="h-5 w-5" />
            {isLive ? 'Live Stream' : 'Start Livestream'}
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isLive ? (
            <>
              <Input
                placeholder="Stream title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="bg-slate-700/50 border-slate-600 text-white"
              />
              <Textarea
                placeholder="Stream description (optional)"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="bg-slate-700/50 border-slate-600 text-white"
              />
              <div className="flex gap-2">
                <Button 
                  onClick={startLivestream}
                  className="bg-red-500 hover:bg-red-600 text-white"
                  disabled={!title.trim()}
                >
                  <Video className="h-4 w-4 mr-2" />
                  Go Live
                </Button>
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
              </div>
            </>
          ) : (
            <>
              <div className="bg-slate-900 rounded-lg p-4 text-center">
                <div className="flex items-center justify-center gap-2 mb-4">
                  <Badge className="bg-red-500 text-white animate-pulse">
                    LIVE
                  </Badge>
                  <span className="text-white font-semibold">{title}</span>
                </div>
                <div className="bg-slate-700 h-48 rounded-lg flex items-center justify-center mb-4">
                  <Video className="h-16 w-16 text-slate-400" />
                </div>
                <div className="flex items-center justify-center gap-4 text-slate-300">
                  <div className="flex items-center gap-1">
                    <Eye className="h-4 w-4" />
                    <span>{viewers}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Heart className="h-4 w-4" />
                    <span>{Math.floor(viewers * 0.7)}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageCircle className="h-4 w-4" />
                    <span>{Math.floor(viewers * 0.3)}</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button 
                  onClick={stopLivestream}
                  variant="destructive"
                  className="flex-1"
                >
                  End Stream
                </Button>
                <Button variant="outline" onClick={onClose}>
                  Close
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default LivestreamModal;
export { LivestreamModal };