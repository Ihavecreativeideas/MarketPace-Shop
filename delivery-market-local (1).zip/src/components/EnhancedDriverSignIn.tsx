import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Truck, User, Lock, Zap, Shield } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const EnhancedDriverSignIn: React.FC = () => {
  const [credentials, setCredentials] = useState({ 
    username: '', 
    password: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      // In a real app, this would validate against the generated credentials
      // For now, we'll simulate the validation
      if (credentials.username && credentials.password) {
        // Check if password follows the color+number format
        const passwordRegex = /^[A-Za-z]+\d+$/;
        if (!passwordRegex.test(credentials.password)) {
          throw new Error('Invalid password format. Expected: Color + Number');
        }

        // Simulate successful authentication
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Navigate to futuristic dashboard
        navigate('/driver-dashboard-futuristic');
      } else {
        throw new Error('Please enter both username and password');
      }
    } catch (error: any) {
      setError(error.message || 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card className="bg-gray-800/90 border-cyan-500/30 shadow-2xl shadow-cyan-500/20 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-3 text-3xl">
              <div className="p-2 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-lg">
                <Truck className="w-8 h-8 text-white" />
              </div>
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                DRIVER ACCESS
              </span>
            </CardTitle>
            <p className="text-cyan-300 mt-2">
              Neural Network Authentication Portal
            </p>
            <div className="flex items-center justify-center gap-2 mt-2">
              <Shield className="w-4 h-4 text-green-400" />
              <span className="text-xs text-green-400 uppercase tracking-wider">Secure Connection</span>
            </div>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert className="mb-6 bg-red-900/50 border-red-500/50 backdrop-blur-sm">
                <AlertDescription className="text-red-200">{error}</AlertDescription>
              </Alert>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="username" className="flex items-center gap-2 text-cyan-300 font-semibold">
                  <User className="w-4 h-4" />
                  DRIVER ID
                </Label>
                <Input
                  id="username"
                  type="text"
                  value={credentials.username}
                  onChange={(e) => setCredentials({...credentials, username: e.target.value})}
                  placeholder="Enter your unique driver username"
                  className="bg-gray-700/50 border-cyan-500/30 text-white placeholder-gray-400 focus:border-cyan-400 focus:ring-cyan-400/20"
                  required
                />
                <p className="text-xs text-gray-400">
                  Format: AdjFirstnameLastInitialNumber (e.g., SwiftJohnD42)
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password" className="flex items-center gap-2 text-purple-300 font-semibold">
                  <Lock className="w-4 h-4" />
                  ACCESS CODE
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={credentials.password}
                  onChange={(e) => setCredentials({...credentials, password: e.target.value})}
                  placeholder="Enter your color+number code"
                  className="bg-gray-700/50 border-purple-500/30 text-white placeholder-gray-400 focus:border-purple-400 focus:ring-purple-400/20"
                  required
                />
                <p className="text-xs text-gray-400">
                  Format: Color + Number (e.g., Blue1234)
                </p>
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-bold py-3 text-lg transition-all duration-300 transform hover:scale-105"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 animate-pulse" />
                    AUTHENTICATING...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    CONNECT TO NETWORK
                  </div>
                )}
              </Button>
            </form>
            
            <div className="mt-6 p-4 bg-gray-700/30 rounded-lg border border-gray-600/30">
              <h4 className="text-cyan-400 font-semibold mb-2 text-sm">CREDENTIAL INFO:</h4>
              <div className="text-xs text-gray-300 space-y-1">
                <p>• Username: Generated by Hiring Manager Brayden Clay</p>
                <p>• Password: Random Color + Number combination</p>
                <p>• Sent via congratulations email after approval</p>
              </div>
            </div>
            
            <div className="mt-4 text-center">
              <Button 
                variant="link" 
                onClick={() => navigate('/driver-application')}
                className="text-cyan-400 hover:text-cyan-300 text-sm"
              >
                Need to apply? Submit Driver Application →
              </Button>
            </div>
            
            <div className="mt-4 text-center">
              <Button 
                variant="link" 
                onClick={() => navigate('/driver-credentials-generator')}
                className="text-purple-400 hover:text-purple-300 text-sm"
              >
                Admin: Generate Credentials →
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EnhancedDriverSignIn;