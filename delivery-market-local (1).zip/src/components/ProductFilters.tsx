import React from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ProductFiltersProps {
  selectedSize: string;
  selectedAge: string;
  onSizeChange: (size: string) => void;
  onAgeChange: (age: string) => void;
  category: string;
}

const clothingSizes = {
  'baby-clothes': ['Newborn', '0-3M', '3-6M', '6-9M', '9-12M', '12-18M', '18-24M'],
  'toddler-clothes': ['2T', '3T', '4T', '5T'],
  'women-clothes': ['XS', 'S', 'M', 'L', 'XL', 'XXL', '0', '2', '4', '6', '8', '10', '12', '14', '16'],
  'men-clothes': ['XS', 'S', 'M', 'L', 'XL', 'XXL', '28', '30', '32', '34', '36', '38', '40', '42'],
  'shoes': ['5', '5.5', '6', '6.5', '7', '7.5', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12']
};

const ageRanges = {
  'baby-clothes': ['0-3 months', '3-6 months', '6-12 months', '12-24 months'],
  'baby-accessories': ['0-6 months', '6-12 months', '12-24 months'],
  'toddler-clothes': ['2-3 years', '3-4 years', '4-5 years'],
  'toys': ['0-1 year', '1-2 years', '2-3 years', '3-5 years', '5+ years']
};

export const ProductFilters: React.FC<ProductFiltersProps> = ({
  selectedSize,
  selectedAge,
  onSizeChange,
  onAgeChange,
  category
}) => {
  const availableSizes = clothingSizes[category as keyof typeof clothingSizes] || [];
  const availableAges = ageRanges[category as keyof typeof ageRanges] || [];

  if (availableSizes.length === 0 && availableAges.length === 0) {
    return null;
  }

  return (
    <Card className="bg-white/10 backdrop-blur-sm border-white/20 mb-4">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-sm">Filters</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {availableSizes.length > 0 && (
          <div>
            <Label className="text-white text-sm mb-2 block">Size</Label>
            <Select value={selectedSize} onValueChange={onSizeChange}>
              <SelectTrigger className="bg-white/10 border-white/20 text-white">
                <SelectValue placeholder="Select size" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sizes</SelectItem>
                {availableSizes.map((size) => (
                  <SelectItem key={size} value={size}>
                    {size}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
        
        {availableAges.length > 0 && (
          <div>
            <Label className="text-white text-sm mb-2 block">Age Range</Label>
            <Select value={selectedAge} onValueChange={onAgeChange}>
              <SelectTrigger className="bg-white/10 border-white/20 text-white">
                <SelectValue placeholder="Select age range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Ages</SelectItem>
                {availableAges.map((age) => (
                  <SelectItem key={age} value={age}>
                    {age}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </CardContent>
    </Card>
  );
};