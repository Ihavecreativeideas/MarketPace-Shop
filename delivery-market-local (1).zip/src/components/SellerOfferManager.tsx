import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { CheckCircle, XCircle, Clock, DollarSign } from 'lucide-react';

interface Offer {
  id: string;
  buyerName: string;
  itemName: string;
  originalPrice: number;
  offerPrice: number;
  discountPercent: number;
  status: 'pending' | 'accepted' | 'declined' | 'countered';
  timestamp: string;
  counterOfferPrice?: number;
}

interface SellerOfferManagerProps {
  sellerId?: string;
}

const SellerOfferManager: React.FC<SellerOfferManagerProps> = ({ sellerId }) => {
  const [offers, setOffers] = useState<Offer[]>([
    {
      id: '1',
      buyerName: 'John D.',
      itemName: 'Handcrafted Ceramic Mug',
      originalPrice: 24.99,
      offerPrice: 18.74,
      discountPercent: 25,
      status: 'pending',
      timestamp: '2 hours ago'
    },
    {
      id: '2',
      buyerName: 'Sarah M.',
      itemName: 'Vintage Band T-Shirt',
      originalPrice: 35.00,
      offerPrice: 22.75,
      discountPercent: 35,
      status: 'pending',
      timestamp: '1 hour ago'
    }
  ]);
  
  const [counterOffers, setCounterOffers] = useState<{ [key: string]: string }>({});

  const handleAcceptOffer = (offerId: string) => {
    setOffers(prev => prev.map(offer => 
      offer.id === offerId 
        ? { ...offer, status: 'accepted' }
        : offer
    ));
  };

  const handleDeclineOffer = (offerId: string) => {
    setOffers(prev => prev.map(offer => 
      offer.id === offerId 
        ? { ...offer, status: 'declined' }
        : offer
    ));
  };

  const handleCounterOffer = (offerId: string) => {
    const counterPrice = parseFloat(counterOffers[offerId]);
    if (!counterPrice) return;
    
    setOffers(prev => prev.map(offer => 
      offer.id === offerId 
        ? { ...offer, status: 'countered', counterOfferPrice: counterPrice }
        : offer
    ));
    
    setCounterOffers(prev => ({ ...prev, [offerId]: '' }));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'accepted': return 'bg-green-100 text-green-800';
      case 'declined': return 'bg-red-100 text-red-800';
      case 'countered': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'accepted': return <CheckCircle className="w-4 h-4" />;
      case 'declined': return <XCircle className="w-4 h-4" />;
      case 'countered': return <DollarSign className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const pendingOffers = offers.filter(offer => offer.status === 'pending');
  const processedOffers = offers.filter(offer => offer.status !== 'pending');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Offer Management</h2>
        <Badge className="bg-blue-100 text-blue-800">
          {pendingOffers.length} Pending
        </Badge>
      </div>

      {/* Pending Offers */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Pending Offers</h3>
        {pendingOffers.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-gray-500">
              No pending offers at the moment
            </CardContent>
          </Card>
        ) : (
          pendingOffers.map((offer) => (
            <Card key={offer.id} className="border-l-4 border-l-yellow-400">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{offer.itemName}</CardTitle>
                    <p className="text-sm text-gray-600">Offer from {offer.buyerName}</p>
                    <p className="text-xs text-gray-500">{offer.timestamp}</p>
                  </div>
                  <Badge className={getStatusColor(offer.status)}>
                    {getStatusIcon(offer.status)}
                    <span className="ml-1 capitalize">{offer.status}</span>
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-sm text-gray-600">Original Price</p>
                      <p className="font-bold">${offer.originalPrice.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Offer Price</p>
                      <p className="font-bold text-blue-600">${offer.offerPrice.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Discount</p>
                      <p className="font-bold text-red-600">{offer.discountPercent}% off</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => handleAcceptOffer(offer.id)}
                      className="flex-1 bg-green-600 hover:bg-green-700"
                    >
                      Accept Offer
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => handleDeclineOffer(offer.id)}
                      className="flex-1 border-red-300 text-red-600 hover:bg-red-50"
                    >
                      Decline
                    </Button>
                  </div>
                  
                  <div className="border-t pt-4">
                    <p className="text-sm font-medium mb-2">Make Counter Offer:</p>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Enter price"
                        value={counterOffers[offer.id] || ''}
                        onChange={(e) => setCounterOffers(prev => ({
                          ...prev,
                          [offer.id]: e.target.value
                        }))}
                        min={offer.offerPrice}
                        max={offer.originalPrice}
                        step="0.01"
                      />
                      <Button 
                        onClick={() => handleCounterOffer(offer.id)}
                        disabled={!counterOffers[offer.id]}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Counter
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Processed Offers */}
      {processedOffers.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Recent Activity</h3>
          <div className="grid gap-4">
            {processedOffers.map((offer) => (
              <Card key={offer.id} className="opacity-75">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">{offer.itemName}</p>
                      <p className="text-sm text-gray-600">{offer.buyerName} • {offer.timestamp}</p>
                    </div>
                    <div className="text-right">
                      <Badge className={getStatusColor(offer.status)}>
                        {getStatusIcon(offer.status)}
                        <span className="ml-1 capitalize">{offer.status}</span>
                      </Badge>
                      <p className="text-sm mt-1">
                        ${offer.status === 'countered' && offer.counterOfferPrice 
                          ? offer.counterOfferPrice.toFixed(2) 
                          : offer.offerPrice.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SellerOfferManager;