import * as React from "react"
import { cn } from "@/lib/utils"

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-10 w-full rounded-lg border px-3 py-2 text-sm transition-all duration-300",
          "bg-slate-900/80 border-cyan-500/40 text-cyan-50 placeholder:text-slate-400",
          "backdrop-blur-md shadow-lg shadow-cyan-500/10",
          "focus:border-cyan-400/70 focus:ring-2 focus:ring-cyan-400/20 focus:shadow-cyan-400/20",
          "hover:border-cyan-400/60 hover:shadow-cyan-400/15",
          "disabled:cursor-not-allowed disabled:opacity-50",
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Input.displayName = "Input"

export { Input }