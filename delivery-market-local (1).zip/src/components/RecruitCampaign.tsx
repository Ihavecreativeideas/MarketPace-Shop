import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent } from './ui/dialog';
import { Users, Building2, Bike, Share2, Target, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LaunchFuelMeter from './LaunchFuelMeter';
import RecruitTownFlyer from './RecruitTownFlyer';
import CampaignSignup from './CampaignSignup';

const RecruitCampaign: React.FC = () => {
  const [showSignup, setShowSignup] = useState(false);
  const navigate = useNavigate();
  // Simulate progress based on community growth (0-100)
  const launchProgress = 45; // This would come from actual signup data

  const handleFacebookShare = () => {
    const shareUrl = encodeURIComponent(window.location.origin);
    const shareText = encodeURIComponent(
      "🚀 Help bring MarketPace to our community! We're ready to support local businesses and families, but we need YOUR support first! It's FREE to sign up and be part of building something amazing for our neighborhood. #RecruitYourTown #ShopLocal #CommunityFirst"
    );
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}&quote=${shareText}`;
    window.open(facebookUrl, '_blank', 'width=600,height=400');
  };

  const handleRecruitDrivers = () => {
    navigate('/driver-job');
  };

  const handleJoinCampaign = () => {
    navigate('/campaign-signup');
  };

  const handleShareFlyer = () => {
    // Share the dedicated flyer page URL instead of just text
    const flyerUrl = `${window.location.origin}/flyer`;
    const shareText = "🏪🚗 Recruit Your Town Launch Campaign! We're preparing to launch a delivery business focused on shopping local and delivering opportunities to communities. Join us in creating local jobs and boosting our local economy! #RecruitYourTown #ShopLocal #MarketPace";
    
    if (navigator.share) {
      navigator.share({
        title: 'Recruit Your Town - MarketPace',
        text: shareText,
        url: flyerUrl,
      });
    } else {
      // Fallback to Facebook share with the flyer page URL
      const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(flyerUrl)}&quote=${encodeURIComponent(shareText)}`;
      window.open(facebookUrl, '_blank', 'width=600,height=400');
    }
  };

  return (
    <section className="bg-gradient-to-r from-orange-500 to-red-500 text-white py-16">
      <div className="max-w-6xl mx-auto px-4">
        {/* Recruit Your Town Flyer */}
        <div className="mb-12">
          <RecruitTownFlyer 
            onJoinCampaign={handleJoinCampaign}
            onShare={handleShareFlyer}
          />
        </div>

        {/* Preparing to Launch */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-white/20 rounded-full px-6 py-2 mb-6">
            <Target className="h-5 w-5" />
            <span className="font-semibold">Preparing to Launch</span>
          </div>
          <h2 className="text-4xl font-bold mb-4">Coming Soon to Your Town!</h2>
          <p className="text-xl opacity-90 max-w-3xl mx-auto">
            We're excited to bring MarketPace to your community, but we need your help to make it happen!
          </p>
        </div>

        {/* Launch Fuel Meter */}
        <div className="mb-8">
          <LaunchFuelMeter progress={launchProgress} />
        </div>

        {/* Recruit Actions */}
        <Card className="bg-white text-gray-900 mb-8">
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-3 gap-4 mb-8">
              <Button 
                className="bg-blue-600 hover:bg-blue-700 h-16"
                onClick={() => navigate('/recruit-shops')}
              >
                <Building2 className="h-5 w-5 mr-2" />
                Recruit Local Businesses
              </Button>
              <Button 
                className="bg-green-600 hover:bg-green-700 h-16"
                onClick={handleRecruitDrivers}
              >
                <Bike className="h-5 w-5 mr-2" />
                Recruit Drivers
              </Button>
              <Button 
                className="bg-orange-600 hover:bg-orange-700 h-16"
                onClick={handleJoinCampaign}
              >
                <Users className="h-5 w-5 mr-2" />
                Join Campaign
              </Button>
            </div>

            {/* Facebook Share Section */}
            <div className="bg-blue-50 rounded-lg p-6 text-center">
              <h3 className="text-xl font-semibold mb-4 text-gray-900">
                Share Our Mission on Facebook
              </h3>
              <p className="text-gray-700 mb-6">
                We're ready to support your community, but we need your support first! 
                Help spread the word - it's completely FREE to sign up and be part of something amazing.
              </p>
              <Button 
                onClick={handleFacebookShare}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3"
                size="lg"
              >
                <Share2 className="h-5 w-5 mr-2" />
                Recruit Your Town on Facebook
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Why We Need You */}
        <div className="grid md:grid-cols-2 gap-8">
          <Card className="bg-white/10 border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <CheckCircle className="h-6 w-6" />
                Community First
              </CardTitle>
            </CardHeader>
            <CardContent className="text-white/90">
              <p>
                MarketPace only launches when we have enough community members to ensure 
                success for everyone - drivers, businesses, and customers alike.
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-white/10 border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <CheckCircle className="h-6 w-6" />
                Free to Join
              </CardTitle>
            </CardHeader>
            <CardContent className="text-white/90">
              <p>
                No cost, no commitment - just be part of building a stronger local economy 
                that supports families and businesses in your neighborhood.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Campaign Signup Modal */}
      <Dialog open={showSignup} onOpenChange={setShowSignup}>
        <DialogContent className="max-w-md">
          <CampaignSignup onClose={() => setShowSignup(false)} />
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default RecruitCampaign;