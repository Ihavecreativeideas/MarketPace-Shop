import { useAuth } from './SecureAuthProvider';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useState } from 'react';
import Index from '../pages/Index';
import MarketplacePage from '../pages/MarketplacePage';
import HandcraftedPage from '../pages/HandcraftedPage';
import ShopsPage from '../pages/ShopsPage';
import ServicesPage from '../pages/ServicesPage';
import MusiciansPage from '../pages/MusiciansPage';
import ProfilePage from '../pages/ProfilePage';
import WishlistPage from '../pages/WishlistPage';
import InviteFriendsPage from '../pages/InviteFriendsPage';
import DriverSignInPage from '../pages/DriverSignInPage';
import DriverApplicationPage from '../pages/DriverApplicationPage';
import ActivityLogPage from '../pages/ActivityLogPage';
import DriverDashboardPage from '../pages/DriverDashboardPage';
import EntertainmentPage from '../pages/EntertainmentPage';
import BusinessSetupPage from '../pages/BusinessSetupPage';
import AuthPage from '../pages/AuthPage';
import SearchPage from '../pages/SearchPage';
import SellerPage from '../pages/SellerPage';
import AdminPage from '../pages/AdminPage';
import DashboardPage from '../pages/DashboardPage';
import OnboardingPage from '../pages/OnboardingPage';
import SetupPage from '../pages/SetupPage';
import LegalPage from '../pages/LegalPage';
import SponsorshipPage from '../pages/SponsorshipPage';
import SubscriptionsPage from '../pages/SubscriptionsPage';
import ReviewsPage from '../pages/ReviewsPage';
import CommunityPage from '../pages/CommunityPage';
import RentAnything from './RentAnything';
import FloatingNavigation from './FloatingNavigation';
import AnalyticsDashboard from './AnalyticsDashboard';
import AdsManager from './AdsManager';
import BusinessIntegrationGuide from './BusinessIntegrationGuide';
import BlockReportMembers from './BlockReportMembers';
import CommunityStandards from './CommunityStandards';
import CookiesPolicy from './CookiesPolicy';
import HealthDataPrivacy from './HealthDataPrivacy';
import PrivacyCenter from './PrivacyCenter';
import PaymentsPayouts from './PaymentsPayouts';
import PostPace from './PostPace';
import FacebookIntegration from './FacebookIntegration';
import ForYouPage from './ForYouPage';
import { CartProvider } from './CartContext';
import FuturisticBackground from './FuturisticBackground';
import GlobalThemeWrapper from './GlobalThemeWrapper';
import AuthModal from './AuthModal';
import FloatingIcon from './FloatingIcon';
import TownLaunchMeter from './TownLaunchMeter';
import { ContactShareModal } from './ContactShareModal';
import { Button } from '@/components/ui/button';
import { Share2 } from 'lucide-react';

export default function AppContent() {
  const { user, isGuest, loading, signIn, signUp, signInAsGuest } = useAuth();
  const [showAuth, setShowAuth] = useState(false);

  if (loading) {
    return (
      <GlobalThemeWrapper>
        <div className="min-h-screen flex items-center justify-center relative">
          <FuturisticBackground />
          <div className="text-lg text-white relative z-10">Loading...</div>
        </div>
      </GlobalThemeWrapper>
    );
  }

  if (!user && !isGuest) {
    return (
      <GlobalThemeWrapper>
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
          <FloatingIcon />
          
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {[...Array(30)].map((_, i) => (
              <div
                key={i}
                className="absolute w-1 h-1 bg-cyan-400/30 rounded-full animate-pulse"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 3}s`,
                  animationDuration: `${2 + Math.random() * 3}s`
                }}
              />
            ))}
          </div>

          <div className="text-center space-y-6 max-w-md mx-auto p-6 relative z-10">
            <TownLaunchMeter 
              townName="Your Town"
              members={247}
              shops={18}
              entertainers={12}
              drivers={31}
              services={9}
              targetMembers={1000}
            />

            <div className="space-y-2">
              <h1 className="text-4xl font-bold text-white">Welcome to MarketPace</h1>
              <p className="text-gray-300 text-lg">You set the pace, we make it happen!</p>
              <p className="text-cyan-400 text-sm font-medium">Buy, sell, rent, and hire locally!</p>
            </div>
            
            <div className="space-y-3">
              <Button 
                onClick={signInAsGuest}
                className="w-full h-12 text-lg font-medium bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700"
              >
                Join Launch Campaign
              </Button>
              
              <ContactShareModal>
                <Button variant="ghost" className="w-full text-gray-300 hover:bg-white/10">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share with Friends
                </Button>
              </ContactShareModal>
            </div>
            
            <p className="text-xs text-gray-400 leading-relaxed">
              Early subscribers get lifetime benefits and help launch MarketPace in your community!
            </p>
          </div>
        </div>
      </GlobalThemeWrapper>
    );
  }

  return (
    <GlobalThemeWrapper>
      <CartProvider>
        <TooltipProvider>
          <Toaster />
          <BrowserRouter>
            <div className="min-h-screen relative">
              <FuturisticBackground />
              <div className="relative z-10">
                <Routes>
                  <Route path="/" element={<Index />} />
                  <Route path="/for-you" element={<ForYouPage />} />
                  <Route path="/marketplace" element={<MarketplacePage />} />
                  <Route path="/handcrafted" element={<HandcraftedPage />} />
                  <Route path="/shops" element={<ShopsPage />} />
                  <Route path="/services" element={<ServicesPage />} />
                  <Route path="/musicians" element={<MusiciansPage />} />
                  <Route path="/profile" element={<ProfilePage />} />
                  <Route path="/wishlist" element={<WishlistPage />} />
                  <Route path="/favorites" element={<WishlistPage />} />
                  <Route path="/invite-friends" element={<InviteFriendsPage />} />
                  <Route path="/driver-signin" element={<DriverSignInPage />} />
                  <Route path="/driver-application" element={<DriverApplicationPage />} />
                  <Route path="/driver-dashboard" element={<DriverDashboardPage />} />
                  <Route path="/driver-demo" element={<DriverDashboardPage />} />
                  <Route path="/activity-log" element={<ActivityLogPage />} />
                  <Route path="/entertainment" element={<EntertainmentPage />} />
                  <Route path="/business-setup" element={<BusinessSetupPage />} />
                  <Route path="/auth" element={<AuthPage />} />
                  <Route path="/search" element={<SearchPage />} />
                  <Route path="/seller" element={<SellerPage />} />
                  <Route path="/admin" element={<AdminPage />} />
                  <Route path="/dashboard" element={<DashboardPage />} />
                  <Route path="/onboarding" element={<OnboardingPage />} />
                  <Route path="/setup" element={<SetupPage />} />
                  <Route path="/legal" element={<LegalPage />} />
                  <Route path="/sponsorship" element={<SponsorshipPage />} />
                  <Route path="/subscriptions" element={<SubscriptionsPage />} />
                  <Route path="/reviews" element={<ReviewsPage />} />
                  <Route path="/community" element={<CommunityPage />} />
                  <Route path="/rent-anything" element={<RentAnything />} />
                  <Route path="/analytics" element={<AnalyticsDashboard />} />
                  <Route path="/ads-manager" element={<AdsManager />} />
                  <Route path="/business-integration" element={<BusinessIntegrationGuide />} />
                  <Route path="/block-report" element={<BlockReportMembers />} />
                  <Route path="/community-standards" element={<CommunityStandards />} />
                  <Route path="/cookies-policy" element={<CookiesPolicy />} />
                  <Route path="/health-privacy" element={<HealthDataPrivacy />} />
                  <Route path="/privacy-center" element={<PrivacyCenter />} />
                  <Route path="/payments" element={<PaymentsPayouts />} />
                  <Route path="/postpace" element={<PostPace />} />
                  <Route path="/facebook-integration" element={<FacebookIntegration />} />
                </Routes>
              </div>
              <FloatingNavigation />
            </div>
          </BrowserRouter>
        </TooltipProvider>
      </CartProvider>
    </GlobalThemeWrapper>
  );
}