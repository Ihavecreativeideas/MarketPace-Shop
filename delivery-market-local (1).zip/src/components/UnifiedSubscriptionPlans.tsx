import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Check, Crown, Calendar, Truck, DollarSign, X, Globe, BarChart3, Star, Package } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import StripeCheckout from './StripeCheckout';
import SubscriptionManager from './SubscriptionManager';

const UnifiedSubscriptionPlans: React.FC = () => {
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [currentUserId] = useState('user-123');
  const { toast } = useToast();

  const deliveryPlans = [
    {
      id: 'premium-daily',
      type: 'delivery',
      name: 'Premium Daily',
      price: Math.round((30 * 14) * 0.80),
      originalPrice: 30 * 14,
      popular: true,
      features: [
        '30 deliveries per month',
        'Up to 20 miles per day',
        'Daily delivery service',
        'All 7 days per week',
        '20% discount on all deliveries'
      ]
    }
  ];

  const partnerPlans = [
    {
      id: 'silver-partner',
      type: 'partner',
      name: 'Silver',
      price: 100,
      tier: 'Silver',
      deliveryDays: '1 day/week (4/month)',
      deliveries: '8 deliveries included',
      features: [
        '20% off base delivery fee',
        '50% off sustainability fees',
        '1 delivery day a week (4 a month) with 8 deliveries',
        'Save $0.25 off every mile for every delivery',
        'External web integration',
        'External delivery service integration',
        'Set your own S&H fee',
        'Advanced Analytics',
        'Promotional options',
        'Priority Placement in search table',
        'Covers Cost of Returns'
      ]
    },
    {
      id: 'gold-partner',
      type: 'partner',
      name: 'Gold',
      price: 150,
      tier: 'Gold',
      deliveryDays: '2 days/week (8/month)',
      deliveries: '16 deliveries included',
      popular: true,
      features: [
        '20% off base delivery fee',
        '100% off sustainability fees',
        '2 delivery days a week (8 a month) with 16 deliveries',
        'Save $0.25 off every mile for every delivery',
        'External web integration',
        'External delivery service integration',
        'Set your own S&H fee',
        'Advanced Analytics',
        'Promotional options',
        'Priority Placement in search table',
        'Covers cost of Returns',
        'Business cards/stickers/merch with MarketPace QR codes'
      ]
    },
    {
      id: 'platinum-partner',
      type: 'partner',
      name: 'Platinum',
      price: 200,
      tier: 'Platinum',
      deliveryDays: '3 days/week (12/month)',
      deliveries: '24 deliveries included',
      features: [
        '25% off base delivery fee',
        '100% off sustainability fees',
        '3 delivery days a week (12 a month) with 24 deliveries',
        'Save $0.25 off every mile for every delivery',
        'External web integration',
        'External delivery service integration',
        'Set your own S&H fee',
        'Advanced Analytics',
        'Promotional options',
        'Priority Placement in search table',
        'Covers Cost of Returns',
        'Business cards/stickers/merch with MarketPace QR codes'
      ]
    }
  ];

  const handleSubscribe = (plan: any) => {
    setSelectedPlan(plan);
    setShowCheckout(true);
  };

  const handlePaymentSuccess = async (subscriptionId: string) => {
    try {
      const response = await fetch(
        'https://mmdhnbfdlecjznaupqko.supabase.co/functions/v1/7bac36cf-b0c7-4eb1-bef7-3cd4e20f2e79',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: currentUserId,
            subscriptionId,
            planId: selectedPlan.id,
            planName: selectedPlan.name,
            planType: selectedPlan.type,
            action: 'activate'
          })
        }
      );

      const result = await response.json();
      
      if (result.success) {
        toast({
          title: 'Subscription Activated!',
          description: `Welcome to ${selectedPlan.name}! Your benefits are now active.`
        });
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setShowCheckout(false);
      setSelectedPlan(null);
    }
  };

  const renderPlanCard = (plan: any) => {
    const tierColors = {
      Silver: 'border-gray-300 bg-gradient-to-br from-gray-50 to-white',
      Gold: 'border-yellow-300 bg-gradient-to-br from-yellow-50 to-white',
      Platinum: 'border-purple-300 bg-gradient-to-br from-purple-50 to-white'
    };

    return (
      <Card key={plan.id} className={`relative ${
        plan.popular ? 'border-purple-300 bg-gradient-to-br from-purple-50 to-white shadow-lg' : 
        plan.tier ? tierColors[plan.tier as keyof typeof tierColors] : 'border-gray-200'
      }`}>
        {plan.popular && (
          <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-purple-600">
            ⭐ Popular
          </Badge>
        )}
        
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2">
            {plan.type === 'delivery' ? <Truck className="w-5 h-5" /> : <Crown className="w-5 h-5" />}
            {plan.name}
          </CardTitle>
          {plan.tier && (
            <div className="text-sm text-gray-600 mb-2">
              {plan.deliveryDays} • {plan.deliveries}
            </div>
          )}
          <div className="space-y-2">
            <div className="text-3xl font-bold text-green-600">
              ${plan.price}
              <span className="text-sm text-gray-500 font-normal">/month</span>
            </div>
            {plan.originalPrice && (
              <div className="text-sm text-gray-500 line-through">
                ${plan.originalPrice}
              </div>
            )}
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="space-y-2">
            {plan.features.map((feature: string, index: number) => (
              <div key={index} className="flex items-start gap-2">
                <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span className="text-sm">{feature}</span>
              </div>
            ))}
          </div>
          
          <Button 
            className="w-full"
            onClick={() => handleSubscribe(plan)}
            variant={plan.popular ? 'default' : 'outline'}
          >
            Subscribe Now
          </Button>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 p-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          Subscription Plans
        </h1>
        <p className="text-xl text-gray-600">
          Choose the perfect plan for your delivery needs or business growth
        </p>
      </div>

      <SubscriptionManager 
        userId={currentUserId}
        onSubscriptionChange={(sub) => console.log('Subscription changed:', sub)}
      />

      <Tabs defaultValue="delivery" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="delivery" className="flex items-center gap-2">
            <Truck className="w-4 h-4" />
            Delivery Plans
          </TabsTrigger>
          <TabsTrigger value="partner" className="flex items-center gap-2">
            <Crown className="w-4 h-4" />
            Vendor Partnership Tiers
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="delivery" className="space-y-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-2">Delivery Subscriptions</h2>
            <p className="text-gray-600">Save 20% on all deliveries with our subscription plans</p>
          </div>
          <div className="grid md:grid-cols-1 gap-6 max-w-md mx-auto">
            {deliveryPlans.map(renderPlanCard)}
          </div>
        </TabsContent>
        
        <TabsContent value="partner" className="space-y-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-2">Vendor Partnership Tiers</h2>
            <p className="text-gray-600">Unlock exclusive features including website integration for your business</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {partnerPlans.map(renderPlanCard)}
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Globe className="w-5 h-5 text-blue-600" />
              <span className="font-semibold text-blue-800">Website Integration Exclusive</span>
            </div>
            <p className="text-sm text-blue-700">
              External web integration is only available to Vendor Partners. 
              Subscribe to any tier to connect your existing website to MarketPace.
            </p>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={showCheckout} onOpenChange={setShowCheckout}>
        <DialogContent className="max-w-md" hideTitle>
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              Subscribe to {selectedPlan?.name}
              <Button variant="ghost" size="sm" onClick={() => setShowCheckout(false)}>
                <X className="h-4 w-4" />
              </Button>
            </DialogTitle>
          </DialogHeader>
          {selectedPlan && (
            <StripeCheckout
              planId={selectedPlan.id}
              planName={selectedPlan.name}
              price={selectedPlan.price}
              onSuccess={handlePaymentSuccess}
              onCancel={() => setShowCheckout(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UnifiedSubscriptionPlans;