import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Store, Wrench, Music, MapPin, Phone, Globe, Clock } from 'lucide-react';

interface BusinessProfileSetupProps {
  businessType: 'shop' | 'service' | 'entertainment';
  onComplete: () => void;
}

const BusinessProfileSetup: React.FC<BusinessProfileSetupProps> = ({ businessType, onComplete }) => {
  const [businessInfo, setBusinessInfo] = useState({
    name: '',
    description: '',
    address: '',
    phone: '',
    website: '',
    hours: '',
    specialties: [] as string[],
    priceRange: '',
    serviceArea: ''
  });

  const [currentSpecialty, setCurrentSpecialty] = useState('');

  const getBusinessIcon = () => {
    switch (businessType) {
      case 'shop': return Store;
      case 'service': return Wrench;
      case 'entertainment': return Music;
    }
  };

  const getBusinessTitle = () => {
    switch (businessType) {
      case 'shop': return 'Shop Profile';
      case 'service': return 'Service Profile';
      case 'entertainment': return 'Entertainment Profile';
    }
  };

  const getSpecialtyPlaceholder = () => {
    switch (businessType) {
      case 'shop': return 'e.g., Electronics, Clothing, Home Goods';
      case 'service': return 'e.g., Plumbing, Cleaning, Consulting';
      case 'entertainment': return 'e.g., Live Music, DJ, Photography';
    }
  };

  const handleAddSpecialty = () => {
    if (currentSpecialty.trim() && !businessInfo.specialties.includes(currentSpecialty.trim())) {
      setBusinessInfo(prev => ({
        ...prev,
        specialties: [...prev.specialties, currentSpecialty.trim()]
      }));
      setCurrentSpecialty('');
    }
  };

  const handleRemoveSpecialty = (specialty: string) => {
    setBusinessInfo(prev => ({
      ...prev,
      specialties: prev.specialties.filter(s => s !== specialty)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Save business profile to database
    console.log('Business profile:', { ...businessInfo, type: businessType });
    onComplete();
  };

  const Icon = getBusinessIcon();

  return (
    <div className="max-w-2xl mx-auto p-4">
      <Card className="bg-gradient-to-br from-slate-900 via-cyan-900 to-purple-900 border-cyan-500/30 text-white">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Icon className="h-12 w-12 text-cyan-400" />
          </div>
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            Setup Your {getBusinessTitle()}
          </CardTitle>
          <p className="text-cyan-300">
            Complete your business information to start attracting customers
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="businessName" className="text-cyan-300">
                Business Name *
              </Label>
              <Input
                id="businessName"
                value={businessInfo.name}
                onChange={(e) => setBusinessInfo(prev => ({ ...prev, name: e.target.value }))}
                className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                required
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-cyan-300">
                Business Description *
              </Label>
              <Textarea
                id="description"
                value={businessInfo.description}
                onChange={(e) => setBusinessInfo(prev => ({ ...prev, description: e.target.value }))}
                className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                placeholder="Describe your business and what makes it special..."
                rows={4}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="address" className="text-cyan-300 flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Business Address
                </Label>
                <Input
                  id="address"
                  value={businessInfo.address}
                  onChange={(e) => setBusinessInfo(prev => ({ ...prev, address: e.target.value }))}
                  className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                />
              </div>
              <div>
                <Label htmlFor="phone" className="text-cyan-300 flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  Business Phone
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  value={businessInfo.phone}
                  onChange={(e) => setBusinessInfo(prev => ({ ...prev, phone: e.target.value }))}
                  className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="website" className="text-cyan-300 flex items-center gap-2">
                <Globe className="h-4 w-4" />
                Website (Optional)
              </Label>
              <Input
                id="website"
                type="url"
                value={businessInfo.website}
                onChange={(e) => setBusinessInfo(prev => ({ ...prev, website: e.target.value }))}
                className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                placeholder="https://"
              />
            </div>

            <div>
              <Label htmlFor="hours" className="text-cyan-300 flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Business Hours
              </Label>
              <Input
                id="hours"
                value={businessInfo.hours}
                onChange={(e) => setBusinessInfo(prev => ({ ...prev, hours: e.target.value }))}
                className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                placeholder="e.g., Mon-Fri 9AM-6PM, Sat 10AM-4PM"
              />
            </div>

            <div>
              <Label className="text-cyan-300">
                {businessType === 'shop' ? 'Product Categories' : 
                 businessType === 'service' ? 'Service Specialties' : 
                 'Entertainment Types'}
              </Label>
              <div className="flex gap-2 mt-1">
                <Input
                  value={currentSpecialty}
                  onChange={(e) => setCurrentSpecialty(e.target.value)}
                  className="bg-slate-800 border-cyan-500/30 text-white"
                  placeholder={getSpecialtyPlaceholder()}
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSpecialty())}
                />
                <Button
                  type="button"
                  onClick={handleAddSpecialty}
                  className="bg-cyan-600 hover:bg-cyan-700"
                >
                  Add
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-2">
                {businessInfo.specialties.map((specialty) => (
                  <Badge
                    key={specialty}
                    variant="secondary"
                    className="bg-purple-600 text-white cursor-pointer"
                    onClick={() => handleRemoveSpecialty(specialty)}
                  >
                    {specialty} ×
                  </Badge>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="priceRange" className="text-cyan-300">
                  Price Range
                </Label>
                <Select onValueChange={(value) => setBusinessInfo(prev => ({ ...prev, priceRange: value }))}>
                  <SelectTrigger className="bg-slate-800 border-cyan-500/30 text-white">
                    <SelectValue placeholder="Select price range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="$">$ - Budget Friendly</SelectItem>
                    <SelectItem value="$$">$$ - Moderate</SelectItem>
                    <SelectItem value="$$$">$$$ - Premium</SelectItem>
                    <SelectItem value="$$$$">$$$$ - Luxury</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="serviceArea" className="text-cyan-300">
                  Service Area
                </Label>
                <Input
                  id="serviceArea"
                  value={businessInfo.serviceArea}
                  onChange={(e) => setBusinessInfo(prev => ({ ...prev, serviceArea: e.target.value }))}
                  className="mt-1 bg-slate-800 border-cyan-500/30 text-white"
                  placeholder="e.g., 10 mile radius, Statewide"
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
            >
              Complete Profile Setup
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default BusinessProfileSetup;