import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Palette, Settings, DollarSign, FileText, Plus, Trash2 } from 'lucide-react';

export default function AdminAppEditor() {
  const [appSettings, setAppSettings] = useState({
    title: 'MarketPace',
    description: 'Community-driven marketplace and delivery platform',
    theme: 'teal',
    deliveryFee: 2.99,
    serviceFee: 0.99,
    taxRate: 8.5
  });

  const [pages, setPages] = useState([
    { id: 1, name: 'Home', path: '/', enabled: true },
    { id: 2, name: 'Marketplace', path: '/marketplace', enabled: true },
    { id: 3, name: 'Community', path: '/community', enabled: true },
    { id: 4, name: 'Services', path: '/services', enabled: true }
  ]);

  const themes = [
    { name: 'Teal', value: 'teal', color: '#14b8a6' },
    { name: 'Blue', value: 'blue', color: '#3b82f6' },
    { name: 'Purple', value: 'purple', color: '#8b5cf6' },
    { name: 'Green', value: 'green', color: '#10b981' }
  ];

  const handleSaveSettings = () => {
    console.log('Saving app settings:', appSettings);
    alert('App settings saved successfully!');
  };

  const addPage = () => {
    const newPage = {
      id: Date.now(),
      name: 'New Page',
      path: '/new-page',
      enabled: true
    };
    setPages([...pages, newPage]);
  };

  const removePage = (id: number) => {
    setPages(pages.filter(p => p.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">App Editor</h2>
        <Button onClick={handleSaveSettings} className="bg-teal-600 hover:bg-teal-700">
          <Settings className="h-4 w-4 mr-2" />
          Save Changes
        </Button>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
          <TabsTrigger value="theme">Theme</TabsTrigger>
          <TabsTrigger value="pages">Pages</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>App Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="app-title">App Title</Label>
                <Input
                  id="app-title"
                  value={appSettings.title}
                  onChange={(e) => setAppSettings({...appSettings, title: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="app-description">Description</Label>
                <Textarea
                  id="app-description"
                  value={appSettings.description}
                  onChange={(e) => setAppSettings({...appSettings, description: e.target.value})}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Payment Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="delivery-fee">Delivery Fee ($)</Label>
                <Input
                  id="delivery-fee"
                  type="number"
                  step="0.01"
                  value={appSettings.deliveryFee}
                  onChange={(e) => setAppSettings({...appSettings, deliveryFee: parseFloat(e.target.value)})}
                />
              </div>
              <div>
                <Label htmlFor="service-fee">Service Fee ($)</Label>
                <Input
                  id="service-fee"
                  type="number"
                  step="0.01"
                  value={appSettings.serviceFee}
                  onChange={(e) => setAppSettings({...appSettings, serviceFee: parseFloat(e.target.value)})}
                />
              </div>
              <div>
                <Label htmlFor="tax-rate">Tax Rate (%)</Label>
                <Input
                  id="tax-rate"
                  type="number"
                  step="0.1"
                  value={appSettings.taxRate}
                  onChange={(e) => setAppSettings({...appSettings, taxRate: parseFloat(e.target.value)})}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="theme" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5" />
                Theme Settings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {themes.map((theme) => (
                  <div
                    key={theme.value}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      appSettings.theme === theme.value
                        ? 'border-teal-500 bg-teal-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setAppSettings({...appSettings, theme: theme.value})}
                  >
                    <div
                      className="w-full h-8 rounded mb-2"
                      style={{ backgroundColor: theme.color }}
                    />
                    <p className="text-sm font-medium text-center">{theme.name}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pages" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Page Management
                </span>
                <Button onClick={addPage} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Page
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pages.map((page) => (
                  <div key={page.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={page.enabled}
                        onCheckedChange={(checked) => {
                          setPages(pages.map(p => p.id === page.id ? {...p, enabled: checked} : p));
                        }}
                      />
                      <div>
                        <p className="font-medium">{page.name}</p>
                        <p className="text-sm text-muted-foreground">{page.path}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={page.enabled ? 'default' : 'secondary'}>
                        {page.enabled ? 'Active' : 'Disabled'}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removePage(page.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}