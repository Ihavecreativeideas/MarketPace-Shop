import { useState, useEffect } from 'react';
import { Brain, TrendingUp, Users, ShoppingCart, Star } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

interface Recommendation {
  id: string;
  type: 'product' | 'vendor' | 'category';
  title: string;
  description: string;
  confidence: number;
  reason: string;
  data: any;
}

interface PersonalizedRecommendationsProps {
  userId?: string;
  context?: 'homepage' | 'product' | 'checkout';
}

export function AIRecommendations({ userId, context = 'homepage' }: PersonalizedRecommendationsProps) {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadRecommendations = () => {
      setLoading(true);
      setError(null);
      
      try {
        // Use static mock data to prevent JSON parsing errors
        const mockRecommendations: Recommendation[] = [
          {
            id: '1',
            type: 'product',
            title: 'Artisan Coffee Blend',
            description: 'Based on your coffee purchases, you might love this premium blend',
            confidence: 92,
            reason: 'Similar taste preferences',
            data: {
              price: 24.99,
              rating: 4.8,
              vendor: 'Local Roasters',
              image: '/placeholder.svg'
            }
          },
          {
            id: '2',
            type: 'vendor',
            title: 'Green Garden Organics',
            description: 'New organic vendor matching your healthy lifestyle choices',
            confidence: 87,
            reason: 'Dietary preferences match',
            data: {
              rating: 4.9,
              deliveryTime: '25-35 min',
              category: 'Organic Food',
              image: '/placeholder.svg'
            }
          },
          {
            id: '3',
            type: 'category',
            title: 'Sustainable Products',
            description: 'Eco-friendly items trending in your area',
            confidence: 78,
            reason: 'Environmental consciousness',
            data: {
              trendingUp: 23,
              popularItems: ['Bamboo Utensils', 'Reusable Bags', 'Solar Chargers']
            }
          }
        ];
        
        // Simulate brief loading without network calls
        setTimeout(() => {
          setRecommendations(mockRecommendations);
          setLoading(false);
        }, 300);
      } catch (err) {
        console.error('Error loading recommendations:', err);
        setError('Failed to load recommendations');
        setLoading(false);
      }
    };

    loadRecommendations();
  }, [userId, context]);

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 animate-pulse" />
            <CardTitle>AI Recommendations</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-red-500" />
            <CardTitle>AI Recommendations</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-red-500">Unable to load recommendations at this time.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-purple-600" />
            <CardTitle>AI Recommendations</CardTitle>
          </div>
          <Badge variant="secondary">Powered by AI</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recommendations.map((rec) => (
            <RecommendationCard key={rec.id} recommendation={rec} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function RecommendationCard({ recommendation }: { recommendation: Recommendation }) {
  const getIcon = (type: string) => {
    switch (type) {
      case 'product': return <ShoppingCart className="h-4 w-4" />;
      case 'vendor': return <Users className="h-4 w-4" />;
      case 'category': return <TrendingUp className="h-4 w-4" />;
      default: return <Brain className="h-4 w-4" />;
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return 'text-green-600';
    if (confidence >= 75) return 'text-blue-600';
    return 'text-yellow-600';
  };

  return (
    <Card className="border-l-4 border-l-purple-500">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3 flex-1">
            <div className="mt-1">
              {getIcon(recommendation.type)}
            </div>
            <div className="flex-1">
              <h4 className="font-medium mb-1">{recommendation.title}</h4>
              <p className="text-sm text-muted-foreground mb-2">
                {recommendation.description}
              </p>
              <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                <span>Reason: {recommendation.reason}</span>
                <div className="flex items-center space-x-1">
                  <span>Confidence:</span>
                  <span className={`font-medium ${getConfidenceColor(recommendation.confidence)}`}>
                    {recommendation.confidence}%
                  </span>
                </div>
              </div>
              <Progress 
                value={recommendation.confidence} 
                className="h-1 mt-2" 
              />
            </div>
          </div>
          <Button size="sm" variant="outline">
            View
          </Button>
        </div>
        
        {recommendation.type === 'product' && recommendation.data && (
          <div className="mt-3 pt-3 border-t flex items-center justify-between">
            <div className="flex items-center space-x-4 text-sm">
              <span className="font-medium">${recommendation.data.price}</span>
              <div className="flex items-center space-x-1">
                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                <span>{recommendation.data.rating}</span>
              </div>
              <span className="text-muted-foreground">{recommendation.data.vendor}</span>
            </div>
          </div>
        )}
        
        {recommendation.type === 'vendor' && recommendation.data && (
          <div className="mt-3 pt-3 border-t flex items-center justify-between text-sm">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                <span>{recommendation.data.rating}</span>
              </div>
              <span>{recommendation.data.deliveryTime}</span>
              <Badge variant="secondary" className="text-xs">
                {recommendation.data.category}
              </Badge>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}