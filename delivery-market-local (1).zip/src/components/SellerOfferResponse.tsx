import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, ArrowLeftRight } from 'lucide-react';

interface SellerOfferResponseProps {
  isOpen: boolean;
  onClose: () => void;
  buyerOffer: {
    itemTitle: string;
    originalPrice: number;
    discountPercent: number;
    offeredPrice: number;
    buyerName: string;
  };
  onAccept: () => void;
  onDecline: () => void;
  onCounterBack: (newDiscountPercent: number, newPrice: number) => void;
}

const SellerOfferResponse: React.FC<SellerOfferResponseProps> = ({
  isOpen,
  onClose,
  buyerOffer,
  onAccept,
  onDecline,
  onCounterBack
}) => {
  const [showCounterOptions, setShowCounterOptions] = useState(false);
  const [selectedCounterDiscount, setSelectedCounterDiscount] = useState<number | null>(null);
  
  // Counter-offer options (seller can offer less discount than buyer requested)
  const getCounterOptions = () => {
    const options = [];
    for (let i = 5; i < buyerOffer.discountPercent; i += 5) {
      options.push(i);
    }
    return options;
  };
  
  const calculateCounterPrice = (discount: number) => {
    return buyerOffer.originalPrice * (1 - discount / 100);
  };
  
  const handleCounterBack = () => {
    if (selectedCounterDiscount) {
      const newPrice = calculateCounterPrice(selectedCounterDiscount);
      onCounterBack(selectedCounterDiscount, newPrice);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowLeftRight className="w-5 h-5" />
            Counter Offer Received
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-medium mb-2">{buyerOffer.itemTitle}</h4>
            <div className="space-y-1 text-sm">
              <p>Buyer: <span className="font-medium">{buyerOffer.buyerName}</span></p>
              <p>Original Price: <span className="line-through">${buyerOffer.originalPrice}</span></p>
              <p>Offered Price: <span className="font-bold text-green-600">${buyerOffer.offeredPrice.toFixed(2)}</span></p>
              <Badge variant="outline" className="text-orange-600 border-orange-300">
                {buyerOffer.discountPercent}% discount requested
              </Badge>
            </div>
          </div>
          
          {!showCounterOptions ? (
            <div className="space-y-3">
              <p className="text-sm font-medium">Choose your response:</p>
              
              <Button 
                onClick={onAccept}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Accept Offer (${buyerOffer.offeredPrice.toFixed(2)})
              </Button>
              
              <Button 
                onClick={onDecline}
                variant="destructive"
                className="w-full"
              >
                <XCircle className="w-4 h-4 mr-2" />
                Decline Offer
              </Button>
              
              <Button 
                onClick={() => setShowCounterOptions(true)}
                variant="outline"
                className="w-full border-orange-300 text-orange-600 hover:bg-orange-50"
              >
                <ArrowLeftRight className="w-4 h-4 mr-2" />
                Counter Back with Different Price
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-sm font-medium">Counter back with a different discount:</p>
              
              {getCounterOptions().map((discount) => {
                const counterPrice = calculateCounterPrice(discount);
                return (
                  <div
                    key={discount}
                    className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                      selectedCounterDiscount === discount
                        ? 'border-orange-500 bg-orange-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedCounterDiscount(discount)}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <Badge variant="outline" className="text-orange-600 border-orange-300">
                          {discount}% discount
                        </Badge>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600">
                          ${counterPrice.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
              
              <div className="flex gap-2 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => setShowCounterOptions(false)}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  onClick={handleCounterBack}
                  disabled={!selectedCounterDiscount}
                  className="flex-1 bg-orange-600 hover:bg-orange-700"
                >
                  Send Counter Offer
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SellerOfferResponse;