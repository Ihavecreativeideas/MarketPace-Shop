import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { UserPlus, Users, Share2, Mail, MessageCircle, Copy } from 'lucide-react';
import { toast } from 'sonner';

interface Friend {
  id: string;
  name: string;
  profilePicture?: string;
  mutualFriends?: number;
}

export default function FacebookFriendsInvite() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedFriends, setSelectedFriends] = useState<string[]>([]);
  const [customMessage, setCustomMessage] = useState(
    "Hey! I'm using MarketPace - it's an amazing local marketplace where you can buy, sell, and get things delivered in our community. Join me and let's support local businesses together! 🛍️🚚"
  );
  const [searchTerm, setSearchTerm] = useState('');

  // Mock Facebook friends data
  const mockFriends: Friend[] = [
    { id: '1', name: 'Sarah Johnson', mutualFriends: 12 },
    { id: '2', name: 'Mike Chen', mutualFriends: 8 },
    { id: '3', name: 'Emily Rodriguez', mutualFriends: 15 },
    { id: '4', name: 'David Kim', mutualFriends: 6 },
    { id: '5', name: 'Lisa Thompson', mutualFriends: 20 },
    { id: '6', name: 'Alex Wilson', mutualFriends: 4 },
    { id: '7', name: 'Maria Garcia', mutualFriends: 11 },
    { id: '8', name: 'James Brown', mutualFriends: 9 }
  ];

  const filteredFriends = mockFriends.filter(friend =>
    friend.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const toggleFriendSelection = (friendId: string) => {
    setSelectedFriends(prev => 
      prev.includes(friendId) 
        ? prev.filter(id => id !== friendId)
        : [...prev, friendId]
    );
  };

  const selectAllFriends = () => {
    setSelectedFriends(filteredFriends.map(friend => friend.id));
  };

  const clearSelection = () => {
    setSelectedFriends([]);
  };

  const sendInvites = () => {
    if (selectedFriends.length === 0) {
      toast.error('Please select at least one friend to invite');
      return;
    }

    // Simulate sending invites
    const selectedFriendNames = mockFriends
      .filter(friend => selectedFriends.includes(friend.id))
      .map(friend => friend.name);

    toast.success(`Invites sent to ${selectedFriendNames.length} friends!`);
    setIsOpen(false);
    setSelectedFriends([]);
  };

  const shareViaFacebookPost = () => {
    const shareUrl = window.location.origin;
    const shareText = customMessage + `\n\nJoin MarketPace: ${shareUrl}`;
    
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
    
    window.open(
      facebookUrl,
      'facebook-share-dialog',
      'width=626,height=436,resizable=yes,scrollbars=yes'
    );
    
    toast.success('Shared to Facebook!');
  };

  const copyInviteLink = () => {
    const inviteLink = `${window.location.origin}?ref=invite`;
    navigator.clipboard.writeText(inviteLink);
    toast.success('Invite link copied to clipboard!');
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2">
          <UserPlus className="h-4 w-4" />
          Invite Facebook Friends
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-blue-600" />
            Invite Friends to MarketPace
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Quick Share Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button
              onClick={shareViaFacebookPost}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700"
            >
              <Share2 className="h-4 w-4" />
              Share on Facebook
            </Button>
            <Button
              onClick={copyInviteLink}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Copy className="h-4 w-4" />
              Copy Invite Link
            </Button>
          </div>

          {/* Custom Message */}
          <div className="space-y-2">
            <Label htmlFor="message">Invitation Message</Label>
            <Textarea
              id="message"
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              rows={4}
              placeholder="Write a personal message to your friends..."
            />
          </div>

          {/* Friend Search */}
          <div className="space-y-2">
            <Label htmlFor="search">Search Friends</Label>
            <Input
              id="search"
              type="text"
              placeholder="Search by name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* Selection Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={selectAllFriends}>
                Select All
              </Button>
              <Button size="sm" variant="outline" onClick={clearSelection}>
                Clear All
              </Button>
              {selectedFriends.length > 0 && (
                <Badge variant="secondary">
                  {selectedFriends.length} selected
                </Badge>
              )}
            </div>
          </div>

          {/* Friends List */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Your Facebook Friends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-2 max-h-60 overflow-y-auto">
                {filteredFriends.map((friend) => (
                  <div
                    key={friend.id}
                    className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-colors ${
                      selectedFriends.includes(friend.id)
                        ? 'bg-teal-50 border-teal-200'
                        : 'hover:bg-muted/50'
                    }`}
                    onClick={() => toggleFriendSelection(friend.id)}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                        {friend.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <p className="font-medium">{friend.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {friend.mutualFriends} mutual friends
                        </p>
                      </div>
                    </div>
                    <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                      selectedFriends.includes(friend.id)
                        ? 'bg-teal-600 border-teal-600'
                        : 'border-gray-300'
                    }`}>
                      {selectedFriends.includes(friend.id) && (
                        <div className="w-2 h-2 bg-white rounded-full" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Send Invites Button */}
          <Button
            onClick={sendInvites}
            className="w-full bg-teal-600 hover:bg-teal-700"
            disabled={selectedFriends.length === 0}
          >
            <Mail className="h-4 w-4 mr-2" />
            Send Invites to {selectedFriends.length} Friend{selectedFriends.length !== 1 ? 's' : ''}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}