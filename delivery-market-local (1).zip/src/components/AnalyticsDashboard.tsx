import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart3, TrendingUp, Users, Eye, ShoppingBag, DollarSign } from 'lucide-react';

const AnalyticsDashboard = () => {
  const overviewStats = [
    { title: 'Total Views', value: '2,847', change: '+12%', icon: Eye },
    { title: 'Profile Visits', value: '1,234', change: '+8%', icon: Users },
    { title: 'Listings', value: '23', change: '+3', icon: ShoppingBag },
    { title: 'Revenue', value: '$1,847', change: '+15%', icon: DollarSign }
  ];

  const topListings = [
    { name: 'Vintage Guitar', views: 456, inquiries: 23, price: '$850' },
    { name: 'Mountain Bike', views: 342, inquiries: 18, price: '$650' },
    { name: 'Camera Lens', views: 298, inquiries: 15, price: '$320' }
  ];

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Analytics Dashboard</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Track your marketplace performance and engagement
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        {overviewStats.map((stat, index) => {
          const IconComponent = stat.icon;
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{stat.title}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-sm text-green-600">{stat.change}</p>
                  </div>
                  <IconComponent className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="listings">Listings</TabsTrigger>
          <TabsTrigger value="audience">Audience</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Performance Trends
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center bg-gray-50 dark:bg-gray-800 rounded">
                  <p className="text-gray-500">Chart visualization would go here</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="listings">
          <Card>
            <CardHeader>
              <CardTitle>Top Performing Listings</CardTitle>
              <CardDescription>Your most viewed and engaged listings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topListings.map((listing, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h3 className="font-medium">{listing.name}</h3>
                      <p className="text-sm text-gray-500">{listing.views} views • {listing.inquiries} inquiries</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">{listing.price}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="audience">
          <Card>
            <CardHeader>
              <CardTitle>Audience Insights</CardTitle>
              <CardDescription>Learn about your visitors and customers</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-medium mb-3">Top Locations</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>New York</span>
                      <span className="text-gray-500">34%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Los Angeles</span>
                      <span className="text-gray-500">28%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Chicago</span>
                      <span className="text-gray-500">18%</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="font-medium mb-3">Age Groups</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>25-34</span>
                      <span className="text-gray-500">42%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>35-44</span>
                      <span className="text-gray-500">31%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>18-24</span>
                      <span className="text-gray-500">27%</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AnalyticsDashboard;