import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, Star, Zap, Bell, Share2, Calendar, Users, Gift } from 'lucide-react';
import { useState } from 'react';

const MusicianSubscription = () => {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubscribed(true);
      setLoading(false);
    }, 2000);
  };

  const features = [
    {
      icon: <Share2 className="w-5 h-5" />,
      title: 'Social Media Integration',
      description: 'Connect and auto-post to Facebook, Instagram, Twitter, and TikTok'
    },
    {
      icon: <Bell className="w-5 h-5" />,
      title: 'Fan Notifications',
      description: 'Automatically notify local fans when you release new music'
    },
    {
      icon: <Calendar className="w-5 h-5" />,
      title: 'Event Promotion',
      description: 'Send event notifications to followers in your area'
    },
    {
      icon: <Users className="w-5 h-5" />,
      title: 'Advanced Analytics',
      description: 'Track fan engagement and reach across all platforms'
    },
    {
      icon: <Zap className="w-5 h-5" />,
      title: 'Priority Support',
      description: 'Get priority customer support and feature requests'
    },
    {
      icon: <Star className="w-5 h-5" />,
      title: 'Verified Badge',
      description: 'Get a verified musician badge on your profile'
    }
  ];

  if (isSubscribed) {
    return (
      <Card className="bg-gradient-to-r from-green-50 to-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-700">
            <Check className="w-6 h-6" />
            Pro Musician - Lifetime Benefits Active
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span>Status:</span>
              <Badge className="bg-green-600 text-white">Lifetime Member</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Launch Supporter:</span>
              <span className="font-medium text-green-600">✓ Verified</span>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-6">
              <Button variant="outline">
                Manage Profile
              </Button>
              <Button variant="outline">
                View Analytics
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Gift className="w-6 h-6 text-purple-600" />
              Free to Subscribe - Limited Time!
            </CardTitle>
            <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white animate-pulse">
              FREE NOW
            </Badge>
          </div>
          <p className="text-gray-600">
            Support our app's successful launch and gain lifetime benefits!
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg border border-yellow-200">
              <h4 className="font-bold text-orange-800 mb-2 flex items-center gap-2">
                <Gift className="w-5 h-5" />
                🚀 Launch Supporter Special
              </h4>
              <ul className="text-sm text-orange-700 space-y-1">
                <li>• Subscribe FREE during our launch period</li>
                <li>• Gain LIFETIME access to all Pro features</li>
                <li>• Support our app's successful launch</li>
                <li>• Never pay monthly fees - ever!</li>
                <li>• Exclusive "Launch Supporter" badge</li>
              </ul>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="text-purple-600 mt-1">
                    {feature.icon}
                  </div>
                  <div>
                    <h4 className="font-medium">{feature.title}</h4>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <Button 
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-lg py-6"
              onClick={handleSubscribe}
              disabled={loading}
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Processing...
                </div>
              ) : (
                <>🎵 Subscribe FREE - Gain Lifetime Benefits!</>
              )}
            </Button>
            
            <p className="text-xs text-gray-500 text-center">
              Limited time offer for launch supporters only. By subscribing, you agree to our Terms of Service.
              This offer may end without notice.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>What Launch Supporters Say</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="border-l-4 border-purple-500 pl-4">
              <p className="text-sm italic">
                "Getting lifetime access for free during launch was amazing! The features are incredible."
              </p>
              <p className="text-xs text-gray-600 mt-2">- Sarah Chen, Launch Supporter #47</p>
            </div>
            <div className="border-l-4 border-purple-500 pl-4">
              <p className="text-sm italic">
                "Supporting the launch and getting lifetime benefits was a no-brainer. Best decision ever!"
              </p>
              <p className="text-xs text-gray-600 mt-2">- The Midnight Blues, Launch Supporter #156</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MusicianSubscription;