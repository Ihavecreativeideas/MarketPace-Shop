import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Crown, Star, CheckCircle, Gift, Clock, Zap, Shield, TrendingUp } from 'lucide-react';
import { useState } from 'react';

interface MarketPaceProPromotionProps {
  onSubscribe: () => void;
  isTrialUser?: boolean;
}

const MarketPaceProPromotion: React.FC<MarketPaceProPromotionProps> = ({ 
  onSubscribe, 
  isTrialUser = true 
}) => {
  const [showDetails, setShowDetails] = useState(false);

  const proFeatures = [
    { icon: Crown, title: 'Professional Profile', desc: 'Stand out with verified pro badge' },
    { icon: Shield, title: 'Secure Contracts', desc: 'AI-generated legal protection' },
    { icon: TrendingUp, title: 'Performance Analytics', desc: 'Track your success metrics' },
    { icon: Zap, title: 'Priority Booking', desc: 'Get featured in search results' },
    { icon: Star, title: 'Lifetime Discounts', desc: '20% off all marketplace fees' },
    { icon: Gift, title: 'Exclusive Features', desc: 'Early access to new tools' }
  ];

  return (
    <Card className="bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 border-2 border-purple-300 shadow-lg">
      <CardHeader className="text-center pb-4">
        <div className="flex justify-center mb-3">
          <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-4 rounded-full">
            <Crown className="w-10 h-10 text-white" />
          </div>
        </div>
        <div className="space-y-2">
          <Badge className="bg-red-500 text-white px-3 py-1 text-sm font-bold animate-pulse">
            🔥 LIMITED TIME - TRIAL ERA SPECIAL
          </Badge>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            MarketPace Pro
          </CardTitle>
          <p className="text-lg text-gray-700">
            Unlock <span className="font-bold text-purple-600">LIFETIME</span> professional benefits!
          </p>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Trial Era Special Offer */}
        {isTrialUser && (
          <div className="bg-gradient-to-r from-green-100 to-blue-100 p-4 rounded-lg border-2 border-green-300">
            <div className="flex items-center gap-3 mb-2">
              <Clock className="w-6 h-6 text-green-600" />
              <span className="font-bold text-green-800 text-lg">Trial Era Exclusive!</span>
            </div>
            <p className="text-green-700 mb-3">
              Subscribe now and get <span className="font-bold">ALL features FREE</span> during our test trial period, 
              plus <span className="font-bold">lifetime Pro benefits</span> when we launch!
            </p>
            <div className="flex items-center gap-2 text-sm text-green-600">
              <CheckCircle className="w-4 h-4" />
              <span>No charges during trial • Lifetime discounts guaranteed</span>
            </div>
          </div>
        )}

        {/* Pro Features Grid */}
        <div className="grid grid-cols-2 gap-3">
          {proFeatures.map((feature, idx) => {
            const IconComponent = feature.icon;
            return (
              <div key={idx} className="flex items-start gap-2 p-2 bg-white/50 rounded-lg">
                <IconComponent className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-semibold text-sm text-gray-800">{feature.title}</p>
                  <p className="text-xs text-gray-600">{feature.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pricing Info */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2">
            <span className="text-2xl font-bold text-gray-400 line-through">$29.99/mo</span>
            <Badge className="bg-red-500 text-white">FREE</Badge>
          </div>
          <p className="text-sm text-gray-600">
            During trial era • Then just $9.99/mo with lifetime benefits
          </p>
        </div>

        {/* CTA Buttons */}
        <div className="space-y-3">
          <Button 
            onClick={onSubscribe}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-3 text-lg"
            size="lg"
          >
            <Crown className="w-5 h-5 mr-2" />
            Claim FREE Pro Access Now
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => setShowDetails(!showDetails)}
            className="w-full border-purple-300 text-purple-700 hover:bg-purple-50"
          >
            {showDetails ? 'Hide' : 'View'} All Benefits
          </Button>
        </div>

        {/* Detailed Benefits */}
        {showDetails && (
          <div className="bg-white/70 p-4 rounded-lg space-y-2">
            <h4 className="font-bold text-purple-800 mb-3">Complete Benefits Package:</h4>
            <div className="space-y-1 text-sm">
              {[
                'Verified professional musician badge',
                'AI-powered contract generation & protection',
                'Advanced booking management system',
                'Real-time performance analytics dashboard',
                'Priority placement in search results',
                'Lifetime 20% discount on all marketplace fees',
                'Early access to beta features',
                'Dedicated customer support',
                'Professional portfolio tools',
                'Integration with major booking platforms'
              ].map((benefit, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Urgency Footer */}
        <div className="text-center bg-yellow-50 p-3 rounded-lg border border-yellow-200">
          <p className="text-sm font-semibold text-yellow-800">
            ⚡ Limited to first 1,000 musicians • Join now to secure your spot!
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default MarketPaceProPromotion;