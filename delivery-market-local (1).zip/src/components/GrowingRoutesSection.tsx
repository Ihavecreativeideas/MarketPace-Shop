import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { TrendingUp, MapPin, Users, Clock } from 'lucide-react';

const GrowingRoutesSection: React.FC = () => {
  const routes = [
    { name: 'Downtown District', drivers: 12, orders: 45, growth: '+25%' },
    { name: 'University Area', drivers: 8, orders: 32, growth: '+18%' },
    { name: 'Shopping Center', drivers: 15, orders: 67, growth: '+32%' },
    { name: 'Residential Zone', drivers: 6, orders: 23, growth: '+15%' }
  ];

  return (
    <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50">
      <CardHeader className="text-center">
        <Badge className="mx-auto mb-2 bg-blue-500">
          <TrendingUp className="w-3 h-3 mr-1" />
          GROWING NETWORK
        </Badge>
        <CardTitle className="text-2xl font-bold text-blue-800">
          Active Delivery Routes
        </CardTitle>
        <p className="text-blue-600">
          Our network is expanding across the city
        </p>
      </CardHeader>
      
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {routes.map((route, index) => (
            <div key={index} className="bg-white rounded-lg p-4 border border-blue-100">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span className="font-semibold text-gray-800">{route.name}</span>
                </div>
                <Badge variant="outline" className="text-green-600 border-green-600">
                  {route.growth}
                </Badge>
              </div>
              
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  <span>{route.drivers} drivers</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{route.orders} orders</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 text-center">
          <p className="text-sm text-blue-600">
            Join our growing network of delivery partners and local businesses
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default GrowingRoutesSection;