import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Home, Search, ShoppingBag, Users, Briefcase, Music, Truck, User } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';

const FloatingNavigation: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState('home');
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  const navItems = [
    { id: 'home', icon: Home, label: 'Home', path: '/' },
    { id: 'marketplace', icon: ShoppingBag, label: 'Market', path: '/marketplace' },
    { id: 'shops', icon: Search, label: 'Shops', path: '/shops' },
    { id: 'services', icon: Briefcase, label: 'Services', path: '/services' },
    { id: 'entertainment', icon: Music, label: 'Entertainment', path: '/entertainment' },
    { id: 'community', icon: Users, label: 'Community', path: '/community' },
    { id: 'delivery', icon: Truck, label: 'Delivery', path: '/driver-demo' },
    { id: 'profile', icon: User, label: 'Profile', path: '/profile' }
  ];

  // Update active tab based on current route
  useEffect(() => {
    const currentPath = location.pathname;
    const currentItem = navItems.find(item => item.path === currentPath);
    if (currentItem) {
      setActiveTab(currentItem.id);
    }
  }, [location.pathname]);

  // Handle scroll behavior
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Show/hide based on scroll direction
      if (currentScrollY < lastScrollY || currentScrollY < 100) {
        setIsVisible(true);
      } else if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsVisible(false);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const handleNavigation = (item: any) => {
    setActiveTab(item.id);
    navigate(item.path);
  };

  return (
    <div className={`fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50 transition-all duration-300 ${
      isVisible ? 'translate-y-0 opacity-100' : 'translate-y-16 opacity-0'
    }`}>
      <div className="bg-black/90 backdrop-blur-md rounded-full shadow-2xl border border-teal-500/30 px-2 py-2">
        <div className="flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={activeTab === item.id ? 'default' : 'ghost'}
                size="sm"
                onClick={() => handleNavigation(item)}
                className={`rounded-full p-2 h-10 w-10 transition-all duration-200 ${
                  activeTab === item.id 
                    ? 'bg-gradient-to-r from-teal-500 to-purple-600 text-white shadow-lg scale-110 shadow-teal-500/25' 
                    : 'text-gray-300 hover:text-teal-400 hover:bg-teal-500/10 hover:scale-105'
                }`}
                title={item.label}
              >
                <Icon className="w-4 h-4" />
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default FloatingNavigation;