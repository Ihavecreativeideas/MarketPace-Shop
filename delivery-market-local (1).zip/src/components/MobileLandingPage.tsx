import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MobileLayout from './MobileLayout';
import CompactHeader from './CompactHeader';
import CompactHeroSection from './CompactHeroSection';
import CompactTownMeter from './CompactTownMeter';
import AuthModal from './AuthModal';
import PlatformDropdown from './PlatformDropdown';

const MobileLandingPage: React.FC = () => {
  const navigate = useNavigate();
  const [authModalOpen, setAuthModalOpen] = useState(false);

  const handleGetStarted = () => {
    navigate('/marketplace');
  };

  const handleAuthClick = () => {
    setAuthModalOpen(true);
  };

  return (
    <MobileLayout>
      <CompactHeader 
        onAuthClick={handleAuthClick}
      />
      
      <div className="space-y-6">
        <div className="px-4 pt-4">
          <CompactTownMeter 
            townName="Your Town"
            members={247}
            shops={18}
            entertainers={12}
            drivers={31}
            services={9}
            targetMembers={1000}
          />
        </div>
        
        <CompactHeroSection 
          onGetStarted={handleGetStarted}
        />
        
        <div className="px-4 pb-6">
          <PlatformDropdown />
        </div>
      </div>

      <AuthModal 
        isOpen={authModalOpen} 
        onClose={() => setAuthModalOpen(false)} 
      />
    </MobileLayout>
  );
};

export default MobileLandingPage;