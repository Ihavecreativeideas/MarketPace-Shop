import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Play, Pause, Heart, Share2, Download, Eye, Music } from 'lucide-react';
import { useState } from 'react';

interface Track {
  id: number;
  title: string;
  artist: string;
  genre: string;
  duration: string;
  plays: number;
  likes: number;
  image: string;
  audioUrl: string;
  isNew: boolean;
  isLiked: boolean;
  price?: number;
  isFree: boolean;
}

interface MusicDiscoveryProps {
  tracks: Track[];
  onPlay: (track: Track) => void;
  onLike: (track: Track) => void;
  onShare: (track: Track) => void;
  onDownload: (track: Track) => void;
}

const MusicDiscovery: React.FC<MusicDiscoveryProps> = ({ 
  tracks, 
  onPlay, 
  onLike, 
  onShare, 
  onDownload 
}) => {
  const [playingTrack, setPlayingTrack] = useState<number | null>(null);

  const handlePlay = (track: Track) => {
    if (playingTrack === track.id) {
      setPlayingTrack(null);
    } else {
      setPlayingTrack(track.id);
      onPlay(track);
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Music className="w-5 h-5 text-purple-600" />
          <h2 className="text-xl font-bold text-purple-800">Discover New Music</h2>
        </div>
        <p className="text-purple-600 text-sm">
          Explore fresh tracks from local and emerging artists
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {tracks.map((track) => (
          <Card key={track.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="p-0 relative">
              <img 
                src={track.image} 
                alt={track.title} 
                className="w-full h-32 object-cover rounded-t-lg" 
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                <Button
                  size="sm"
                  onClick={() => handlePlay(track)}
                  className="bg-white text-black hover:bg-gray-100 rounded-full w-12 h-12 p-0"
                >
                  {playingTrack === track.id ? (
                    <Pause className="w-6 h-6" />
                  ) : (
                    <Play className="w-6 h-6 ml-1" />
                  )}
                </Button>
              </div>
              <div className="absolute top-2 right-2 flex gap-2">
                {track.isNew && (
                  <Badge className="bg-green-500 text-xs">
                    NEW
                  </Badge>
                )}
                {track.isFree ? (
                  <Badge className="bg-blue-500 text-xs">
                    FREE
                  </Badge>
                ) : (
                  <Badge className="bg-orange-500 text-xs">
                    ${track.price}
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-3">
              <div className="space-y-2">
                <div>
                  <CardTitle className="text-sm font-semibold line-clamp-1">
                    {track.title}
                  </CardTitle>
                  <p className="text-xs text-gray-600">{track.artist}</p>
                </div>

                <div className="flex items-center justify-between text-xs text-gray-500">
                  <Badge variant="outline" className="text-xs">
                    {track.genre}
                  </Badge>
                  <span>{track.duration}</span>
                </div>

                <div className="flex items-center justify-between text-xs text-gray-500">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      <span>{formatNumber(track.plays)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className={`w-3 h-3 ${track.isLiked ? 'fill-red-500 text-red-500' : ''}`} />
                      <span>{formatNumber(track.likes)}</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onLike(track)}
                    className="flex-1 h-7 text-xs"
                  >
                    <Heart className={`w-3 h-3 mr-1 ${track.isLiked ? 'fill-red-500 text-red-500' : ''}`} />
                    Like
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onShare(track)}
                    className="flex-1 h-7 text-xs"
                  >
                    <Share2 className="w-3 h-3 mr-1" />
                    Share
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => onDownload(track)}
                    className="flex-1 h-7 text-xs bg-purple-600 hover:bg-purple-700"
                  >
                    <Download className="w-3 h-3 mr-1" />
                    {track.isFree ? 'Free' : 'Buy'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default MusicDiscovery;