import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ExternalLink, CheckCircle, AlertTriangle, Utensils } from 'lucide-react';

interface DoorDashIntegrationProps {
  businessType?: string;
  onConnectionChange?: (connected: boolean) => void;
}

const DoorDashIntegration: React.FC<DoorDashIntegrationProps> = ({
  businessType,
  onConnectionChange
}) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  const isFoodBusiness = businessType === 'restaurant' || businessType === 'food';

  const handleConnect = async () => {
    setIsConnecting(true);
    
    // Simulate connection process
    setTimeout(() => {
      setIsConnected(true);
      setIsConnecting(false);
      onConnectionChange?.(true);
      
      // Open DoorDash merchant signup
      window.open('https://get.doordash.com/en-us/products/business/restaurants', '_blank');
    }, 1000);
  };

  const handleManage = () => {
    window.open('https://merchant-portal.doordash.com/', '_blank');
  };

  return (
    <Card className="border-red-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="w-6 h-6 bg-red-500 rounded flex items-center justify-center">
            <span className="text-white text-xs font-bold">DD</span>
          </div>
          DoorDash Integration
          {isConnected && (
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              <CheckCircle className="h-3 w-3 mr-1" />
              Connected
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {isFoodBusiness ? (
          <Alert>
            <Utensils className="h-4 w-4" />
            <AlertDescription>
              <strong>Food Business Detected:</strong> DoorDash is recommended for food delivery. 
              MarketPlace drivers cannot deliver food products.
            </AlertDescription>
          </Alert>
        ) : (
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              DoorDash primarily serves food businesses. Consider UPS, FedEx, or MarketPlace drivers for non-food items.
            </AlertDescription>
          </Alert>
        )}

        <div className="space-y-3">
          <h4 className="font-semibold">DoorDash Benefits:</h4>
          <ul className="text-sm space-y-1 text-gray-600">
            <li>• Specialized food delivery network</li>
            <li>• Temperature-controlled delivery bags</li>
            <li>• Licensed food handling drivers</li>
            <li>• Real-time order tracking</li>
            <li>• Customer support for food orders</li>
            <li>• Marketing exposure on DoorDash platform</li>
          </ul>
        </div>

        <div className="bg-red-50 p-4 rounded-lg">
          <h4 className="font-semibold text-red-900 mb-2">Integration Features:</h4>
          <ul className="text-sm text-red-800 space-y-1">
            <li>• Sync menu items automatically</li>
            <li>• Manage orders from one dashboard</li>
            <li>• Track delivery performance</li>
            <li>• Access DoorDash analytics</li>
          </ul>
        </div>

        <div className="flex gap-2">
          {!isConnected ? (
            <Button 
              onClick={handleConnect}
              disabled={isConnecting}
              className="flex-1 bg-red-500 hover:bg-red-600"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              {isConnecting ? 'Connecting...' : 'Connect DoorDash'}
            </Button>
          ) : (
            <>
              <Button 
                onClick={handleManage}
                variant="outline"
                className="flex-1"
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Manage Account
              </Button>
              <Button 
                onClick={() => {
                  setIsConnected(false);
                  onConnectionChange?.(false);
                }}
                variant="destructive"
                size="sm"
              >
                Disconnect
              </Button>
            </>
          )}
        </div>

        {isConnected && (
          <div className="bg-green-50 p-3 rounded-lg">
            <p className="text-sm text-green-800">
              ✅ Successfully connected to DoorDash! You can now manage your delivery settings 
              and start receiving orders through their platform.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default DoorDashIntegration;