import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Music, Calendar, Bell, ExternalLink, Crown, Star } from 'lucide-react';
import ProMusicianProfile from './ProMusicianProfile';

const EnhancedMusicians: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMusician, setSelectedMusician] = useState<any>(null);
  
  const mockMusicians = [
    { 
      id: 1, 
      name: 'The Midnight Blues', 
      genre: 'Blues Rock', 
      followers: 1250, 
      image: '/placeholder.svg',
      hasNewRelease: true,
      nextShow: 'Dec 15 - Blue Note Cafe',
      isPro: true,
      bio: 'Professional blues rock band with 10+ years of experience performing at weddings, corporate events, and festivals. Known for our energetic performances and crowd interaction.',
      genres: ['Blues', 'Rock', 'Classic Rock'],
      venues: [
        { id: 1, name: 'Blue Note Cafe', location: 'Downtown', date: '2023-12-01', type: 'Concert' },
        { id: 2, name: 'Grand Hotel', location: 'Uptown', date: '2023-11-15', type: 'Wedding' },
        { id: 3, name: 'City Festival', location: 'Central Park', date: '2023-10-20', type: 'Festival' }
      ],
      rating: 4.8,
      totalGigs: 156
    },
    { 
      id: 2, 
      name: 'Sarah Chen', 
      genre: 'Indie Folk', 
      followers: 890, 
      image: '/placeholder.svg',
      hasNewRelease: false,
      nextShow: 'Dec 22 - The Venue',
      isPro: true,
      bio: 'Singer-songwriter specializing in acoustic performances for intimate gatherings, coffee shops, and private events.',
      genres: ['Indie', 'Folk', 'Acoustic'],
      venues: [
        { id: 1, name: 'Coffee Corner', location: 'Arts District', date: '2023-11-28', type: 'Acoustic Set' },
        { id: 2, name: 'Private Event', location: 'Residential', date: '2023-11-10', type: 'Birthday Party' }
      ],
      rating: 4.9,
      totalGigs: 89
    },
    { 
      id: 3, 
      name: 'Electric Dreams', 
      genre: 'Electronic', 
      followers: 2100, 
      image: '/placeholder.svg',
      hasNewRelease: true,
      nextShow: 'Jan 5 - Metro Club',
      isPro: false,
      bio: 'Electronic music duo creating atmospheric soundscapes for modern events.',
      genres: ['Electronic', 'Ambient', 'Dance'],
      venues: [],
      rating: 4.5,
      totalGigs: 34
    }
  ];

  if (selectedMusician) {
    return (
      <div>
        <Button 
          variant="outline" 
          onClick={() => setSelectedMusician(null)}
          className="mb-4"
        >
          ← Back to Musicians
        </Button>
        <ProMusicianProfile musician={selectedMusician} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Input
          placeholder="Search musicians, equipment, or gear..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1"
        />
        <Button variant="outline">
          <Music className="w-4 h-4 mr-2" />
          Genres
        </Button>
      </div>

      <div>
        <h3 className="text-xl font-semibold mb-4">Local Musicians</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mockMusicians.map((musician) => (
            <Card key={musician.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="p-0 relative">
                <img src={musician.image} alt={musician.name} className="w-full h-40 object-cover rounded-t-lg" />
                <div className="absolute top-2 right-2 flex gap-2">
                  {musician.hasNewRelease && (
                    <Badge className="bg-red-500">New Release!</Badge>
                  )}
                  {musician.isPro && (
                    <Badge className="bg-gradient-to-r from-purple-600 to-pink-600">
                      <Crown className="w-3 h-3 mr-1" />PRO
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div>
                    <CardTitle className="text-lg">{musician.name}</CardTitle>
                    <p className="text-sm text-gray-600">{musician.genre}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <span>{musician.followers} fans</span>
                      {musician.isPro && (
                        <>
                          <span>•</span>
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                            <span>{musician.rating}</span>
                          </div>
                          <span>•</span>
                          <span>{musician.totalGigs} gigs</span>
                        </>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="w-4 h-4" />
                      <span>{musician.nextShow}</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <Bell className="w-4 h-4 mr-1" />
                      Follow
                    </Button>
                    <Button size="sm" variant="outline">
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <Button 
                    className="w-full" 
                    onClick={() => setSelectedMusician(musician)}
                  >
                    {musician.isPro ? 'View Pro Profile' : 'View Profile'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <Card className="bg-gradient-to-r from-purple-50 to-pink-50">
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <h3 className="text-xl font-semibold">Upgrade to Pro Musician</h3>
            <p className="text-gray-600">
              Get a professional profile with biography, venue history, booking calendar, 
              AI contract generator, and secure payment processing!
            </p>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600">
              <Crown className="w-4 h-4 mr-2" />
              Upgrade to Pro
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EnhancedMusicians;