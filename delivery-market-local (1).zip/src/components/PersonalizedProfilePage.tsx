import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { User, MapPin, Settings, Store, Wrench, Music, ArrowRight } from 'lucide-react';

const PersonalizedProfilePage: React.FC = () => {
  const navigate = useNavigate();
  const [profileData, setProfileData] = useState({
    name: '',
    bio: '',
    address: '',
    radius: 15,
    interests: [] as string[],
    accountType: 'personal' as 'personal' | 'dual',
    businessType: '' as 'shops' | 'services' | 'entertainment' | ''
  });

  const availableInterests = [
    'Electronics', 'Fashion', 'Home & Garden', 'Sports', 'Books', 'Music',
    'Food & Dining', 'Health & Beauty', 'Automotive', 'Toys & Games',
    'Art & Crafts', 'Travel', 'Fitness', 'Technology', 'Photography'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setProfileData({
      ...profileData,
      [e.target.name]: e.target.value
    });
  };

  const handleInterestToggle = (interest: string) => {
    setProfileData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Profile setup:', profileData);
    // Navigate to marketplace after profile setup
    navigate('/marketplace');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="max-w-2xl mx-auto">
        <Card className="bg-slate-800/90 border-slate-600/30 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-white flex items-center justify-center gap-2">
              <User className="h-6 w-6" />
              Personalize Your Profile
            </CardTitle>
            <p className="text-slate-400 mt-2">
              Tell us about yourself to get the best MarketPace experience
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Basic Info */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-white">Full Name</Label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    placeholder="Enter your full name"
                    value={profileData.name}
                    onChange={handleInputChange}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio" className="text-white">Bio</Label>
                  <Textarea
                    id="bio"
                    name="bio"
                    placeholder="Tell us about yourself..."
                    value={profileData.bio}
                    onChange={handleInputChange}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400 min-h-[100px]"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address" className="text-white flex items-center gap-2">
                    <MapPin className="h-4 w-4" />
                    Address
                  </Label>
                  <Input
                    id="address"
                    name="address"
                    type="text"
                    placeholder="Enter your address"
                    value={profileData.address}
                    onChange={handleInputChange}
                    className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="radius" className="text-white">Delivery Radius (miles)</Label>
                  <Input
                    id="radius"
                    name="radius"
                    type="number"
                    min="1"
                    max="50"
                    value={profileData.radius}
                    onChange={handleInputChange}
                    className="bg-slate-700/50 border-slate-600 text-white"
                  />
                </div>
              </div>

              {/* Interests */}
              <div className="space-y-4">
                <Label className="text-white text-lg font-semibold">Your Interests</Label>
                <p className="text-slate-400 text-sm">Select topics you're interested in to personalize your feed</p>
                <div className="flex flex-wrap gap-2">
                  {availableInterests.map((interest) => (
                    <Badge
                      key={interest}
                      variant={profileData.interests.includes(interest) ? 'default' : 'outline'}
                      className={`cursor-pointer transition-colors ${
                        profileData.interests.includes(interest)
                          ? 'bg-teal-500 hover:bg-teal-600 text-white'
                          : 'bg-slate-700 hover:bg-slate-600 text-slate-300 border-slate-600'
                      }`}
                      onClick={() => handleInterestToggle(interest)}
                    >
                      {interest}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Account Type */}
              <div className="space-y-4">
                <Label className="text-white text-lg font-semibold">Account Type</Label>
                <Tabs value={profileData.accountType} onValueChange={(value) => 
                  setProfileData(prev => ({ ...prev, accountType: value as 'personal' | 'dual' }))
                }>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="personal">Personal Only</TabsTrigger>
                    <TabsTrigger value="dual">Dual Account</TabsTrigger>
                  </TabsList>

                  <TabsContent value="personal" className="mt-4">
                    <Card className="bg-slate-700/30 border-slate-600">
                      <CardContent className="pt-6">
                        <p className="text-slate-300 text-sm">
                          Perfect for buyers and individual users. You can browse, shop, and use all MarketPace services.
                        </p>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="dual" className="mt-4">
                    <Card className="bg-slate-700/30 border-slate-600">
                      <CardContent className="pt-6">
                        <p className="text-slate-300 text-sm mb-4">
                          Get both personal and business features. Choose your business type:
                        </p>
                        <div className="grid grid-cols-1 gap-3">
                          <Button
                            type="button"
                            variant={profileData.businessType === 'shops' ? 'default' : 'outline'}
                            onClick={() => setProfileData(prev => ({ ...prev, businessType: 'shops' }))}
                            className="flex items-center gap-2 justify-start"
                          >
                            <Store className="h-4 w-4" />
                            Shops - Sell physical products
                          </Button>
                          <Button
                            type="button"
                            variant={profileData.businessType === 'services' ? 'default' : 'outline'}
                            onClick={() => setProfileData(prev => ({ ...prev, businessType: 'services' }))}
                            className="flex items-center gap-2 justify-start"
                          >
                            <Wrench className="h-4 w-4" />
                            Services - Offer professional services
                          </Button>
                          <Button
                            type="button"
                            variant={profileData.businessType === 'entertainment' ? 'default' : 'outline'}
                            onClick={() => setProfileData(prev => ({ ...prev, businessType: 'entertainment' }))}
                            className="flex items-center gap-2 justify-start"
                          >
                            <Music className="h-4 w-4" />
                            Entertainment - Musicians, DJs, performers
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>

              <Button type="submit" className="w-full bg-teal-500 hover:bg-teal-600 text-white">
                Complete Profile Setup
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PersonalizedProfilePage;
export { PersonalizedProfilePage };