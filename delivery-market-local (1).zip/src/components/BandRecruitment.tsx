import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, Users, MapPin, Calendar } from 'lucide-react';
import { useState } from 'react';

interface BandPost {
  id: number;
  title: string;
  instrument: string;
  genre: string;
  location: string;
  description: string;
  experience: string;
  commitment: string;
  postedBy: string;
}

const BandRecruitment = () => {
  const [posts, setPosts] = useState<BandPost[]>([
    {
      id: 1,
      title: 'Looking for Lead Guitarist',
      instrument: 'Guitar',
      genre: 'Rock',
      location: 'Downtown',
      description: 'Established band seeking talented lead guitarist for regular gigs',
      experience: 'Intermediate',
      commitment: 'Weekly rehearsals',
      postedBy: 'The Midnight Blues'
    }
  ]);
  
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    instrument: '',
    genre: '',
    location: '',
    description: '',
    experience: '',
    commitment: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newPost: BandPost = {
      id: Date.now(),
      ...formData,
      postedBy: 'You'
    };
    setPosts([...posts, newPost]);
    setFormData({
      title: '',
      instrument: '',
      genre: '',
      location: '',
      description: '',
      experience: '',
      commitment: ''
    });
    setIsOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Band Member Recruitment</h3>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Post Recruitment
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Recruit Band Members</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Post Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  placeholder="Looking for drummer..."
                  required
                />
              </div>
              <div>
                <Label htmlFor="instrument">Instrument Needed</Label>
                <Select value={formData.instrument} onValueChange={(value) => setFormData({...formData, instrument: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select instrument" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Guitar">Guitar</SelectItem>
                    <SelectItem value="Bass">Bass</SelectItem>
                    <SelectItem value="Drums">Drums</SelectItem>
                    <SelectItem value="Vocals">Vocals</SelectItem>
                    <SelectItem value="Keyboard">Keyboard</SelectItem>
                    <SelectItem value="Saxophone">Saxophone</SelectItem>
                    <SelectItem value="Trumpet">Trumpet</SelectItem>
                    <SelectItem value="Violin">Violin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="genre">Genre</Label>
                <Select value={formData.genre} onValueChange={(value) => setFormData({...formData, genre: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select genre" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Rock">Rock</SelectItem>
                    <SelectItem value="Pop">Pop</SelectItem>
                    <SelectItem value="Jazz">Jazz</SelectItem>
                    <SelectItem value="Blues">Blues</SelectItem>
                    <SelectItem value="Country">Country</SelectItem>
                    <SelectItem value="Electronic">Electronic</SelectItem>
                    <SelectItem value="Folk">Folk</SelectItem>
                    <SelectItem value="Hip Hop">Hip Hop</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                  placeholder="Downtown, Suburbs, etc."
                />
              </div>
              <div>
                <Label htmlFor="experience">Experience Level</Label>
                <Select value={formData.experience} onValueChange={(value) => setFormData({...formData, experience: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Beginner">Beginner</SelectItem>
                    <SelectItem value="Intermediate">Intermediate</SelectItem>
                    <SelectItem value="Advanced">Advanced</SelectItem>
                    <SelectItem value="Professional">Professional</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="commitment">Time Commitment</Label>
                <Input
                  id="commitment"
                  value={formData.commitment}
                  onChange={(e) => setFormData({...formData, commitment: e.target.value})}
                  placeholder="Weekly rehearsals, weekend gigs..."
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Tell us about your band and what you're looking for..."
                  rows={3}
                />
              </div>
              <Button type="submit" className="w-full">
                Post Recruitment
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {posts.map((post) => (
          <Card key={post.id}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                {post.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex gap-2">
                  <Badge variant="outline">{post.instrument}</Badge>
                  <Badge variant="outline">{post.genre}</Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  {post.location}
                </div>
                <p className="text-sm">{post.description}</p>
                <div className="space-y-1 text-sm text-gray-600">
                  <p><strong>Experience:</strong> {post.experience}</p>
                  <p><strong>Commitment:</strong> {post.commitment}</p>
                  <p><strong>Posted by:</strong> {post.postedBy}</p>
                </div>
                <Button size="sm" className="w-full">
                  Contact
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default BandRecruitment;