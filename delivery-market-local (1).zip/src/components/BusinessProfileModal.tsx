import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { MapPin, Phone, Mail, Globe, Facebook, Instagram, Clock, Star } from 'lucide-react';
import { PaceMakerBusiness } from './PaceMakersCard';

interface BusinessProfileModalProps {
  business: PaceMakerBusiness | null;
  isOpen: boolean;
  onClose: () => void;
  onUpgradeToPartner: (businessId: string) => void;
}

export const BusinessProfileModal: React.FC<BusinessProfileModalProps> = ({
  business,
  isOpen,
  onClose,
  onUpgradeToPartner
}) => {
  if (!business) return null;

  const formatBusinessHours = (hours: any) => {
    if (!hours) return 'Hours not specified';
    return Object.entries(hours).map(([day, time]) => 
      `${day}: ${time}`
    ).join(', ');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>{business.business_name}</span>
            <div className="flex gap-2">
              <Badge variant={business.is_service_business ? 'secondary' : 'default'}>
                {business.is_service_business ? 'Service Business' : 'Product Business'}
              </Badge>
              {business.is_partner && (
                <Badge variant="outline">
                  {business.partner_tier.toUpperCase()} PARTNER
                </Badge>
              )}
            </div>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <h3 className="font-semibold mb-2">About</h3>
            <p className="text-sm text-muted-foreground">{business.description}</p>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2">Category</h3>
            <Badge variant="outline">{business.category}</Badge>
          </div>
          
          {business.services && business.services.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2">Services Offered</h3>
              <div className="flex flex-wrap gap-2">
                {business.services.map((service, index) => (
                  <Badge key={index} variant="secondary">{service}</Badge>
                ))}
              </div>
            </div>
          )}
          
          <Separator />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {business.address && (
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-1 text-muted-foreground" />
                <div className="text-sm">
                  <p>{business.address}</p>
                  <p>{business.city}, {business.state} {business.zip_code}</p>
                </div>
              </div>
            )}
            
            {business.contact_phone && (
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{business.contact_phone}</span>
              </div>
            )}
            
            {business.contact_email && (
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{business.contact_email}</span>
              </div>
            )}
            
            {business.business_hours && (
              <div className="flex items-start gap-2">
                <Clock className="h-4 w-4 mt-1 text-muted-foreground" />
                <span className="text-sm">{formatBusinessHours(business.business_hours)}</span>
              </div>
            )}
          </div>
          
          {(business.website_url || business.facebook_url || business.instagram_url) && (
            <div>
              <h3 className="font-semibold mb-2">Connect Online</h3>
              <div className="flex gap-2">
                {business.website_url && (
                  <Button variant="outline" size="sm" asChild>
                    <a href={business.website_url} target="_blank" rel="noopener noreferrer">
                      <Globe className="h-4 w-4 mr-2" />
                      Website
                    </a>
                  </Button>
                )}
                {business.facebook_url && (
                  <Button variant="outline" size="sm" asChild>
                    <a href={business.facebook_url} target="_blank" rel="noopener noreferrer">
                      <Facebook className="h-4 w-4 mr-2" />
                      Facebook
                    </a>
                  </Button>
                )}
                {business.instagram_url && (
                  <Button variant="outline" size="sm" asChild>
                    <a href={business.instagram_url} target="_blank" rel="noopener noreferrer">
                      <Instagram className="h-4 w-4 mr-2" />
                      Instagram
                    </a>
                  </Button>
                )}
              </div>
            </div>
          )}
          
          {!business.is_partner && (
            <div className="bg-muted p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Upgrade to Partner</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Get more visibility, integrate your website and social media, and access premium features.
              </p>
              <Button 
                onClick={() => onUpgradeToPartner(business.id)}
                className="w-full"
              >
                Upgrade to Partner
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};