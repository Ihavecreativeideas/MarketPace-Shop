import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { X, Star, Gift, Users } from 'lucide-react';

export function OnboardingPopups() {
  const [showWelcome, setShowWelcome] = useState(false);
  const [showFeatures, setShowFeatures] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding');
    if (!hasSeenOnboarding) {
      setTimeout(() => setShowWelcome(true), 1000);
    }
  }, []);

  const handleWelcomeNext = () => {
    setShowWelcome(false);
    setShowFeatures(true);
  };

  const handleFeaturesNext = () => {
    if (currentStep < 2) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowFeatures(false);
      localStorage.setItem('hasSeenOnboarding', 'true');
    }
  };

  const features = [
    {
      icon: <Star className="w-8 h-8 text-yellow-500" />,
      title: "Welcome to MarketPace!",
      description: "Your local marketplace for everything - from rentals to services to entertainment."
    },
    {
      icon: <Gift className="w-8 h-8 text-green-500" />,
      title: "Free Trial Period",
      description: "Enjoy 3 months of premium features completely free during our launch campaign!"
    },
    {
      icon: <Users className="w-8 h-8 text-blue-500" />,
      title: "Build Your Profile",
      description: "Set up your personal or business profile to start connecting with your community."
    }
  ];

  if (showWelcome) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-purple-600">
              🎉 Welcome to MarketPace!
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p>You're joining a community-first marketplace that's revolutionizing local commerce.</p>
            <Button onClick={handleWelcomeNext} className="w-full">
              Let's Get Started!
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showFeatures) {
    const feature = features[currentStep];
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="relative">
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-0 top-0"
              onClick={() => {
                setShowFeatures(false);
                localStorage.setItem('hasSeenOnboarding', 'true');
              }}
            >
              <X size={16} />
            </Button>
            <div className="text-center">
              {feature.icon}
              <CardTitle className="mt-2">{feature.title}</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p>{feature.description}</p>
            <div className="flex justify-center space-x-2">
              {features.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full ${
                    index === currentStep ? 'bg-purple-600' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
            <Button onClick={handleFeaturesNext} className="w-full">
              {currentStep < 2 ? 'Next' : 'Get Started!'}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}