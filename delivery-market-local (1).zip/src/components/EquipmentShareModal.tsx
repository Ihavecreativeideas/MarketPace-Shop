import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X, Upload, Music, Facebook, Share2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface EquipmentShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEquipmentShared: (equipment: any) => void;
}

const EquipmentShareModal: React.FC<EquipmentShareModalProps> = ({
  isOpen,
  onClose,
  onEquipmentShared
}) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    type: 'sell',
    category: '',
    condition: ''
  });
  const [images, setImages] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (images.length + files.length > 5) {
      toast({ title: 'Maximum 5 images allowed', variant: 'destructive' });
      return;
    }

    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setImages(prev => [...prev, e.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (shareToFacebook = false) => {
    if (!formData.name || !formData.description || !formData.price) {
      toast({ title: 'Please fill in all required fields', variant: 'destructive' });
      return;
    }

    setIsSubmitting(true);
    
    const newEquipment = {
      id: Date.now(),
      name: formData.name,
      description: formData.description,
      price: `$${formData.price}`,
      shop: 'Musician Equipment',
      platform: 'local' as const,
      rating: 5.0,
      image: images[0] || '/placeholder.svg',
      images,
      deliveryType: 'local' as const,
      isPartnerShop: false,
      category: formData.category,
      condition: formData.condition,
      type: formData.type,
      createdAt: new Date().toISOString()
    };

    onEquipmentShared(newEquipment);
    
    if (shareToFacebook) {
      shareToFacebookMarketplace(newEquipment);
    }

    toast({ title: `Equipment ${formData.type === 'sell' ? 'listed for sale' : 'available for rent'} successfully!` });
    
    // Reset form
    setFormData({ name: '', description: '', price: '', type: 'sell', category: '', condition: '' });
    setImages([]);
    setIsSubmitting(false);
    onClose();
  };

  const shareToFacebookMarketplace = (equipment: any) => {
    const fbText = `${equipment.name} - ${equipment.type === 'sell' ? 'For Sale' : 'For Rent'}\n\n${equipment.description}\n\nPrice: ${equipment.price}\n\nContact me for more details!`;
    const fbUrl = `https://www.facebook.com/marketplace/create/item?title=${encodeURIComponent(equipment.name)}&description=${encodeURIComponent(fbText)}&price=${encodeURIComponent(equipment.price.replace('$', ''))}`;
    window.open(fbUrl, '_blank');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Music className="w-5 h-5" />
            Share Equipment to Marketplace
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Equipment Name *</Label>
              <Input
                placeholder="e.g., Fender Stratocaster Guitar"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div>
              <Label>Type *</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sell">For Sale</SelectItem>
                  <SelectItem value="rent">For Rent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Category</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="guitar">Guitar</SelectItem>
                  <SelectItem value="bass">Bass</SelectItem>
                  <SelectItem value="drums">Drums</SelectItem>
                  <SelectItem value="keyboard">Keyboard/Piano</SelectItem>
                  <SelectItem value="microphone">Microphone</SelectItem>
                  <SelectItem value="amplifier">Amplifier</SelectItem>
                  <SelectItem value="audio-interface">Audio Interface</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Condition</Label>
              <Select value={formData.condition} onValueChange={(value) => setFormData({...formData, condition: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select condition" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="excellent">Excellent</SelectItem>
                  <SelectItem value="good">Good</SelectItem>
                  <SelectItem value="fair">Fair</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>Price * {formData.type === 'rent' && '(per day)'}</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              <Input
                type="number"
                placeholder="0.00"
                className="pl-8"
                value={formData.price}
                onChange={(e) => setFormData({...formData, price: e.target.value})}
              />
            </div>
          </div>

          <div>
            <Label>Description *</Label>
            <Textarea
              placeholder="Describe your equipment, its condition, and any special features..."
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              rows={4}
            />
          </div>

          <div>
            <Label>Images (up to 5)</Label>
            <div className="space-y-3">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="image-upload"
                />
                <label htmlFor="image-upload" className="cursor-pointer">
                  <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm text-gray-600">Click to upload images</p>
                </label>
              </div>
              
              {images.length > 0 && (
                <div className="grid grid-cols-3 gap-2">
                  {images.map((image, index) => (
                    <div key={index} className="relative">
                      <img src={image} alt={`Upload ${index + 1}`} className="w-full h-20 object-cover rounded" />
                      <button
                        onClick={() => removeImage(index)}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={() => handleSubmit(false)} 
              disabled={isSubmitting}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share to Marketplace
            </Button>
            <Button 
              onClick={() => handleSubmit(true)} 
              disabled={isSubmitting}
              className="flex-1 bg-blue-800 hover:bg-blue-900"
            >
              <Facebook className="w-4 h-4 mr-2" />
              Share to Facebook
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EquipmentShareModal;