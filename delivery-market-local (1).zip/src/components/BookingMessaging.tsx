import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, Send, User, Music } from 'lucide-react';

interface Message {
  id: number;
  sender: 'client' | 'musician';
  content: string;
  timestamp: string;
  type: 'message' | 'booking_request' | 'contract';
}

interface BookingMessagingProps {
  bookingId: number;
  clientName: string;
  musicianName: string;
  onSendMessage: (message: string) => void;
  onAcceptBooking: () => void;
  onDeclineBooking: () => void;
}

const BookingMessaging: React.FC<BookingMessagingProps> = ({
  bookingId,
  clientName,
  musicianName,
  onSendMessage,
  onAcceptBooking,
  onDeclineBooking
}) => {
  const [newMessage, setNewMessage] = useState('');
  const [messages] = useState<Message[]>([
    {
      id: 1,
      sender: 'client',
      content: 'Hi! I\'d like to book you for my wedding on January 15th.',
      timestamp: '2024-01-10 10:30 AM',
      type: 'booking_request'
    },
    {
      id: 2,
      sender: 'musician',
      content: 'Thank you for your interest! I\'d love to perform at your wedding. What kind of music are you looking for?',
      timestamp: '2024-01-10 11:15 AM',
      type: 'message'
    },
    {
      id: 3,
      sender: 'client',
      content: 'We\'re looking for acoustic covers during dinner and some upbeat songs for dancing later.',
      timestamp: '2024-01-10 12:00 PM',
      type: 'message'
    }
  ]);

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      onSendMessage(newMessage);
      setNewMessage('');
    }
  };

  return (
    <Card className="h-96 flex flex-col">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <MessageCircle className="w-5 h-5" />
          Booking Discussion
        </CardTitle>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <span>{clientName}</span>
          <span>↔</span>
          <span>{musicianName}</span>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col p-0">
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.sender === 'client' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-xs p-3 rounded-lg ${
                message.sender === 'client' 
                  ? 'bg-blue-500 text-white' 
                  : 'bg-gray-100 text-gray-900'
              }`}>
                <div className="flex items-center gap-2 mb-1">
                  {message.sender === 'client' ? 
                    <User className="w-3 h-3" /> : 
                    <Music className="w-3 h-3" />
                  }
                  <span className="text-xs opacity-75">
                    {message.sender === 'client' ? clientName : musicianName}
                  </span>
                </div>
                <p className="text-sm">{message.content}</p>
                <p className="text-xs opacity-75 mt-1">{message.timestamp}</p>
                {message.type === 'booking_request' && (
                  <Badge variant="secondary" className="mt-2">
                    Booking Request
                  </Badge>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <div className="border-t p-4">
          <div className="flex gap-2 mb-3">
            <Button size="sm" onClick={onAcceptBooking} className="bg-green-600 hover:bg-green-700">
              Accept Booking
            </Button>
            <Button size="sm" variant="outline" onClick={onDeclineBooking}>
              Decline
            </Button>
          </div>
          
          <div className="flex gap-2">
            <Input
              placeholder="Type your message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              className="flex-1"
            />
            <Button size="sm" onClick={handleSendMessage}>
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default BookingMessaging;