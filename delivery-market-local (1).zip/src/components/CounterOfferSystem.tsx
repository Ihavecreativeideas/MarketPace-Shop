import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { DollarSign, MessageSquare, Clock, CheckCircle, XCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface CounterOfferProps {
  itemId: string;
  originalPrice: number;
  sellerId: string;
  buyerId?: string;
}

interface Offer {
  id: string;
  amount: number;
  message: string;
  status: 'pending' | 'accepted' | 'rejected' | 'countered';
  created_at: string;
  buyer_name: string;
}

export const CounterOfferSystem: React.FC<CounterOfferProps> = ({
  itemId,
  originalPrice,
  sellerId,
  buyerId
}) => {
  const [offerAmount, setOfferAmount] = useState('');
  const [offerMessage, setOfferMessage] = useState('');
  const [offers, setOffers] = useState<Offer[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSubmitOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!buyerId) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('marketplace_offers')
        .insert({
          item_id: itemId,
          buyer_id: buyerId,
          seller_id: sellerId,
          amount: parseFloat(offerAmount),
          message: offerMessage,
          status: 'pending'
        })
        .select();

      if (error) throw error;
      
      setOfferAmount('');
      setOfferMessage('');
      // Refresh offers list
      fetchOffers();
    } catch (error) {
      console.error('Error submitting offer:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchOffers = async () => {
    const { data, error } = await supabase
      .from('marketplace_offers')
      .select(`
        *,
        buyer:user_profiles!buyer_id(name)
      `)
      .eq('item_id', itemId)
      .order('created_at', { ascending: false });

    if (data) {
      setOffers(data.map(offer => ({
        ...offer,
        buyer_name: offer.buyer?.name || 'Anonymous'
      })));
    }
  };

  const handleOfferResponse = async (offerId: string, status: 'accepted' | 'rejected') => {
    const { error } = await supabase
      .from('marketplace_offers')
      .update({ status })
      .eq('id', offerId);

    if (!error) {
      fetchOffers();
    }
  };

  React.useEffect(() => {
    fetchOffers();
  }, [itemId]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'accepted': return 'bg-green-500';
      case 'rejected': return 'bg-red-500';
      case 'countered': return 'bg-blue-500';
      default: return 'bg-yellow-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'accepted': return <CheckCircle className="w-4 h-4" />;
      case 'rejected': return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Make Offer Form */}
      {buyerId && (
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Make an Offer
            </CardTitle>
            <p className="text-sm text-gray-300">
              Listed Price: ${originalPrice.toFixed(2)}
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmitOffer} className="space-y-4">
              <div>
                <Label htmlFor="offer-amount" className="text-white">Your Offer ($)</Label>
                <Input
                  id="offer-amount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={offerAmount}
                  onChange={(e) => setOfferAmount(e.target.value)}
                  className="bg-white/10 border-white/20 text-white"
                  placeholder="Enter your offer amount"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="offer-message" className="text-white">Message (Optional)</Label>
                <Textarea
                  id="offer-message"
                  value={offerMessage}
                  onChange={(e) => setOfferMessage(e.target.value)}
                  className="bg-white/10 border-white/20 text-white"
                  placeholder="Add a message to your offer..."
                  rows={3}
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={loading || !offerAmount}
              >
                {loading ? 'Submitting...' : 'Submit Offer'}
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Offers List */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Offers ({offers.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {offers.length === 0 ? (
            <p className="text-gray-400 text-center py-4">No offers yet</p>
          ) : (
            <div className="space-y-4">
              {offers.map((offer) => (
                <div key={offer.id} className="bg-white/5 p-4 rounded-lg border border-white/10">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-white font-semibold">${offer.amount.toFixed(2)}</span>
                        <Badge className={`${getStatusColor(offer.status)} text-white`}>
                          {getStatusIcon(offer.status)}
                          <span className="ml-1 capitalize">{offer.status}</span>
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-300">From: {offer.buyer_name}</p>
                      <p className="text-xs text-gray-400">
                        {new Date(offer.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    
                    {/* Seller Actions */}
                    {offer.status === 'pending' && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleOfferResponse(offer.id, 'accepted')}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          Accept
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleOfferResponse(offer.id, 'rejected')}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          Decline
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  {offer.message && (
                    <div className="bg-white/5 p-2 rounded border-l-2 border-blue-400">
                      <p className="text-sm text-gray-300">{offer.message}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};