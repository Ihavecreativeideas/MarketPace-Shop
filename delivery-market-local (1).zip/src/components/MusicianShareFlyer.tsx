import React from 'react';
import { Button } from './ui/button';
import { Music, Users, Mic, Calendar, Share2, Star, Headphones, ShoppingBag } from 'lucide-react';

interface MusicianShareFlyerProps {
  onJoinNow: () => void;
  onShare: () => void;
}

const MusicianShareFlyer: React.FC<MusicianShareFlyerProps> = ({ onJoinNow, onShare }) => {
  return (
    <div className="bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400 p-8 rounded-2xl text-white shadow-2xl max-w-md mx-auto">
      {/* Header */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-4 animate-pulse">
          <Music className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold mb-2">
          MarketPace Musicians
        </h1>
        <p className="text-lg opacity-90 font-semibold">
          Grow a local fan base at MarketPace
        </p>
      </div>

      {/* Main Message */}
      <div className="text-center mb-6">
        <p className="text-base font-semibold mb-3">
          Join our community of local musicians!
        </p>
        <p className="text-sm opacity-90 leading-relaxed">
          Rent/buy/sell sound equipment, hire soundmen & DJs, post events that instantly connect with local marketplace users.
        </p>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="text-center">
          <Headphones className="h-5 w-5 mx-auto mb-1 text-yellow-300" />
          <p className="text-xs font-semibold">Rent Equipment</p>
        </div>
        <div className="text-center">
          <Mic className="h-5 w-5 mx-auto mb-1 text-green-300" />
          <p className="text-xs font-semibold">Hire Talent</p>
        </div>
        <div className="text-center">
          <Calendar className="h-5 w-5 mx-auto mb-1 text-blue-300" />
          <p className="text-xs font-semibold">Post Events</p>
        </div>
        <div className="text-center">
          <Users className="h-5 w-5 mx-auto mb-1 text-pink-300" />
          <p className="text-xs font-semibold">Connect Locally</p>
        </div>
      </div>

      {/* Pro Features */}
      <div className="bg-white/10 rounded-lg p-4 mb-6">
        <div className="flex items-center mb-2">
          <Star className="h-4 w-4 text-yellow-300 mr-2" />
          <p className="text-sm font-bold">Upgrade to Pro Musician</p>
        </div>
        <ul className="text-xs space-y-1 opacity-90">
          <li>• Integrate social media & websites</li>
          <li>• Sell merch locally & online</li>
          <li>• Notify fans of new releases</li>
          <li>• Access delivery services</li>
        </ul>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button 
          onClick={onJoinNow}
          className="w-full bg-white text-purple-600 hover:bg-gray-100 font-bold py-3"
        >
          Join Musicians Community
        </Button>
        <Button 
          onClick={onShare}
          variant="outline"
          className="w-full border-white text-white hover:bg-white/10 font-semibold flex items-center justify-center gap-2"
        >
          <Share2 className="h-4 w-4" />
          Share with Musicians
        </Button>
      </div>
    </div>
  );
};

export default MusicianShareFlyer;