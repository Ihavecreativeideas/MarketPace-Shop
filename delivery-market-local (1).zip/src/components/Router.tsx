import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LandingPage from './LandingPage';
import { MultiAuthModal } from './MultiAuthModal';
import { PersonalizedProfilePage } from './PersonalizedProfilePage';
import { CommunityPage } from './CommunityPage';
import { Marketplace } from './Marketplace';
import { RentAnything } from './RentAnything';
import { CartPage } from './CartPage';
import { CheckoutPage } from './CheckoutPage';
import { Musicians } from './Musicians';
import { ShopsAndServices } from './ShopsAndServices';
import { UserProfile, DriverDashboard, BusinessDashboard, AdminDashboard, DeliverNowPage, DriverApplicationPage } from './SimpleComponents';
import { SettingsPage } from '../pages/SettingsPage';
import { EditProfilePage } from '../pages/EditProfilePage';
import { OrderHistoryPage } from '../pages/OrderHistoryPage';
import { FavoritesPage } from '../pages/FavoritesPage';

// Simple NotFound component
const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white mb-4">404</h1>
        <p className="text-slate-400 mb-6">Page not found</p>
        <button 
          onClick={() => window.location.href = '/'}
          className="bg-teal-500 hover:bg-teal-600 text-white px-6 py-2 rounded-lg"
        >
          Go Home
        </button>
      </div>
    </div>
  );
};

const Router: React.FC = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/auth" element={<MultiAuthModal />} />
        <Route path="/personalized-profile" element={<PersonalizedProfilePage />} />
        <Route path="/community" element={<CommunityPage />} />
        <Route path="/marketplace" element={<Marketplace />} />
        <Route path="/rent" element={<RentAnything />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/checkout" element={<CheckoutPage />} />
        <Route path="/musicians" element={<Musicians />} />
        <Route path="/shops" element={<ShopsAndServices />} />
        <Route path="/deliver" element={<DeliverNowPage />} />
        <Route path="/driver-application" element={<DriverApplicationPage />} />
        <Route path="/profile" element={<UserProfile />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/edit-profile" element={<EditProfilePage />} />
        <Route path="/order-history" element={<OrderHistoryPage />} />
        <Route path="/favorites" element={<FavoritesPage />} />
        <Route path="/driver-dashboard" element={<DriverDashboard />} />
        <Route path="/business-dashboard" element={<BusinessDashboard />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

export default Router;
export { Router };