import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, Clock, DollarSign, Package, Phone, Navigation, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface DeliveryJob {
  id: string;
  orderId: string;
  pickupAddress: string;
  deliveryAddress: string;
  customerName: string;
  customerPhone: string;
  orderValue: number;
  deliveryFee: number;
  distance: number;
  estimatedTime: number;
  priority: 'normal' | 'urgent' | 'rush';
  status: 'available' | 'accepted' | 'picked_up' | 'delivered';
  items: string[];
  specialInstructions?: string;
  createdAt: string;
}

interface DriverJobDashboardProps {
  driverId: string;
}

export default function DriverJobDashboard({ driverId }: DriverJobDashboardProps) {
  const [availableJobs, setAvailableJobs] = useState<DeliveryJob[]>([]);
  const [activeJob, setActiveJob] = useState<DeliveryJob | null>(null);
  const [earnings, setEarnings] = useState({ today: 0, week: 0, total: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadJobs();
    loadEarnings();
  }, [driverId]);

  const loadJobs = async () => {
    try {
      // Load available jobs
      const { data: available, error: availableError } = await supabase
        .from('deliveries')
        .select('*')
        .eq('status', 'pending')
        .is('driver_id', null)
        .order('created_at', { ascending: false });

      if (availableError) throw availableError;

      // Load active job for this driver
      const { data: active, error: activeError } = await supabase
        .from('deliveries')
        .select('*')
        .eq('driver_id', driverId)
        .in('status', ['accepted', 'picked_up'])
        .single();

      const formatJob = (job: any): DeliveryJob => ({
        id: job.id,
        orderId: job.order_id || job.id,
        pickupAddress: job.pickup_address || 'Unknown',
        deliveryAddress: job.delivery_address || 'Unknown',
        customerName: job.customer_name || 'Customer',
        customerPhone: job.customer_phone || '',
        orderValue: job.order_value || 0,
        deliveryFee: job.delivery_fee || 0,
        distance: job.distance || 0,
        estimatedTime: job.estimated_time || 30,
        priority: job.priority || 'normal',
        status: job.status || 'available',
        items: job.items || [],
        specialInstructions: job.special_instructions,
        createdAt: job.created_at
      });

      setAvailableJobs((available || []).map(formatJob));
      setActiveJob(active ? formatJob(active) : null);
    } catch (error) {
      console.error('Error loading jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadEarnings = async () => {
    try {
      const { data, error } = await supabase
        .from('driver_payments')
        .select('amount, created_at')
        .eq('driver_id', driverId);

      if (error) throw error;

      const now = new Date();
      const today = now.toDateString();
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

      const todayEarnings = (data || []).filter(p => new Date(p.created_at).toDateString() === today)
        .reduce((sum, p) => sum + p.amount, 0);
      
      const weekEarnings = (data || []).filter(p => new Date(p.created_at) >= weekAgo)
        .reduce((sum, p) => sum + p.amount, 0);
      
      const totalEarnings = (data || []).reduce((sum, p) => sum + p.amount, 0);

      setEarnings({ today: todayEarnings, week: weekEarnings, total: totalEarnings });
    } catch (error) {
      console.error('Error loading earnings:', error);
    }
  };

  const acceptJob = async (jobId: string) => {
    try {
      const { error } = await supabase
        .from('deliveries')
        .update({ driver_id: driverId, status: 'accepted' })
        .eq('id', jobId);

      if (error) throw error;
      loadJobs();
    } catch (error) {
      console.error('Error accepting job:', error);
    }
  };

  const updateJobStatus = async (jobId: string, status: string, notifyCustomer = false) => {
    try {
      const { error } = await supabase
        .from('deliveries')
        .update({ status })
        .eq('id', jobId);

      if (error) throw error;

      if (notifyCustomer && activeJob) {
        // Send notification to customer
        const message = status === 'picked_up' ? 
          `Your order has been picked up and is on the way!` :
          `Your order has been delivered. Thank you for using MarketPace!`;
        
        // TODO: Implement actual notification system
        console.log(`Notifying customer: ${message}`);
      }

      if (status === 'delivered') {
        // Process payment
        await supabase.from('driver_payments').insert({
          driver_id: driverId,
          delivery_id: jobId,
          amount: activeJob?.deliveryFee || 0,
          status: 'completed'
        });
        loadEarnings();
      }

      loadJobs();
    } catch (error) {
      console.error('Error updating job status:', error);
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'urgent': return <Badge className="bg-red-100 text-red-800">🚨 Urgent</Badge>;
      case 'rush': return <Badge className="bg-orange-100 text-orange-800">⚡ Rush</Badge>;
      default: return <Badge className="bg-green-100 text-green-800">📦 Normal</Badge>;
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading dashboard...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Earnings Overview */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Today's Earnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">${earnings.today.toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">This Week</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">${earnings.week.toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Earnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">${earnings.total.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Active Job */}
      {activeJob && (
        <Card className="border-green-200">
          <CardHeader>
            <CardTitle className="text-green-700">🚗 Active Delivery</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">{activeJob.customerName}</h3>
                <p className="text-sm text-muted-foreground">Order #{activeJob.orderId}</p>
              </div>
              {getPriorityBadge(activeJob.priority)}
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pickup</p>
                <p className="text-sm">{activeJob.pickupAddress}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Delivery</p>
                <p className="text-sm">{activeJob.deliveryAddress}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <DollarSign className="h-4 w-4" />
                ${activeJob.deliveryFee}
              </div>
              <div className="flex items-center gap-1">
                <Navigation className="h-4 w-4" />
                {activeJob.distance} mi
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {activeJob.estimatedTime} min
              </div>
            </div>

            {activeJob.specialInstructions && (
              <Alert>
                <AlertDescription>
                  <strong>Special Instructions:</strong> {activeJob.specialInstructions}
                </AlertDescription>
              </Alert>
            )}

            <div className="flex gap-2">
              {activeJob.status === 'accepted' && (
                <Button onClick={() => updateJobStatus(activeJob.id, 'picked_up', true)} className="flex-1">
                  <Package className="h-4 w-4 mr-2" />
                  Mark as Picked Up
                </Button>
              )}
              {activeJob.status === 'picked_up' && (
                <Button onClick={() => updateJobStatus(activeJob.id, 'delivered', true)} className="flex-1">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Mark as Delivered
                </Button>
              )}
              <Button variant="outline" onClick={() => window.open(`tel:${activeJob.customerPhone}`)}>
                <Phone className="h-4 w-4 mr-2" />
                Call Customer
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Available Jobs */}
      <Card>
        <CardHeader>
          <CardTitle>📋 Available Jobs ({availableJobs.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {availableJobs.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No jobs available right now. Check back soon!</p>
          ) : (
            <div className="space-y-4">
              {availableJobs.map(job => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{job.customerName}</h3>
                      <p className="text-sm text-muted-foreground">Order #{job.orderId}</p>
                    </div>
                    {getPriorityBadge(job.priority)}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="font-medium text-muted-foreground">Pickup</p>
                      <p>{job.pickupAddress}</p>
                    </div>
                    <div>
                      <p className="font-medium text-muted-foreground">Delivery</p>
                      <p>{job.deliveryAddress}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <DollarSign className="h-4 w-4" />
                        ${job.deliveryFee}
                      </div>
                      <div className="flex items-center gap-1">
                        <Navigation className="h-4 w-4" />
                        {job.distance} mi
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {job.estimatedTime} min
                      </div>
                    </div>
                    <Button 
                      onClick={() => acceptJob(job.id)}
                      disabled={!!activeJob}
                      size="sm"
                    >
                      Accept Job
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}