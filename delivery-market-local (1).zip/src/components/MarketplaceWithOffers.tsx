import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, ShoppingCart, Star, Crown, MessageCircle, CreditCard, Plus } from 'lucide-react';
import CounterOfferModal from './CounterOfferModal';
import SellerOfferResponse from './SellerOfferResponse';
import MarketplacePostModal from './MarketplacePostModal';
import { useCart } from './CartContext';
import { useNavigate } from 'react-router-dom';

interface Product {
  id: number;
  name: string;
  price: string;
  shop: string;
  rating: number;
  image: string;
  isPartnerShop: boolean;
}

interface CounterOffer {
  id: string;
  productId: number;
  buyerName: string;
  originalPrice: number;
  discountPercent: number;
  offeredPrice: number;
  status: 'pending' | 'accepted' | 'declined' | 'countered';
}

interface MarketplacePost {
  id: string;
  type: string;
  title: string;
  description: string;
  price?: number;
  category: string;
  images: File[];
  createdAt: string;
  author: string;
}

const MarketplaceWithOffers: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [counterOfferModal, setCounterOfferModal] = useState<{isOpen: boolean, product: Product | null}>({isOpen: false, product: null});
  const [sellerResponseModal, setSellerResponseModal] = useState<{isOpen: boolean, offer: CounterOffer | null}>({isOpen: false, offer: null});
  const [postModal, setPostModal] = useState(false);
  const [counterOffers, setCounterOffers] = useState<CounterOffer[]>([]);
  const [userPosts, setUserPosts] = useState<MarketplacePost[]>([]);
  const { addToCart } = useCart();
  const navigate = useNavigate();

  const mockProducts: Product[] = [
    {
      id: 1,
      name: 'Handcrafted Ceramic Mug',
      price: '24.99',
      shop: 'Clay Creations',
      rating: 4.8,
      image: '/placeholder.svg',
      isPartnerShop: false
    },
    {
      id: 2,
      name: 'Vintage Band T-Shirt',
      price: '35.00',
      shop: 'Retro Threads',
      rating: 4.6,
      image: '/placeholder.svg',
      isPartnerShop: true
    }
  ];

  const filteredProducts = mockProducts.filter(product => 
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.shop.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddToCart = (product: Product) => {
    const cartItem = {
      id: product.id,
      title: product.name,
      price: parseFloat(product.price),
      image: product.image,
      category: 'Marketplace',
      location: product.shop,
      size: 'medium' as const
    };
    addToCart(cartItem);
    navigate('/cart');
  };

  const handleCounterOffer = (product: Product) => {
    setCounterOfferModal({isOpen: true, product});
  };

  const handleSubmitCounterOffer = (discountPercent: number, newPrice: number) => {
    if (counterOfferModal.product) {
      const newOffer: CounterOffer = {
        id: Date.now().toString(),
        productId: counterOfferModal.product.id,
        buyerName: 'Current User',
        originalPrice: parseFloat(counterOfferModal.product.price),
        discountPercent,
        offeredPrice: newPrice,
        status: 'pending'
      };
      setCounterOffers(prev => [...prev, newOffer]);
      setTimeout(() => {
        setSellerResponseModal({isOpen: true, offer: newOffer});
      }, 2000);
    }
  };

  const handleCreatePost = (postData: any) => {
    const newPost: MarketplacePost = {
      ...postData,
      id: Date.now().toString(),
      author: 'Current User'
    };
    setUserPosts(prev => [newPost, ...prev]);
  };

  const handleSellerAccept = () => {
    console.log('Seller accepted offer');
    setSellerResponseModal({isOpen: false, offer: null});
  };

  const handleSellerDecline = () => {
    console.log('Seller declined offer');
    setSellerResponseModal({isOpen: false, offer: null});
  };

  const handleSellerCounterBack = (newDiscountPercent: number, newPrice: number) => {
    console.log('Seller countered back:', newDiscountPercent, newPrice);
    setSellerResponseModal({isOpen: false, offer: null});
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-lg p-4">
        <h2 className="text-xl font-bold text-orange-800 mb-2">Counter Offer System</h2>
        <p className="text-sm text-orange-600">
          Make counter offers with fixed discounts: 10%, 20%, 30%, 40%, or 50% off regular price.
        </p>
      </div>
      
      <div className="flex gap-4 items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button 
          onClick={() => setPostModal(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Post
        </Button>
      </div>

      {userPosts.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Your Posts</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {userPosts.map((post) => (
              <Card key={post.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline">{post.type}</Badge>
                      <span className="text-xs text-gray-500">
                        {new Date(post.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <CardTitle className="text-lg">{post.title}</CardTitle>
                    <p className="text-sm text-gray-600 line-clamp-2">{post.description}</p>
                    {post.price && (
                      <span className="text-lg font-bold text-green-600">${post.price}</span>
                    )}
                    {post.category && (
                      <Badge variant="secondary">{post.category}</Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredProducts.map((product) => (
          <Card key={product.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="p-0 relative">
              <img src={product.image} alt={product.name} className="w-full h-48 object-cover rounded-t-lg" />
              {product.isPartnerShop && (
                <Badge className="absolute top-2 left-2 bg-purple-600">
                  <Crown className="w-3 h-3 mr-1" />
                  Partner
                </Badge>
              )}
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-2">
                <CardTitle className="text-lg">{product.name}</CardTitle>
                <p className="text-sm text-gray-600">{product.shop}</p>
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold text-green-600">${product.price}</span>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm">{product.rating}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Button 
                    variant="outline" 
                    className="w-full text-orange-600 border-orange-600 hover:bg-orange-50"
                    onClick={() => handleCounterOffer(product)}
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Counter Offer
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => handleAddToCart(product)}
                  >
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Add to Cart
                  </Button>
                  <Button className="w-full bg-green-600 hover:bg-green-700">
                    <CreditCard className="w-4 h-4 mr-2" />
                    Buy Now
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <MarketplacePostModal
        isOpen={postModal}
        onClose={() => setPostModal(false)}
        onSubmit={handleCreatePost}
      />

      <CounterOfferModal
        isOpen={counterOfferModal.isOpen}
        onClose={() => setCounterOfferModal({isOpen: false, product: null})}
        originalPrice={counterOfferModal.product ? parseFloat(counterOfferModal.product.price) : 0}
        itemTitle={counterOfferModal.product?.name || ''}
        onSubmitOffer={handleSubmitCounterOffer}
      />

      {sellerResponseModal.offer && (
        <SellerOfferResponse
          isOpen={sellerResponseModal.isOpen}
          onClose={() => setSellerResponseModal({isOpen: false, offer: null})}
          buyerOffer={{
            itemTitle: mockProducts.find(p => p.id === sellerResponseModal.offer?.productId)?.name || '',
            originalPrice: sellerResponseModal.offer.originalPrice,
            discountPercent: sellerResponseModal.offer.discountPercent,
            offeredPrice: sellerResponseModal.offer.offeredPrice,
            buyerName: sellerResponseModal.offer.buyerName
          }}
          onAccept={handleSellerAccept}
          onDecline={handleSellerDecline}
          onCounterBack={handleSellerCounterBack}
        />
      )}
    </div>
  );
};

export default MarketplaceWithOffers;