import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, MapPin, Clock, Users, Share2, Truck } from 'lucide-react';
import { useState } from 'react';
import ProductFacebookShare from './ProductFacebookShare';

interface EquipmentItem {
  id: number;
  title: string;
  price: number;
  category: string;
  seller: string;
  rating: number;
  image: string;
  condition: string;
  location: string;
  description: string;
  isRental: boolean;
  rentalPeriod?: string;
  distance: number;
  isSubscriber: boolean;
}

interface EquipmentCardProps {
  item: EquipmentItem;
  onMessage: (item: EquipmentItem) => void;
  onPurchase: (item: EquipmentItem) => void;
}

const EquipmentCard: React.FC<EquipmentCardProps> = ({ item, onMessage, onPurchase }) => {
  const [showShareModal, setShowShareModal] = useState(false);

  return (
    <>
      <Card className="hover:shadow-lg transition-shadow">
        <CardHeader className="p-0 relative">
          <img 
            src={item.image} 
            alt={item.title} 
            className="w-full h-48 object-cover rounded-t-lg" 
          />
          <div className="absolute top-2 right-2 flex gap-2">
            {item.isRental && (
              <Badge className="bg-green-500">
                <Clock className="w-3 h-3 mr-1" />
                Rental
              </Badge>
            )}
            <Badge variant="secondary">{item.condition}</Badge>
          </div>
          <div className="absolute top-2 left-2 flex gap-2">
            {item.isSubscriber && (
              <Badge className="bg-blue-600">
                Member
              </Badge>
            )}
            <Badge className="bg-orange-600">
              {item.distance} mi
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="p-4">
          <div className="space-y-3">
            <div>
              <CardTitle className="text-lg line-clamp-2">{item.title}</CardTitle>
              <p className="text-sm text-gray-600">{item.description}</p>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-green-600">
                ${item.price}
                {item.isRental && (
                  <span className="text-sm text-gray-500 ml-1">
                    {item.rentalPeriod}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1 text-sm text-gray-500">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                <span>{item.rating}</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Users className="w-4 h-4" />
                <span>Sold by {item.seller}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="w-4 h-4" />
                <span>{item.location}</span>
              </div>
            </div>

            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => onMessage(item)}
                className="flex-1"
              >
                Message Seller
              </Button>
              <Button 
                size="sm" 
                onClick={() => onPurchase(item)}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                {item.isRental ? 'Rent Now' : 'Buy Now'}
              </Button>
            </div>

            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowShareModal(true)}
                className="flex-1"
              >
                <Share2 className="w-4 h-4 mr-1" />
                Share to Facebook
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-1 bg-green-50 hover:bg-green-100 text-green-700"
              >
                <Truck className="w-4 h-4 mr-1" />
                Deliver Now
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {showShareModal && (
        <ProductFacebookShare
          product={{
            id: item.id.toString(),
            name: item.title,
            price: item.price,
            description: item.description,
            image: item.image,
            category: item.category,
            seller: item.seller
          }}
          onClose={() => setShowShareModal(false)}
        />
      )}
    </>
  );
};

export default EquipmentCard;