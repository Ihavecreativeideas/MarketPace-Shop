import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Crown, Gift, Star, CheckCircle, Clock, Zap } from 'lucide-react';
import { useState } from 'react';
import { toast } from '@/hooks/use-toast';

interface TrialEraSubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubscriptionComplete: (subscriptionData: any) => void;
}

const TrialEraSubscriptionModal: React.FC<TrialEraSubscriptionModalProps> = ({ 
  isOpen, 
  onClose, 
  onSubscriptionComplete 
}) => {
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    agreeToTerms: false,
    wantUpdates: true
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.agreeToTerms) {
      toast({ title: "Please agree to terms", variant: "destructive" });
      return;
    }

    setIsSubmitting(true);
    
    // Simulate subscription process
    setTimeout(() => {
      toast({
        title: "🎉 MarketPace Pro Activated!",
        description: "Welcome to your lifetime Pro membership with trial era benefits!"
      });
      onSubscriptionComplete({
        ...formData,
        subscriptionType: 'marketpace_pro',
        trialEraUser: true,
        lifetimeBenefits: true,
        subscriptionDate: new Date().toISOString()
      });
      setIsSubmitting(false);
      onClose();
    }, 2000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <div className="text-center space-y-3">
            <div className="flex justify-center">
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-3 rounded-full">
                <Crown className="w-8 h-8 text-white" />
              </div>
            </div>
            <DialogTitle className="text-2xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Activate MarketPace Pro
            </DialogTitle>
            <p className="text-sm text-gray-600">
              Get <span className="font-bold text-purple-600">lifetime benefits</span> starting FREE during trial era!
            </p>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Trial Era Special Banner */}
          <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg border-2 border-green-300">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-5 h-5 text-green-600" />
              <span className="font-bold text-green-800">Trial Era Special:</span>
            </div>
            <div className="space-y-1 text-sm text-green-700">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>All Pro features FREE during trial period</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>Lifetime 20% marketplace discount guaranteed</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span>Lock in $9.99/mo rate (normally $29.99)</span>
              </div>
            </div>
          </div>

          {/* Form Fields */}
          <div className="space-y-3">
            <div>
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Your full name"
                required
              />
            </div>
            <div>
              <Label htmlFor="email">Email Address *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                placeholder="your@email.com"
                required
              />
            </div>
          </div>

          {/* Pro Features Reminder */}
          <div className="bg-purple-50 p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Star className="w-4 h-4 text-purple-600" />
              <span className="font-semibold text-purple-800 text-sm">Included Forever:</span>
            </div>
            <div className="grid grid-cols-2 gap-1 text-xs text-purple-700">
              <span>• Professional Badge</span>
              <span>• AI Contracts</span>
              <span>• Priority Booking</span>
              <span>• Analytics Dashboard</span>
              <span>• Lifetime Discounts</span>
              <span>• Early Access</span>
            </div>
          </div>

          {/* Checkboxes */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="terms"
                checked={formData.agreeToTerms}
                onCheckedChange={(checked) => setFormData({...formData, agreeToTerms: !!checked})}
              />
              <Label htmlFor="terms" className="text-sm">
                I agree to the Terms of Service and understand this is a FREE trial with lifetime benefits *
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="updates"
                checked={formData.wantUpdates}
                onCheckedChange={(checked) => setFormData({...formData, wantUpdates: !!checked})}
              />
              <Label htmlFor="updates" className="text-sm">
                Send me updates about new Pro features and opportunities
              </Label>
            </div>
          </div>

          {/* Pricing Display */}
          <div className="text-center bg-gray-50 p-3 rounded-lg">
            <div className="flex items-center justify-center gap-2 mb-1">
              <span className="text-lg font-bold text-gray-400 line-through">$29.99/mo</span>
              <span className="text-2xl font-bold text-green-600">FREE</span>
            </div>
            <p className="text-xs text-gray-600">
              During trial era • Then $9.99/mo with lifetime benefits locked in
            </p>
          </div>

          {/* Submit Buttons */}
          <div className="flex gap-3 pt-2">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Maybe Later
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || !formData.name || !formData.email || !formData.agreeToTerms}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Activating...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Activate Pro FREE
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TrialEraSubscriptionModal;