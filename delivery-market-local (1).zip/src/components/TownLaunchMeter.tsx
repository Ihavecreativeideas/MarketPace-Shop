import React from 'react';
import { Card, CardContent } from './ui/card';
import { Users, Store, Music, Truck, Wrench, Target } from 'lucide-react';

interface TownLaunchMeterProps {
  townName: string;
  members: number;
  shops: number;
  entertainers: number;
  drivers: number;
  services: number;
  targetMembers: number;
}

const TownLaunchMeter: React.FC<TownLaunchMeterProps> = ({
  townName,
  members,
  shops,
  entertainers,
  drivers,
  services,
  targetMembers
}) => {
  const progress = Math.min((members / targetMembers) * 100, 100);
  
  const stats = [
    { icon: Users, value: members, label: 'Members', color: 'text-blue-400' },
    { icon: Store, value: shops, label: 'Shops', color: 'text-green-400' },
    { icon: Music, value: entertainers, label: 'Artists', color: 'text-purple-400' },
    { icon: Truck, value: drivers, label: 'Drivers', color: 'text-orange-400' },
    { icon: Wrench, value: services, label: 'Services', color: 'text-pink-400' }
  ];

  return (
    <Card className="bg-slate-800/60 border-slate-600/40 backdrop-blur-sm">
      <CardContent className="p-6 space-y-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-2">{townName} Launch Progress</h2>
          <div className="flex items-center justify-center gap-2 text-slate-300">
            <Target className="h-5 w-5 text-teal-400" />
            <span>{members} / {targetMembers} members to launch</span>
          </div>
        </div>
        
        <div className="space-y-3">
          <div className="bg-slate-700/50 rounded-full h-4 overflow-hidden">
            <div 
              className="bg-gradient-to-r from-teal-500 to-teal-400 h-full transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="text-center text-sm text-slate-400">
            {progress.toFixed(1)}% complete
          </div>
        </div>

        <div className="grid grid-cols-5 gap-4">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="text-center">
                <Icon className={`h-6 w-6 mx-auto mb-2 ${stat.color}`} />
                <div className="text-lg font-semibold text-white">{stat.value}</div>
                <div className="text-xs text-slate-400">{stat.label}</div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default TownLaunchMeter;