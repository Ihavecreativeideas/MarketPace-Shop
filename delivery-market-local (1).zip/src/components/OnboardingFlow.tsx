import React, { useState } from 'react';
import AccountPersonalization from './AccountPersonalization';
import DualAccountSetup from './DualAccountSetup';
import BusinessProfileSetup from './BusinessProfileSetup';
import { Card, CardContent } from './ui/card';
import { CheckCircle, User, Building2, Sparkles, Edit, UserCircle } from 'lucide-react';
import { Button } from './ui/button';

interface OnboardingFlowProps {
  onComplete: () => void;
}

type OnboardingStep = 'personalization' | 'account-type' | 'business-setup' | 'complete';

const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState<OnboardingStep>('personalization');
  const [accountType, setAccountType] = useState<'personal' | 'dual'>('personal');
  const [businessType, setBusinessType] = useState<'shop' | 'service' | 'entertainment' | null>(null);

  const handlePersonalizationComplete = () => {
    setCurrentStep('account-type');
  };

  const handleAccountTypeComplete = (type: 'personal' | 'dual', bizType?: 'shop' | 'service' | 'entertainment') => {
    setAccountType(type);
    setBusinessType(bizType || null);
    
    if (type === 'personal') {
      setCurrentStep('complete');
    } else {
      setCurrentStep('business-setup');
    }
  };

  const handleBusinessSetupComplete = () => {
    setCurrentStep('complete');
  };

  const handleGoBackToEdit = () => {
    setCurrentStep('personalization');
  };

  const handleGoToProfile = () => {
    onComplete();
  };

  const getStepIcon = (step: OnboardingStep) => {
    switch (step) {
      case 'personalization': return User;
      case 'account-type': return Building2;
      case 'business-setup': return Building2;
      case 'complete': return CheckCircle;
    }
  };

  const steps = [
    { id: 'personalization', title: 'Personal Info', completed: currentStep !== 'personalization' },
    { id: 'account-type', title: 'Account Type', completed: currentStep === 'business-setup' || currentStep === 'complete' },
    ...(accountType === 'dual' ? [{ id: 'business-setup', title: 'Business Setup', completed: currentStep === 'complete' }] : []),
    { id: 'complete', title: 'Complete', completed: currentStep === 'complete' }
  ];

  if (currentStep === 'complete') {
    return (
      <div className="max-w-2xl mx-auto p-4">
        <Card className="bg-gradient-to-br from-slate-900 via-cyan-900 to-purple-900 border-cyan-500/30 text-white">
          <CardContent className="p-8 text-center">
            <div className="mb-6">
              <Sparkles className="h-16 w-16 mx-auto text-cyan-400 mb-4" />
              <h2 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-2">
                Welcome to MarketPace!
              </h2>
              <p className="text-cyan-300 text-lg">
                Your profile has been set up successfully
              </p>
            </div>
            
            <div className="bg-slate-800/50 rounded-lg p-6 mb-6">
              <h3 className="text-xl font-semibold text-white mb-4">Account Summary</h3>
              <div className="space-y-2 text-left">
                <div className="flex justify-between">
                  <span className="text-slate-300">Account Type:</span>
                  <span className="text-cyan-400 capitalize">{accountType}</span>
                </div>
                {businessType && (
                  <div className="flex justify-between">
                    <span className="text-slate-300">Business Type:</span>
                    <span className="text-purple-400 capitalize">{businessType}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-300">Status:</span>
                  <span className="text-green-400">Active</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-slate-300">
                You're all set! Choose what you'd like to do next.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button
                  onClick={handleGoBackToEdit}
                  variant="outline"
                  className="border-cyan-500 text-cyan-400 hover:bg-cyan-500/10 px-6 py-3"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Go Back and Edit
                </Button>
                
                <Button
                  onClick={handleGoToProfile}
                  className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 px-6 py-3"
                >
                  <UserCircle className="h-4 w-4 mr-2" />
                  Go to Your Personalized Profile
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-purple-900">
      {/* Progress Steps */}
      <div className="max-w-4xl mx-auto pt-8 pb-4 px-4">
        <div className="flex justify-center items-center space-x-4 mb-8">
          {steps.map((step, index) => {
            const Icon = getStepIcon(step.id as OnboardingStep);
            const isActive = step.id === currentStep;
            const isCompleted = step.completed;
            
            return (
              <div key={step.id} className="flex items-center">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                  isCompleted ? 'bg-green-500 border-green-500' :
                  isActive ? 'bg-cyan-500 border-cyan-500' :
                  'bg-slate-700 border-slate-600'
                }`}>
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <span className={`ml-2 text-sm font-medium ${
                  isCompleted ? 'text-green-400' :
                  isActive ? 'text-cyan-400' :
                  'text-slate-400'
                }`}>
                  {step.title}
                </span>
                {index < steps.length - 1 && (
                  <div className={`w-8 h-0.5 mx-4 ${
                    isCompleted ? 'bg-green-500' : 'bg-slate-600'
                  }`} />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Step Content */}
      <div className="pb-8">
        {currentStep === 'personalization' && (
          <AccountPersonalization onComplete={handlePersonalizationComplete} />
        )}
        {currentStep === 'account-type' && (
          <DualAccountSetup onComplete={handleAccountTypeComplete} />
        )}
        {currentStep === 'business-setup' && businessType && (
          <BusinessProfileSetup 
            businessType={businessType} 
            onComplete={handleBusinessSetupComplete} 
          />
        )}
      </div>
    </div>
  );
};

export default OnboardingFlow;