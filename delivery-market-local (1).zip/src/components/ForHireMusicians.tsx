import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Music, Star, MapPin, Calendar, MessageCircle, Crown, Verified } from 'lucide-react';
import { useState } from 'react';

interface ForHireMusicianProps {
  onBookMusician?: (musician: any) => void;
}

const ForHireMusicians: React.FC<ForHireMusicianProps> = ({ onBookMusician }) => {
  const [selectedGenre, setSelectedGenre] = useState('all');

  const forHireMusicians = [
    {
      id: 1,
      name: 'Jake Martinez',
      instrument: 'Guitar & Vocals',
      genre: 'Acoustic/Folk',
      location: 'Downtown',
      rating: 4.9,
      hourlyRate: '$75-120',
      availability: 'Available weekends',
      isPro: true,
      isVerified: true,
      image: '/placeholder.svg',
      experience: '8 years',
      specialties: ['Wedding Ceremonies', 'Corporate Events', 'Private Parties']
    },
    {
      id: 2,
      name: 'Sarah Chen',
      instrument: 'Piano & Vocals',
      genre: 'Jazz/Classical',
      location: 'Arts District',
      rating: 4.8,
      hourlyRate: '$90-150',
      availability: 'Flexible schedule',
      isPro: true,
      isVerified: false,
      image: '/placeholder.svg',
      experience: '12 years',
      specialties: ['Jazz Clubs', 'Hotel Lounges', 'Wedding Receptions']
    },
    {
      id: 3,
      name: 'Mike Thunder',
      instrument: 'Drums',
      genre: 'Rock/Pop',
      location: 'Uptown',
      rating: 4.7,
      hourlyRate: '$60-100',
      availability: 'Evenings & weekends',
      isPro: false,
      isVerified: false,
      image: '/placeholder.svg',
      experience: '5 years',
      specialties: ['Session Recording', 'Live Performances', 'Music Lessons']
    }
  ];

  const handleBookMusician = (musician: any) => {
    if (onBookMusician) {
      onBookMusician(musician);
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Musicians For Hire</h2>
        <p className="text-gray-600">Book talented musicians for your events, sessions, or performances</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {forHireMusicians.map((musician) => (
          <Card key={musician.id} className="hover:shadow-lg transition-all">
            <CardHeader className="p-0 relative">
              <img 
                src={musician.image} 
                alt={musician.name} 
                className="w-full h-32 object-cover rounded-t-lg" 
              />
              <div className="absolute top-2 right-2 flex gap-1">
                {musician.isPro && (
                  <Badge className="bg-purple-600">
                    <Crown className="w-3 h-3 mr-1" />PRO
                  </Badge>
                )}
                {musician.isVerified && (
                  <Badge className="bg-blue-600">
                    <Verified className="w-3 h-3" />
                  </Badge>
                )}
              </div>
            </CardHeader>
            
            <CardContent className="p-4 space-y-3">
              <div>
                <CardTitle className="text-lg">{musician.name}</CardTitle>
                <p className="text-sm text-gray-600">{musician.instrument}</p>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <MapPin className="w-3 h-3" />
                  <span>{musician.location}</span>
                  <span>•</span>
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <span>{musician.rating}</span>
                </div>
              </div>

              <Badge variant="outline">
                <Music className="w-3 h-3 mr-1" />
                {musician.genre}
              </Badge>

              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Rate:</span>
                  <span className="font-medium text-green-600">{musician.hourlyRate}/hr</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Experience:</span>
                  <span>{musician.experience}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Calendar className="w-4 h-4" />
                <span>{musician.availability}</span>
              </div>

              <div className="flex flex-wrap gap-1">
                {musician.specialties.slice(0, 2).map((specialty, idx) => (
                  <Badge key={idx} variant="secondary" className="text-xs">
                    {specialty}
                  </Badge>
                ))}
              </div>

              <div className="flex gap-2 pt-2">
                <Button 
                  size="sm" 
                  className="flex-1"
                  onClick={() => handleBookMusician(musician)}
                >
                  Book Now
                </Button>
                <Button size="sm" variant="outline">
                  <MessageCircle className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ForHireMusicians;