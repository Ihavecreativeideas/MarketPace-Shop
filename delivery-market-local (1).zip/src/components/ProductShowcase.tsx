import React, { useState } from 'react';
import { ProductCard } from './ProductCard';
import { Button } from './ui/button';
import { ShoppingCart, MessageCircle } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
}

const ProductShowcase: React.FC = () => {
  const [products] = useState<Product[]>([
    {
      id: '1',
      name: 'Sample Product',
      price: 29.99,
      image: '/placeholder.svg',
      description: 'A great product for everyone'
    }
  ]);

  const handleAddToCart = (product: Product) => {
    console.log('Added to cart:', product);
  };

  const handleCounterOffer = (product: Product) => {
    console.log('Counter offer for:', product);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
      {products.map((product) => (
        <div key={product.id} className="border rounded-lg p-4 shadow-md">
          <img 
            src={product.image} 
            alt={product.name}
            className="w-full h-48 object-cover rounded mb-4"
          />
          <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
          <p className="text-gray-600 mb-2">{product.description}</p>
          <p className="text-xl font-bold mb-4">${product.price}</p>
          
          <div className="flex gap-2">
            <Button 
              onClick={() => handleAddToCart(product)}
              className="flex-1 flex items-center gap-2"
            >
              <ShoppingCart size={16} />
              Add to Cart
            </Button>
            
            <Button 
              variant="outline"
              onClick={() => handleCounterOffer(product)}
              className="flex-1 flex items-center gap-2"
            >
              <MessageCircle size={16} />
              Counter Offer
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProductShowcase;