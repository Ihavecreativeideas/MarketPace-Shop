import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { Facebook, Mail, User, Heart, DollarSign, Store, Truck, Users, Music } from 'lucide-react';
import { useToast } from './ui/use-toast';

interface CampaignSignupProps {
  onClose?: () => void;
}

const CampaignSignup: React.FC<CampaignSignupProps> = ({ onClose }) => {
  const [isLogin, setIsLogin] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [userType, setUserType] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleEmailSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate signup/login
    setTimeout(() => {
      toast({
        title: isLogin ? "Welcome back!" : "Welcome to MarketPace!",
        description: isLogin ? "You've successfully signed in." : "Your account has been created successfully."
      });
      setLoading(false);
      onClose?.();
    }, 1000);
  };

  const handleFacebookAuth = () => {
    // Simulate Facebook login
    setLoading(true);
    setTimeout(() => {
      toast({
        title: "Facebook Sign Up Complete!",
        description: "Welcome to MarketPace! Your account has been created."
      });
      setLoading(false);
      onClose?.();
    }, 1500);
  };

  const handleInviteFriends = () => {
    const shareText = encodeURIComponent(
      "Join me on MarketPace! Help bring local delivery to our community. It's free to sign up and be part of something amazing! 🏪🚗"
    );
    const shareUrl = encodeURIComponent(window.location.origin);
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}&quote=${shareText}`;
    window.open(facebookUrl, '_blank', 'width=600,height=400');
  };

  const handleDonate = () => {
    toast({
      title: "Donation System",
      description: "Donation processing will be available soon!"
    });
  };

  return (
    <div className="max-w-md mx-auto p-4">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-orange-600">
            Join the Campaign
          </CardTitle>
          <p className="text-gray-600">
            Be part of bringing MarketPace to your community
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* User Type Selection */}
          {!isLogin && (
            <div>
              <Label className="text-base font-semibold mb-3 block">I want to join as:</Label>
              <div className="grid grid-cols-1 gap-3">
                <Button
                  type="button"
                  variant={userType === 'basic' ? 'default' : 'outline'}
                  onClick={() => setUserType('basic')}
                  className="justify-start h-12"
                >
                  <Users className="h-5 w-5 mr-3" />
                  Basic Member
                </Button>
                <Button
                  type="button"
                  variant={userType === 'musician' ? 'default' : 'outline'}
                  onClick={() => setUserType('musician')}
                  className="justify-start h-12"
                >
                  <Music className="h-5 w-5 mr-3" />
                  Musician
                </Button>
                <Button
                  type="button"
                  variant={userType === 'business' ? 'default' : 'outline'}
                  onClick={() => setUserType('business')}
                  className="justify-start h-12"
                >
                  <Store className="h-5 w-5 mr-3" />
                  Business
                </Button>
                <Button
                  type="button"
                  variant={userType === 'driver' ? 'default' : 'outline'}
                  onClick={() => setUserType('driver')}
                  className="justify-start h-12"
                >
                  <Truck className="h-5 w-5 mr-3" />
                  Driver
                </Button>
              </div>
            </div>
          )}

          {/* Facebook Auth */}
          <Button 
            onClick={handleFacebookAuth}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            size="lg"
            disabled={loading}
          >
            <Facebook className="h-5 w-5 mr-2" />
            {loading ? 'Connecting...' : 'Continue with Facebook'}
          </Button>

          <div className="relative">
            <Separator />
            <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-2 text-sm text-gray-500">
              or
            </span>
          </div>

          {/* Email Form */}
          <form onSubmit={handleEmailSignup} className="space-y-4">
            {!isLogin && (
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="mt-1"
                />
              </div>
            )}
            
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="mt-1"
              />
            </div>

            <Button 
              type="submit" 
              className="w-full bg-orange-600 hover:bg-orange-700"
              disabled={loading}
            >
              <User className="h-4 w-4 mr-2" />
              {loading ? 'Processing...' : (isLogin ? 'Sign In' : 'Sign Up')}
            </Button>
          </form>

          <div className="text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-sm text-blue-600 hover:underline"
            >
              {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
            </button>
          </div>

          <Separator />

          {/* Invite Friends */}
          <Button 
            onClick={handleInviteFriends}
            variant="outline"
            className="w-full border-blue-200 text-blue-600 hover:bg-blue-50"
          >
            <Facebook className="h-4 w-4 mr-2" />
            Invite Facebook Friends
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default CampaignSignup;