import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Calculator, Truck, MapPin } from 'lucide-react';

interface DeliveryCalculation {
  distance: number;
  baseFee: number;
  overageFee: number;
  totalFee: number;
  buyerPays: number;
  sellerPays: number;
  driverEarns: number;
}

const LargeItemDeliveryCalculator: React.FC = () => {
  const [distance, setDistance] = useState<string>('');
  const [calculation, setCalculation] = useState<DeliveryCalculation | null>(null);

  const calculateDelivery = () => {
    const miles = parseFloat(distance);
    if (isNaN(miles) || miles <= 0) return;

    const baseFee = 50;
    const overageFee = miles > 20 ? (miles - 20) * 1.25 : 0;
    const totalFee = baseFee + overageFee;
    const buyerPays = totalFee / 2;
    const sellerPays = totalFee / 2;
    // Updated: $40 flat rate for drivers up to 20 miles
    const driverEarns = miles > 20 ? 40 + (miles - 20) * 1 : 40;

    setCalculation({
      distance: miles,
      baseFee,
      overageFee,
      totalFee,
      buyerPays,
      sellerPays,
      driverEarns
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Large Item Delivery Calculator
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="distance">Delivery Distance (miles)</Label>
              <Input
                id="distance"
                type="number"
                placeholder="Enter distance in miles"
                value={distance}
                onChange={(e) => setDistance(e.target.value)}
                className="mt-1"
              />
            </div>
            <Button onClick={calculateDelivery} className="w-full">
              Calculate Delivery Cost
            </Button>
          </div>
        </CardContent>
      </Card>

      {calculation && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Delivery Breakdown - {calculation.distance} miles
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h3 className="font-semibold text-lg">Cost Breakdown</h3>
                <div className="space-y-2">
                  <div className="flex justify-between p-2 bg-gray-50 rounded">
                    <span>Base Fee (up to 20 miles)</span>
                    <span className="font-medium">${calculation.baseFee}</span>
                  </div>
                  {calculation.overageFee > 0 && (
                    <div className="flex justify-between p-2 bg-orange-50 rounded">
                      <span>Overage Fee ({(calculation.distance - 20).toFixed(1)} miles × $1.25)</span>
                      <span className="font-medium">${calculation.overageFee.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between p-2 bg-blue-50 rounded border-2 border-blue-200">
                    <span className="font-semibold">Total Delivery Fee</span>
                    <span className="font-bold text-blue-600">${calculation.totalFee.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold text-lg">Payment Split</h3>
                <div className="space-y-2">
                  <div className="flex justify-between p-2 bg-green-50 rounded">
                    <span>Buyer Pays (50%)</span>
                    <span className="font-medium text-green-600">${calculation.buyerPays.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between p-2 bg-purple-50 rounded">
                    <span>Seller Pays (50%)</span>
                    <span className="font-medium text-purple-600">${calculation.sellerPays.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between p-2 bg-yellow-50 rounded border-2 border-yellow-200">
                    <span className="font-semibold flex items-center gap-1">
                      <Truck className="w-4 h-4" />
                      Driver Earns
                    </span>
                    <span className="font-bold text-yellow-600">${calculation.driverEarns.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-green-50 rounded-lg border border-green-200">
              <p className="text-sm text-green-800">
                <strong>100% Tips:</strong> Drivers keep 100% of all tips from both buyers and sellers. 
                Tips are encouraged for all large item deliveries.
              </p>
            </div>
            
            <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-800">
                <strong>Note:</strong> Large item deliveries are paid at a flat rate of $40 up to 20 miles, 
                plus $1 per mile over 20 miles. Both buyers and sellers are encouraged to tip.
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default LargeItemDeliveryCalculator;