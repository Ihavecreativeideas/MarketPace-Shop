import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Store, Users, Building2, Settings } from 'lucide-react';
import { useCart } from './CartContext';
import { Badge } from './ui/badge';

const FloatingBottomNav: React.FC = () => {
  const location = useLocation();
  const { items } = useCart();

  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/marketplace', icon: Store, label: 'Market', badge: items.length > 0 ? items.length : null },
    { path: '/rent-anything', icon: Settings, label: 'Rent' },
    { path: '/community', icon: Users, label: 'Community' },
    { path: '/services', icon: Building2, label: 'Services' },
    { path: '/shops', icon: Store, label: 'Shops' }
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 lg:hidden">
      <div className="bg-black/90 backdrop-blur-lg border-t border-white/10 px-2 py-2">
        <div className="flex justify-around items-center">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`relative flex flex-col items-center p-2 rounded-lg transition-colors ${
                  active 
                    ? 'text-cyan-400' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs mt-1">{item.label}</span>
                {item.badge && (
                  <Badge className="absolute -top-1 -right-1 bg-red-500 text-white text-xs min-w-[16px] h-4 flex items-center justify-center rounded-full">
                    {item.badge}
                  </Badge>
                )}
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default FloatingBottomNav;