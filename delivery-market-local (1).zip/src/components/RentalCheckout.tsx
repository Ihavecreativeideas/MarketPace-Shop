import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, CreditCard, MapPin, Truck } from 'lucide-react';
import { SelfDeliveryOptions } from './SelfDeliveryOptions';

interface RentalItem {
  id: string;
  title: string;
  price: number;
  image?: string;
  owner_name: string;
  location: string;
  self_pickup_available?: boolean;
  marketplace_delivery_available?: boolean;
}

interface RentalCheckoutProps {
  item: RentalItem;
  onBack: () => void;
  onComplete: () => void;
}

const RentalCheckout: React.FC<RentalCheckoutProps> = ({
  item,
  onBack,
  onComplete
}) => {
  const [deliveryOption, setDeliveryOption] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState({
    street: '',
    city: '',
    state: '',
    zip: ''
  });
  const [deliveryTimes, setDeliveryTimes] = useState({
    dropoff: '',
    pickup: ''
  });
  const [paymentMethod, setPaymentMethod] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    name: ''
  });
  const [tipAmount, setTipAmount] = useState(0);

  const timeSlots = [
    { value: '9am', label: '9:00 AM' },
    { value: '12pm', label: '12:00 PM' },
    { value: '3pm', label: '3:00 PM' },
    { value: '6pm', label: '6:00 PM' },
    { value: '9pm', label: '9:00 PM' }
  ];

  const getDeliveryOptions = () => {
    const options = [];
    
    if (item.self_pickup_available) {
      options.push({
        type: 'self_pickup' as const,
        available: true,
        fee: 0,
        description: 'Pick up and return the item yourself'
      });
    }
    
    if (item.marketplace_delivery_available) {
      options.push({
        type: 'marketplace_delivery' as const,
        available: true,
        fee: 30,
        estimatedTime: '2-4 hours',
        description: 'MarketPace handles both drop-off and pick-up'
      });
    }
    
    return options;
  };

  const calculateSubtotal = () => {
    return item.price;
  };

  const calculateDeliveryFees = () => {
    if (deliveryOption === 'self_pickup') return 0;
    if (deliveryOption === 'marketplace_delivery') return 30;
    return 0;
  };

  const calculateTotal = () => {
    return calculateSubtotal() + calculateDeliveryFees() + tipAmount;
  };

  const handleCheckout = () => {
    if (!deliveryOption) {
      alert('Please select a delivery option');
      return;
    }
    
    if (deliveryOption === 'marketplace_delivery') {
      if (!deliveryAddress.street || !deliveryAddress.city) {
        alert('Please provide a delivery address');
        return;
      }
      if (!deliveryTimes.dropoff || !deliveryTimes.pickup) {
        alert('Please select delivery times');
        return;
      }
    }
    
    if (!paymentMethod.cardNumber || !paymentMethod.name) {
      alert('Please provide payment information');
      return;
    }
    
    onComplete();
  };

  const needsDeliveryInfo = deliveryOption === 'marketplace_delivery';

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-indigo-900 to-purple-900 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={onBack}
            className="text-white hover:bg-white/10 mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <h1 className="text-3xl font-bold text-white">Rental Checkout</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white">Rental Item</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-white/5 rounded-lg p-4">
                  <div className="flex gap-4">
                    <div className="w-20 h-20 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      {item.image ? (
                        <img src={item.image} alt={item.title} className="w-full h-full object-cover rounded-lg" />
                      ) : (
                        <div className="text-3xl">📦</div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-white font-semibold text-lg truncate">{item.title}</h3>
                      <p className="text-gray-400 text-sm truncate">by {item.owner_name}</p>
                      <div className="flex items-center gap-1 text-gray-400 text-sm mt-1">
                        <MapPin className="w-3 h-3 flex-shrink-0" />
                        <span className="truncate">{item.location}</span>
                      </div>
                      <div className="text-green-400 font-bold text-xl mt-2">
                        ${item.price.toFixed(2)}/day
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white">Delivery & Pickup</CardTitle>
              </CardHeader>
              <CardContent>
                <SelfDeliveryOptions
                  options={getDeliveryOptions()}
                  selectedOption={deliveryOption}
                  onOptionSelect={setDeliveryOption}
                  itemLocation={item.location}
                />
              </CardContent>
            </Card>

            {needsDeliveryInfo && (
              <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-white">Delivery Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-white">Delivery Address</Label>
                    <div className="space-y-2 mt-2">
                      <Input
                        value={deliveryAddress.street}
                        onChange={(e) => setDeliveryAddress(prev => ({ ...prev, street: e.target.value }))}
                        className="bg-white/10 border-white/20 text-white"
                        placeholder="Street Address"
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <Input
                          value={deliveryAddress.city}
                          onChange={(e) => setDeliveryAddress(prev => ({ ...prev, city: e.target.value }))}
                          className="bg-white/10 border-white/20 text-white"
                          placeholder="City"
                        />
                        <Input
                          value={deliveryAddress.state}
                          onChange={(e) => setDeliveryAddress(prev => ({ ...prev, state: e.target.value }))}
                          className="bg-white/10 border-white/20 text-white"
                          placeholder="State"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white">Drop-off Time</Label>
                      <Select value={deliveryTimes.dropoff} onValueChange={(value) => setDeliveryTimes(prev => ({ ...prev, dropoff: value }))}>
                        <SelectTrigger className="bg-white/10 border-white/20 text-white">
                          <SelectValue placeholder="Select time" />
                        </SelectTrigger>
                        <SelectContent>
                          {timeSlots.map(slot => (
                            <SelectItem key={slot.value} value={slot.value}>
                              {slot.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-white">Pick-up Time</Label>
                      <Select value={deliveryTimes.pickup} onValueChange={(value) => setDeliveryTimes(prev => ({ ...prev, pickup: value }))}>
                        <SelectTrigger className="bg-white/10 border-white/20 text-white">
                          <SelectValue placeholder="Select time" />
                        </SelectTrigger>
                        <SelectContent>
                          {timeSlots.map(slot => (
                            <SelectItem key={slot.value} value={slot.value}>
                              {slot.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-3">
                    <div className="flex items-center gap-2 text-blue-300 text-sm">
                      <Truck className="w-4 h-4" />
                      <span>Both delivery fees must be paid upfront</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <div className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <CreditCard className="w-5 h-5" />
                  Payment Method
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="cardName" className="text-white">Cardholder Name</Label>
                  <Input
                    id="cardName"
                    value={paymentMethod.name}
                    onChange={(e) => setPaymentMethod(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-white/10 border-white/20 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="cardNumber" className="text-white">Card Number</Label>
                  <Input
                    id="cardNumber"
                    value={paymentMethod.cardNumber}
                    onChange={(e) => setPaymentMethod(prev => ({ ...prev, cardNumber: e.target.value }))}
                    className="bg-white/10 border-white/20 text-white"
                    placeholder="1234 5678 9012 3456"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20 shadow-xl">
              <CardHeader>
                <CardTitle className="text-white">Rental Total</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between text-gray-300">
                  <span>Rental Price:</span>
                  <span>${calculateSubtotal().toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>Delivery Fees:</span>
                  <span>${calculateDeliveryFees().toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>Tip:</span>
                  <span>${tipAmount.toFixed(2)}</span>
                </div>
                <Separator className="bg-white/20" />
                <div className="flex justify-between text-white font-semibold text-lg">
                  <span>Total:</span>
                  <span>${calculateTotal().toFixed(2)}</span>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleCheckout}
              className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white py-3 text-lg font-semibold"
            >
              Complete Rental
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RentalCheckout;
export { RentalCheckout };