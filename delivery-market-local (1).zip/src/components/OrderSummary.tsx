import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Package, Truck, DollarSign, Users, Crown } from 'lucide-react';

interface CartItem {
  id: number;
  title: string;
  price: number;
  image: string;
  category: string;
  location: string;
  size: 'small' | 'medium' | 'large';
}

interface OrderSummaryProps {
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  sustainabilityFee: number;
  tax: number;
  total: number;
  tip?: number;
  growRouteDiscount?: number;
  buyerDeliveryShare?: number;
  sellerDeliveryShare?: number;
  isPartnerShop?: boolean;
  customShippingFee?: number;
}

export const OrderSummary: React.FC<OrderSummaryProps> = ({
  items,
  subtotal,
  deliveryFee,
  sustainabilityFee = 4,
  tax,
  total,
  tip = 0,
  growRouteDiscount = 0,
  buyerDeliveryShare,
  sellerDeliveryShare,
  isPartnerShop = false,
  customShippingFee = 0
}) => {
  const getSizeInfo = (size: string) => {
    switch (size) {
      case 'small':
        return { label: 'Small', color: 'bg-green-100 text-green-800' };
      case 'medium':
        return { label: 'Medium', color: 'bg-yellow-100 text-yellow-800' };
      case 'large':
        return { label: 'Large', color: 'bg-red-100 text-red-800' };
      default:
        return { label: 'Unknown', color: 'bg-gray-100 text-gray-800' };
    }
  };

  const hasLargeItems = items.some(item => item.size === 'large');
  const originalSubtotal = subtotal / (1 - growRouteDiscount / 100);
  const discountAmount = originalSubtotal - subtotal;
  const totalDeliveryFee = buyerDeliveryShare ? buyerDeliveryShare + (sellerDeliveryShare || 0) : deliveryFee;
  const actualSustainabilityFee = isPartnerShop ? 0 : sustainabilityFee;

  return (
    <Card className={isPartnerShop ? 'border-purple-200' : ''}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="w-5 h-5" />
          Order Summary
          {isPartnerShop && (
            <Badge className="bg-purple-600">
              <Crown className="w-3 h-3 mr-1" />
              Partner
            </Badge>
          )}
          {growRouteDiscount > 0 && (
            <Badge className="bg-green-100 text-green-700">
              <Users className="w-3 h-3 mr-1" />
              {growRouteDiscount}% OFF
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {items.map((item) => {
            const sizeInfo = getSizeInfo(item.size);
            return (
              <div key={item.id} className="flex items-center gap-3">
                <img src={item.image} alt={item.title} className="w-12 h-12 object-cover rounded" />
                <div className="flex-1">
                  <h4 className="font-medium">{item.title}</h4>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge className={sizeInfo.color} variant="secondary">
                      {sizeInfo.label}
                    </Badge>
                    {item.size === 'large' && (
                      <div className="flex items-center gap-1">
                        <Truck className="w-3 h-3 text-red-600" />
                        <span className="text-xs text-red-600">Truck Required</span>
                      </div>
                    )}
                  </div>
                </div>
                <span className="font-medium">${item.price.toFixed(2)}</span>
              </div>
            );
          })}
        </div>
        
        <Separator />
        
        <div className="space-y-2">
          {growRouteDiscount > 0 && (
            <>
              <div className="flex justify-between text-gray-600">
                <span>Original Subtotal</span>
                <span>${originalSubtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-green-600">
                <span>Grow Route Discount ({growRouteDiscount}%)</span>
                <span>-${discountAmount.toFixed(2)}</span>
              </div>
            </>
          )}
          
          <div className="flex justify-between">
            <span>Subtotal</span>
            <span>${subtotal.toFixed(2)}</span>
          </div>
          
          <div className="flex justify-between">
            <div className="flex items-center gap-2">
              <span>Delivery Fee</span>
              {hasLargeItems && (
                <div className="flex items-center gap-1">
                  <Truck className="w-3 h-3 text-red-600" />
                  <span className="text-xs text-red-600">Large Item</span>
                </div>
              )}
              {isPartnerShop && (
                <Badge className="bg-purple-100 text-purple-700 text-xs">
                  20% off
                </Badge>
              )}
            </div>
            <span>${deliveryFee.toFixed(2)}</span>
          </div>
          
          {buyerDeliveryShare && (
            <div className="ml-4 text-sm text-gray-600">
              <div className="flex justify-between">
                <span>• Your share:</span>
                <span>${buyerDeliveryShare.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className={isPartnerShop ? 'text-purple-600' : ''}>
                  • Seller share:
                  {isPartnerShop && ' (20% off)'}
                </span>
                <span className={isPartnerShop ? 'text-purple-600' : ''}>
                  ${(sellerDeliveryShare || 0).toFixed(2)}
                </span>
              </div>
            </div>
          )}
          
          {customShippingFee > 0 && (
            <div className="flex justify-between">
              <div className="flex items-center gap-2">
                <span>Custom S&H Fee</span>
                <Badge className="bg-purple-100 text-purple-700 text-xs">
                  Partner Set
                </Badge>
              </div>
              <span>${customShippingFee.toFixed(2)}</span>
            </div>
          )}
          
          <div className="flex justify-between">
            <div className="flex items-center gap-2">
              <span>Sustainability Fee</span>
              {isPartnerShop && (
                <Badge className="bg-green-100 text-green-700 text-xs">
                  Waived
                </Badge>
              )}
            </div>
            <span className={isPartnerShop ? 'text-green-600' : ''}>
              ${actualSustainabilityFee.toFixed(2)}
              {isPartnerShop && ' (Partner Benefit)'}
            </span>
          </div>
          
          {tip > 0 && (
            <div className="flex justify-between">
              <div className="flex items-center gap-1">
                <DollarSign className="w-3 h-3" />
                <span>Driver Tip</span>
              </div>
              <span>${tip.toFixed(2)}</span>
            </div>
          )}
          
          <div className="flex justify-between">
            <span>Tax</span>
            <span>${tax.toFixed(2)}</span>
          </div>
          
          <Separator />
          
          <div className="flex justify-between text-lg font-bold">
            <span>Total</span>
            <span>${total.toFixed(2)}</span>
          </div>
          
          {growRouteDiscount > 0 && (
            <div className="text-center text-sm text-green-600 font-medium">
              🎉 You saved ${(discountAmount + (totalDeliveryFee - deliveryFee)).toFixed(2)} with Grow Routes!
            </div>
          )}
        </div>
        
        {isPartnerShop && (
          <div className="bg-purple-50 p-3 rounded-lg text-sm border border-purple-200">
            <div className="font-medium text-purple-900 mb-1 flex items-center gap-1">
              <Crown className="w-4 h-4" />
              Partner Shop Benefits Applied
            </div>
            <div className="text-purple-800 space-y-1">
              <div>✓ 20% discount on delivery fees</div>
              <div>✓ No sustainability fee charged</div>
              <div>✓ Custom shipping & handling control</div>
              <div>✓ Priority marketplace placement</div>
            </div>
          </div>
        )}
        
        {growRouteDiscount > 0 ? (
          <div className="bg-green-50 p-3 rounded-lg text-sm">
            <div className="font-medium text-green-900 mb-1 flex items-center gap-1">
              <Users className="w-4 h-4" />
              Grow Route Active
            </div>
            <div className="text-green-800 space-y-1">
              <div>• {growRouteDiscount}% discount on items</div>
              <div>• Split delivery fee with seller</div>
              <div>• Shared delivery with nearby buyers</div>
              <div>• Estimated delivery: 2-4 hours</div>
            </div>
          </div>
        ) : (
          <div className="bg-blue-50 p-3 rounded-lg text-sm">
            <div className="font-medium text-blue-900 mb-1">Delivery Info</div>
            <div className="text-blue-800 space-y-1">
              <div>• 20 mile radius coverage</div>
              <div>• Delivery fee split with seller</div>
              <div>• Large items require truck/trailer capability</div>
              {!isPartnerShop && <div>• $4 sustainability fee supports platform</div>}
            </div>
          </div>
        )}
        
        <div className="bg-green-50 p-3 rounded-lg text-sm">
          <div className="font-medium text-green-900 mb-1">💡 Tip Your Driver</div>
          <div className="text-green-800">
            Show appreciation for great service! Tips go 100% to your driver instantly.
          </div>
        </div>
      </CardContent>
    </Card>
  );
};