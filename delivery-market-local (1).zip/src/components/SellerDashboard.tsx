import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Package, TrendingUp, DollarSign, Edit, Trash2, Zap, Crown, BarChart3 } from 'lucide-react';
import ProAnalyticsDashboard from './ProAnalyticsDashboard';
import ProductBoostModal from './ProductBoostModal';

interface InventoryItem {
  id: string;
  name: string;
  price: number;
  stock: number;
  category: string;
  status: 'active' | 'inactive';
}

export default function SellerDashboard() {
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [isProSubscriber] = useState(true); // Mock Pro status
  const [newItem, setNewItem] = useState({
    name: '',
    price: 0,
    stock: 0,
    category: ''
  });

  useEffect(() => {
    const fetchInventory = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockInventory: InventoryItem[] = [
        { id: '1', name: 'Vintage Guitar', price: 299.99, stock: 5, category: 'Music', status: 'active' },
        { id: '2', name: 'Art Print Set', price: 49.99, stock: 25, category: 'Art', status: 'active' },
        { id: '3', name: 'Handmade Jewelry', price: 89.99, stock: 12, category: 'Accessories', status: 'active' }
      ];
      
      setInventory(mockInventory);
      setLoading(false);
    };

    fetchInventory();
  }, []);

  const addItem = () => {
    if (!newItem.name || newItem.price <= 0) return;
    
    const item: InventoryItem = {
      id: Date.now().toString(),
      ...newItem,
      status: 'active'
    };
    
    setInventory([...inventory, item]);
    setNewItem({ name: '', price: 0, stock: 0, category: '' });
  };

  const updateItem = (item: InventoryItem) => {
    setInventory(inventory.map(i => i.id === item.id ? item : i));
    setEditingItem(null);
  };

  const deleteItem = (id: string) => {
    setInventory(inventory.filter(i => i.id !== id));
  };

  const totalValue = inventory.reduce((sum, item) => sum + (item.price * item.stock), 0);
  const lowStockItems = inventory.filter(item => item.stock < 10).length;

  return (
    <div className="space-y-6 bg-gradient-to-br from-blue-50 to-lime-50 min-h-screen p-4">
      {/* Pro Status Banner */}
      {isProSubscriber && (
        <Card className="bg-gradient-to-r from-blue-600 to-lime-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Crown className="h-5 w-5" />
              <span className="font-bold">MarketPace Pro Active</span>
              <Badge className="bg-white/20 text-white">VIP</Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-white/80 backdrop-blur border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Items</p>
                <p className="text-2xl font-bold text-gray-800">{inventory.length}</p>
              </div>
              <Package className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/80 backdrop-blur border-lime-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Inventory Value</p>
                <p className="text-2xl font-bold text-gray-800">${totalValue.toFixed(2)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-lime-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/80 backdrop-blur border-orange-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Low Stock</p>
                <p className="text-2xl font-bold text-orange-600">{lowStockItems}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="inventory" className="space-y-4">
        <TabsList className="bg-white/80 backdrop-blur">
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
          <TabsTrigger value="add-item">Add Item</TabsTrigger>
          {isProSubscriber && (
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
          )}
        </TabsList>
        
        <TabsContent value="inventory" className="space-y-4">
          <Card className="bg-white/80 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-gray-800">Inventory Management</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="animate-pulse">
                      <div className="h-16 bg-gray-200 rounded"></div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {inventory.map(item => (
                    <div key={item.id} className="flex items-center justify-between p-4 border border-blue-200 rounded-lg bg-white/60">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium text-gray-800">{item.name}</h4>
                          <Badge variant={item.status === 'active' ? 'default' : 'secondary'} className="bg-blue-100 text-blue-700">
                            {item.status}
                          </Badge>
                          {item.stock < 10 && (
                            <Badge variant="destructive">Low Stock</Badge>
                          )}
                        </div>
                        <div className="text-sm text-gray-600">
                          Price: ${item.price} | Stock: {item.stock} | Category: {item.category}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {isProSubscriber && (
                          <ProductBoostModal productName={item.name}>
                            <Button size="sm" className="bg-gradient-to-r from-lime-500 to-blue-500 hover:from-lime-600 hover:to-blue-600 text-white">
                              <Zap className="h-4 w-4" />
                            </Button>
                          </ProductBoostModal>
                        )}
                        <Button size="sm" variant="outline" onClick={() => setEditingItem(item)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => deleteItem(item.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="add-item">
          <Card className="bg-white/80 backdrop-blur">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-800">
                <Plus className="h-5 w-5" />
                Add New Item
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input placeholder="Product name" value={newItem.name} onChange={(e) => setNewItem({...newItem, name: e.target.value})} />
              <Input type="number" placeholder="Price" value={newItem.price || ''} onChange={(e) => setNewItem({...newItem, price: parseFloat(e.target.value) || 0})} />
              <Input type="number" placeholder="Stock quantity" value={newItem.stock || ''} onChange={(e) => setNewItem({...newItem, stock: parseInt(e.target.value) || 0})} />
              <Input placeholder="Category" value={newItem.category} onChange={(e) => setNewItem({...newItem, category: e.target.value})} />
              <Button onClick={addItem} className="w-full bg-gradient-to-r from-blue-600 to-lime-500 hover:from-blue-700 hover:to-lime-600 text-white">
                Add Item
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {isProSubscriber && (
          <TabsContent value="analytics">
            <ProAnalyticsDashboard />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}