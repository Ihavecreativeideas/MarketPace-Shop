import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Heart, DollarSign, Users, Target, Gift, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function DonatePage() {
  const navigate = useNavigate();
  const [selectedAmount, setSelectedAmount] = useState(25);
  const [customAmount, setCustomAmount] = useState('');
  const [donorInfo, setDonorInfo] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isProcessing, setIsProcessing] = useState(false);

  const presetAmounts = [10, 25, 50, 100, 250, 500];
  const currentGoal = 50000;
  const currentRaised = 12750;
  const progressPercentage = (currentRaised / currentGoal) * 100;

  const handleAmountSelect = (amount: number) => {
    setSelectedAmount(amount);
    setCustomAmount('');
  };

  const handleCustomAmountChange = (value: string) => {
    setCustomAmount(value);
    if (value) {
      setSelectedAmount(0);
    }
  };

  const getFinalAmount = () => {
    return customAmount ? parseFloat(customAmount) : selectedAmount;
  };

  const handleDonate = async () => {
    setIsProcessing(true);
    
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const donationData = {
        amount: getFinalAmount(),
        donor: donorInfo,
        timestamp: new Date().toISOString()
      };
      
      console.log('Processing donation:', donationData);
      alert(`Thank you for your $${getFinalAmount()} donation! Your support means everything to us.`);
      
      // Reset form
      setSelectedAmount(25);
      setCustomAmount('');
      setDonorInfo({ name: '', email: '', message: '' });
      
    } catch (error) {
      console.error('Donation error:', error);
      alert('There was an error processing your donation. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-red-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-600 to-red-600 text-white py-12">
        <div className="container mx-auto px-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20 mb-4"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div className="text-center">
            <Heart className="h-16 w-16 mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Support Our Launch</h1>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              Help us build the future of community commerce and create opportunities for everyone
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Progress Card */}
          <Card className="mb-8 border-2 border-pink-200">
            <CardHeader>
              <CardTitle className="text-center text-2xl text-pink-600">
                <Target className="h-6 w-6 inline mr-2" />
                Launch Goal Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-6">
                <div className="text-3xl font-bold text-pink-600 mb-2">
                  ${currentRaised.toLocaleString()} raised
                </div>
                <div className="text-lg text-muted-foreground">
                  of ${currentGoal.toLocaleString()} goal
                </div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-4 mb-4">
                <div 
                  className="bg-gradient-to-r from-pink-500 to-red-500 h-4 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(progressPercentage, 100)}%` }}
                />
              </div>
              <div className="text-center text-sm text-muted-foreground">
                {Math.round(progressPercentage)}% complete • {Math.ceil((currentGoal - currentRaised) / 100)} more supporters needed
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Donation Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Make a Donation
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Amount Selection */}
                <div>
                  <Label className="text-base font-medium mb-3 block">Select Amount</Label>
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    {presetAmounts.map((amount) => (
                      <Button
                        key={amount}
                        variant={selectedAmount === amount ? "default" : "outline"}
                        className={selectedAmount === amount ? "bg-pink-600 hover:bg-pink-700" : ""}
                        onClick={() => handleAmountSelect(amount)}
                      >
                        ${amount}
                      </Button>
                    ))}
                  </div>
                  <div>
                    <Label htmlFor="custom-amount">Custom Amount ($)</Label>
                    <Input
                      id="custom-amount"
                      type="number"
                      placeholder="Enter custom amount"
                      value={customAmount}
                      onChange={(e) => handleCustomAmountChange(e.target.value)}
                    />
                  </div>
                </div>

                {/* Donor Information */}
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="donor-name">Name (Optional)</Label>
                    <Input
                      id="donor-name"
                      placeholder="Your name"
                      value={donorInfo.name}
                      onChange={(e) => setDonorInfo({...donorInfo, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="donor-email">Email</Label>
                    <Input
                      id="donor-email"
                      type="email"
                      placeholder="your@email.com"
                      value={donorInfo.email}
                      onChange={(e) => setDonorInfo({...donorInfo, email: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="donor-message">Message (Optional)</Label>
                    <Textarea
                      id="donor-message"
                      placeholder="Share why you're supporting MarketPace..."
                      value={donorInfo.message}
                      onChange={(e) => setDonorInfo({...donorInfo, message: e.target.value})}
                    />
                  </div>
                </div>

                {/* Donation Summary */}
                <div className="bg-pink-50 p-4 rounded-lg">
                  <div className="flex justify-between items-center text-lg font-semibold">
                    <span>Total Donation:</span>
                    <span className="text-pink-600">${getFinalAmount()}</span>
                  </div>
                </div>

                <Button 
                  className="w-full bg-pink-600 hover:bg-pink-700 text-lg py-6"
                  onClick={handleDonate}
                  disabled={isProcessing || !donorInfo.email || getFinalAmount() <= 0}
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                      Processing...
                    </div>
                  ) : (
                    <>
                      <Heart className="h-5 w-5 mr-2" />
                      Donate ${getFinalAmount()}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Impact Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gift className="h-5 w-5" />
                  Your Impact
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-3">How Your Donation Helps:</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Badge className="bg-pink-100 text-pink-800">$10</Badge>
                      <p className="text-sm">Supports server costs for 100 users</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <Badge className="bg-pink-100 text-pink-800">$25</Badge>
                      <p className="text-sm">Funds driver onboarding for one town</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <Badge className="bg-pink-100 text-pink-800">$50</Badge>
                      <p className="text-sm">Covers marketing for community outreach</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <Badge className="bg-pink-100 text-pink-800">$100</Badge>
                      <p className="text-sm">Enables new feature development</p>
                    </div>
                    <div className="flex items-start gap-3">
                      <Badge className="bg-pink-100 text-pink-800">$250+</Badge>
                      <p className="text-sm">Accelerates expansion to new cities</p>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-pink-50 to-red-50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2 text-pink-800">Donor Benefits:</h3>
                  <ul className="text-sm space-y-1 text-pink-700">
                    <li>• Recognition in our launch credits</li>
                    <li>• Exclusive donor newsletter updates</li>
                    <li>• Early access to premium features</li>
                    <li>• Special donor badge on your profile</li>
                    <li>• Invitation to launch celebration events</li>
                  </ul>
                </div>

                <div className="text-center">
                  <Users className="h-12 w-12 text-pink-600 mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">
                    Join <strong>127 supporters</strong> who believe in building stronger communities
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}