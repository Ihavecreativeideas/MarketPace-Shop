import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { calculateTax } from '@/components/TaxCalculator';
import { Receipt, Info, Shield } from 'lucide-react';

interface CheckoutWithTaxProps {
  productSubtotal: number;
  deliveryFee: number;
  serviceFee: number;
  tipAmount: number;
  taxRate?: number;
  isPartnerShop?: boolean;
}

export const CheckoutWithTax: React.FC<CheckoutWithTaxProps> = ({
  productSubtotal,
  deliveryFee,
  serviceFee,
  tipAmount,
  taxRate = 0.0925,
  isPartnerShop = false
}) => {
  const taxCalculation = calculateTax(productSubtotal, deliveryFee, serviceFee, tipAmount, taxRate);

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Receipt className="w-5 h-5" />
          Order Total
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Product Subtotal - Not taxed by MarketPace */}
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span>Product Subtotal</span>
            <Badge variant="outline" className="text-xs">
              Vendor Tax Responsibility
            </Badge>
          </div>
          <span className="font-medium">${taxCalculation.productSubtotal.toFixed(2)}</span>
        </div>

        <Separator />

        {/* Taxable Fees Section */}
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
            <Shield className="w-4 h-4" />
            MarketPace Platform Fees (Taxable)
          </div>
          
          <div className="ml-6 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Delivery Fee</span>
              <span>${taxCalculation.deliveryFee.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between text-sm">
              <span>Service Fee</span>
              <span>${taxCalculation.serviceFee.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between text-sm border-t pt-2">
              <span className="font-medium">Taxable Amount</span>
              <span className="font-medium">${taxCalculation.taxableAmount.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between text-sm">
              <span>Sales Tax ({(taxRate * 100).toFixed(2)}%)</span>
              <span>${taxCalculation.taxCollected.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <Separator />

        {/* Tip - Not taxed */}
        {tipAmount > 0 && (
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <span>Driver Tip</span>
              <Badge variant="outline" className="text-xs bg-green-50">
                Tax-Free Gratuity
              </Badge>
            </div>
            <span className="font-medium">${tipAmount.toFixed(2)}</span>
          </div>
        )}

        <Separator className="border-2" />

        {/* Final Total */}
        <div className="flex justify-between items-center text-lg font-bold">
          <span>Total Amount</span>
          <span>${taxCalculation.checkoutTotal.toFixed(2)}</span>
        </div>

        {/* Tax Responsibility Info */}
        <div className="bg-blue-50 p-3 rounded-lg text-xs space-y-2">
          <div className="flex items-start gap-2">
            <Info className="w-4 h-4 text-blue-600 mt-0.5" />
            <div className="text-blue-800">
              <div className="font-medium mb-1">Tax Responsibilities:</div>
              <div className="space-y-1">
                <div>• Product prices: Vendor collects & remits tax</div>
                <div>• Platform fees: MarketPace collects & remits tax</div>
                <div>• Tips: Tax-free gratuities to drivers</div>
              </div>
            </div>
          </div>
        </div>

        {isPartnerShop && (
          <div className="bg-purple-50 p-3 rounded-lg text-xs">
            <div className="font-medium text-purple-900 mb-1">Partner Shop Benefits</div>
            <div className="text-purple-800">
              Reduced service fees and enhanced marketplace features
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};