import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, MapPin, Users, Calendar, DollarSign, Music } from 'lucide-react';
import { useState } from 'react';
import BookingModal from './BookingModal';

interface Artist {
  id: number;
  name: string;
  type: 'musician' | 'dj' | 'soundman' | 'band';
  hourlyRate: number;
  rating: number;
  image: string;
  location: string;
  description: string;
  genres: string[];
  availability: string;
  distance: number;
  isSubscriber: boolean;
  experience: string;
  equipment: string[];
}

interface ArtistBookingCardProps {
  artist: Artist;
  onBook: (artist: Artist) => void;
  onMessage: (artist: Artist) => void;
}

const ArtistBookingCard: React.FC<ArtistBookingCardProps> = ({ artist, onBook, onMessage }) => {
  const [showBookingModal, setShowBookingModal] = useState(false);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'dj': return '🎧';
      case 'soundman': return '🎚️';
      case 'band': return '🎵';
      default: return '🎤';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'dj': return 'bg-blue-500';
      case 'soundman': return 'bg-green-500';
      case 'band': return 'bg-purple-500';
      default: return 'bg-orange-500';
    }
  };

  return (
    <>
      <Card className="hover:shadow-lg transition-shadow">
        <CardHeader className="p-0 relative">
          <img 
            src={artist.image} 
            alt={artist.name} 
            className="w-full h-48 object-cover rounded-t-lg" 
          />
          <div className="absolute top-2 right-2 flex gap-2">
            <Badge className={getTypeColor(artist.type)}>
              {getTypeIcon(artist.type)} {artist.type.toUpperCase()}
            </Badge>
          </div>
          <div className="absolute top-2 left-2 flex gap-2">
            {artist.isSubscriber && (
              <Badge className="bg-blue-600">
                PRO
              </Badge>
            )}
            <Badge className="bg-orange-600">
              {artist.distance} mi
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="p-4">
          <div className="space-y-3">
            <div>
              <CardTitle className="text-lg">{artist.name}</CardTitle>
              <p className="text-sm text-gray-600">{artist.description}</p>
              <p className="text-xs text-gray-500 mt-1">{artist.experience}</p>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-green-600">
                ${artist.hourlyRate}
                <span className="text-sm text-gray-500 ml-1">/hour</span>
              </div>
              <div className="flex items-center gap-1 text-sm text-gray-500">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                <span>{artist.rating}</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="w-4 h-4" />
                <span>{artist.location}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Calendar className="w-4 h-4" />
                <span>{artist.availability}</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex flex-wrap gap-1">
                {artist.genres.slice(0, 3).map((genre, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {genre}
                  </Badge>
                ))}
                {artist.genres.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{artist.genres.length - 3} more
                  </Badge>
                )}
              </div>
              {artist.equipment.length > 0 && (
                <div className="text-xs text-gray-500">
                  Equipment: {artist.equipment.join(', ')}
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => onMessage(artist)}
                className="flex-1"
              >
                <Users className="w-4 h-4 mr-1" />
                Message
              </Button>
              <Button 
                size="sm" 
                onClick={() => setShowBookingModal(true)}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                <Calendar className="w-4 h-4 mr-1" />
                Book Now
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {showBookingModal && (
        <BookingModal
          artist={artist}
          onClose={() => setShowBookingModal(false)}
          onConfirm={(bookingData) => {
            onBook(artist);
            setShowBookingModal(false);
          }}
        />
      )}
    </>
  );
};

export default ArtistBookingCard;