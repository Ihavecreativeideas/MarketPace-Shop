import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Index } from './pages/Index';
import { CommunityPage } from './components/CommunityPage';
import { ServicesPage } from './pages/ServicesPage';
import { WebShopIntegrationPage } from './pages/WebShopIntegrationPage';
import { SettingsPage } from './pages/SettingsPage';
import { EditProfilePage } from './pages/EditProfilePage';
import { OrderHistoryPage } from './pages/OrderHistoryPage';
import { FavoritesPage } from './pages/FavoritesPage';
import { ProfilePage } from './pages/ProfilePage';
import { MarketplacePage } from './pages/MarketplacePage';
import { MusiciansPage } from './pages/MusiciansPage';
import { ShopsPage } from './pages/ShopsPage';
import { AdminPage } from './pages/AdminPage';
import LaunchCampaignPage from './components/LaunchCampaignPage';
import DonatePage from './components/DonatePage';
import SponsorshipPage from './components/SponsorshipPage';
import AdminAppSettings from './components/AdminAppSettings';
import AIAppEditorPage from './pages/AIAppEditorPage';
import AdminAnalytics from './components/AdminAnalytics';
import AdminDriversTable from './components/AdminDriversTable';
import AdminBusinessTable from './components/AdminBusinessTable';
import AdminRoutesTable from './components/AdminRoutesTable';
import AdminSalesTable from './components/AdminSalesTable';
import DriverPanel from './components/DriverPanel';
import BusinessPanel from './components/BusinessPanel';
import RoutesPanel from './components/RoutesPanel';
import SalesPanel from './components/SalesPanel';
import { NotFound } from './pages/NotFound';

const Router: React.FC = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/community" element={<CommunityPage />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/webshop" element={<WebShopIntegrationPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/edit-profile" element={<EditProfilePage />} />
        <Route path="/order-history" element={<OrderHistoryPage />} />
        <Route path="/favorites" element={<FavoritesPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/marketplace" element={<MarketplacePage />} />
        <Route path="/musicians" element={<MusiciansPage />} />
        <Route path="/shops" element={<ShopsPage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/admin/app-settings" element={<AdminAppSettings />} />
        <Route path="/admin/ai-app-editor" element={<AIAppEditorPage />} />
        <Route path="/admin/analytics" element={<AdminAnalytics />} />
        <Route path="/admin/drivers" element={<DriverPanel />} />
        <Route path="/admin/businesses" element={<BusinessPanel />} />
        <Route path="/admin/routes" element={<RoutesPanel />} />
        <Route path="/admin/sales" element={<SalesPanel />} />
        <Route path="/launch-campaign" element={<LaunchCampaignPage />} />
        <Route path="/donate" element={<DonatePage />} />
        <Route path="/sponsorship" element={<SponsorshipPage />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

export default Router;
export { Router };