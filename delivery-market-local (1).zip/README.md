# MarketPace - Secure Marketplace Platform

## 🔐 HIPAA-Compliant & Secure Platform

MarketPace is a secure, HIPAA-compliant marketplace platform that prioritizes user privacy and data protection. All personal information, payment data, and addresses are encrypted end-to-end.

## 🚀 Quick Start Guide

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn
- Git
- Supabase account (for backend)

### Setup Instructions

1. **Clone the Repository**
   ```bash
   git clone <your-repo-url>
   cd marketplace
   ```

2. **Install Dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   - Copy `.env.example` to `.env.local`
   - Add your Supabase credentials:
     ```
     VITE_SUPABASE_URL=your_supabase_url
     VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
     ```

4. **Start Development Server**
   ```bash
   npm run dev
   ```

5. **Access the Application**
   - Open http://localhost:5173 in your browser
   - You'll see the welcome screen with guest access option

### 🎯 Guest Access Feature

**New Feature**: Users can now browse the entire platform as guests without providing any personal information.

- **Guest Mode**: Click "Continue as Guest" on the welcome screen
- **Full Browse Access**: View all products, services, and content
- **No Personal Data Required**: No email, phone, or personal information needed
- **Secure Restrictions**: Cannot purchase, sell, or access payment features
- **Easy Upgrade**: Simple sign-up process when ready for full access

### 🔒 Security Features

- **HIPAA Compliant**: All personal health information is protected
- **End-to-End Encryption**: Payment and personal data encrypted
- **PCI DSS Certified**: Secure payment processing
- **256-bit SSL**: Industry-standard encryption
- **Privacy First**: No data collection in guest mode

### 📱 Development Workflow

#### Using GitHub Codespaces:
1. Open repository in GitHub
2. Click "Code" → "Codespaces" → "Create codespace"
3. Wait for environment setup
4. Run `npm install && npm run dev`
5. Access via forwarded port

#### Using StackBlitz:
1. Import GitHub repository to StackBlitz
2. Install dependencies automatically
3. Start dev server
4. Edit files in browser

#### Local Development:
1. Clone repository
2. Install Node.js and dependencies
3. Set up environment variables
4. Run development server
5. Make changes and see live updates

### 🛠️ Making Simple Edits

#### Key Files to Modify:
- `src/components/WelcomeScreen.tsx` - Welcome/login screen
- `src/components/SecureAuthProvider.tsx` - Authentication logic
- `src/components/Navigation.tsx` - Main navigation
- `src/pages/Index.tsx` - Home page content
- `src/components/Marketplace.tsx` - Marketplace features

#### Common Edits:
1. **Change Welcome Message**: Edit `WelcomeScreen.tsx`
2. **Update Navigation**: Modify `Navigation.tsx`
3. **Add Security Features**: Update `SecurePaymentWrapper.tsx`
4. **Customize Guest Experience**: Edit `GuestRestrictionModal.tsx`

### 🔧 Supabase Setup

1. **Create Supabase Project**
   - Go to https://supabase.com
   - Create new project
   - Note your URL and anon key

2. **Database Setup**
   - Tables are auto-created via migrations
   - RLS (Row Level Security) enabled
   - HIPAA-compliant configuration

3. **Authentication Setup**
   - Enable email/password auth
   - Configure social providers (optional)
   - Set up email templates

### 📊 Architecture Overview

```
src/
├── components/
│   ├── SecureAuthProvider.tsx    # HIPAA-compliant auth
│   ├── WelcomeScreen.tsx         # Guest access welcome
│   ├── GuestRestrictionModal.tsx # Guest limitations
│   ├── SecurePaymentWrapper.tsx  # Secure payments
│   └── Navigation.tsx            # Main navigation
├── pages/
│   ├── Index.tsx                 # Home page
│   ├── MarketplacePage.tsx       # Marketplace
│   └── ...
├── lib/
│   └── supabase.ts              # Database client
└── contexts/
    └── AppContext.tsx           # Global state
```

### 🚀 Deployment

#### Vercel (Recommended):
1. Connect GitHub repository
2. Add environment variables
3. Deploy automatically on push

#### Netlify:
1. Connect repository
2. Set build command: `npm run build`
3. Set publish directory: `dist`
4. Add environment variables

### 🔍 Troubleshooting

**Common Issues:**
- **Build Errors**: Check all imports are correct
- **Auth Issues**: Verify Supabase credentials
- **Guest Mode**: Ensure SecureAuthProvider is used
- **Payment Issues**: Check SecurePaymentWrapper implementation

**Getting Help:**
- Check browser console for errors
- Verify environment variables
- Ensure all dependencies are installed
- Check Supabase dashboard for backend issues

### 📝 Contributing

1. Fork the repository
2. Create feature branch
3. Make changes with security in mind
4. Test guest and authenticated modes
5. Submit pull request

### 🔐 Security Compliance

- **HIPAA**: Health information protection
- **PCI DSS**: Payment card industry standards
- **GDPR**: European privacy regulation
- **SOC 2**: Security and availability standards

---

**Need Help?** Check the troubleshooting section or create an issue in the repository.