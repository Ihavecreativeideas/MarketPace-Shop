# MarketPace Complete Setup Instructions

## 🎯 Goal: Get Your App Running in Under 5 Minutes

### ⚡ Fastest Method: GitHub Codespaces

**Step 1:** Open Your Repository
- Go to your GitHub repository page
- Look for the green **"Code"** button (top right)

**Step 2:** Launch Codespace
- Click **"Code"** → **"Codespaces"** tab
- Click **"Create codespace on main"**
- Wait 2-3 minutes (coffee break time ☕)

**Step 3:** Start the App
- Terminal opens automatically
- Copy and paste this command:
  ```bash
  npm install && npm run dev
  ```
- Press Enter and wait 30 seconds

**Step 4:** Access Your App
- Look for notification: "Your application running on port 5173 is available"
- Click the **"Open in Browser"** button
- 🎉 **Success!** Your app is live

### 🌐 Alternative: StackBlitz (No GitHub Account Needed)

1. Go to [stackblitz.com](https://stackblitz.com)
2. Click **"Import from GitHub"**
3. Paste your repository URL
4. Wait 30 seconds for automatic setup
5. 🎉 App runs immediately in browser

### 💻 Local Development (Advanced Users)

**Prerequisites Check:**
```bash
# Check if Node.js is installed (need v18+)
node --version

# If not installed, download from nodejs.org
```

**Setup Steps:**
```bash
# 1. Clone repository
git clone <your-repo-url>
cd marketpace

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev

# 4. Open browser to:
# http://localhost:5173
```

## 🔍 What You Should See

### Landing Page Checklist:
- [ ] **"Welcome to MarketPace"** header
- [ ] Purple **"Continue as Guest"** button
- [ ] Security badges (HIPAA, SSL, PCI DSS)
- [ ] Navigation menu (Marketplace, Musicians, etc.)

### Guest Mode Features:
- ✅ **Browse marketplace** - See all products
- ✅ **View musician profiles** - Check availability
- ✅ **Explore services** - Delivery, pharmacy, etc.
- ✅ **Search and filter** - Find specific items
- ❌ **Purchase items** - Shows "Sign up to purchase" modal
- ❌ **Sell products** - Shows "Create account to sell" modal

## 🛠️ Quick Customization Guide

### Change Welcome Message:
**File:** `src/components/WelcomeScreen.tsx`
**Line 41:** Change `"Welcome to MarketPace"` to your text

### Modify Guest Button:
**File:** `src/components/WelcomeScreen.tsx`
**Line 67:** Change `"Continue as Guest"` to your preferred text

### Update App Name:
**File:** `src/components/Navigation.tsx`
**Line 15:** Change `"MarketPace"` to your app name

### Add Your Logo:
**File:** `public/placeholder.svg`
Replace with your logo file (keep same name)

## 🔧 Backend Setup (Optional)

**When do you need this?**
- User accounts and login
- Saving user data
- Processing payments
- Order history

### Supabase Setup (Free Tier Available):

**Step 1:** Create Account
- Go to [supabase.com](https://supabase.com)
- Sign up with GitHub (recommended)

**Step 2:** Create Project
- Click **"New Project"**
- Choose organization
- Project name: `marketpace-app`
- Database password: (save this!)
- Region: Choose closest to your users
- Click **"Create new project"**

**Step 3:** Get Credentials
- Wait for project setup (2-3 minutes)
- Go to **Settings** → **API**
- Copy these values:
  - **Project URL**
  - **anon public key**

**Step 4:** Configure App
```bash
# Create environment file
cp .env.example .env.local

# Edit .env.local with your values:
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here

# Restart your app
npm run dev
```

## 🚨 Common Issues & Solutions

### Issue: "npm command not found"
**Solution:** Install Node.js from [nodejs.org](https://nodejs.org)

### Issue: "Port 5173 already in use"
**Solution:** 
```bash
# Kill existing process
pkill -f vite
# Or use different port
npm run dev -- --port 3000
```

### Issue: "Module not found" errors
**Solution:**
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Issue: Guest button not working
**Solution:** Check browser console (F12) for errors

### Issue: Blank white screen
**Solution:** 
1. Check browser console for errors
2. Verify all files downloaded correctly
3. Try hard refresh (Ctrl+Shift+R)

## 📱 Mobile Testing

### Test on Your Phone:
1. Get your computer's IP address:
   ```bash
   # On Mac/Linux
   ifconfig | grep inet
   
   # On Windows
   ipconfig
   ```
2. Start app with network access:
   ```bash
   npm run dev -- --host
   ```
3. Open phone browser to: `http://YOUR-IP:5173`

## 🚀 Going Live (Production)

### Build for Production:
```bash
# Create production build
npm run build

# Test production build locally
npm run preview
```

### Deploy Options:

**Vercel (Recommended):**
1. Connect GitHub account to Vercel
2. Import your repository
3. Auto-deploys on every push

**Netlify:**
1. Drag & drop `dist` folder to netlify.com
2. Or connect GitHub for auto-deploy

**GitHub Pages:**
1. Repository Settings → Pages
2. Source: GitHub Actions
3. Use provided workflow file

## ✅ Final Checklist

- [ ] App loads without errors
- [ ] Guest mode works (can browse, can't purchase)
- [ ] Mobile responsive
- [ ] All navigation links work
- [ ] Security badges display
- [ ] No console errors (F12)
- [ ] Environment variables set (if using backend)

## 🆘 Need Help?

### Debug Steps:
1. **Check browser console** (F12 → Console tab)
2. **Verify all files exist** in your project folder
3. **Check network tab** for failed requests
4. **Try incognito mode** to rule out browser cache

### Common Error Messages:
- `"Cannot resolve module"` → Run `npm install`
- `"Port in use"` → Use different port or kill process
- `"Permission denied"` → Check file permissions
- `"Network error"` → Check internet connection

---

**🎉 Congratulations!** Your MarketPace app is now running with secure guest access. Users can explore all features without providing personal information, and the app prompts for signup only when needed for purchases or selling.